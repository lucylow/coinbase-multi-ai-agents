import { describe, expect, it } from "vitest";
import { GET } from "../app/api/coinbase/portfolio/route";
import { POST as runXray } from "../app/api/coinbase/portfolio/xray/route";

describe("read-only Coinbase portfolio route", () => {
  it("lists the demo context and marks the response non-cacheable", async () => {
    const response = await GET(new Request("http://localhost/api/coinbase/portfolio"));
    const payload = await response.json();
    expect(response.status).toBe(200);
    expect(response.headers.get("cache-control")).toContain("no-store");
    expect(payload.data.readOnly).toBe(true);
    expect(payload.data.portfolios.some((portfolio: { portfolioId: string; mode: string }) => portfolio.portfolioId === "demo-portfolio-01" && portfolio.mode === "demo")).toBe(true);
    expect(payload.data.unsupportedActions).toContain("transfer-funds");
  });

  it("returns a synthetic snapshot only for the explicit demo context", async () => {
    const response = await GET(new Request("http://localhost/api/coinbase/portfolio?providerId=demo&portfolioId=demo-portfolio-01"));
    const payload = await response.json();
    expect(response.status).toBe(200);
    expect(payload.data.snapshot.provider).toBe("demo");
    expect(payload.data.snapshot.portfolioId).toBe("demo-portfolio-01");
    expect(payload.data.snapshot.missingData.join(" ")).toContain("synthetic fixtures");
    expect(Array.isArray(payload.data.history)).toBe(true);
    expect(payload.data.metrics.totalPortfolioValue).toBe(payload.data.snapshot.totalValueFiat);
    expect(payload.data.metrics.sharpeRatio).toBeNull();
    expect(payload.data.metrics.sharpeUnavailableReason).toContain("explicit annual risk-free-rate assumption");
  });

  it("rejects partially specified portfolio contexts", async () => {
    const response = await GET(new Request("http://localhost/api/coinbase/portfolio?providerId=default"));
    expect(response.status).toBe(400);
  });

  it("validates X-ray context before performing any reads", async () => {
    const missing = await runXray(new Request("http://localhost/api/coinbase/portfolio/xray", { method: "POST", body: JSON.stringify({ providerId: "demo" }) }));
    expect(missing.status).toBe(400);
    expect(missing.headers.get("cache-control")).toContain("no-store");
    const malformed = await runXray(new Request("http://localhost/api/coinbase/portfolio/xray", { method: "POST", body: "not-json" }));
    expect(malformed.status).toBe(400);
  });
});
