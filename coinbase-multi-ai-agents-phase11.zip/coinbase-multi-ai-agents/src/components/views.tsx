"use client";

import React, { useEffect, useState } from "react";
import {
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileSearch,
  Gauge,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  WalletCards,
} from "lucide-react";
import type {
  AgentTask,
  AuditEvent,
  MarketProduct,
  PortfolioBalance,
  TradeProposal,
} from "@/models/domain";
import type { AdvancedTradeWsStatus } from "@/integrations/coinbase/market-data-types";
import type { CandleGranularity } from "@/integrations/coinbase/advancedTradeProvider";
import type { AdvancedPortfolioMetrics } from "@/services/portfolio/advanced-metrics";
import type { AuthorizedPortfolio, PortfolioSnapshot, PortfolioSnapshotComparison, PortfolioWorkspaceMapping } from "@/services/portfolio/portfolio-workspace-manager";
import { alignPortfolioSnapshots, compareCurrentToTargetAllocation, comparePortfolioAllocations } from "@/services/portfolio/portfolio-comparison";
import type { PortfolioXrayResult } from "@/services/portfolio/portfolio-xray";
import {
  portfolioMetrics,
  formatMoney,
  historicalVolatility,
  rsi,
  atr,
  maxDrawdown,
  movingAverage,
  concentration,
} from "@/services/analytics";
import {
  applyMarketScenario,
  SCENARIOS,
  type MarketScenario,
} from "@/services/scenarios";
import { AllocationChart, MarketVolumeChart, PriceChart } from "./charts";
import {
  calculateMicrostructure,
  createDemoOrderBook,
  type MicrostructureBook,
} from "@/services/market-microstructure";

export type ViewName =
  | "Overview"
  | "Coinbase Portfolio"
  | "Agent Command Center"
  | "Market Intelligence"
  | "Risk Intelligence"
  | "Trade Proposals"
  | "Execution Ledger"
  | "AgentKit Operations Center"
  | "Onchain Governance Center"
  | "Integration Health Center"
  | "Onchain Control Center"
  | "Technical Command Center";
export interface ViewProps {
  balances: PortfolioBalance[];
  markets: MarketProduct[];
  marketStreamStatus?: AdvancedTradeWsStatus;
  tasks: AgentTask[];
  proposals: TradeProposal[];
  audit: AuditEvent[];
  busy: boolean;
  onRunInvestigation: (objective?: string) => void;
  onCreateProposal: () => void;
  onProposalDecision: (
    id: string,
    decision: "approve" | "reject" | "analyze",
  ) => void;
}

const presets = [
  "Analyze portfolio concentration and major exposure risks.",
  "Compare BTC and ETH volatility in the synthetic sample.",
  "Analyze the effect of a simulated 10% BTC decline.",
];

function SectionTitle({
  eyebrow,
  title,
  text,
  action,
}: {
  eyebrow: string;
  title: string;
  text: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="section-title">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{text}</p>
      </div>
      {action}
    </div>
  );
}

function Metric({
  label,
  value,
  change,
  icon: Icon,
  tone = "blue",
}: {
  label: string;
  value: string;
  change?: string;
  icon: React.ElementType;
  tone?: string;
}) {
  return (
    <div className="metric-card">
      <div className={`metric-icon ${tone}`}>
        <Icon size={17} />
      </div>
      <div className="metric-label">{label}</div>
      <div className="metric-value mono">{value}</div>
      {change && <div className="metric-foot">{change}</div>}
    </div>
  );
}

function Tag({
  children,
  tone = "muted",
}: {
  children: React.ReactNode;
  tone?: string;
}) {
  return <span className={`tag ${tone}`}>{children}</span>;
}

function Panel({
  title,
  subtitle,
  action,
  children,
  className = "",
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`panel ${className}`}>
      <div className="panel-heading">
        <div>
          <h2>{title}</h2>
          {subtitle && <p>{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function MarketStrip({ markets }: { markets: MarketProduct[] }) {
  return (
    <div className="market-strip">
      {markets.slice(0, 4).map((item) => (
        <div className="market-chip" key={item.productId}>
          <div className="market-chip-top">
            <span>{item.productId}</span>
            <Tag>{item.source === "coinbase-advanced-trade" ? "LIVE" : "DEMO"}</Tag>
          </div>
          <strong className="mono">
            ${item.price.toLocaleString("en-US", { maximumFractionDigits: 2 })}
          </strong>
          <span className={item.change24h >= 0 ? "positive" : "negative"}>
            {item.change24h >= 0 ? "+" : ""}
            {item.change24h.toFixed(2)}%
          </span>
        </div>
      ))}
    </div>
  );
}

export function OverviewView(props: ViewProps) {
  const metrics = portfolioMetrics(props.balances);
  const selected =
    props.markets.find((item) => item.productId === "BTC-USD") ||
    props.markets[0];
  const recent = props.audit.slice(0, 4);
  const dailyMovePct = metrics.rows.reduce(
    (sum, row) => sum + row.allocation * row.change24h,
    0,
  );
  const roster = [
    {
      id: "portfolio-analyst",
      name: "Portfolio Analyst",
      role: "Allocation and PnL",
    },
    {
      id: "market-intelligence",
      name: "Market Intelligence",
      role: "Coinbase pair research",
    },
    {
      id: "quant-research",
      name: "Quant Research",
      role: "Indicators and scenarios",
    },
    { id: "risk-officer", name: "Risk Officer", role: "Adversarial challenge" },
    {
      id: "verification-audit",
      name: "Verification & Audit",
      role: "Independent review",
    },
  ];
  return (
    <>
      <SectionTitle
        eyebrow="COMMAND OVERVIEW · SYNTHETIC WORKSPACE"
        title="Portfolio intelligence"
        text="A transparent demo view of your Coinbase research environment."
        action={
          <button
            className="button primary"
            onClick={() => props.onRunInvestigation()}
            disabled={props.busy}
          >
            <Sparkles size={16} />
            {props.busy ? "Analysis running…" : "Run multi-agent analysis"}
          </button>
        }
      />
      <div className="banner demo-banner">
        <span className="banner-dot" />
        <div>
          <strong>DEMO MODE</strong>
          <span>
            {" "}
            All portfolio and market figures below are synthetic fixtures — not
            Coinbase account balances or live prices.
          </span>
        </div>
      </div>
      <div className="metric-grid four">
        <Metric
          label="Demo portfolio value"
          value={formatMoney(metrics.totalCents, { compact: true })}
          change="Coinbase Demo Portfolio 01"
          icon={WalletCards}
        />
        <Metric
          label="Unrealized PnL"
          value={formatMoney(metrics.totalPnlCents)}
          change={`Daily simulated move ${dailyMovePct > 0 ? "+" : ""}${dailyMovePct.toFixed(2)}% · synthetic`}
          icon={TrendingUp}
          tone="green"
        />
        <Metric
          label="Available stablecoin"
          value={formatMoney(
            metrics.rows.find((row) => row.asset === "USDC")?.valueCents ?? 0,
          )}
          change="USDC · synthetic balance"
          icon={Gauge}
          tone="cyan"
        />
        <Metric
          label="Largest exposure"
          value={`${(Math.max(...metrics.rows.map((row) => row.allocation)) * 100).toFixed(0)}%`}
          change="BTC concentration · review"
          icon={AlertTriangle}
          tone="amber"
        />
      </div>
      <div className="content-grid two-one">
        <Panel
          title="Market pulse"
          subtitle="36-hour synthetic BTC-USD sample"
          action={<Tag>DEMO SNAPSHOT</Tag>}
        >
          {selected && (
            <>
              <PriceChart market={selected} />
              <div className="chart-footer">
                <span>
                  Sample only · fixture timestamp 05 Nov 2026 20:00 UTC
                </span>
                <span className="market-price">
                  ${selected.price.toLocaleString()}{" "}
                  <i
                    className={
                      selected.change24h >= 0 ? "positive" : "negative"
                    }
                  >
                    {selected.change24h > 0 ? "+" : ""}
                    {selected.change24h.toFixed(2)}%
                  </i>
                </span>
              </div>
            </>
          )}
        </Panel>
        <Panel title="Allocation" subtitle="Weight by synthetic market value">
          <div className="allocation-wrap">
            <AllocationChart items={props.balances} />
            <div className="allocation-legend">
              {metrics.rows.map((row, index) => (
                <div key={row.asset} className="legend-row">
                  <span className={`legend-dot color-${index}`} />
                  <span>{row.asset}</span>
                  <b>{(row.allocation * 100).toFixed(1)}%</b>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>
      <div className="content-grid two-one">
        <Panel
          title="Market watch"
          subtitle="Coinbase pair naming · fixtures only"
        >
          <MarketStrip markets={props.markets} />
        </Panel>
        <Panel
          title="Agent activity"
          subtitle="Persisted demo workspace"
          action={<Tag tone="green">{props.tasks.length} RUNS</Tag>}
        >
          {recent.length ? (
            <div className="activity-list">
              {recent.map((item) => (
                <div className="activity-row" key={item.id}>
                  <span className="activity-dot" />
                  <div>
                    <b>{item.action}</b>
                    <span>{item.outcome}</span>
                  </div>
                  <time>
                    {new Date(item.timestamp).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </time>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-note">
              Start an investigation to create the first auditable event.
            </div>
          )}
        </Panel>
      </div>
      <Panel
        title="Specialist agent status"
        subtitle="Five independent read-only research roles · deterministic demo execution"
      >
        <div className="agent-status-grid">
          {roster.map((agent) => {
            const completed = props.tasks.filter(
              (task) =>
                task.status === "completed" &&
                task.findings.some((item) => item.agentId === agent.id),
            );
            const latestTask = completed[0];
            const finding = latestTask?.findings.find(
              (item) => item.agentId === agent.id,
            );
            const running = props.tasks.find(
              (task) => task.status === "running",
            );
            return (
              <div className="agent-status-card" key={agent.id}>
                <div>
                  <b>{agent.name}</b>
                  <small>{agent.role}</small>
                </div>
                <span
                  className={`agent-state ${running ? "running" : latestTask ? "completed" : "idle"}`}
                >
                  {running ? "RUNNING" : latestTask ? "DONE" : "READY"}
                </span>
                <small className="agent-snapshot">
                  {completed.length} tasks ·{" "}
                  {finding
                    ? `${Math.round(finding.confidence * 100)}% confidence`
                    : "no completed run"}
                </small>
                <p>
                  {running
                    ? `Current task: ${running.objective}`
                    : finding?.summary || "Waiting for an investigation task."}
                </p>
                <small className="agent-last">
                  {latestTask?.completedAt
                    ? `Last active ${new Date(latestTask.completedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
                    : "Last active —"}
                </small>
              </div>
            );
          })}
        </div>
      </Panel>
    </>
  );
}

type ComparisonApiEnvelope = {
  ok: boolean;
  data?: { snapshot?: PortfolioSnapshot; history?: PortfolioSnapshot[] };
  error?: { message?: string };
};

function portfolioContextKey(item: Pick<AuthorizedPortfolio, "providerId" | "portfolioId">) {
  return `${item.providerId}|${item.portfolioId}`;
}

function PortfolioComparisonView({ portfolios, selectedKey, currentSnapshot }: {
  portfolios: AuthorizedPortfolio[];
  selectedKey: string;
  currentSnapshot: PortfolioSnapshot | null;
}) {
  const [leftKey, setLeftKey] = useState(selectedKey);
  const [rightKey, setRightKey] = useState("");
  const [leftHistory, setLeftHistory] = useState<PortfolioSnapshot[]>([]);
  const [rightHistory, setRightHistory] = useState<PortfolioSnapshot[]>([]);
  const [leftSnapshotId, setLeftSnapshotId] = useState("");
  const [rightSnapshotId, setRightSnapshotId] = useState("");
  const [comparisonLoading, setComparisonLoading] = useState(false);
  const [comparisonError, setComparisonError] = useState("");
  const [targetText, setTargetText] = useState("");

  useEffect(() => {
    if (selectedKey) setLeftKey(selectedKey);
  }, [selectedKey]);
  useEffect(() => {
    if (!portfolios.length) return;
    if (!portfolios.some((item) => portfolioContextKey(item) === leftKey)) {
      setLeftKey(selectedKey || portfolioContextKey(portfolios[0]));
    }
    if (!portfolios.some((item) => portfolioContextKey(item) === rightKey) || rightKey === leftKey) {
      const other = portfolios.find((item) => portfolioContextKey(item) !== leftKey);
      setRightKey(other ? portfolioContextKey(other) : leftKey);
    }
  }, [portfolios, leftKey, rightKey, selectedKey]);
  useEffect(() => {
    if (!currentSnapshot) { setTargetText(""); return; }
    const weights = currentSnapshot.positions.filter((position) => position.allocation !== null).map((position) => [position.asset, position.allocation! * 100] as const);
    const sum = weights.reduce((total, [, value]) => total + value, 0);
    setTargetText(Math.abs(sum - 100) <= 0.01 ? JSON.stringify(Object.fromEntries(weights.map(([asset, value]) => [asset, Number(value.toFixed(4))])), null, 2) : "");
  }, [currentSnapshot?.snapshotId]);

  const loadComparison = async () => {
    const leftContext = portfolios.find((item) => portfolioContextKey(item) === leftKey);
    const rightContext = portfolios.find((item) => portfolioContextKey(item) === rightKey);
    if (!leftContext || !rightContext) { setComparisonError("Select two authorized portfolio contexts to compare."); return; }
    setComparisonLoading(true);
    setComparisonError("");
    try {
      const load = async (item: AuthorizedPortfolio) => {
        const query = new URLSearchParams({ providerId: item.providerId, portfolioId: item.portfolioId });
        const response = await fetch(`/api/coinbase/portfolio?${query.toString()}`, { cache: "no-store" });
        const result = await response.json() as ComparisonApiEnvelope;
        if (!response.ok || !result.ok || !result.data?.snapshot) throw new Error(result.error?.message || `Could not retrieve ${item.name}.`);
        const byId = new Map([...(result.data.history || []), result.data.snapshot].map((snapshot) => [snapshot.snapshotId, snapshot]));
        return [...byId.values()].sort((a, b) => Date.parse(a.asOf) - Date.parse(b.asOf));
      };
      let left: PortfolioSnapshot[];
      let right: PortfolioSnapshot[];
      if (leftKey === rightKey) {
        left = await load(leftContext);
        right = left;
      } else {
        [left, right] = await Promise.all([load(leftContext), load(rightContext)]);
      }
      setLeftHistory(left);
      setRightHistory(right);
      const aligned = alignPortfolioSnapshots(left, right);
      if (!aligned) {
        setLeftSnapshotId(""); setRightSnapshotId("");
        setComparisonError("No timestamps in the two contexts share a currency. No FX conversion is applied.");
        return;
      }
      setLeftSnapshotId(aligned.left.snapshotId);
      setRightSnapshotId(aligned.right.snapshotId);
    } catch (error) {
      setComparisonError(error instanceof Error ? error.message : "Portfolio comparison could not be loaded.");
      setLeftHistory([]); setRightHistory([]);
    } finally {
      setComparisonLoading(false);
    }
  };

  const leftSnapshot = leftHistory.find((item) => item.snapshotId === leftSnapshotId);
  const rightSnapshot = rightHistory.find((item) => item.snapshotId === rightSnapshotId);
  const comparison = leftSnapshot && rightSnapshot ? comparePortfolioAllocations(leftSnapshot, rightSnapshot) : null;
  const timeOffset = leftSnapshot && rightSnapshot ? Math.abs(Date.parse(leftSnapshot.asOf) - Date.parse(rightSnapshot.asOf)) : null;
  let parsedTarget: Record<string, number> | null = null;
  let targetError = "";
  if (targetText.trim()) {
    try {
      const value: unknown = JSON.parse(targetText);
      if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Enter a JSON object of asset symbols and target percentages.");
      const entries = Object.entries(value as Record<string, unknown>);
      if (!entries.length || entries.some(([asset, weight]) => !/^[A-Za-z0-9._-]{1,20}$/.test(asset) || typeof weight !== "number" || !Number.isFinite(weight) || weight < 0)) throw new Error("Target weights must be non-negative numbers keyed by asset symbol.");
      const sum = entries.reduce((total, [, weight]) => total + Number(weight), 0);
      if (Math.abs(sum - 100) > 0.01) throw new Error(`Target weights must sum to 100%; current total is ${sum.toFixed(2)}%.`);
      parsedTarget = Object.fromEntries(entries.map(([asset, weight]) => [asset.toUpperCase(), Number(weight)]));
    } catch (error) {
      targetError = error instanceof Error ? error.message : "Target allocation is invalid.";
    }
  }
  const targetRows = parsedTarget && currentSnapshot
    ? compareCurrentToTargetAllocation(currentSnapshot, parsedTarget).map((row) => ({ asset: row.asset, currentPct: row.currentAllocationPct, targetPct: row.targetAllocationPct, drift: row.differencePercentagePoints }))
    : [];
  const formatMoney = (value: number | null, currency: string) => value === null || !Number.isFinite(value)
    ? "Unavailable"
    : new Intl.NumberFormat("en-US", { style: "currency", currency, maximumFractionDigits: 2 }).format(value);

  return <div className="portfolio-comparison-grid">
    <Panel title="Portfolio and historical comparison" subtitle="Compare two authorized Coinbase contexts, demo versus connected data, or snapshots from a shared history. Closest matching-currency timestamps are selected first; there is no interpolation or FX conversion.">
      <div className="portfolio-comparison-controls">
        <label>Portfolio A<select value={leftKey} onChange={(event) => setLeftKey(event.target.value)}>{portfolios.map((item) => <option key={portfolioContextKey(item)} value={portfolioContextKey(item)}>{item.name} · {item.mode === "demo" ? "DEMO" : `LIVE · ${item.providerId}`}</option>)}</select></label>
        <label>Portfolio B<select value={rightKey} onChange={(event) => setRightKey(event.target.value)}>{portfolios.map((item) => <option key={portfolioContextKey(item)} value={portfolioContextKey(item)}>{item.name} · {item.mode === "demo" ? "DEMO" : `LIVE · ${item.providerId}`}</option>)}</select></label>
        <button className="button secondary" onClick={() => void loadComparison()} disabled={comparisonLoading || portfolios.length === 0}>{comparisonLoading ? "Loading snapshots…" : "Load aligned comparison"}</button>
      </div>
      {comparisonError && <div className="portfolio-warning"><AlertTriangle size={16} /> {comparisonError}</div>}
      {leftHistory.length > 0 && rightHistory.length > 0 && <div className="portfolio-comparison-controls snapshot-selectors">
        <label>Snapshot A<select value={leftSnapshotId} onChange={(event) => setLeftSnapshotId(event.target.value)}>{leftHistory.map((item) => <option key={item.snapshotId} value={item.snapshotId}>{new Date(item.asOf).toLocaleString()} · {formatMoney(item.totalValueFiat, item.currency)}</option>)}</select></label>
        <label>Snapshot B<select value={rightSnapshotId} onChange={(event) => setRightSnapshotId(event.target.value)}>{rightHistory.map((item) => <option key={item.snapshotId} value={item.snapshotId}>{new Date(item.asOf).toLocaleString()} · {formatMoney(item.totalValueFiat, item.currency)}</option>)}</select></label>
      </div>}
      {leftSnapshot && rightSnapshot && comparison && <>
        <div className={`portfolio-alignment-status ${timeOffset !== null && timeOffset > 5 * 60_000 ? "warning" : ""}`}>
          A: {new Date(leftSnapshot.asOf).toLocaleString()} · B: {new Date(rightSnapshot.asOf).toLocaleString()} · difference {timeOffset === null ? "—" : timeOffset < 60_000 ? `${Math.round(timeOffset / 1000)} sec` : `${(timeOffset / 60_000).toFixed(1)} min`}
          {timeOffset !== null && timeOffset > 5 * 60_000 && <span> Selected observations differ by over five minutes; review the timestamps before interpreting changes.</span>}
        </div>
        {comparison.warnings.map((warning) => <div className="portfolio-warning" key={warning}><AlertTriangle size={16} /> {warning}</div>)}
        <div className="table-wrap"><table><thead><tr><th>Asset</th><th>Allocation A · {leftSnapshot.portfolioName}</th><th>Allocation B · {rightSnapshot.portfolioName}</th><th>Difference A − B</th><th>Explanation</th></tr></thead><tbody>
          {comparison.differences.map((item) => <tr key={item.asset}><td><b>{item.asset}</b></td><td>{item.leftAllocationPct === null ? "Not observed" : `${item.leftAllocationPct.toFixed(2)}%`}</td><td>{item.rightAllocationPct === null ? "Not observed" : `${item.rightAllocationPct.toFixed(2)}%`}</td><td className={item.differencePercentagePoints === null ? "" : item.differencePercentagePoints >= 0 ? "positive" : "negative"}>{item.differencePercentagePoints === null ? "Unavailable" : `${item.differencePercentagePoints >= 0 ? "+" : ""}${item.differencePercentagePoints.toFixed(2)} pp`}</td><td>{item.interpretation}</td></tr>)}
          {!comparison.differences.length && <tr><td colSpan={5} className="empty-state">No comparable asset allocations were returned.</td></tr>}
        </tbody></table></div>
        <p className="portfolio-comparison-note">A positive difference means a higher reported asset weight in A, not superior performance. Differences can reflect holdings, price cutoffs, cash flows, fees, missing positions, and coverage. Missing assets are not treated as confirmed zero balances.</p>
      </>}
    </Panel>

    <Panel title="Current allocation versus target" subtitle="Enter a target allocation as JSON percentages. This comparison is informational only and does not create orders or transfer funds.">
      {currentSnapshot ? <>
        <label className="target-allocation-label">Target weights · percentages · must total 100%<textarea value={targetText} onChange={(event) => setTargetText(event.target.value)} placeholder={'{\n  "BTC": 50,\n  "ETH": 30,\n  "USDC": 20\n}'} spellCheck={false} /></label>
        {targetError && <div className="portfolio-warning"><AlertTriangle size={16} /> {targetError}</div>}
        {!targetText.trim() && <div className="portfolio-warning"><AlertTriangle size={16} /> Add a complete target allocation that sums to 100% to see drift.</div>}
        {targetRows.length > 0 && <div className="table-wrap"><table><thead><tr><th>Asset</th><th>Current</th><th>Target</th><th>Current − target</th></tr></thead><tbody>{targetRows.map((row) => <tr key={row.asset}><td>{row.asset}</td><td>{row.currentPct === null ? "Not observed" : `${row.currentPct.toFixed(2)}%`}</td><td>{row.targetPct.toFixed(2)}%</td><td className={row.drift === null ? "" : row.drift >= 0 ? "positive" : "negative"}>{row.drift === null ? "Unavailable" : `${row.drift >= 0 ? "+" : ""}${row.drift.toFixed(2)} pp`}</td></tr>)}</tbody></table></div>}
        <p className="portfolio-comparison-note">Current allocation uses the selected snapshot's reported spot positions. A zero current weight is shown only when the snapshot claims complete coverage; otherwise absent assets are marked not observed.</p>
      </> : <div className="empty-state">Load a portfolio snapshot to compare its allocation with a target.</div>}
    </Panel>
  </div>;
}

export function PortfolioView({ balances }: ViewProps) {
  type PortfolioApiEnvelope = {
    ok: boolean;
    data?: { portfolios?: AuthorizedPortfolio[]; sourceWarnings?: string[]; mappings?: PortfolioWorkspaceMapping[]; snapshot?: PortfolioSnapshot; comparison?: PortfolioSnapshotComparison; metrics?: AdvancedPortfolioMetrics };
    error?: { message?: string };
  };
  const fallback = portfolioMetrics(balances);
  const [portfolios, setPortfolios] = useState<AuthorizedPortfolio[]>([]);
  const [mappings, setMappings] = useState<PortfolioWorkspaceMapping[]>([]);
  const [sourceWarnings, setSourceWarnings] = useState<string[]>([]);
  const [selectedKey, setSelectedKey] = useState("");
  const [snapshot, setSnapshot] = useState<PortfolioSnapshot | null>(null);
  const [comparison, setComparison] = useState<PortfolioSnapshotComparison | null>(null);
  const [advancedMetrics, setAdvancedMetrics] = useState<AdvancedPortfolioMetrics | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState("");
  const [xrayLoading, setXrayLoading] = useState(false);
  const [xrayResult, setXrayResult] = useState<PortfolioXrayResult | null>(null);
  const [xrayError, setXrayError] = useState("");

  const contextKey = (item: Pick<AuthorizedPortfolio, "providerId" | "portfolioId">) => `${item.providerId}|${item.portfolioId}`;
  const selected = portfolios.find((item) => contextKey(item) === selectedKey);
  const loadPortfolio = async (item: AuthorizedPortfolio) => {
    setLoading(true);
    setLoadError("");
    setSnapshot(null);
    setComparison(null);
    setAdvancedMetrics(null);
    setXrayResult(null);
    setXrayError("");
    try {
      const query = new URLSearchParams({ providerId: item.providerId, portfolioId: item.portfolioId });
      const response = await fetch(`/api/coinbase/portfolio?${query.toString()}`, { cache: "no-store" });
      const result = (await response.json()) as PortfolioApiEnvelope;
      if (!response.ok || !result.ok || !result.data?.snapshot) throw new Error(result.error?.message || "Portfolio snapshot could not be loaded.");
      setSnapshot(result.data.snapshot);
      setComparison(result.data.comparison || null);
      setAdvancedMetrics(result.data.metrics || null);
    } catch (error) {
      setLoadError(error instanceof Error ? error.message : "Portfolio snapshot could not be loaded.");
    } finally {
      setLoading(false);
    }
  };

  const runXray = async () => {
    if (!selected) return;
    setXrayLoading(true);
    setXrayError("");
    setXrayResult(null);
    try {
      const response = await fetch("/api/coinbase/portfolio/xray", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ providerId: selected.providerId, portfolioId: selected.portfolioId }),
      });
      const result = await response.json() as { ok: boolean; data?: PortfolioXrayResult; error?: { message?: string } };
      if (!response.ok || !result.ok || !result.data) throw new Error(result.error?.message || "Portfolio X-ray could not be completed.");
      setXrayResult(result.data);
    } catch (error) {
      setXrayError(error instanceof Error ? error.message : "Portfolio X-ray could not be completed.");
    } finally {
      setXrayLoading(false);
    }
  };

  useEffect(() => {
    let mounted = true;
    void (async () => {
      try {
        const response = await fetch("/api/coinbase/portfolio", { cache: "no-store" });
        const result = (await response.json()) as PortfolioApiEnvelope;
        if (!response.ok || !result.ok || !result.data?.portfolios) throw new Error(result.error?.message || "Portfolio sources could not be listed.");
        if (!mounted) return;
        setPortfolios(result.data.portfolios);
        setMappings(result.data.mappings || []);
        setSourceWarnings(result.data.sourceWarnings || []);
        const initial = result.data.portfolios.find((item) => item.provider === "demo") || result.data.portfolios[0];
        if (initial) {
          setSelectedKey(contextKey(initial));
          await loadPortfolio(initial);
        }
      } catch (error) {
        if (!mounted) return;
        setSourceWarnings([error instanceof Error ? error.message : "Portfolio sources could not be listed."]);
      }
    })();
    return () => { mounted = false; };
  }, []);

  const useFixtureFallback = !snapshot && (!selected || selected.provider === "demo");
  const positions = snapshot
    ? snapshot.positions.map((position) => ({
        asset: position.asset,
        quantity: position.quantity,
        value: position.valueFiat,
        costBasis: position.costBasisFiat,
        allocation: position.allocation,
        pnl: position.valueFiat !== null && position.costBasisFiat !== null ? position.valueFiat - position.costBasisFiat : null,
      }))
    : useFixtureFallback
      ? fallback.rows.map((row) => ({ asset: row.asset, quantity: Number(row.quantity), value: row.valueCents / 100, costBasis: row.valueCents / 100 - row.pnlCents / 100, allocation: row.allocation, pnl: row.pnlCents / 100 }))
      : [];
  const totalValue = snapshot ? snapshot.totalValueFiat : useFixtureFallback ? fallback.totalCents / 100 : null;
  const coveredPnl = positions.filter((position) => position.pnl !== null).reduce((sum, position) => sum + (position.pnl || 0), 0);
  const isLive = snapshot?.provider !== undefined && snapshot.provider !== "demo";
  const isStale = Boolean(isLive && snapshot && Date.now() - Date.parse(snapshot.asOf) > 5 * 60_000);
  const money = (value: number | null | undefined, currency = snapshot?.currency || "USD") => value === null || value === undefined || !Number.isFinite(value)
    ? "Unavailable"
    : new Intl.NumberFormat("en-US", { style: "currency", currency, minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(value);
  const mapping = snapshot ? mappings.find((item) => item.providerId === snapshot.providerId && item.portfolioId === snapshot.portfolioId) : undefined;

  return (
    <>
      <SectionTitle
        eyebrow="COINBASE PORTFOLIO CONTEXTS"
        title="Portfolio intelligence"
        text="Switch between synthetic demo data and portfolios visible to configured, read-only Coinbase API keys. Viewing a portfolio does not automatically map it to a research agent."
        action={<div className="portfolio-header-actions"><button className="button secondary" onClick={() => selected && void loadPortfolio(selected)} disabled={loading || !selected}><RefreshCw size={15} /> Refresh</button><button className="button primary" onClick={() => void runXray()} disabled={loading || xrayLoading || !selected}>{xrayLoading ? "RUNNING PORTFOLIO X-RAY…" : "RUN COINBASE PORTFOLIO X-RAY"}</button></div>}
      />
      <div className="portfolio-controls">
        <label htmlFor="portfolio-context-select">Portfolio context</label>
        <select
          id="portfolio-context-select"
          className="portfolio-context-select"
          value={selectedKey}
          onChange={(event) => {
            const item = portfolios.find((candidate) => contextKey(candidate) === event.target.value);
            setSelectedKey(event.target.value);
            if (item) void loadPortfolio(item);
          }}
          disabled={!portfolios.length || loading}
        >
          {!portfolios.length && <option value="">Loading contexts…</option>}
          {portfolios.map((item) => (
            <option key={contextKey(item)} value={contextKey(item)}>
              {item.name} · {item.mode === "demo" ? "DEMO" : `LIVE READ-ONLY · ${item.providerId}`}
            </option>
          ))}
        </select>
        {loading && <span className="portfolio-loading">Retrieving snapshot…</span>}
      </div>

      <div className={`portfolio-source-banner ${isLive ? "live" : "demo"}`}>
        <span className="banner-dot" />
        <div>
          <strong>{snapshot?.portfolioName || (useFixtureFallback ? "Coinbase Demo Portfolio 01" : selected?.name || "Portfolio context")}</strong>
          <span>
            {isLive
              ? ` LIVE READ-ONLY · ${snapshot?.providerId} · retrieved ${snapshot ? new Date(snapshot.retrievedAt).toLocaleString() : "—"} · no order or transfer capability.`
              : ` SYNTHETIC DEMO FIXTURE${snapshot ? ` · fixture as-of ${new Date(snapshot.asOf).toLocaleString()}` : ""} · not Coinbase account data.`}
          </span>
        </div>
      </div>
      {isStale && <div className="portfolio-warning"><AlertTriangle size={16} /> Live snapshot is more than five minutes old; refresh before relying on it.</div>}
      {loadError && <div className="portfolio-warning"><AlertTriangle size={16} /> {loadError} {selected?.provider !== "demo" && "No demo values are shown for the selected live context."}</div>}
      {sourceWarnings.map((warning) => <div className="portfolio-warning" key={warning}><AlertTriangle size={16} /> {warning}</div>)}
      {mapping
        ? <div className="note-box"><CircleHelp size={16} /><span>This context is explicitly mapped to workspace <b>{mapping.workspaceId}</b> and strategy <b>{mapping.strategyId}</b>. Only that configured workspace uses it in Portfolio Analyst investigations.</span></div>
        : <div className="note-box"><CircleHelp size={16} /><span>This portfolio view is not an internal-agent assignment. The Portfolio Analyst uses demo data unless a server-side workspace-to-portfolio mapping is explicitly configured.</span></div>}

      <div className="content-grid two-one">
        <Panel title="Allocation map" subtitle={snapshot?.coverage === "partial" ? "Reported spot exposure; unsupported or missing fields are excluded and disclosed" : "Position-level value divided by the reported portfolio total"}>
          {positions.length ? <div className="portfolio-allocation-list">
            {positions.slice().sort((a, b) => (b.allocation || 0) - (a.allocation || 0)).map((position) => (
              <div className="portfolio-allocation-row" key={position.asset}>
                <div className="portfolio-allocation-label"><b>{position.asset}</b><span>{money(position.value)}</span><strong>{position.allocation === null ? "—" : `${(position.allocation * 100).toFixed(1)}%`}</strong></div>
                <div className="portfolio-allocation-track"><i style={{ width: `${Math.max(0, Math.min(100, (position.allocation || 0) * 100))}%` }} /></div>
              </div>
            ))}
          </div> : <div className="empty-state">{loading ? "Loading positions…" : "No position values available for this context."}</div>}
        </Panel>
        <Panel title="Portfolio summary" subtitle={isLive ? "Read-only Coinbase Advanced Trade portfolio breakdown" : "Synthetic fixture · no account sync"}>
          <div className="summary-list">
            <div><span>Total portfolio value</span><b className="mono">{money(totalValue)}</b></div>
            <div><span>Covered position PnL</span><b className={`mono ${coveredPnl >= 0 ? "positive" : "negative"}`}>{positions.some((position) => position.pnl !== null) ? `${coveredPnl >= 0 ? "+" : ""}${money(coveredPnl)}` : "Unavailable"}</b></div>
            <div><span>Valued positions</span><b>{positions.filter((position) => position.value !== null).length}</b></div>
            <div><span>Data coverage</span><Tag tone={snapshot?.coverage === "partial" ? "amber" : undefined}>{snapshot?.coverage?.toUpperCase() || (useFixtureFallback ? "DEMO FIXTURE" : "UNAVAILABLE")}</Tag></div>
            <div><span>Source</span><Tag>{isLive ? "COINBASE READ-ONLY" : "FIXTURE"}</Tag></div>
            <div><span>Last retrieved</span><b className="mono">{snapshot ? new Date(snapshot.retrievedAt).toLocaleString() : "—"}</b></div>
            {comparison?.portfolioValueChangeFiat !== null && comparison?.portfolioValueChangeFiat !== undefined && <div><span>Change vs prior snapshot</span><b className={`mono ${comparison.portfolioValueChangeFiat >= 0 ? "positive" : "negative"}`}>{comparison.portfolioValueChangeFiat >= 0 ? "+" : ""}{money(comparison.portfolioValueChangeFiat)}</b></div>}
          </div>
        </Panel>
      </div>

      {xrayError && <div className="portfolio-warning"><AlertTriangle size={16} /> {xrayError}</div>}
      {xrayResult && <Panel title="Coinbase Portfolio X-ray" subtitle={`${xrayResult.mode === "demo" ? "Synthetic balance fixture" : "Authorized read-only Coinbase balances"} · prices retrieved ${new Date(xrayResult.retrievedAt).toLocaleString()} · ${xrayResult.coverage.toUpperCase()} coverage`}>
        <div className="portfolio-xray-summary"><div><span>Covered spot subtotal</span><b>{money(xrayResult.coveredSpotTotalFiat, xrayResult.currency)}</b></div><div><span>Account-reported total at snapshot time</span><b>{money(xrayResult.reportedPortfolioTotalFiat, xrayResult.currency)}</b></div><div><span>Allocation denominator</span><b>{xrayResult.allocationBasis === "covered-spot-subtotal" ? "Covered spot subtotal" : "Unavailable"}</b></div></div>
        <div className="table-wrap"><table><thead><tr><th>Asset</th><th>Quantity</th><th>Public price</th><th>Valuation</th><th>Allocation of covered spot</th><th>Method</th></tr></thead><tbody>
          {xrayResult.positions.map((position) => <tr key={position.asset}><td><b>{position.asset}</b></td><td>{position.quantity === null ? "Unavailable" : position.quantity.toLocaleString("en-US", { maximumFractionDigits: 8 })}</td><td>{position.price === null ? "Unavailable" : `${money(position.price, xrayResult.currency)}${position.priceAsOf ? ` · ${new Date(position.priceAsOf).toLocaleTimeString()}` : ""}`}</td><td>{money(position.valueFiat, xrayResult.currency)}</td><td>{position.allocationPct === null ? "Unavailable" : `${position.allocationPct.toFixed(2)}%`}</td><td>{position.valuationMethod.replaceAll("-", " ")}</td></tr>)}
          {!xrayResult.positions.length && <tr><td colSpan={6} className="empty-state">No spot positions were available for this X-ray.</td></tr>}
        </tbody></table></div>
        {xrayResult.warnings.map((warning) => <div className="portfolio-warning" key={warning}><AlertTriangle size={16} /> {warning}</div>)}
        <p className="portfolio-comparison-note">Public market product prices are read-only and may not match the exchangeable execution price. Fiat quote-currency balances are valued at par. No orders, transfers, or portfolio changes are performed.</p>
      </Panel>}

      <PortfolioComparisonView portfolios={portfolios} selectedKey={selectedKey} currentSnapshot={snapshot} />

      {advancedMetrics && <Panel title="Advanced portfolio metrics" subtitle={`Snapshot-based analytics · ${advancedMetrics.historyPointCount} distinct positive-value observation(s) · as of ${new Date(advancedMetrics.asOf).toLocaleString()}`}>
        <div className="advanced-metric-grid">
          <div><span>Total portfolio value</span><b>{money(advancedMetrics.totalPortfolioValue)}</b></div>
          <div><span>Cash allocation</span><b>{advancedMetrics.cashAllocationPct === null ? "Unavailable" : `${advancedMetrics.cashAllocationPct.toFixed(2)}%`}</b></div>
          <div><span>Concentration (HHI)</span><b>{advancedMetrics.assetConcentrationHHI === null ? "Unavailable" : advancedMetrics.assetConcentrationHHI.toFixed(4)}</b><small>Score {advancedMetrics.concentrationScore === null ? "—" : advancedMetrics.concentrationScore.toFixed(0)} / 10,000</small></div>
          <div><span>Effective holdings</span><b>{advancedMetrics.effectiveHoldings === null ? "Unavailable" : advancedMetrics.effectiveHoldings.toFixed(2)}</b></div>
          <div><span>24-hour change</span><b className={advancedMetrics.dailyChange.amount === null ? "" : advancedMetrics.dailyChange.amount >= 0 ? "positive" : "negative"}>{advancedMetrics.dailyChange.amount === null ? "Unavailable" : `${advancedMetrics.dailyChange.amount >= 0 ? "+" : ""}${money(advancedMetrics.dailyChange.amount)} (${advancedMetrics.dailyChange.returnPct!.toFixed(2)}%)`}</b></div>
          <div><span>Simple return · last interval</span><b>{advancedMetrics.simpleReturnPct === null ? "Unavailable" : `${advancedMetrics.simpleReturnPct >= 0 ? "+" : ""}${advancedMetrics.simpleReturnPct.toFixed(2)}%`}</b></div>
          <div><span>Cumulative observed return</span><b>{advancedMetrics.cumulativeReturnPct === null ? "Unavailable" : `${advancedMetrics.cumulativeReturnPct >= 0 ? "+" : ""}${advancedMetrics.cumulativeReturnPct.toFixed(2)}%`}</b></div>
          <div><span>Volatility · per observation</span><b>{advancedMetrics.volatilityPct === null ? "Unavailable" : `${advancedMetrics.volatilityPct.toFixed(2)}%`}</b></div>
          <div><span>Annualized volatility</span><b>{advancedMetrics.annualizedVolatilityPct === null ? "Unavailable" : `${advancedMetrics.annualizedVolatilityPct.toFixed(2)}%`}</b></div>
          <div><span>Maximum drawdown</span><b>{advancedMetrics.maximumDrawdownPct === null ? "Unavailable" : `${advancedMetrics.maximumDrawdownPct.toFixed(2)}%`}</b></div>
          <div><span>Recovery from maximum drawdown</span><b>{advancedMetrics.recoveredFromMaximumDrawdown === null ? "Unavailable" : advancedMetrics.recoveredFromMaximumDrawdown ? `${advancedMetrics.recoveryTimeDays?.toFixed(1) ?? "—"} days` : "Not yet recovered"}</b></div>
          <div><span>Sharpe ratio</span><b>{advancedMetrics.sharpeRatio === null ? "Withheld" : advancedMetrics.sharpeRatio.toFixed(3)}</b><small>{advancedMetrics.sharpeUnavailableReason || `Annual risk-free rate ${(advancedMetrics.riskFreeRateAnnual! * 100).toFixed(2)}% · ${advancedMetrics.periodsPerYear} periods/year`}</small></div>
        </div>

        <div className="advanced-metric-columns">
          <div className="advanced-metric-box">
            <h3>Largest holdings</h3>
            {advancedMetrics.largestHoldings.length ? advancedMetrics.largestHoldings.map((holding) => <div className="advanced-metric-row" key={holding.asset}><span>{holding.asset}</span><b>{money(holding.value)}</b><strong>{holding.allocationPct === null ? "—" : `${holding.allocationPct.toFixed(2)}%`}</strong></div>) : <p>No valued holdings available.</p>}
          </div>
          <div className="advanced-metric-box">
            <h3>Portfolio drift</h3>
            <p>Allocation change versus the previous stored snapshot, not a target-weight recommendation.</p>
            {advancedMetrics.allocationDrift.length ? advancedMetrics.allocationDrift.map((item) => <div className="advanced-metric-row" key={item.asset}><span>{item.asset}</span><b>{item.previousAllocationPct === null ? "No prior weight" : `${item.previousAllocationPct.toFixed(2)}% → ${item.currentAllocationPct?.toFixed(2)}%`}</b><strong>{item.changePercentagePoints === null ? "—" : `${item.changePercentagePoints >= 0 ? "+" : ""}${item.changePercentagePoints.toFixed(2)} pp`}</strong></div>) : <p>Unavailable until a prior distinct snapshot is stored.</p>}
          </div>
        </div>

        <div className="advanced-metric-columns">
          <div className="advanced-metric-box matrix-scroll">
            <h3>Historical covariance</h3>
            <p>Sample covariance of aligned snapshot-to-snapshot simple returns (decimal return²); {advancedMetrics.historicalCovariance.observationCount} common observation(s).</p>
            {advancedMetrics.historicalCovariance.assets.length ? <table><thead><tr><th>Asset</th>{advancedMetrics.historicalCovariance.assets.map((asset) => <th key={asset}>{asset}</th>)}</tr></thead><tbody>{advancedMetrics.historicalCovariance.assets.map((asset, row) => <tr key={asset}><th>{asset}</th>{advancedMetrics.historicalCovariance.matrix[row].map((value, column) => <td key={`${asset}-${column}`}>{value === null ? "—" : value.toExponential(2)}</td>)}</tr>)}</tbody></table> : <p>At least three snapshots with common positions are required.</p>}
          </div>
          <div className="advanced-metric-box matrix-scroll">
            <h3>Asset correlation</h3>
            <p>Pearson correlation of aligned snapshot-to-snapshot simple returns; undefined for zero-variance series.</p>
            {advancedMetrics.assetCorrelation.assets.length ? <table><thead><tr><th>Asset</th>{advancedMetrics.assetCorrelation.assets.map((asset) => <th key={asset}>{asset}</th>)}</tr></thead><tbody>{advancedMetrics.assetCorrelation.assets.map((asset, row) => <tr key={asset}><th>{asset}</th>{advancedMetrics.assetCorrelation.matrix[row].map((value, column) => <td key={`${asset}-${column}`}>{value === null ? "—" : value.toFixed(2)}</td>)}</tr>)}</tbody></table> : <p>At least three snapshots with common positions are required.</p>}
          </div>
        </div>

        <div className="advanced-metric-box volatility-contribution">
          <h3>Volatility contribution</h3>
          <p>Estimated share of reported portfolio variance using latest allocation weights and the historical covariance matrix.</p>
          {advancedMetrics.volatilityContributionPct.length ? advancedMetrics.volatilityContributionPct.map((item) => <div className="advanced-metric-row" key={item.asset}><span>{item.asset}</span><div className="portfolio-allocation-track"><i style={{ width: `${Math.max(0, Math.min(100, item.contributionPct))}%` }} /></div><strong>{item.contributionPct.toFixed(2)}%</strong></div>) : <p>{advancedMetrics.volatilityContributionUnavailableReason || "Unavailable for the current data."}</p>}
        </div>

        {advancedMetrics.dailyChange.unavailableReason && <div className="portfolio-warning"><AlertTriangle size={16} /> Daily change unavailable: {advancedMetrics.dailyChange.unavailableReason}</div>}
        {advancedMetrics.sharpeUnavailableReason && <div className="portfolio-warning"><AlertTriangle size={16} /> {advancedMetrics.sharpeUnavailableReason}</div>}
        {advancedMetrics.dataWarnings.map((warning) => <div className="portfolio-warning" key={warning}><AlertTriangle size={16} /> {warning}</div>)}
        <details className="advanced-metric-definitions"><summary>Metric definitions and assumptions</summary>
          <ul>
            <li>Simple return is the latest total-value ratio minus one; cumulative observed return compares the first and latest stored snapshots. Both are unadjusted for deposits, withdrawals, transfers, fees, or other external cash flows.</li>
            <li>Daily change uses the closest prior snapshot to 24 hours before the latest observation, within a two-hour tolerance. Otherwise it is withheld.</li>
            <li>Volatility is the sample standard deviation of snapshot-to-snapshot simple returns. Annualized volatility and Sharpe require a regular snapshot cadence and an explicitly configured periods-per-year assumption.</li>
            <li>Sharpe converts the explicitly configured effective annual risk-free rate to the observation period as (1 + annual rate)^(1 / periods per year) − 1. No risk-free rate is assumed by default.</li>
            <li>Maximum drawdown is peak-to-trough on reported total values. Recovery time measures elapsed time from the peak before the maximum drawdown until that prior peak is regained; unrecovered drawdowns are labeled.</li>
            <li>HHI is the sum of squared reported allocation fractions; effective holdings equals 1/HHI. Portfolio drift compares stored snapshots, not policy targets.</li>
            <li>Covariance and correlation use pairwise complete snapshot-to-snapshot asset returns. Volatility contribution uses current reported weights and is withheld if those weights or the covariance matrix do not reconcile.</li>
          </ul>
        </details>
      </Panel>}

      {snapshot?.missingData.map((item) => <div className="portfolio-warning" key={item}><AlertTriangle size={16} /> {item}</div>)}
      {comparison?.unusualMovements.map((item) => <div className="portfolio-warning" key={item}><AlertTriangle size={16} /> Unusual balance observation: {item}</div>)}
      {comparison?.missingData.map((item) => <div className="portfolio-warning" key={`comparison-${item}`}><AlertTriangle size={16} /> {item}</div>)}
      {comparison?.positionChanges.some((change) => change.state === "missing-from-latest") && <div className="note-box"><CircleHelp size={16} /><span>A position absent from the latest response is treated as unknown, not as a confirmed zero balance or transfer.</span></div>}

      <Panel title="Asset balances" subtitle={isLive ? "Coinbase-reported spot balances; cost basis and PnL appear only when supplied" : "Synthetic fixture values; no live portfolio was substituted"}>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Asset</th><th>Quantity</th><th>Implied price</th><th>Value</th><th>Cost basis</th><th>PnL</th><th>Allocation</th></tr></thead>
            <tbody>
              {positions.map((position) => {
                const impliedPrice = position.quantity && position.value !== null ? position.value / position.quantity : null;
                return <tr key={position.asset}>
                  <td><div className="asset-name"><span className="asset-symbol">{position.asset.slice(0, 1)}</span><div><b>{position.asset}</b><small>{snapshot?.portfolioType || "DEMO"}</small></div></div></td>
                  <td className="mono">{position.quantity === null ? "Unavailable" : `${position.quantity.toLocaleString("en-US", { maximumFractionDigits: 8 })} ${position.asset}`}</td>
                  <td className="mono">{impliedPrice === null ? "Unavailable" : money(impliedPrice)}</td>
                  <td className="mono">{money(position.value)}</td>
                  <td className="mono">{money(position.costBasis)}</td>
                  <td className={`mono ${position.pnl === null ? "" : position.pnl >= 0 ? "positive" : "negative"}`}>{position.pnl === null ? "Unavailable" : `${position.pnl >= 0 ? "+" : ""}${money(position.pnl)}`}</td>
                  <td><div className="allocation-cell"><span>{position.allocation === null ? "—" : `${(position.allocation * 100).toFixed(1)}%`}</span><div><i style={{ width: `${Math.max(0, Math.min(100, (position.allocation || 0) * 100))}%` }} /></div></div></td>
                </tr>;
              })}
              {!positions.length && <tr><td colSpan={7} className="empty-state">No balances to display.</td></tr>}
            </tbody>
          </table>
        </div>
      </Panel>
    </>
  );
}
export function AgentsView({ tasks, busy, onRunInvestigation }: ViewProps) {
  const [objective, setObjective] = useState("");
  const [selectedTaskId, setSelectedTaskId] = useState<string | undefined>();
  const selected =
    tasks.find((task) => task.status === "running") ||
    tasks.find((task) => task.id === selectedTaskId) ||
    tasks[0];
  return (
    <>
      <SectionTitle
        eyebrow="HIERARCHICAL RESEARCH PIPELINE"
        title="Agent command center"
        text="Parallel research, then a risk challenge and independent verification."
        action={
          <button
            className="button primary"
            disabled={busy}
            onClick={() => onRunInvestigation()}
          >
            <Sparkles size={16} />
            {busy ? "Orchestrating…" : "Start investigation"}
          </button>
        }
      />
      <div className="banner agent-banner">
        <Sparkles size={16} />
        <span>
          <strong>DEMO AGENT SIMULATION</strong> · deterministic calculations
          over seeded data; no external LLM is running.
        </span>
      </div>
      {busy && (
        <div className="run-progress">
          <span className="progress-pulse" />
          <div>
            <b>Orchestrator running</b>
            <span>
              Parallel portfolio, market, and quantitative research → risk
              challenge → independent verification.
            </span>
          </div>
        </div>
      )}
      <form
        className="objective-form"
        onSubmit={(event) => {
          event.preventDefault();
          const value = objective.trim();
          onRunInvestigation(
            value ||
              "Analyze my Coinbase portfolio and evaluate whether current allocation has excessive concentration.",
          );
          setObjective("");
        }}
      >
        <input
          value={objective}
          onChange={(event) => setObjective(event.target.value)}
          maxLength={500}
          placeholder="Ask a Coinbase-specific portfolio research question…"
          aria-label="Investigation objective"
        />
        <button className="button primary" disabled={busy}>
          <Sparkles size={15} />
          Investigate
        </button>
      </form>
      <div className="preset-row">
        {presets.map((preset) => (
          <button
            key={preset}
            className="preset-button"
            onClick={() => onRunInvestigation(preset)}
            disabled={busy}
          >
            {preset}
            <ArrowUpRight size={14} />
          </button>
        ))}
      </div>
      <div className="agent-flow">
        {[
          "Orchestrator",
          "Portfolio Analyst",
          "Market Intelligence",
          "Quant Research",
          "Risk Officer",
          "Verification",
        ].map((name, index) => (
          <div
            key={name}
            className={`flow-step ${index === 0 || index > 3 ? "sequential" : ""}`}
          >
            <span className="flow-index">
              {String(index + 1).padStart(2, "0")}
            </span>
            <b>{name}</b>
            <small>
              {index === 0
                ? "Task routing"
                : index < 4
                  ? "Parallel research"
                  : "Independent review"}
            </small>
          </div>
        ))}
      </div>
      {selected ? (
        selected.status === "running" ? (
          <TaskProgress task={selected} />
        ) : selected.status === "failed" ? (
          <Panel
            title={selected.objective}
            subtitle={`${selected.id} · failed`}
          >
            <div className="empty-note">
              This task did not produce a completed report. Correct the
              objective or retry the investigation.
            </div>
          </Panel>
        ) : (
          <TaskReport task={selected} />
        )
      ) : (
        <div className="empty-panel">
          <FileSearch size={25} />
          <b>No investigation yet</b>
          <span>
            Run a multi-agent analysis to inspect evidence, metrics, dissent,
            and the verification report.
          </span>
        </div>
      )}
      {tasks.length > 1 && (
        <Panel
          title="Investigation history"
          subtitle="Select a prior persisted demo task"
        >
          <div className="history-list">
            {tasks.map((task) => (
              <button
                className={`history-row ${task.id === selected?.id ? "active" : ""}`}
                key={task.id}
                onClick={() => setSelectedTaskId(task.id)}
              >
                <span className="mono">{task.id}</span>
                <b>{task.objective}</b>
                <Tag tone="green">{task.status}</Tag>
              </button>
            ))}
          </div>
        </Panel>
      )}
      <Panel
        title="Specialist roster"
        subtitle="Distinct task handlers · read-only analysis"
      >
        <div className="roster-grid">
          {[
            {
              n: "01",
              name: "Portfolio Analyst",
              role: "Allocation, exposure and PnL",
              color: "blue",
            },
            {
              n: "02",
              name: "Market Intelligence",
              role: "Coinbase market snapshot analysis",
              color: "cyan",
            },
            {
              n: "03",
              name: "Quant Research",
              role: "Indicators and scenario metrics",
              color: "violet",
            },
            {
              n: "04",
              name: "Risk Officer",
              role: "Adversarial review and internal veto",
              color: "amber",
            },
            {
              n: "05",
              name: "Verification & Audit",
              role: "Independent arithmetic and evidence review",
              color: "green",
            },
          ].map((agent) => (
            <div key={agent.name} className="roster-card">
              <span className={`roster-icon ${agent.color}`}>{agent.n}</span>
              <div>
                <b>{agent.name}</b>
                <small>{agent.role}</small>
              </div>
              <Tag tone="green">READY</Tag>
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}

function TaskProgress({ task }: { task: AgentTask }) {
  const stages = [
    { label: "Portfolio Analyst", state: "Processing" },
    { label: "Market Intelligence", state: "Processing" },
    { label: "Quant Research", state: "Processing" },
    { label: "Risk Officer challenge", state: "Queued" },
    { label: "Verification & Audit", state: "Queued" },
  ];
  return (
    <Panel title={task.objective} subtitle={`${task.id} · research running`}>
      <div className="task-progress-banner">
        <span className="progress-pulse" />
        <div>
          <b>DEMO AGENT SIMULATION</b>
          <span>
            Independent calculations on seeded portfolio and market fixtures.
          </span>
        </div>
      </div>
      <div className="task-progress-list">
        {stages.map((stage) => (
          <div key={stage.label}>
            <span
              className={`task-stage-dot ${stage.state === "Complete" ? "done" : stage.state === "Processing" ? "active" : ""}`}
            />
            <b>{stage.label}</b>
            <span>{stage.state}</span>
          </div>
        ))}
      </div>
      <p className="task-progress-note">
        Risk challenge and numerical verification complete in sequence before
        the final report is accepted.
      </p>
    </Panel>
  );
}

function TaskReport({ task }: { task: AgentTask }) {
  return (
    <Panel
      title={task.objective}
      subtitle={`${task.id} · completed ${new Date(task.completedAt || task.createdAt).toLocaleString()}`}
      action={
        <Tag tone={task.status === "completed" ? "green" : "red"}>
          {task.status.toUpperCase()}
        </Tag>
      }
    >
      <div className="consensus">
        <ShieldCheck size={18} />
        <div>
          <b>Research conclusion</b>
          <span>{task.finalRecommendation}</span>
          <small className="agreement-note">
            Agreement is similarity of agent research conclusions, not
            probability of investment success.
          </small>
        </div>
        <div className="agreement">
          <b>{Math.round((task.agreementScore || 0) * 100)}%</b>
          <small>agent agreement</small>
        </div>
      </div>
      <div className="finding-list">
        {task.findings.map((finding) => (
          <details key={finding.id} className="finding-card">
            <summary>
              <span className={`finding-marker ${finding.agentId}`} />
              <b>{finding.agentId.replaceAll("-", " ")}</b>
              <span className="finding-summary">{finding.summary}</span>
              <span className="confidence">
                {Math.round(finding.confidence * 100)}% conf.
              </span>
              <ChevronDown size={15} />
            </summary>
            <div className="finding-body">
              <div className="finding-columns">
                <div>
                  <h4>Findings</h4>
                  {finding.findings.map((item) => (
                    <p key={item}>{item}</p>
                  ))}
                </div>
                <div>
                  <h4>Calculations</h4>
                  {finding.calculations.map((item) => (
                    <p key={item} className="mono">
                      {item}
                    </p>
                  ))}
                </div>
              </div>
              <div className="evidence-row">
                <span>Evidence</span>
                {finding.evidenceRefs.map((ref) => (
                  <Tag key={ref}>{ref}</Tag>
                ))}
              </div>
              <div className="evidence-row">
                <span>Assumptions</span>
                {finding.assumptions.map((item) => (
                  <Tag key={item}>{item}</Tag>
                ))}
              </div>
              {finding.metrics && (
                <div className="evidence-row">
                  <span>Structured metrics</span>
                  {Object.entries(finding.metrics).map(([key, value]) => (
                    <Tag key={key}>
                      {key}: {value}
                    </Tag>
                  ))}
                </div>
              )}
              {finding.toolTrace?.length ? <div className="evidence-row"><span>Tool and source trace</span>{finding.toolTrace.map((trace, index) => <Tag key={`${trace.toolId}-${trace.reference || index}`} tone={trace.status === "success" ? "green" : trace.status === "partial" ? "amber" : "red"}>{trace.toolId} · {trace.source} · {trace.status}{trace.retrievedAt ? ` · ${new Date(trace.retrievedAt).toLocaleString()}` : ""}</Tag>)}</div> : null}
              {finding.validationChecks?.length ? <div className="agent-validation-checks"><b>Independent checks</b><ul>{finding.validationChecks.map((check) => <li key={check.name} className={`validation-${check.status}`}><strong>{check.status.toUpperCase()}</strong> · {check.name}: {check.detail}</li>)}</ul></div> : null}
              {finding.riskFlags.length > 0 && (
                <div className="risk-inline">
                  {finding.riskFlags.map((flag) => (
                    <span key={flag}>
                      <AlertTriangle size={13} />
                      {flag}
                    </span>
                  ))}
                </div>
              )}
              {finding.dissent && (
                <div className="dissent">Dissent: {finding.dissent}</div>
              )}
            </div>
          </details>
        ))}
      </div>
      {task.decisionReview && (
        <div className="evidence-row decision-meta">
          <span>Decision review</span>
          <Tag>{task.decisionReview.participatingAgents.length} AGENTS</Tag>
          <Tag>
            {(task.decisionReview.evidenceCoverage * 100).toFixed(0)}% evidence
            coverage
          </Tag>
          <Tag tone="amber">HUMAN REVIEW REQUIRED</Tag>
          {task.contractVersion && <Tag>CONTRACT v{task.contractVersion}</Tag>}
          {task.auditTrail && <Tag>{task.auditTrail.length} audit events · {task.contextRefs?.length || 0} context refs</Tag>}
          {task.decisionReview.unresolvedDisagreements.map((item) => (
            <Tag key={item}>Dissent: {item}</Tag>
          ))}
        </div>
      )}
    </Panel>
  );
}

const CANDLE_INTERVALS: Array<{ value: CandleGranularity; label: string; milliseconds: number }> = [
  { value: "ONE_MINUTE", label: "1 minute", milliseconds: 60_000 },
  { value: "FIVE_MINUTE", label: "5 minutes", milliseconds: 300_000 },
  { value: "FIFTEEN_MINUTE", label: "15 minutes", milliseconds: 900_000 },
  { value: "THIRTY_MINUTE", label: "30 minutes", milliseconds: 1_800_000 },
  { value: "ONE_HOUR", label: "1 hour", milliseconds: 3_600_000 },
  { value: "TWO_HOUR", label: "2 hours", milliseconds: 7_200_000 },
  { value: "SIX_HOUR", label: "6 hours", milliseconds: 21_600_000 },
  { value: "ONE_DAY", label: "1 day", milliseconds: 86_400_000 },
];

function priceText(value: number | null | undefined) {
  return value == null || !Number.isFinite(value)
    ? "—"
    : `$${value.toLocaleString("en-US", { maximumFractionDigits: value < 1 ? 6 : 2 })}`;
}

function MarketStat({ label, value, detail }: { label: string; value: string; detail?: string }) {
  return (
    <div className="micro-stat">
      <span>{label}</span>
      <b className="mono">{value}</b>
      {detail && <small>{detail}</small>}
    </div>
  );
}

function DepthSide({
  side,
  levels,
  color,
}: {
  side: string;
  levels: Array<{ price: number; size: number }>;
  color: "bid" | "ask";
}) {
  const visible = levels.slice(0, 8);
  const maxSize = Math.max(0, ...visible.map((level) => level.size));
  return (
    <div className={`depth-side ${color}`}>
      <div className="depth-side-heading"><b>{side}</b><span>Price / base size</span></div>
      {visible.length ? visible.map((level, index) => (
        <div className="depth-level" key={`${side}-${level.price}-${index}`}>
          <div className="depth-level-values">
            <span className="mono">{priceText(level.price)}</span>
            <span className="mono">{level.size.toLocaleString("en-US", { maximumFractionDigits: 5 })}</span>
          </div>
          <div className="depth-track"><span style={{ width: `${maxSize ? (level.size / maxSize) * 100 : 0}%` }} /></div>
        </div>
      )) : <div className="depth-empty">No book levels available.</div>}
    </div>
  );
}

function MarketMicrostructurePanel({ book, candles }: { book: MicrostructureBook | null; candles: MarketProduct["candles"] }) {
  const metrics = calculateMicrostructure(book, candles);
  const imbalance = metrics.imbalance;
  const imbalanceText = imbalance == null ? "—" : `${imbalance > 0 ? "+" : ""}${(imbalance * 100).toFixed(1)}%`;
  return (
    <details className="microstructure-panel" open>
      <summary>
        <span><b>Market Microstructure Analytics</b><small>Top-of-book measurements · descriptive, not predictive</small></span>
        <span className={`book-source ${book?.source === "coinbase-advanced-trade" ? "live" : "demo"}`}>
          {book?.source === "coinbase-advanced-trade" ? "COINBASE BOOK" : book?.source === "demo" ? "SYNTHETIC BOOK" : "BOOK UNAVAILABLE"}
        </span>
      </summary>
      <div className="microstructure-content">
        <div className="micro-stats-grid">
          <MarketStat label="Bid–ask spread" value={metrics.spread == null ? "—" : `${priceText(metrics.spread)} · ${metrics.spreadBps?.toFixed(2)} bps`} detail="Best ask minus best bid" />
          <MarketStat label="Mid-market price" value={priceText(metrics.midPrice)} detail="Average of best bid and ask" />
          <MarketStat label="Visible bid depth" value={`${metrics.bidDepthBase.toLocaleString("en-US", { maximumFractionDigits: 5 })} base`} detail={`${priceText(metrics.bidDepthUsd)} quote notional`} />
          <MarketStat label="Visible ask depth" value={`${metrics.askDepthBase.toLocaleString("en-US", { maximumFractionDigits: 5 })} base`} detail={`${priceText(metrics.askDepthUsd)} quote notional`} />
          <MarketStat label="Order-book imbalance" value={imbalanceText} detail="Positive = more visible bid size" />
          <MarketStat label="Approx. one-way spread cost" value={metrics.oneWaySpreadCostOn1000 == null ? "—" : priceText(metrics.oneWaySpreadCostOn1000)} detail="Illustrative $1,000 notional, before fees" />
          <MarketStat label="5-candle price momentum" value={metrics.momentumPct == null ? "—" : `${metrics.momentumPct > 0 ? "+" : ""}${metrics.momentumPct.toFixed(3)}%`} detail="Close vs. five candles earlier" />
          <MarketStat label="20-return realized volatility" value={metrics.realizedVolPct == null ? "—" : `${metrics.realizedVolPct.toFixed(3)}%`} detail="Unannualized; latest available returns" />
        </div>
        <section className="depth-visualization" aria-label="Order-book depth visualization">
          <div className="depth-visualization-heading"><b>Order-book depth</b><span>{book?.source === "demo" ? "Synthetic example levels" : "Visible snapshot levels only"}</span></div>
          <div className="depth-columns">
            <DepthSide side="Bids" levels={metrics.bids} color="bid" />
            <DepthSide side="Asks" levels={metrics.asks} color="ask" />
          </div>
        </section>
        {book && <p className="book-timestamp">Book snapshot timestamp: {book.time ? new Date(book.time).toLocaleString() : "not supplied"}</p>}
        {!book && <p className="book-error">Order-book snapshot unavailable. Refresh or try another product.</p>}
        <details className="micro-definitions">
          <summary>Definitions and interpretation</summary>
          <dl>
            <div><dt>Bid–ask spread</dt><dd>Lowest ask minus highest bid, in quote currency; basis points divide the spread by the mid-market price.</dd></div>
            <div><dt>Mid-market price</dt><dd>The arithmetic midpoint of the best bid and best ask. It is a reference, not a guaranteed execution price.</dd></div>
            <div><dt>Bid / ask depth</dt><dd>Sum of displayed base-asset size across the returned book levels; quote notional is shown alongside. Limited to this snapshot, not all market liquidity.</dd></div>
            <div><dt>Order-book imbalance</dt><dd>(Visible bid size − visible ask size) ÷ total visible size. It describes displayed resting size only and does not predict future price direction with certainty.</dd></div>
            <div><dt>Approximate spread cost</dt><dd>Estimated one-way cost for a $1,000 notional trade using half the quoted spread relative to the midpoint. Excludes fees, market impact, latency, and slippage.</dd></div>
            <div><dt>Price momentum</dt><dd>Percentage change from the close five candles earlier to the latest close; it is a backward-looking description.</dd></div>
            <div><dt>Short-term realized volatility</dt><dd>Square root of summed squared log returns over up to the latest 20 candle-to-candle observations; unannualized and dependent on candle interval.</dd></div>
          </dl>
          <p>These measures describe the selected snapshot and history only. Order-book imbalance and momentum are not certain forecasts or trading recommendations.</p>
        </details>
      </div>
    </details>
  );
}

export function MarketsView({ markets, marketStreamStatus }: ViewProps) {
  const [selected, setSelected] = useState(markets[0]?.productId || "BTC-USD");
  const [granularity, setGranularity] = useState<CandleGranularity>("ONE_HOUR");
  const [scenario, setScenario] = useState<MarketScenario>("Baseline sample");
  const [historyMarket, setHistoryMarket] = useState<MarketProduct | null>(null);
  const [historyError, setHistoryError] = useState("");
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyFetchedAt, setHistoryFetchedAt] = useState("");
  const [book, setBook] = useState<MicrostructureBook | null>(null);
  const [bookError, setBookError] = useState("");
  const [bookLoading, setBookLoading] = useState(false);
  const [refreshCounter, setRefreshCounter] = useState(0);
  const [clock, setClock] = useState(Date.now());
  const baseMarket = markets.find((item) => item.productId === selected) || markets[0];
  const matchingHistory = historyMarket?.productId === selected ? historyMarket : null;
  const currentSource = matchingHistory?.source || baseMarket?.source;
  const isLive = currentSource === "coinbase-advanced-trade";
  const granularityConfig = CANDLE_INTERVALS.find((item) => item.value === granularity)!;

  useEffect(() => {
    if (!markets.length) return;
    if (!markets.some((item) => item.productId === selected)) setSelected(markets[0].productId);
  }, [markets, selected]);

  useEffect(() => {
    if (!baseMarket) return;
    const controller = new AbortController();
    setHistoryLoading(true);
    setHistoryError("");
    const query = new URLSearchParams({ productId: selected, granularity });
    void fetch(`/api/markets/live?${query}`, { signal: controller.signal })
      .then(async (response) => {
        const payload = await response.json() as { ok?: boolean; data?: { markets?: MarketProduct[]; asOf?: string }; error?: string };
        if (!response.ok || !payload.ok) throw new Error(payload.error || "Historical market data is unavailable.");
        const result = payload.data?.markets?.find((item) => item.productId === selected);
        if (!result) throw new Error("No historical data was returned for this product.");
        setHistoryMarket(result);
        setHistoryFetchedAt(payload.data?.asOf || new Date().toISOString());
      })
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") return;
        setHistoryError(error instanceof Error ? error.message : "Historical market data is unavailable.");
      })
      .finally(() => {
        if (!controller.signal.aborted) setHistoryLoading(false);
      });
    return () => controller.abort();
  }, [selected, granularity, refreshCounter]);

  useEffect(() => {
    const timer = window.setInterval(() => setClock(Date.now()), 15_000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!baseMarket) return;
    const controller = new AbortController();
    setBookLoading(true);
    setBookError("");
    if (currentSource !== "coinbase-advanced-trade") {
      setBook(createDemoOrderBook(selected, baseMarket.price, baseMarket.candles.at(-1)?.time || baseMarket.dataAsOf || ""));
      setBookLoading(false);
      return () => controller.abort();
    }
    void fetch(`/api/markets/orderbook?productId=${encodeURIComponent(selected)}&limit=10`, { signal: controller.signal })
      .then(async (response) => {
        const payload = await response.json() as { ok?: boolean; data?: MicrostructureBook; error?: string };
        if (!response.ok || !payload.ok || !payload.data) throw new Error(payload.error || "Order-book data is unavailable.");
        setBook(payload.data);
      })
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === "AbortError") return;
        setBook(null);
        setBookError(error instanceof Error ? error.message : "Order-book data is unavailable.");
      })
      .finally(() => {
        if (!controller.signal.aborted) setBookLoading(false);
      });
    return () => controller.abort();
  }, [selected, currentSource, refreshCounter]);

  if (!baseMarket)
    return <div className="empty-panel"><b>No market products are available.</b></div>;

  const chartMarket = matchingHistory
    ? { ...baseMarket, candles: matchingHistory.candles, volume24h: matchingHistory.volume24h, dataQuality: matchingHistory.dataQuality }
    : baseMarket;
  const active = applyMarketScenario(chartMarket, scenario);
  const closes = active.candles.map((item) => item.close);
  const sma7 = movingAverage(closes, 7).at(-1) || 0;
  const sma20 = movingAverage(closes, 20).at(-1) || 0;
  const streamSelected = marketStreamStatus?.subscribedProducts.includes(selected) ?? false;
  const latestTimestamp = !isLive
    ? active.candles.at(-1)?.time || baseMarket.dataAsOf
    : streamSelected && marketStreamStatus?.state === "connected"
      ? baseMarket.dataAsOf || matchingHistory?.dataAsOf
      : matchingHistory?.dataAsOf || baseMarket.dataAsOf || active.candles.at(-1)?.time;
  const parsedTimestamp = latestTimestamp ? Date.parse(latestTimestamp) : Number.NaN;
  const ageMs = Number.isFinite(parsedTimestamp)
    ? Math.max(0, clock - parsedTimestamp)
    : Number.POSITIVE_INFINITY;
  const isStale = isLive && (
    marketStreamStatus?.state === "stale" ||
    ageMs > Math.max(granularityConfig.milliseconds * 3, 300_000)
  );
  const formattedTimestamp = latestTimestamp && Number.isFinite(Date.parse(latestTimestamp))
    ? new Date(latestTimestamp).toLocaleString()
    : "Timestamp unavailable";
  const volume = active.volume24h;
  const microstructure = calculateMicrostructure(book, chartMarket.candles);

  return (
    <>
      <SectionTitle
        eyebrow="COINBASE MARKET INTELLIGENCE"
        title="Market intelligence"
        text={isLive ? "Read-only public Coinbase market history and order-book snapshots. Public data is not a private account connection." : "Synthetic demo history and generated depth are shown; no live market data is implied."}
      />
      <div className="market-dashboard-controls">
        <label>
          <span>Product</span>
          <select value={selected} onChange={(event) => setSelected(event.target.value)}>
            {markets.map((item) => <option key={item.productId} value={item.productId}>{item.productId}</option>)}
          </select>
        </label>
        <label>
          <span>Candle interval</span>
          <select value={granularity} onChange={(event) => setGranularity(event.target.value as CandleGranularity)}>
            {CANDLE_INTERVALS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}
          </select>
        </label>
        <label>
          <span>Scenario lens</span>
          <select value={scenario} onChange={(event) => setScenario(event.target.value as MarketScenario)}>
            {SCENARIOS.map((name) => <option key={name}>{name}</option>)}
          </select>
        </label>
        <button className="button market-refresh" onClick={() => setRefreshCounter((value) => value + 1)} disabled={historyLoading || bookLoading}>
          <RefreshCw size={15} className={historyLoading || bookLoading ? "refresh-spinning" : ""} />
          {historyLoading || bookLoading ? "Refreshing…" : "Refresh data"}
        </button>
      </div>
      <div className={`market-data-status ${isStale || !isLive ? "warning" : "fresh"}`} role="status">
        <div><b>Market-data source</b><span>{isLive ? "Coinbase Advanced Trade · public read-only" : "Synthetic demo fixture · not live"}</span></div>
        <div><b>Stream status</b><span>{streamSelected ? marketStreamStatus?.state?.toUpperCase() : isLive ? "REST SNAPSHOT" : "DEMO"}</span></div>
        <div><b>Last update</b><span>{formattedTimestamp}</span></div>
        {streamSelected && <div><b>Events accepted / dropped</b><span>{Math.max(0, (marketStreamStatus?.incomingEventCount ?? 0) - (marketStreamStatus?.droppedEventCount ?? 0))} / {marketStreamStatus?.droppedEventCount ?? 0}</span></div>}
        {(isStale || !isLive) && <p className="market-stale-warning">{!isLive ? "Demo data is static and must not be treated as a current quote." : "Market data may be stale. Verify the source timestamp before relying on it."}</p>}
        {historyError && <p className="market-inline-error">History refresh failed: {historyError}</p>}
      </div>
      <div className="content-grid two-one market-history-grid">
        <Panel
          title={`${active.productId} · historical close`}
          subtitle={`${active.candles.length} ${granularityConfig.label} candles · ${active.dataQuality?.missingCandles || 0} missing intervals`}
          action={<Tag>{isLive ? "READ ONLY" : "DEMO"}</Tag>}
        >
          <PriceChart market={active} />
          <div className="chart-footer">
            <span>{historyLoading ? "Updating candle history…" : isLive ? `Coinbase history fetched ${historyFetchedAt ? new Date(historyFetchedAt).toLocaleTimeString() : "recently"}` : "Synthetic fixture history · never a current quote"}</span>
            <span className="market-price mono">{priceText(active.price)}</span>
          </div>
          <div className="volume-heading"><b>Trading volume by candle</b><span>Base-asset units</span></div>
          <MarketVolumeChart market={active} />
        </Panel>
        <Panel title="Market snapshot" subtitle="Descriptive indicators · not forecasts">
          <div className="quant-metrics">
            <div><span>24h change</span><b className={active.change24h >= 0 ? "positive" : "negative"}>{active.change24h >= 0 ? "+" : ""}{active.change24h.toFixed(2)}%</b></div>
            <div><span>Reported 24h volume</span><b>${(volume / 1e6).toFixed(1)}M</b></div>
            <div><span>RSI (14)</span><b>{rsi(closes).toFixed(1)}</b></div>
            <div><span>ATR (14)</span><b>{priceText(atr(active.candles))}</b></div>
            <div><span>Sample volatility</span><b>{historicalVolatility(closes).toFixed(1)}%</b></div>
            <div><span>Max drawdown</span><b>{maxDrawdown(closes).toFixed(2)}%</b></div>
            <div><span>SMA (7)</span><b className="mono">{priceText(sma7)}</b></div>
            <div><span>SMA (20)</span><b className="mono">{priceText(sma20)}</b></div>
          </div>
          <div className="note-box"><CircleHelp size={15} /><span>History-based indicators are backward-looking descriptions; they do not guarantee future results.</span></div>
        </Panel>
      </div>
      <Panel className="market-order-book" title="Order-book snapshot" subtitle={bookLoading ? "Loading public depth…" : book?.source === "demo" ? "Synthetic levels shown for interface demonstration only" : book ? "Coinbase public product-book snapshot · top 10 levels" : bookError || "Waiting for book data"} action={<Tag tone={book?.source === "coinbase-advanced-trade" ? "green" : "amber"}>{book?.source === "coinbase-advanced-trade" ? "PUBLIC LIVE-READ-ONLY" : book?.source === "demo" ? "SYNTHETIC" : "UNAVAILABLE"}</Tag>}>
        <div className="book-summary-row">
          <div><span>Best bid</span><b className="positive mono">{priceText(microstructure.bestBid)}</b></div>
          <div><span>Best ask</span><b className="negative mono">{priceText(microstructure.bestAsk)}</b></div>
          <div><span>Spread</span><b className="mono">{priceText(microstructure.spread)}</b></div>
          <div><span>Reported 24h volume</span><b className="mono">${(volume / 1e6).toFixed(1)}M</b></div>
          <div><span>Volatility tag</span><b>{active.volatility}</b></div>
        </div>
      </Panel>
      <MarketMicrostructurePanel book={book} candles={chartMarket.candles} />
      <Panel title="Coinbase pair watch" subtitle="Selected market products and reported 24-hour metrics">
        <div className="table-wrap">
          <table>
            <thead><tr><th>Product</th><th>Price</th><th>24h move</th><th>Reported 24h volume</th><th>Volatility tag</th></tr></thead>
            <tbody>{markets.map((market) => (
              <tr key={market.productId}>
                <td className="mono"><b>{market.productId}</b></td>
                <td className="mono">{priceText(market.price)}</td>
                <td className={market.change24h >= 0 ? "positive" : "negative"}>{market.change24h > 0 ? "+" : ""}{market.change24h.toFixed(2)}%</td>
                <td className="mono">${(market.volume24h / 1e6).toFixed(1)}M</td>
                <td><Tag tone={market.volatility === "Elevated" ? "amber" : "muted"}>{market.volatility.toUpperCase()}</Tag></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </Panel>
    </>
  );
}
export function RiskView({ balances }: ViewProps) {
  const metrics = portfolioMetrics(balances);
  const maxRow = [...metrics.rows].sort(
    (a, b) => b.allocation - a.allocation,
  )[0];
  return (
    <>
      <SectionTitle
        eyebrow="INDEPENDENT POLICY MONITOR"
        title="Risk intelligence"
        text="Policy checks run outside the agent/LLM layer; live execution is disabled."
      />
      <div className="banner risk-banner">
        <ShieldCheck size={18} />
        <div>
          <b>Execution boundary active</b>
          <span>
            No live orders, withdrawals, deposits, transfers, swaps or financial
            writes can be initiated from this app.
          </span>
        </div>
        <Tag tone="green">ENFORCED</Tag>
      </div>
      <div className="metric-grid three">
        <Metric
          label="Largest position"
          value={`${(maxRow.allocation * 100).toFixed(1)}% ${maxRow.asset}`}
          change="Review concentration"
          icon={AlertTriangle}
          tone="amber"
        />
        <Metric
          label="Concentration index"
          value={concentration(metrics.rows).toFixed(3)}
          change="Sum of squared asset weights"
          icon={Gauge}
          tone="violet"
        />
        <Metric
          label="Data freshness"
          value="DEMO"
          change="Synthetic fixture · not a live sync"
          icon={Clock3}
          tone="cyan"
        />
      </div>
      <Panel
        title="Risk register"
        subtitle="Transparent flags and hard policy status"
      >
        <div className="risk-register">
          <div className="risk-entry high">
            <span>
              <AlertTriangle size={15} />
            </span>
            <div>
              <b>Elevated asset concentration</b>
              <small>
                {maxRow.asset} is {(maxRow.allocation * 100).toFixed(1)}% of
                demo portfolio. Internal review is required; this is not an
                execution instruction.
              </small>
            </div>
            <Tag tone="amber">REVIEW</Tag>
          </div>
          <div className="risk-entry">
            <span>
              <CircleHelp size={15} />
            </span>
            <div>
              <b>Synthetic pricing and history</b>
              <small>
                Market samples are fixtures and cannot be used as live price or
                liquidity evidence.
              </small>
            </div>
            <Tag>DATA</Tag>
          </div>
          <div className="risk-entry">
            <span>
              <ShieldCheck size={15} />
            </span>
            <div>
              <b>Unsupported financial writes blocked</b>
              <small>
                Policy engine returns false for live execution independent of
                model or agent output.
              </small>
            </div>
            <Tag tone="green">PASS</Tag>
          </div>
          <div className="risk-entry">
            <span>
              <Clock3 size={15} />
            </span>
            <div>
              <b>Fees and slippage are illustrative</b>
              <small>
                Proposal previews use a demo estimate, not Coinbase fee quotes
                or an execution receipt.
              </small>
            </div>
            <Tag>SIMULATION</Tag>
          </div>
        </div>
      </Panel>
      <Panel
        title="Exposure by asset"
        subtitle="Marked to synthetic fixture prices"
      >
        <div className="exposure-list">
          {metrics.rows.map((row) => (
            <div className="exposure-row" key={row.asset}>
              <span>{row.asset}</span>
              <div className="exposure-track">
                <i style={{ width: `${row.allocation * 100}%` }} />
              </div>
              <b>{(row.allocation * 100).toFixed(1)}%</b>
              <span className="mono">{formatMoney(row.valueCents)}</span>
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}

export function ProposalsView({
  proposals,
  onCreateProposal,
  onProposalDecision,
}: ViewProps) {
  return (
    <>
      <SectionTitle
        eyebrow="HYPOTHETICAL ORDER REVIEW"
        title="Trade proposals"
        text="Every proposal is simulation-only. Approval never creates or submits a Coinbase order."
        action={
          <button className="button primary" onClick={onCreateProposal}>
            <Sparkles size={15} />
            Generate demo proposal
          </button>
        }
      />
      <div className="banner demo-banner">
        <span className="banner-dot" />
        <div>
          <strong>SIMULATION ONLY</strong>
          <span>
            {" "}
            No exchange connection, order preview endpoint, or live financial
            write is used.
          </span>
        </div>
      </div>
      {proposals.length === 0 ? (
        <div className="empty-panel">
          <FileSearch size={25} />
          <b>No proposals yet</b>
          <span>
            Create a sample proposal to review risk checks and the simulated
            order preview workflow.
          </span>
        </div>
      ) : (
        <div className="proposal-list">
          {proposals.map((proposal) => {
            const finalized =
              proposal.reviewDecision === "approved-for-simulation" ||
              proposal.reviewDecision === "rejected";
            return (
              <div className="panel proposal-card" key={proposal.id}>
                <div className="proposal-heading">
                  <div>
                    <div className="eyebrow">{proposal.id} · SIMULATION</div>
                    <h2>
                      <span
                        className={
                          proposal.side === "BUY" ? "positive" : "negative"
                        }
                      >
                        {proposal.side}
                      </span>{" "}
                      {proposal.productId}
                    </h2>
                  </div>
                  <Tag
                    tone={proposal.riskStatus === "rejected" ? "red" : "green"}
                  >
                    {proposal.reviewDecision
                      ? proposal.reviewDecision
                          .replaceAll("-", " ")
                          .toUpperCase()
                      : proposal.riskStatus.toUpperCase()}
                  </Tag>
                </div>
                <div className="proposal-grid">
                  <div>
                    <span>Order type</span>
                    <b>{proposal.orderType}</b>
                  </div>
                  <div>
                    <span>Proposed size</span>
                    <b className="mono">{proposal.proposedSize}</b>
                  </div>
                  <div>
                    <span>Estimated notional</span>
                    <b className="mono">
                      {formatMoney(proposal.notionalCents)}
                    </b>
                  </div>
                  <div>
                    <span>Illustrative fee</span>
                    <b className="mono">${proposal.estimatedFees}</b>
                  </div>
                  <div>
                    <span>Price assumption</span>
                    <b className="mono">
                      {proposal.proposedPrice
                        ? `$${proposal.proposedPrice}`
                        : "Synthetic snapshot"}
                    </b>
                  </div>
                  <div>
                    <span>Execution mode</span>
                    <b>Simulation only</b>
                  </div>
                </div>
                <p className="proposal-rationale">{proposal.rationale}</p>
                <div className="proposal-support">
                  <span>Supporting agents</span>
                  <b>
                    {proposal.supportingAgentIds
                      .map((agent) => agent.replaceAll("-", " "))
                      .join(" · ")}
                  </b>
                </div>
                {proposal.riskFlags.length > 0 && (
                  <div className="proposal-flags">
                    {proposal.riskFlags.map((flag) => (
                      <Tag key={flag} tone="amber">
                        {flag}
                      </Tag>
                    ))}
                  </div>
                )}
                {proposal.rejectionExplanations?.length ? <div className="proposal-rejection-explanations"><b>Risk Officer · rejection explanation</b><ul>{proposal.rejectionExplanations.map((reason) => <li key={reason}>{reason}</li>)}</ul></div> : null}
                {proposal.preview && (
                  <div className="preview-box">
                    <b>
                      <CheckCircle2 size={15} /> Hypothetical preview · no
                      exchange receipt
                    </b>
                    <span>
                      Expected ${proposal.preview.expectedPrice} · estimated
                      slippage ${proposal.preview.slippage} · resulting
                      allocation{" "}
                      {(proposal.preview.resultingAllocation * 100).toFixed(1)}%
                      · portfolio{" "}
                      {formatMoney(proposal.preview.resultingPortfolioCents)}.
                    </span>
                  </div>
                )}
                {!finalized && (
                  <div className="proposal-actions">
                    <button
                      className="button primary small"
                      onClick={() => onProposalDecision(proposal.id, "approve")}
                      disabled={proposal.riskStatus === "rejected"}
                    >
                      Approve for simulation
                    </button>
                    <button
                      className="button secondary small"
                      onClick={() => onProposalDecision(proposal.id, "analyze")}
                    >
                      Request analysis
                    </button>
                    <button
                      className="button quiet small"
                      onClick={() => onProposalDecision(proposal.id, "reject")}
                    >
                      Reject
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}

export function LedgerView({ audit, tasks, proposals }: ViewProps) {
  const entries = [...audit].sort((a, b) =>
    b.timestamp.localeCompare(a.timestamp),
  );
  return (
    <>
      <SectionTitle
        eyebrow="AUDITABILITY AND SIMULATION HISTORY"
        title="Execution ledger"
        text="A local demo ledger of research actions, policy checks, and simulated proposal decisions."
      />
      <div className="metric-grid three">
        <Metric
          label="Audit events"
          value={String(audit.length)}
          change="Persisted in this browser"
          icon={FileSearch}
        />
        <Metric
          label="Completed investigations"
          value={String(
            tasks.filter((task) => task.status === "completed").length,
          )}
          change="Five-agent runs"
          icon={Sparkles}
          tone="cyan"
        />
        <Metric
          label="Simulation proposals"
          value={String(proposals.length)}
          change="No exchange receipts"
          icon={WalletCards}
          tone="violet"
        />
      </div>
      <Panel
        title="Activity timeline"
        subtitle="Source mode and action outcome are retained"
      >
        <div className="ledger-list">
          {entries.length ? (
            entries.map((item) => (
              <div className="ledger-event" key={item.id}>
                <div className={`ledger-mark ${item.actor}`}>
                  <span />
                </div>
                <div className="ledger-main">
                  <div>
                    <b>{item.action}</b>
                    <Tag>{item.dataMode.toUpperCase()}</Tag>
                  </div>
                  <p>{item.outcome}</p>
                  <div className="ledger-meta">
                    <span>{item.actor}</span>
                    <span>
                      {item.references.join(" · ") || "No external inputs"}
                    </span>
                    {item.proposalId && <span>{item.proposalId}</span>}
                  </div>
                  {item.checks && (
                    <div className="ledger-checks">
                      {item.checks.map((check) => (
                        <span key={check}>
                          <CheckCircle2 size={12} />
                          {check}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <time>{new Date(item.timestamp).toLocaleString()}</time>
              </div>
            ))
          ) : (
            <div className="empty-note">
              No events recorded. Investigation and simulated proposal actions
              will be recorded here.
            </div>
          )}
        </div>
      </Panel>
    </>
  );
}
