import { NextResponse } from "next/server";
import { syncPublicMarkets } from "@/integrations/coinbase/marketData";
export async function GET() {
  const result = await syncPublicMarkets();
  return NextResponse.json({ ok: result.mode === "live-read-only", data: result }, { status: result.mode === "live-read-only" ? 200 : 503 });
}
