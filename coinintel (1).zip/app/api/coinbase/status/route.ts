import { NextResponse } from "next/server";
import { coinbaseProvider } from "@/integrations/coinbase/coinbase-provider";

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: {
      mcp: await coinbaseProvider.status(),
      advancedTrade: {
        status: "not-configured",
        authorization: "missing",
        capabilities: [],
        message:
          "Advanced Trade is a separate adapter and has not been authorized.",
      },
    },
  });
}
