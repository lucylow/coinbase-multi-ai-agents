import { describe, expect, it } from "vitest";
import { CoinbaseConnectionManager, type CoinbaseMcpHostTransport } from "@/integrations/coinbase/coinbase/client/connection-manager";
import { CoinbaseToolDiscovery } from "@/integrations/coinbase/coinbase/client/tool-discovery";
import { PortfolioAdapter } from "@/integrations/coinbase/coinbase/adapters/read-only-adapters";
import { CoinbaseIntegrationError } from "@/integrations/coinbase/coinbase/errors/coinbase-errors";

describe("Coinbase for Agents MCP architecture", () => {
  it("keeps pending host authorization distinct from connected read-only access", async () => {
    const transport: CoinbaseMcpHostTransport = { connect: async () => ({ authorization: "pending", tools: [] }) };
    const manager = new CoinbaseConnectionManager("https://agents.coinbase.com/mcp", transport);
    const status = await manager.connect();
    expect(status.status).toBe("awaiting-authorization");
    expect(manager.state).toBe("pending");
    expect(() => manager.requireAuthorized()).toThrow(/supported host/);
  });
  it("discovers capabilities and allows only a discovered read-only portfolio tool", async () => {
    const transport: CoinbaseMcpHostTransport = {
      connect: async () => ({ authorization: "authorized", tools: [{ name: "list_accounts", readOnly: true }] }),
      call: async () => ({ structuredContent: { accounts: [{ uuid: "a", currency: "USDC", available_balance: { value: "10", currency: "USDC" } }] } }),
    };
    const manager = new CoinbaseConnectionManager("https://agents.coinbase.com/mcp", transport);
    await manager.connect();
    const discovery = new CoinbaseToolDiscovery(manager);
    const accounts = await new PortfolioAdapter(discovery).listAccounts();
    expect(accounts[0].availableBalance.value).toBe("10");
    expect(discovery.list()[0].name).toBe("list_accounts");
  });
  it("rejects a discovered write-capable tool even if the host exposes it", async () => {
    const transport: CoinbaseMcpHostTransport = { connect: async () => ({ authorization: "authorized", tools: [{ name: "place_order", readOnly: false }] }), call: async () => ({}) };
    const manager = new CoinbaseConnectionManager("https://agents.coinbase.com/mcp", transport);
    await manager.connect();
    await expect(new CoinbaseToolDiscovery(manager).callReadOnly("place_order")).rejects.toMatchObject({ code: "WRITE_DISABLED" });
    expect(CoinbaseIntegrationError).toBeDefined();
  });
});
