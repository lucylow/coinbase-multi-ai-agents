import type { MarketProduct, PortfolioBalance } from "@/models/domain";
import { HttpAdvancedTradeProvider, type AdvancedTradeAccount, type AdvancedTradeProvider } from "./advancedTradeProvider";

export const DEFAULT_PRODUCTS = ["BTC-USD", "ETH-USD", "SOL-USD"] as const;
export type SyncMode = "live-read-only" | "demo-fallback";
export interface MarketSyncResult { mode: SyncMode; asOf: string; markets: MarketProduct[]; warning?: string; }
export interface PortfolioSyncResult { mode: SyncMode; asOf: string; balances: PortfolioBalance[]; warning?: string; }

function toMarket(productId: string, product: Awaited<ReturnType<AdvancedTradeProvider["getProduct"]>>, candles: Awaited<ReturnType<AdvancedTradeProvider["getPublicCandles"]>>): MarketProduct {
  const price = Number(product.price || candles.at(-1)?.close || 0);
  const first = candles[0]?.close || price;
  const change24h = product.pricePercentageChange24h ?? (first ? ((price - first) / first) * 100 : 0);
  const volume24h = product.volume24h ?? candles.reduce((sum, candle) => sum + candle.volume * candle.close, 0);
  const annualized = candles.length > 2 ? Math.sqrt(24 * 365) * Math.sqrt(candles.slice(1).reduce((sum, candle, index) => {
    const prior = candles[index].close;
    return sum + (prior ? Math.log(candle.close / prior) ** 2 : 0);
  }, 0) / Math.max(candles.length - 1, 1)) * 100 : 0;
  return { productId, price, change24h, volume24h, volatility: annualized > 80 ? "Elevated" : annualized > 35 ? "Moderate" : "Low", candles: candles.map((candle) => ({ time: candle.timestamp, open: candle.open, high: candle.high, low: candle.low, close: candle.close, volume: candle.volume })) };
}

export async function syncPublicMarkets(options: { productIds?: readonly string[]; provider?: AdvancedTradeProvider; now?: Date } = {}): Promise<MarketSyncResult> {
  const provider = options.provider || new HttpAdvancedTradeProvider();
  const end = options.now || new Date();
  const start = new Date(end.getTime() - 36 * 60 * 60 * 1000);
  try {
    const markets = await Promise.all((options.productIds || DEFAULT_PRODUCTS).map(async (productId) => toMarket(productId, await provider.getProduct(productId), await provider.getPublicCandles(productId, start.toISOString(), end.toISOString(), "ONE_HOUR"))));
    return { mode: "live-read-only", asOf: end.toISOString(), markets };
  } catch {
    return { mode: "demo-fallback", asOf: end.toISOString(), markets: [], warning: "Coinbase public market data was unavailable; caller should keep demo fixtures visible." };
  }
}

function normalizeAccount(account: AdvancedTradeAccount, price: number): PortfolioBalance {
  const quantity = account.availableBalance;
  return { asset: account.currency, name: account.name || account.currency, productId: `${account.currency}-USD`, quantity, averageCost: price > 0 ? String(price) : "0", price: String(price), change24h: 0 };
}
export async function syncPortfolio(accounts: AdvancedTradeAccount[], prices: Record<string, number>): Promise<PortfolioSyncResult> {
  const balances = accounts.map((account) => normalizeAccount(account, prices[account.currency] || (account.currency === "USD" ? 1 : 0))).filter((item) => Number(item.quantity) > 0 && Number(item.price) > 0);
  return { mode: "live-read-only", asOf: new Date().toISOString(), balances };
}
export { HttpAdvancedTradeProvider };
