export interface AdvancedTradeProduct {
  productId: string;
  baseCurrencyId: string;
  quoteCurrencyId: string;
  status: string;
  price?: string;
  pricePercentageChange24h?: number;
  volume24h?: number;
}
export interface AdvancedTradeCandle {
  timestamp: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}
export interface AdvancedTradeAccount {
  accountId: string;
  name?: string;
  currency: string;
  availableBalance: string;
  holdBalance: string;
}
export interface AdvancedTradeProvider {
  getProduct(productId: string): Promise<AdvancedTradeProduct>;
  getPublicCandles(productId: string, start: string, end: string, granularity: string): Promise<AdvancedTradeCandle[]>;
  getAccounts(): Promise<AdvancedTradeAccount[]>;
}
type FetchLike = typeof fetch;
const DEFAULT_BASE_URL = "https://api.coinbase.com";
const object = (value: unknown): Record<string, unknown> => value && typeof value === "object" ? value as Record<string, unknown> : {};
const number = (value: unknown, fallback = 0) => {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};

/** Public product/candle reads require no credentials; account reads require a server-side bearer token. */
export class HttpAdvancedTradeProvider implements AdvancedTradeProvider {
  private readonly baseUrl: string;
  private readonly accessToken?: string;
  private readonly fetcher: FetchLike;
  constructor(options: { baseUrl?: string; accessToken?: string; fetcher?: FetchLike } = {}) {
    this.baseUrl = (options.baseUrl || process.env.COINBASE_ADVANCED_TRADE_URL || DEFAULT_BASE_URL).replace(/\/$/, "");
    this.accessToken = options.accessToken || process.env.COINBASE_ACCESS_TOKEN;
    this.fetcher = options.fetcher || fetch;
  }
  private async request(path: string, authenticated = false): Promise<Record<string, unknown>> {
    if (authenticated && !this.accessToken) throw new Error("Coinbase account read requires COINBASE_ACCESS_TOKEN.");
    const response = await this.fetcher(`${this.baseUrl}${path}`, {
      headers: { Accept: "application/json", ...(this.accessToken ? { Authorization: `Bearer ${this.accessToken}` } : {}) },
      cache: "no-store",
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(`Coinbase Advanced Trade request failed (${response.status}).`);
    return object(body);
  }
  async getProduct(productId: string): Promise<AdvancedTradeProduct> {
    const body = await this.request(`/api/v3/brokerage/market/products/${encodeURIComponent(productId)}`);
    const product = object(body.product || body);
    const id = String(product.product_id || product.productId || productId);
    return {
      productId: id,
      baseCurrencyId: String(product.base_currency_id || product.baseCurrencyId || id.split("-")[0]),
      quoteCurrencyId: String(product.quote_currency_id || product.quoteCurrencyId || "USD"),
      status: String(product.status || "UNKNOWN"),
      price: product.price == null ? undefined : String(product.price),
      pricePercentageChange24h: number(product.price_percentage_change_24h ?? product.pricePercentageChange24h),
      volume24h: number(product.volume_24h ?? product.volume24h),
    };
  }
  async getPublicCandles(productId: string, start: string, end: string, granularity: string): Promise<AdvancedTradeCandle[]> {
    const query = new URLSearchParams({ start: String(Math.floor(Date.parse(start) / 1000)), end: String(Math.floor(Date.parse(end) / 1000)), granularity, limit: "350" });
    const body = await this.request(`/api/v3/brokerage/market/products/${encodeURIComponent(productId)}/candles?${query}`);
    return (Array.isArray(body.candles) ? body.candles : []).map((raw) => {
      const candle = object(raw);
      return { timestamp: new Date(number(candle.start) * 1000).toISOString(), open: number(candle.open), high: number(candle.high), low: number(candle.low), close: number(candle.close), volume: number(candle.volume) };
    }).filter((candle) => candle.close > 0 && candle.high >= candle.low).sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp));
  }
  async getAccounts(): Promise<AdvancedTradeAccount[]> {
    const body = await this.request("/api/v3/brokerage/accounts?limit=250", true);
    return (Array.isArray(body.accounts) ? body.accounts : []).map((raw) => {
      const account = object(raw);
      const available = object(account.available_balance);
      const hold = object(account.hold);
      return { accountId: String(account.uuid || "unknown"), name: account.name == null ? undefined : String(account.name), currency: String(account.currency || available.currency || "UNKNOWN"), availableBalance: String(available.value || "0"), holdBalance: String(hold.value || "0") };
    });
  }
}

export class UnconfiguredAdvancedTradeProvider implements AdvancedTradeProvider {
  private unavailable(): never { throw new Error("Advanced Trade API is not configured; no request was sent."); }
  async getProduct(_productId: string): Promise<AdvancedTradeProduct> { return this.unavailable(); }
  async getPublicCandles(_productId: string, _start: string, _end: string, _granularity: string): Promise<AdvancedTradeCandle[]> { return this.unavailable(); }
  async getAccounts(): Promise<AdvancedTradeAccount[]> { return this.unavailable(); }
}
