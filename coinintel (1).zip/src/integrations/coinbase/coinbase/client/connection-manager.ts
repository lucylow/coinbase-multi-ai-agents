import type { CoinbaseStatus } from "@/models/domain";
import { CoinbaseCapabilityRegistry, type DiscoveredCapability } from "../../coinbase-capability-registry";
import { authorizationRequired } from "../errors/coinbase-errors";
import type { CoinbaseToolDescriptor } from "../models/coinbase-models";

export interface CoinbaseMcpSession {
  authorization: "authorized" | "pending";
  tools: CoinbaseToolDescriptor[];
}
export interface CoinbaseMcpHostTransport {
  connect(endpoint: string, signal: AbortSignal): Promise<CoinbaseMcpSession>;
  call?(toolName: string, input: Record<string, unknown>, signal: AbortSignal): Promise<unknown>;
}
export class CoinbaseConnectionManager {
  readonly registry = new CoinbaseCapabilityRegistry();
  private session: "disconnected" | "pending" | "authorized" = "disconnected";
  constructor(public readonly endpoint: string, private readonly transport?: CoinbaseMcpHostTransport) {}
  async connect(timeoutMs = 8_000): Promise<CoinbaseStatus> {
    if (!this.transport) {
      this.session = "disconnected";
      return { provider: "coinbase-mcp", status: "not-configured", endpoint: this.endpoint, authorization: "missing", capabilities: [], message: "No host-provided Coinbase MCP transport is configured. Demo fixtures remain separate." };
    }
    const controller = new AbortController(); const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const result = await this.transport.connect(this.endpoint, controller.signal);
      this.registry.replace(result.tools.map((tool): DiscoveredCapability => ({ name: tool.name, description: tool.description || "Discovered Coinbase MCP tool", readOnly: tool.readOnly, inputSchema: tool.inputSchema })));
      this.session = result.authorization === "authorized" ? "authorized" : "pending";
      return { provider: "coinbase-mcp", status: result.authorization === "authorized" ? "read-only" : "awaiting-authorization", endpoint: this.endpoint, authorization: result.authorization, capabilities: this.registry.list().map((tool) => tool.name), lastSyncAt: new Date().toISOString(), message: result.authorization === "authorized" ? "Coinbase MCP tools discovered through the host authorization session." : "Coinbase MCP authorization is pending in the supported host." };
    } catch (error) {
      this.session = "disconnected";
      return { provider: "coinbase-mcp", status: error instanceof Error && error.name === "AbortError" ? "failed" : "failed", endpoint: this.endpoint, authorization: "missing", capabilities: [], message: "Coinbase MCP connection failed; no account or market data is shown." };
    } finally { clearTimeout(timer); }
  }
  requireAuthorized(): void { if (this.session !== "authorized") authorizationRequired(); }
  async call(toolName: string, input: Record<string, unknown>): Promise<unknown> {
    this.requireAuthorized();
    if (!this.transport?.call) throw new Error("The host transport did not provide an MCP tool caller.");
    return this.transport.call(toolName, input, new AbortController().signal);
  }
  get state() { return this.session; }
}
