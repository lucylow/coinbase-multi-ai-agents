import type { CoinbaseStatus } from "@/models/domain";
import { MCP_ENDPOINT } from "@/fixtures/demo";
import {
  CoinbaseCapabilityRegistry,
  type DiscoveredCapability,
} from "./coinbase-capability-registry";

export interface CoinbaseMcpTransport {
  connect(
    endpoint: string,
    signal: AbortSignal,
  ): Promise<{
    authorization: "authorized" | "pending";
    capabilities: DiscoveredCapability[];
  }>;
}

export class CoinbaseMcpClient {
  readonly endpoint: string;
  readonly registry = new CoinbaseCapabilityRegistry();
  private readonly transport?: CoinbaseMcpTransport;

  constructor(
    options: { endpoint?: string; transport?: CoinbaseMcpTransport } = {},
  ) {
    this.endpoint = options.endpoint || MCP_ENDPOINT;
    this.transport = options.transport;
  }

  async connect(timeoutMs = 8_000): Promise<CoinbaseStatus> {
    if (!this.transport)
      return {
        provider: "coinbase-mcp",
        status: "not-configured",
        endpoint: this.endpoint,
        authorization: "missing",
        capabilities: [],
        message:
          "No official Coinbase MCP authorization/transport is configured. Demo fixtures are not account data.",
      };
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const result = await this.transport.connect(
        this.endpoint,
        controller.signal,
      );
      this.registry.replace(result.capabilities);
      return {
        provider: "coinbase-mcp",
        status:
          result.authorization === "authorized"
            ? "read-only"
            : "awaiting-authorization",
        endpoint: this.endpoint,
        authorization: result.authorization,
        capabilities: this.registry.list().map((capability) => capability.name),
        lastSyncAt: new Date().toISOString(),
        message:
          result.authorization === "authorized"
            ? "Authorized MCP capability discovery completed."
            : "MCP authorization is awaiting user approval.",
      };
    } catch (error) {
      return {
        provider: "coinbase-mcp",
        status: "failed",
        endpoint: this.endpoint,
        authorization: "missing",
        capabilities: [],
        message:
          error instanceof Error && error.name === "AbortError"
            ? "Coinbase MCP connection timed out."
            : "Coinbase MCP connection failed; no account data is shown.",
      };
    } finally {
      clearTimeout(timer);
    }
  }

  async discoverCapabilities(): Promise<DiscoveredCapability[]> {
    return this.registry.list();
  }
}
