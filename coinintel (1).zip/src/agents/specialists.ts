import type { AgentFinding } from "@/models/domain";
import { balances, markets } from "@/fixtures/demo";
import {
  atr,
  historicalVolatility,
  maxDrawdown,
  movingAverage,
  portfolioMetrics,
  rsi,
  simpleReturns,
} from "@/services/analytics";

export const AGENTS = [
  {
    id: "portfolio-analyst",
    name: "Portfolio Analyst",
    role: "Allocation, exposure and PnL",
    color: "blue",
  },
  {
    id: "market-intelligence",
    name: "Market Intelligence",
    role: "Coinbase market snapshots",
    color: "cyan",
  },
  {
    id: "quant-research",
    name: "Quant Research",
    role: "Technical and scenario metrics",
    color: "violet",
  },
  {
    id: "risk-officer",
    name: "Risk Officer",
    role: "Independent policy challenge",
    color: "amber",
  },
  {
    id: "verification-audit",
    name: "Verification & Audit",
    role: "Evidence and arithmetic review",
    color: "green",
  },
] as const;

function makeFinding(
  taskId: string,
  agentId: string,
  summary: string,
  findings: string[],
  calculations: string[],
  evidenceRefs: string[],
  riskFlags: string[],
  confidence: number,
  dissent?: string,
  metrics?: Record<string, number | string>,
  stance: AgentFinding["stance"] = "market-neutral",
): AgentFinding {
  return {
    id: `${taskId}-${agentId}`,
    agentId,
    taskId,
    summary,
    findings,
    calculations,
    evidenceRefs,
    assumptions: [
      "All balances and prices are synthetic demonstration fixtures.",
      "No live Coinbase account was accessed.",
    ],
    confidence,
    riskFlags,
    requiresReview: riskFlags.length > 0,
    dissent,
    status: "completed",
    metrics,
    stance,
  };
}

export async function portfolioAnalyst(
  taskId: string,
  objective: string,
): Promise<AgentFinding> {
  const result = portfolioMetrics(balances);
  const top = [...result.rows].sort((a, b) => b.allocation - a.allocation)[0];
  return makeFinding(
    taskId,
    "portfolio-analyst",
    `Portfolio analysis complete for “${objective}”`,
    [
      `Portfolio value is $${(result.totalCents / 100).toLocaleString("en-US", { minimumFractionDigits: 2 })}.`,
      `${top.asset} is the largest position at ${(top.allocation * 100).toFixed(1)}% of the demo portfolio.`,
      `Unrealized demo PnL is $${(result.totalPnlCents / 100).toLocaleString("en-US", { minimumFractionDigits: 2 })}.`,
    ],
    [
      `Allocation: ${result.rows.map((row) => `${row.asset} ${(row.allocation * 100).toFixed(1)}%`).join(" · ")}`,
      "PnL computed from seeded average cost versus synthetic snapshot price.",
    ],
    ["demo:portfolio:balances", "demo:portfolio:allocation"],
    top.allocation > 0.65 ? ["Elevated single-asset concentration"] : [],
    0.94,
    undefined,
    {
      portfolioValueCents: result.totalCents,
      totalPnlCents: result.totalPnlCents,
      largestAllocation: top.allocation,
    },
    top.allocation > 0.65 ? "risk-flagged" : "market-neutral",
  );
}

export async function marketIntelligence(
  taskId: string,
): Promise<AgentFinding> {
  const moving = markets.filter((market) => market.productId !== "USDC-USD");
  const strongest = [...moving].sort((a, b) => b.change24h - a.change24h)[0];
  const weakest = [...moving].sort((a, b) => a.change24h - b.change24h)[0];
  return makeFinding(
    taskId,
    "market-intelligence",
    "Synthetic Coinbase pair snapshots compared",
    [
      `${strongest.productId} leads the seeded 24-hour sample at ${strongest.change24h.toFixed(2)}%.`,
      `${weakest.productId} is weakest at ${weakest.change24h.toFixed(2)}%.`,
      "Price history and volume values are compact synthetic fixtures, not current market data.",
    ],
    moving.map(
      (market) =>
        `${market.productId}: $${market.price.toLocaleString("en-US")} · 24h ${market.change24h > 0 ? "+" : ""}${market.change24h.toFixed(2)}% · ${market.volatility} sample volatility`,
    ),
    ["demo:markets:BTC-USD", "demo:markets:ETH-USD", "demo:markets:SOL-USD"],
    ["Synthetic market snapshot; not suitable for execution"],
    0.87,
    "Market direction alone does not establish a portfolio action.",
    undefined,
    "market-neutral",
  );
}

export async function quantitativeResearch(
  taskId: string,
): Promise<AgentFinding> {
  const btc = markets.find((market) => market.productId === "BTC-USD")!;
  const closes = btc.candles.map((candle) => candle.close);
  const vol = historicalVolatility(closes);
  const drawdown = maxDrawdown(closes);
  const sma7 = movingAverage(closes, 7).at(-1) || 0;
  const sma20 = movingAverage(closes, 20).at(-1) || 0;
  const returns = simpleReturns(closes);
  const meanReturn =
    returns.reduce((sum, value) => sum + value, 0) /
    Math.max(returns.length, 1);
  const returnDeviation = Math.sqrt(
    returns.reduce((sum, value) => sum + (value - meanReturn) ** 2, 0) /
      Math.max(returns.length - 1, 1),
  );
  const sampleReturnToVolatility = returnDeviation
    ? meanReturn / returnDeviation
    : 0;
  return makeFinding(
    taskId,
    "quant-research",
    "Quantitative metrics calculated from seeded candles",
    [
      "Indicators describe this small synthetic sample only; they are not predictive certainty.",
      `BTC sample RSI is ${rsi(closes).toFixed(1)} and annualized historical volatility is ${vol.toFixed(1)}%.`,
      `Maximum peak-to-trough sample drawdown is ${drawdown.toFixed(2)}%.`,
    ],
    [
      `BTC RSI(14): ${rsi(closes).toFixed(2)}`,
      `BTC ATR(14): $${atr(btc.candles).toFixed(2)}`,
      `Sample volatility: ${vol.toFixed(2)}% annualized`,
      `Sample max drawdown: ${drawdown.toFixed(2)}%`,
      `SMA(7): $${sma7.toFixed(2)} · SMA(20): $${sma20.toFixed(2)}`,
      `Sample simple return/deviation ratio: ${sampleReturnToVolatility.toFixed(3)} (descriptive; not a Sharpe ratio)`,
    ],
    ["demo:markets:BTC-USD:candles"],
    ["Synthetic sample is too short for robust forecasting"],
    0.81,
    undefined,
    undefined,
    "market-neutral",
  );
}

export async function riskOfficer(
  taskId: string,
  prior: AgentFinding[],
): Promise<AgentFinding> {
  const metrics = portfolioMetrics(balances);
  const largest = [...metrics.rows].sort(
    (a, b) => b.allocation - a.allocation,
  )[0];
  const repeatedConcentration = prior.some((finding) =>
    finding.riskFlags.some((flag) => /concentration/i.test(flag)),
  );
  const stanceConflict =
    new Set(prior.map((finding) => finding.stance)).size > 1;
  const flags = [
    largest.allocation > 0.65 ? "Concentration warrants human review" : "",
    "All market evidence is synthetic and non-executable",
    repeatedConcentration
      ? "Concentration risk appears across independent findings"
      : "",
    "Synthetic liquidity cannot be independently verified",
    "Fees are illustrative, not Coinbase fee quotes",
    stanceConflict
      ? "Specialist stances differ; preserve dissent for human review"
      : "",
  ].filter(Boolean);
  return makeFinding(
    taskId,
    "risk-officer",
    "Adversarial risk review completed",
    [
      `${largest.asset} at ${(largest.allocation * 100).toFixed(1)}% creates concentration exposure.`,
      "No recommendation should be treated as an order or a return forecast.",
      "Synthetic market values and unverified fees are not appropriate for live execution.",
    ],
    [
      `Largest allocation: ${(largest.allocation * 100).toFixed(1)}%`,
      "Hard live-execution policy: disabled",
      "Source freshness: demo fixture timestamp, not a Coinbase sync",
    ],
    [
      "demo:portfolio:allocation",
      "demo:market-history",
      "security:live-execution-disabled",
    ],
    flags,
    0.96,
    "A bullish market snapshot does not offset concentration, data freshness, or suitability concerns.",
    undefined,
    "risk-flagged",
  );
}

function independentValueCents(quantity: string, price: string): bigint {
  const scale = 100_000_000n;
  const parse = (value: string) => {
    const [whole, fraction = ""] = value.split(".");
    if (!/^\d+(?:\.\d{1,8})?$/.test(value))
      throw new Error("Malformed demo decimal");
    return (
      BigInt(whole) * scale + BigInt((fraction + "0".repeat(8)).slice(0, 8))
    );
  };
  const qtyUnits = parse(quantity);
  const priceCents = (parse(price) * 100n + scale / 2n) / scale;
  return (qtyUnits * priceCents + scale / 2n) / scale;
}

export async function verificationAgent(
  taskId: string,
  prior: AgentFinding[],
): Promise<AgentFinding> {
  const totalCents = balances.reduce(
    (sum, item) => sum + independentValueCents(item.quantity, item.price),
    0n,
  );
  const claimed = prior.find(
    (finding) => finding.agentId === "portfolio-analyst",
  )?.metrics?.portfolioValueCents;
  const consistent =
    typeof claimed === "number" && BigInt(claimed) === totalCents;
  const safeCents = Number(totalCents);
  return makeFinding(
    taskId,
    "verification-audit",
    "Independent arithmetic and evidence review complete",
    [
      consistent
        ? "Independent BigInt recalculation matches the portfolio analyst’s structured value claim."
        : "Recalculated portfolio value does not match the portfolio analyst claim; review source data.",
      "Every specialist finding identifies demo provenance and evidence references.",
      "No Coinbase connection or live market price was asserted.",
    ],
    [
      `Independently recalculated total: $${(safeCents / 100).toLocaleString("en-US", { minimumFractionDigits: 2 })}`,
      `Portfolio analyst claim: ${typeof claimed === "number" ? `$${(claimed / 100).toLocaleString("en-US", { minimumFractionDigits: 2 })}` : "missing"}`,
      `Verification status: ${consistent ? "pass" : "fail"}`,
    ],
    ["demo:portfolio:balances", "agent-findings:all"],
    consistent ? [] : ["Numerical verification failed"],
    0.99,
    consistent ? undefined : "Hold the report until the mismatch is resolved.",
    { independentlyVerifiedCents: safeCents },
    consistent ? "verification-pass" : "verification-fail",
  );
}
