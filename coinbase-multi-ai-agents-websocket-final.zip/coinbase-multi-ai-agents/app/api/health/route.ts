import { NextResponse } from "next/server";
import { runtimeConfig } from "@/config/runtime";

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: {
      service: "coinbase-intelligence",
      mode: runtimeConfig.appMode,
      liveExecutionRequested: runtimeConfig.liveExecutionRequested,
      liveExecutionEnabled: runtimeConfig.liveExecutionEnabled,
    },
  });
}
