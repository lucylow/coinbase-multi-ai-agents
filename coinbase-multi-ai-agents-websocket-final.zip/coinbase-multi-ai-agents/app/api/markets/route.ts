import { NextResponse } from "next/server";
import { DEMO_AS_OF, markets } from "@/fixtures/demo";

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: { mode: "demo", synthetic: true, asOf: DEMO_AS_OF, markets },
  });
}
