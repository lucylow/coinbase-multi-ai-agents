import { NextResponse } from "next/server";
import { syncPublicMarkets } from "@/integrations/coinbase/marketData";
import type { CandleGranularity } from "@/integrations/coinbase/advancedTradeProvider";
const intervals: CandleGranularity[] = ["ONE_MINUTE", "FIVE_MINUTE", "FIFTEEN_MINUTE", "THIRTY_MINUTE", "ONE_HOUR", "TWO_HOUR", "SIX_HOUR", "ONE_DAY"];
export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const granularity = (params.get("granularity") || "ONE_HOUR") as CandleGranularity;
  if (!intervals.includes(granularity)) return NextResponse.json({ ok: false, error: "Unsupported granularity" }, { status: 400 });
  const start = params.get("start") || undefined; const end = params.get("end") || undefined;
  if ((start && !Number.isFinite(Date.parse(start))) || (end && !Number.isFinite(Date.parse(end))) || (start && end && Date.parse(start) >= Date.parse(end))) {
    return NextResponse.json({ ok: false, error: "Use valid ISO start/end timestamps with start before end." }, { status: 400 });
  }
  const productIds = params.getAll("productId").flatMap((value) => value.split(",")).map((value) => value.trim()).filter(Boolean);
  if (productIds.length > 100 || productIds.some((id) => !/^[A-Z0-9]+-[A-Z0-9]+$/.test(id))) return NextResponse.json({ ok: false, error: "Invalid productId list" }, { status: 400 });
  const result = await syncPublicMarkets({ productIds: productIds.length ? productIds : undefined, granularity, start, end });
  return NextResponse.json({ ok: true, data: result });
}
