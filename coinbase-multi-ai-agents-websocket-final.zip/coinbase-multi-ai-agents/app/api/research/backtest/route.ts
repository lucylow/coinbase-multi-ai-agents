import { NextResponse } from "next/server";
import { z } from "zod";
import { markets } from "@/fixtures/demo";
import { backtestSmaCrossover } from "@/services/research";
const schema = z.object({ productId: z.string().regex(/^[A-Z0-9]+-USD$/).default("BTC-USD"), candles: z.array(z.object({ time: z.string(), open: z.number(), high: z.number(), low: z.number(), close: z.number(), volume: z.number() })).optional(), initialCapitalCents: z.number().int().positive().max(100_000_000).default(100_000) });
export async function POST(request: Request) {
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ ok: false, error: { code: "INVALID_INPUT", message: "Backtest input is invalid." } }, { status: 400 });
  const source = parsed.data.candles || markets.find((item) => item.productId === parsed.data.productId)?.candles;
  if (!source) return NextResponse.json({ ok: false, error: { code: "NO_CANDLES", message: "No candle history is available for this product." } }, { status: 400 });
  try { return NextResponse.json({ ok: true, data: backtestSmaCrossover(parsed.data.productId, source, parsed.data.initialCapitalCents), source: parsed.data.candles ? "request" : "demo-fixture" }); } catch (error) { return NextResponse.json({ ok: false, error: { code: "BACKTEST_FAILED", message: error instanceof Error ? error.message : "Backtest could not be completed." } }, { status: 400 }); }
}
