import { NextResponse } from "next/server";
import { z } from "zod";
import { balances } from "@/fixtures/demo";
import { stressPortfolio } from "@/services/research";
const schema = z.object({ scenario: z.string().min(2).max(80).default("crypto drawdown"), shocks: z.record(z.string(), z.number().finite().min(-1).max(1)).default({ BTC: -0.2, ETH: -0.25, SOL: -0.35, USDC: 0 }) });
export async function POST(request: Request) {
  const parsed = schema.safeParse(await request.json().catch(() => ({})));
  if (!parsed.success) return NextResponse.json({ ok: false, error: { code: "INVALID_INPUT", message: "Stress scenario input is invalid." } }, { status: 400 });
  return NextResponse.json({ ok: true, data: stressPortfolio(balances, parsed.data.shocks, parsed.data.scenario), source: "demo-fixture" });
}
