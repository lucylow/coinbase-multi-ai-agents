import { NextResponse } from "next/server";
import { HttpAdvancedTradeProvider, syncPortfolio } from "@/integrations/coinbase/marketData";
export async function GET() {
  try {
    const provider = new HttpAdvancedTradeProvider();
    const accounts = await provider.getAccounts();
    const prices: Record<string, number> = {};
    for (const account of accounts) {
      if (account.currency === "USD" || account.currency === "USDC") prices[account.currency] = 1;
      else {
        try { prices[account.currency] = Number((await provider.getProduct(`${account.currency}-USD`)).price || 0); } catch { prices[account.currency] = 0; }
      }
    }
    const result = await syncPortfolio(accounts, prices);
    return NextResponse.json({ ok: true, data: result });
  } catch {
    return NextResponse.json({ ok: false, error: { code: "COINBASE_ACCOUNT_UNAVAILABLE", message: "Read-only Coinbase portfolio sync is unavailable or unauthorized." } }, { status: 503 });
  }
}
