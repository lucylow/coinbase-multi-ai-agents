import { NextResponse } from "next/server";
import { coinbaseProvider } from "@/integrations/coinbase/coinbase-provider";

export async function GET() {
  const advancedTradeCredentialsConfigured = Boolean(
    process.env.COINBASE_ADVANCED_API_KEY_NAME &&
      process.env.COINBASE_ADVANCED_API_PRIVATE_KEY,
  );
  return NextResponse.json({
    ok: true,
    data: {
      mcp: await coinbaseProvider.status(),
      advancedTrade: {
        status: advancedTradeCredentialsConfigured
          ? "credentials-configured-unvalidated"
          : "not-configured",
        authentication: "CDP API key + private-key JWT; independent of MCP",
        credentialsConfigured: advancedTradeCredentialsConfigured,
        publicCapabilities: ["product-information", "market-data", "candles"],
        accountReadConfigured: advancedTradeCredentialsConfigured,
        accountReadValidated: false,
        message: advancedTradeCredentialsConfigured
          ? "Advanced Trade CDP credentials are present server-side. The first REST response is required to validate account access and permissions."
          : "Public market/product reads do not require credentials. Account reads require separate Advanced Trade CDP key-name and private-key credentials.",
      },
    },
  });
}
