import { NextResponse } from "next/server";
import { DEMO_ACCOUNT, DEMO_AS_OF, balances } from "@/fixtures/demo";
import { formatMoney, portfolioMetrics } from "@/services/analytics";

export async function GET() {
  const metrics = portfolioMetrics(balances);
  return NextResponse.json({
    ok: true,
    data: {
      mode: "demo",
      synthetic: true,
      account: DEMO_ACCOUNT,
      asOf: DEMO_AS_OF,
      totalValue: formatMoney(metrics.totalCents),
      totalCents: metrics.totalCents,
      totalPnl: formatMoney(metrics.totalPnlCents),
      balances: metrics.rows,
    },
  });
}
