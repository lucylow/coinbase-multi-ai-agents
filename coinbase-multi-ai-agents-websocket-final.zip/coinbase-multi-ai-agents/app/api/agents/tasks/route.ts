import { NextResponse } from "next/server";
import { runInvestigation } from "@/agents/orchestrator";

const examples = [
  "Analyze portfolio concentration and identify major exposure risks.",
  "Compare BTC and ETH volatility in the synthetic sample.",
  "Evaluate hypothetical portfolio diversification scenarios.",
  "Analyze the effects of a simulated 10% BTC market decline.",
  "Challenge the proposed portfolio allocation using independent risk analysis.",
];

export async function GET() {
  try {
    const tasks = await Promise.all(
      examples.map((objective) => runInvestigation(objective)),
    );
    return NextResponse.json({
      ok: true,
      data: tasks,
      source: "DEMO AGENT SIMULATION",
    });
  } catch {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "DEMO_SEED_FAILED",
          message: "Sample demo investigations could not be generated.",
        },
      },
      { status: 500 },
    );
  }
}
