import { NextResponse } from "next/server";
import { agentRoster } from "@/agents/orchestrator";

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: { mode: "demo-agent-simulation", agents: agentRoster() },
  });
}
