import { NextResponse } from "next/server";
import { z } from "zod";
import { runInvestigation } from "@/agents/orchestrator";

const inputSchema = z.object({ objective: z.string().trim().min(8).max(500) });
const invalidInput = () =>
  NextResponse.json(
    {
      ok: false,
      error: {
        code: "INVALID_INPUT",
        message: "Enter a valid JSON objective between 8 and 500 characters.",
      },
    },
    { status: 400 },
  );

export async function POST(request: Request) {
  let input: unknown;
  try {
    input = await request.json();
  } catch {
    return invalidInput();
  }
  const parsed = inputSchema.safeParse(input);
  if (!parsed.success) return invalidInput();
  try {
    const task = await runInvestigation(parsed.data.objective);
    return NextResponse.json({ ok: true, data: task });
  } catch (error) {
    console.error("Investigation failed", error);
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "INVESTIGATION_FAILED",
          message: "Investigation could not be completed. Please retry.",
        },
      },
      { status: 500 },
    );
  }
}
