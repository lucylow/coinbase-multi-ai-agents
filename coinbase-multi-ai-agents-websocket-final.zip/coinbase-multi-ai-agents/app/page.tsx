import CoinbaseApp from "@/components/coinbase-app";

export default function Home() {
  return <CoinbaseApp />;
}
