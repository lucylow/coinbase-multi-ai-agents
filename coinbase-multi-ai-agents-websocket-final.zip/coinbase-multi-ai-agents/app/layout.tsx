import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Coinbase Intelligence · Demo Workstation",
  description:
    "A Coinbase-specific multi-agent portfolio research and risk review workstation. Demo mode uses synthetic data.",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
