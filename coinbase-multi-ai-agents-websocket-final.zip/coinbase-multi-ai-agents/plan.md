# Coinbase Intelligence — Implementation Plan

## Scope and approach

Build the smallest complete demo-first Next.js App Router application matching the supplied Coinbase Intelligence specification. The app starts without credentials, labels all seeded account and market values as synthetic, and provides a deterministic five-agent research workflow. The seven primary sections are functional client-side views backed by shared typed domain modules, with API handlers for the implemented health, overview, Coinbase status, markets, agent roster/investigation, and proposal operations. Demo tasks, proposals, simulated approvals, and audit events persist in browser local storage; no managed database is provisioned. Financial writes remain impossible: proposal approval only records a hypothetical preview, and the independent policy engine blocks unsupported execution.

Coinbase integration is represented by a server-only provider contract and capability registry boundary configured for the official MCP URL, plus a separate Advanced Trade adapter interface. Missing credentials mean disconnected/not configured; there are no guessed endpoints or fabricated live responses. Specialist agents compute reproducible results from fixtures and clearly identify DEMO AGENT SIMULATION; no LLM API is called.

## Project structure

- `app/`: Next.js App Router shell, global styling, route manifest, and typed API route handlers.
- `src/models/`: shared TypeScript contracts for portfolios, markets, agents, proposals, risks, and audit events.
- `src/fixtures/`: consistent synthetic portfolio, prices, and candle history.
- `src/services/`: portfolio/market analytics, independent policy checks, and browser-local persistence.
- `src/agents/`: five isolated specialist handlers and multi-stage orchestration.
- `src/integrations/coinbase/`: official MCP provider boundary and separate Advanced Trade contract.
- `src/components/`: section views, charts, and workspace shell.
- `tests/`: focused unit/workflow tests for calculations, policies, and orchestration.

## Design

**Design Movement:** Institutional terminal design informed by modern financial workstations. **Core Principles:** clear data provenance; high information density; calm hierarchy; risk visibility before action. **Color Philosophy:** deep navy anchors trust, restrained electric blue marks active intelligence, green/amber/red encode status rather than decoration. **Layout Paradigm:** persistent narrow navigation beside a wide, asymmetrical workspace with a compact market rail and selectively expanded analysis panels. **Signature Elements:** monospaced market numerals; a thin blue signal line; explicit DEMO provenance chips. **Interaction Philosophy:** every action returns a visible state transition, evidence, or reason for rejection; no dead buttons. **Animation:** short, low-amplitude state transitions only; respect reduced-motion settings. **Typography System:** system sans for UI, tabular/monospaced numerals for prices and metrics, clear label/value hierarchy. **Brand Essence:** a Coinbase-specific research workstation for portfolio operators; precise, skeptical, auditable. **Brand Voice:** concise, technical, candid (e.g. “Synthetic market snapshot”; “Risk review required before simulation”). **Wordmark & Logo:** independent text wordmark paired with a simple three-bar signal glyph, not a Coinbase logo. **Signature Brand Color:** electric blue `#3F78FF` against deep navy.

## Runtime and dependencies

Use Next.js App Router, React, strict TypeScript, Tailwind CSS, Lucide icons, and Recharts. Serve Preview on initialized port 3000. Use no external financial API keys, live trading, paid data services, managed database, or deployment work. Include `.env.example`, README, and a lightweight test command. All browser-facing requests use relative paths.

The first clean browser workspace seeds five completed, deterministic sample investigations through a validated demo task API. New browser-triggered tasks persist a RUNNING placeholder, then transition to completed or failed while preserving the sample/history records. Proposal approvals only produce funded hypothetical previews using the fictional USDC balance and illustrative fees.
