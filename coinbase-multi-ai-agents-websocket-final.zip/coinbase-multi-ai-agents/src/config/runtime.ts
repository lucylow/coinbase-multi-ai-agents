export const runtimeConfig = {
  appMode: "demo" as const,
  coinbaseMcpUrl:
    process.env.COINBASE_MCP_URL || "https://agents.coinbase.com/mcp",
  liveExecutionRequested: process.env.ENABLE_LIVE_EXECUTION === "true",
  liveExecutionEnabled: false as const,
};
