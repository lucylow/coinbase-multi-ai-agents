import type { PortfolioBalance, TradeProposal } from "@/models/domain";
import { moneyCents, portfolioMetrics } from "./analytics";

export interface SimulationPreview {
  expectedPrice: string;
  slippage: string;
  resultingAllocation: number;
  resultingPortfolioCents: number;
  resultingStablecoinCents: number;
}

export function simulateAllocation(
  proposal: Pick<
    TradeProposal,
    "productId" | "side" | "notionalCents" | "estimatedFees"
  >,
  portfolio: PortfolioBalance[],
  expectedPrice: number,
): SimulationPreview {
  const metrics = portfolioMetrics(portfolio);
  const position = metrics.rows.find(
    (row) => row.productId === proposal.productId,
  );
  if (!position)
    throw new Error("No matching demo position exists for this proposal.");
  const cash = metrics.rows.find((row) => row.asset === "USDC");
  const isBuy = proposal.side === "BUY";
  const feeCents = proposal.estimatedFees
    ? moneyCents(proposal.estimatedFees)
    : Math.round(proposal.notionalCents * 0.006);
  const resultingPosition = Math.max(
    0,
    position.valueCents +
      (isBuy ? proposal.notionalCents : -proposal.notionalCents),
  );
  const resultingStablecoin = cash
    ? Math.max(
        0,
        cash.valueCents +
          (isBuy
            ? -proposal.notionalCents - feeCents
            : proposal.notionalCents - feeCents),
      )
    : 0;
  const unchangedValue = metrics.rows
    .filter(
      (row) => row.productId !== proposal.productId && row.asset !== "USDC",
    )
    .reduce((sum, row) => sum + row.valueCents, 0);
  const resultingPortfolio =
    resultingPosition + resultingStablecoin + unchangedValue;
  const resultingAllocation =
    resultingPortfolio > 0 ? resultingPosition / resultingPortfolio : 0;
  return {
    expectedPrice: expectedPrice.toFixed(2),
    slippage: (expectedPrice * 0.001).toFixed(2),
    resultingAllocation,
    resultingPortfolioCents: resultingPortfolio,
    resultingStablecoinCents: resultingStablecoin,
  };
}
