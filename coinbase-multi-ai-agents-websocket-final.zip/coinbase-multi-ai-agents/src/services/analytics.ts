import type { Candle, PortfolioBalance } from "@/models/domain";

const DECIMAL_SCALE = 100_000_000n;
const MAX_SAFE_CENTS = BigInt(Number.MAX_SAFE_INTEGER);

function toScaledDecimal(value: string | number): bigint {
  const text = String(value);
  if (!/^\d+(?:\.\d+)?$/.test(text))
    throw new Error(`Invalid non-negative decimal: ${text}`);
  const [whole, fraction = ""] = text.split(".");
  if (fraction.length > 8)
    throw new Error("Precision exceeds 8 decimal places");
  return (
    BigInt(whole) * DECIMAL_SCALE +
    BigInt((fraction + "0".repeat(8)).slice(0, 8))
  );
}

export function compareDecimals(left: string, right: string): -1 | 0 | 1 {
  const a = toScaledDecimal(left);
  const b = toScaledDecimal(right);
  return a < b ? -1 : a > b ? 1 : 0;
}

function toCents(value: string | number): bigint {
  const scaled = toScaledDecimal(value);
  return (scaled * 100n + DECIMAL_SCALE / 2n) / DECIMAL_SCALE;
}

function safeCents(value: bigint): number {
  if (value > MAX_SAFE_CENTS || value < -MAX_SAFE_CENTS)
    throw new Error("Aggregate value exceeds safe integer range");
  return Number(value);
}

export function multiplyToCents(quantity: string, price: string): number {
  const units = toScaledDecimal(quantity);
  const priceCents = toCents(price);
  return safeCents((units * priceCents + DECIMAL_SCALE / 2n) / DECIMAL_SCALE);
}

export function moneyCents(value: string): number {
  return safeCents(toCents(value));
}

export function portfolioValueCents(items: PortfolioBalance[]): number {
  const total = items.reduce(
    (sum, item) => sum + BigInt(multiplyToCents(item.quantity, item.price)),
    0n,
  );
  return safeCents(total);
}

export function portfolioMetrics(items: PortfolioBalance[]) {
  const rows = items.map((item) => {
    const valueCents = multiplyToCents(item.quantity, item.price);
    const costCents = multiplyToCents(item.quantity, item.averageCost);
    return {
      ...item,
      valueCents,
      costCents,
      pnlCents: valueCents - costCents,
      allocation: 0,
    };
  });
  const totalCents = safeCents(
    rows.reduce((sum, row) => sum + BigInt(row.valueCents), 0n),
  );
  for (const row of rows)
    row.allocation = totalCents ? row.valueCents / totalCents : 0;
  const totalPnlCents = safeCents(
    rows.reduce((sum, row) => sum + BigInt(row.pnlCents), 0n),
  );
  return { totalCents, rows, totalPnlCents };
}

export function simpleReturns(values: number[]): number[] {
  return values
    .slice(1)
    .map((value, index) =>
      values[index] === 0 ? 0 : value / values[index] - 1,
    );
}

export function movingAverage(values: number[], period: number): number[] {
  if (period <= 0) throw new Error("Period must be positive");
  return values.map((_, index) =>
    index + 1 < period
      ? Number.NaN
      : values
          .slice(index + 1 - period, index + 1)
          .reduce((sum, value) => sum + value, 0) / period,
  );
}

export function rsi(values: number[], period = 14): number {
  if (values.length <= period) return 50;
  let gains = 0;
  let losses = 0;
  for (let index = values.length - period; index < values.length; index += 1) {
    const change = values[index] - values[index - 1];
    gains += Math.max(change, 0);
    losses += Math.max(-change, 0);
  }
  if (losses === 0) return gains === 0 ? 50 : 100;
  const relativeStrength = gains / losses;
  return 100 - 100 / (1 + relativeStrength);
}

export function atr(candles: Candle[], period = 14): number {
  if (candles.length < 2) return 0;
  const ranges = candles
    .slice(1)
    .map((candle, index) =>
      Math.max(
        candle.high - candle.low,
        Math.abs(candle.high - candles[index].close),
        Math.abs(candle.low - candles[index].close),
      ),
    );
  const recent = ranges.slice(-period);
  return (
    recent.reduce((sum, value) => sum + value, 0) / Math.max(recent.length, 1)
  );
}

export function historicalVolatility(values: number[]): number {
  if (values.length < 3) return 0;
  const returns = values
    .slice(1)
    .map((value, index) => Math.log(value / values[index]));
  const mean = returns.reduce((sum, value) => sum + value, 0) / returns.length;
  const variance =
    returns.reduce((sum, value) => sum + (value - mean) ** 2, 0) /
    (returns.length - 1);
  return Math.sqrt(variance * 24 * 365) * 100;
}

export function maxDrawdown(values: number[]): number {
  let peak = Number.NEGATIVE_INFINITY;
  let max = 0;
  for (const value of values) {
    peak = Math.max(peak, value);
    if (peak > 0) max = Math.max(max, (peak - value) / peak);
  }
  return max * 100;
}

export function concentration(rows: Array<{ allocation: number }>): number {
  return rows.reduce((sum, row) => sum + row.allocation ** 2, 0);
}

export function formatMoney(
  cents: number,
  options: { compact?: boolean } = {},
): string {
  const amount = cents / 100;
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2,
    notation: options.compact ? "compact" : "standard",
  }).format(amount);
}
