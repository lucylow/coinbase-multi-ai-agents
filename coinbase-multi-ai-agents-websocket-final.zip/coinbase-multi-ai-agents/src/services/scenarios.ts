import type { MarketProduct } from "@/models/domain";

export const SCENARIOS = [
  "Baseline sample",
  "Bullish momentum",
  "Bearish momentum",
  "Sideways market",
  "High volatility",
  "Liquidity deterioration",
] as const;
export type MarketScenario = (typeof SCENARIOS)[number];

export function applyMarketScenario(
  market: MarketProduct,
  scenario: MarketScenario,
): MarketProduct {
  if (scenario === "Baseline sample") return market;
  const count = Math.max(market.candles.length - 1, 1);
  const candles = market.candles.map((candle, index) => {
    const phase = index / count - 0.5;
    let multiplier = 1;
    if (scenario === "Bullish momentum") multiplier = 1 + phase * 0.04;
    if (scenario === "Bearish momentum") multiplier = 1 - phase * 0.04;
    if (scenario === "Sideways market")
      multiplier = 1 + Math.sin(index * 1.35) * 0.0025;
    if (scenario === "High volatility")
      multiplier = 1 + Math.sin(index * 1.55) * 0.024;
    if (scenario === "Liquidity deterioration")
      multiplier = 1 + Math.sin(index * 0.74) * 0.012;
    const open = candle.open * multiplier;
    const close = candle.close * multiplier;
    const high = Math.max(candle.high * multiplier, open, close);
    const low = Math.min(candle.low * multiplier, open, close);
    const volumeFactor =
      scenario === "Liquidity deterioration"
        ? 0.28
        : scenario === "High volatility"
          ? 1.35
          : 1;
    return {
      ...candle,
      open,
      high,
      low,
      close,
      volume: Math.round(candle.volume * volumeFactor),
    };
  });
  const first = candles[0]?.close || market.price;
  const last = candles[candles.length - 1]?.close || market.price;
  const price = last;
  const change24h = ((last - first) / first) * 100;
  return {
    ...market,
    price,
    change24h,
    volatility:
      scenario === "High volatility" || scenario === "Liquidity deterioration"
        ? "Elevated"
        : market.volatility,
    volume24h: Math.round(
      market.volume24h *
        (scenario === "Liquidity deterioration"
          ? 0.28
          : scenario === "High volatility"
            ? 1.35
            : 1),
    ),
    candles,
  };
}
