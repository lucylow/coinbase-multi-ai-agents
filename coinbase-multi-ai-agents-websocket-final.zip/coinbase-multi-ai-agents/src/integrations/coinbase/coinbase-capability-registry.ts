export interface DiscoveredCapability {
  name: string;
  description: string;
  readOnly: boolean;
  inputSchema?: Record<string, unknown>;
}

export class CoinbaseCapabilityRegistry {
  private readonly capabilities = new Map<string, DiscoveredCapability>();

  replace(discovered: DiscoveredCapability[]): void {
    this.capabilities.clear();
    for (const capability of discovered) {
      if (!capability.name.trim())
        throw new Error("A discovered Coinbase capability must have a name.");
      this.capabilities.set(capability.name, capability);
    }
  }

  list(): DiscoveredCapability[] {
    return [...this.capabilities.values()];
  }

  get(name: string): DiscoveredCapability | undefined {
    return this.capabilities.get(name);
  }

  assertAvailable(name: string, mode: "read" | "write"): DiscoveredCapability {
    const capability = this.capabilities.get(name);
    if (!capability)
      throw new Error(`Unsupported Coinbase capability: ${name}`);
    if (mode === "write" || !capability.readOnly)
      throw new Error(
        "Financial write capabilities are disabled in this foundation build.",
      );
    return capability;
  }

  get status(): "empty" | "discovered" {
    return this.capabilities.size ? "discovered" : "empty";
  }
}
