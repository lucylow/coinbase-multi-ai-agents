import { createPrivateKey, randomBytes, sign, type KeyObject } from "node:crypto";

export interface AdvancedTradeCredentials {
  keyName: string;
  privateKey: string;
}

const base64url = (value: string | Buffer) => Buffer.from(value).toString("base64url");
const ED25519_PKCS8_PREFIX = Buffer.from("302e020100300506032b657004220420", "hex");

function privateKeyObject(secret: string): KeyObject {
  const normalized = secret.replace(/\\n/g, "\n").trim();
  if (normalized.startsWith("-----BEGIN")) return createPrivateKey(normalized);
  const raw = Buffer.from(normalized.replace(/\s/g, ""), "base64");
  if (raw.length !== 32 && raw.length !== 64) {
    throw new Error("CDP private key must be PEM or a 32/64-byte base64 Ed25519 key.");
  }
  // CDP's 32-byte Ed25519 seed and 64-byte seed||public-key formats both
  // become the RFC 8410 PKCS#8 seed representation accepted by Node crypto.
  return createPrivateKey({
    key: Buffer.concat([ED25519_PKCS8_PREFIX, raw.subarray(0, 32)]),
    format: "der",
    type: "pkcs8",
  });
}

/** Create a short-lived CDP JWT bound to one REST method, host, and path. */
export function createAdvancedTradeRestJwt(
  credentials: AdvancedTradeCredentials,
  method: string,
  requestUrl: string,
  nowSeconds = Math.floor(Date.now() / 1000),
): string {
  if (!credentials.keyName || !credentials.privateKey) {
    throw new Error("Advanced Trade account reads require a separate CDP API key name and private key.");
  }
  const target = new URL(requestUrl);
  const uri = `${method.toUpperCase()} ${target.host}${target.pathname}`;
  const key = privateKeyObject(credentials.privateKey);
  const keyType = key.asymmetricKeyType;
  const algorithm = keyType === "ed25519" ? "EdDSA" : keyType === "ec" ? "ES256" : undefined;
  if (!algorithm) throw new Error(`Unsupported CDP private key type: ${keyType || "unknown"}. Use Ed25519 or P-256 ECDSA.`);
  if (algorithm === "ES256" && key.asymmetricKeyDetails?.namedCurve !== "prime256v1") {
    throw new Error("Advanced Trade ES256 requires a P-256 private key.");
  }
  const header = {
    alg: algorithm,
    kid: credentials.keyName,
    nonce: randomBytes(16).toString("hex"),
    typ: "JWT",
  };
  const payload = {
    iss: "cdp",
    nbf: nowSeconds,
    exp: nowSeconds + 120,
    sub: credentials.keyName,
    uri,
  };
  const signingInput = `${base64url(JSON.stringify(header))}.${base64url(JSON.stringify(payload))}`;
  const signature = algorithm === "EdDSA"
    ? sign(null, Buffer.from(signingInput), key)
    : sign("sha256", Buffer.from(signingInput), { key, dsaEncoding: "ieee-p1363" });
  return `${signingInput}.${base64url(signature)}`;
}

/** Exposed for validation and future SDK adapters without exposing the key itself. */
export function validateAdvancedTradeCredentials(credentials: Partial<AdvancedTradeCredentials>): boolean {
  return Boolean(credentials.keyName?.trim() && credentials.privateKey?.trim());
}
