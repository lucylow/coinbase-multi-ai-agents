import { CoinbaseIntegrationError } from "../errors/coinbase-errors";
import type { CoinbaseAccount, CoinbaseMarketSnapshot, CoinbaseProduct } from "../models/coinbase-models";
import { normalizeAccounts, normalizeMarketSnapshot, normalizeProduct } from "../normalization/normalizers";
import { CoinbaseToolDiscovery } from "../client/tool-discovery";
const firstTool = (discovery: CoinbaseToolDiscovery, candidates: string[]) => candidates.find((name) => discovery.hasReadOnly(name));
export class PortfolioAdapter {
  constructor(private readonly discovery: CoinbaseToolDiscovery) {}
  async listAccounts(): Promise<CoinbaseAccount[]> {
    const tool = firstTool(this.discovery, ["list_portfolios", "list_accounts", "get_accounts"]);
    if (!tool) throw new CoinbaseIntegrationError("UNSUPPORTED_CAPABILITY", "No discovered read-only Coinbase portfolio capability is available.");
    const result = await this.discovery.callReadOnly(tool);
    return normalizeAccounts(result);
  }
}
export class ProductAdapter {
  constructor(private readonly discovery: CoinbaseToolDiscovery) {}
  async getProduct(productId: string): Promise<CoinbaseProduct> {
    const tool = firstTool(this.discovery, ["get_product", "get_products", "list_products"]);
    if (!tool) throw new CoinbaseIntegrationError("UNSUPPORTED_CAPABILITY", "No discovered read-only Coinbase product capability is available.");
    return normalizeProduct(await this.discovery.callReadOnly(tool, { product_id: productId }), productId);
  }
}
export class MarketDataAdapter {
  constructor(private readonly discovery: CoinbaseToolDiscovery) {}
  async getSnapshot(productId: string): Promise<CoinbaseMarketSnapshot> {
    const tool = firstTool(this.discovery, ["get_market_data", "get_ticker", "get_product"]);
    if (!tool) throw new CoinbaseIntegrationError("UNSUPPORTED_CAPABILITY", "No discovered read-only Coinbase market capability is available.");
    const result = await this.discovery.callReadOnly(tool, { product_id: productId });
    const product = normalizeProduct(result, productId);
    if (!product.price) throw new CoinbaseIntegrationError("INVALID_RESPONSE", "Discovered Coinbase market tool did not return a price.");
    return { productId: product.productId, price: product.price, asOf: new Date().toISOString(), source: "coinbase-mcp" };
  }
}
export class OrderPreviewAdapter {
  constructor(private readonly discovery: CoinbaseToolDiscovery) {}
  async preview(input: Record<string, unknown>): Promise<unknown> {
    const tool = firstTool(this.discovery, ["preview_order", "preview_trade"]);
    if (!tool) throw new CoinbaseIntegrationError("UNSUPPORTED_CAPABILITY", "No discovered read-only order-preview capability is available.");
    return this.discovery.callReadOnly(tool, input);
  }
}
export class FeeAdapter {
  constructor(private readonly discovery: CoinbaseToolDiscovery) {}
  async quote(input: Record<string, unknown>): Promise<unknown> {
    const tool = firstTool(this.discovery, ["get_fee", "get_fees", "estimate_fee"]);
    if (!tool) throw new CoinbaseIntegrationError("UNSUPPORTED_CAPABILITY", "No discovered read-only fee capability is available.");
    return this.discovery.callReadOnly(tool, input);
  }
}
export { normalizeMarketSnapshot };
