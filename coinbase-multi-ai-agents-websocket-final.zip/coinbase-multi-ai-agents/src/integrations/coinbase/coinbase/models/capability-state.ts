import type { DiscoveredCapability } from "../../coinbase-capability-registry";

export interface CoinbaseCapabilityState {
  connected: boolean;
  authenticated: boolean;
  accountRead: boolean;
  portfolioRead: boolean;
  marketData: boolean;
  productInfo: boolean;
  orderPreview: boolean;
  orderManagement: boolean;
  trading: boolean;
  x402Research: boolean;
  missingCapabilities: string[];
  /** Only set when the provider exposes this information explicitly. */
  regionEligibility?: string;
  /** Only set when the provider exposes this information explicitly. */
  accountEligibility?: string;
  lastValidatedAt?: string;
}

export type CoinbaseSyncState = "idle" | "syncing" | "healthy" | "degraded" | "failed";
export interface CoinbaseRequestFailure {
  at: string;
  message: string;
  code?: string;
  permissionError: boolean;
  rateLimited: boolean;
}
export interface CoinbaseIntegrationHealth {
  connectionState: "connected" | "pending" | "disconnected" | "failed";
  authenticationState: "authorized" | "pending" | "missing";
  lastSuccessfulDataRetrieval?: string;
  lastFailedRequest?: CoinbaseRequestFailure;
  availableCapabilities: string[];
  responseLatencyMs?: number;
  rateLimitWarning: boolean;
  permissionErrors: number;
  syncStatus: CoinbaseSyncState;
}

const normalize = (capability: DiscoveredCapability) =>
  `${capability.name} ${capability.description} ${Object.keys(capability.inputSchema || {}).join(" ")}`
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ");

/** Capability flags are true only when a real discovered tool matches the category. */
export function discoverCoinbaseCapabilities(
  tools: DiscoveredCapability[],
  connected: boolean,
  authenticated: boolean,
  lastValidatedAt?: string,
): CoinbaseCapabilityState {
  const descriptions = tools.map(normalize);
  const match = (...patterns: RegExp[]) =>
    tools.some((tool, index) => patterns.some((pattern) => pattern.test(descriptions[index])));

  const accountRead = match(/\b(account|accounts|balance|balances)\b/);
  const portfolioRead = match(/\b(portfolio|holdings|allocation)\b/);
  const marketData = match(/\b(market|ticker|candles?|prices?|quotes?|order book)\b/);
  const productInfo = match(/\b(products?|product info|tradable)\b/);
  const orderPreview = match(/\b(order preview|preview order|quote order|estimate order)\b/);
  const orderManagement = match(/\b(list orders|get order|order status|cancel order|create order|place order|submit order)\b/);
  const trading = tools.some((tool, index) => !tool.readOnly && /\b(trade|order|buy|sell|execution)\b/.test(descriptions[index]));
  const x402Research = match(/\b(x402|research payment|paid research|payment required)\b/);
  const missingCapabilities = [
    ...(!accountRead ? ["account-reading"] : []),
    ...(!portfolioRead ? ["portfolio-reading"] : []),
    ...(!marketData ? ["market-data"] : []),
    ...(!productInfo ? ["product-information"] : []),
    ...(!orderPreview ? ["order-preview"] : []),
    ...(!orderManagement ? ["order-management"] : []),
    ...(!trading ? ["trading"] : []),
    ...(!x402Research ? ["x402-research-payment"] : []),
  ];
  return {
    connected,
    authenticated,
    accountRead,
    portfolioRead,
    marketData,
    productInfo,
    orderPreview,
    orderManagement,
    trading,
    x402Research,
    missingCapabilities,
    lastValidatedAt,
  };
}

export function emptyCoinbaseHealth(
  authenticationState: CoinbaseIntegrationHealth["authenticationState"] = "missing",
  availableCapabilities: string[] = [],
): CoinbaseIntegrationHealth {
  return {
    connectionState: "disconnected",
    authenticationState,
    availableCapabilities,
    rateLimitWarning: false,
    permissionErrors: 0,
    syncStatus: "idle",
  };
}

export function classifyCoinbaseFailure(error: unknown): CoinbaseRequestFailure {
  const message = error instanceof Error ? error.message : String(error);
  const code = typeof error === "object" && error !== null && "code" in error
    ? String((error as { code?: unknown }).code || "")
    : undefined;
  const lower = `${code || ""} ${message}`.toLowerCase();
  return {
    at: new Date().toISOString(),
    message,
    code: code || undefined,
    permissionError: /permission|forbidden|unauthorized|scope|403/.test(lower),
    rateLimited: /rate.?limit|429|too many requests/.test(lower),
  };
}

/** Exponential delay with a cap. Authentication and permission errors are terminal. */
export function retryDelayMs(attempt: number, error: unknown, baseMs = 500, maxMs = 30_000): number | null {
  const failure = classifyCoinbaseFailure(error);
  if (failure.permissionError || /invalid.?auth|invalid.?token|unauthorized|401/.test(failure.message.toLowerCase())) return null;
  if (error instanceof Error && error.name === "AbortError") return Math.min(maxMs, baseMs * 2 ** Math.max(0, attempt));
  if (!/timeout|network|temporar|unavailable|rate.?limit|429|5\d\d|fetch failed/i.test(`${failure.code || ""} ${failure.message}`)) return null;
  return Math.min(maxMs, baseMs * 2 ** Math.max(0, attempt));
}
