export interface CoinbaseAmount { value: string; currency: string; }
export interface CoinbaseAccount { uuid: string; name?: string; currency: string; availableBalance: CoinbaseAmount; hold?: CoinbaseAmount; }
export interface CoinbasePortfolio { portfolioId?: string; name?: string; accounts: CoinbaseAccount[]; asOf?: string; }
export interface CoinbaseProduct { productId: string; baseCurrencyId?: string; quoteCurrencyId?: string; status?: string; price?: string; }
export interface CoinbaseMarketSnapshot { productId: string; price: string; change24h?: string; volume24h?: string; asOf: string; source: "coinbase-mcp"; }
export interface CoinbaseToolDescriptor { name: string; description?: string; readOnly: boolean; inputSchema?: Record<string, unknown>; }
export interface CoinbaseToolResult { structuredContent?: unknown; content?: Array<{ type: string; text?: string }>; isError?: boolean; }
