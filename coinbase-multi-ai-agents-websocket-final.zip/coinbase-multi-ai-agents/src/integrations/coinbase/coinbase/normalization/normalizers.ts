import type { PortfolioBalance, MarketProduct } from "@/models/domain";
import type { CoinbaseAccount, CoinbaseMarketSnapshot, CoinbaseProduct } from "../models/coinbase-models";
import { CoinbaseIntegrationError } from "../errors/coinbase-errors";
const record = (value: unknown): Record<string, unknown> => value && typeof value === "object" ? value as Record<string, unknown> : {};
const text = (value: unknown) => typeof value === "string" ? value : undefined;
const payload = (value: unknown) => {
  const envelope = record(value);
  return envelope.structuredContent ?? value;
};
export function normalizeAccounts(value: unknown): CoinbaseAccount[] {
  const rows = record(payload(value)).accounts;
  if (!Array.isArray(rows)) throw new CoinbaseIntegrationError("INVALID_RESPONSE", "Coinbase account response did not contain an accounts array.");
  return rows.map((row) => {
    const account = record(row); const available = record(account.available_balance); const hold = record(account.hold);
    const currency = text(account.currency) || text(available.currency);
    const amount = text(available.value);
    if (!currency || !amount) throw new CoinbaseIntegrationError("INVALID_RESPONSE", "Coinbase account balance is missing currency or value.");
    return { uuid: text(account.uuid) || "unknown", name: text(account.name), currency, availableBalance: { value: amount, currency }, hold: hold.value ? { value: String(hold.value), currency: String(hold.currency || currency) } : undefined };
  });
}
export function normalizePortfolio(accounts: CoinbaseAccount[], prices: Record<string, string>, asOf = new Date().toISOString()): PortfolioBalance[] {
  return accounts.map((account) => {
    const price = prices[account.currency];
    if (!price) return null;
    return { asset: account.currency, name: account.name || account.currency, productId: `${account.currency}-USD`, quantity: account.availableBalance.value, averageCost: price, price, change24h: 0 };
  }).filter((item): item is PortfolioBalance => item !== null);
}
export function normalizeProduct(value: unknown, fallbackProductId: string): CoinbaseProduct {
  const body = payload(value); const product = record(record(body).product || body); const productId = text(product.product_id) || fallbackProductId;
  return { productId, baseCurrencyId: text(product.base_currency_id), quoteCurrencyId: text(product.quote_currency_id), status: text(product.status), price: text(product.price) };
}
export function normalizeMarketSnapshot(snapshot: CoinbaseMarketSnapshot): MarketProduct {
  const price = Number(snapshot.price);
  if (!Number.isFinite(price) || price <= 0) throw new CoinbaseIntegrationError("INVALID_RESPONSE", "Coinbase market snapshot has an invalid price.");
  return { productId: snapshot.productId, price, change24h: Number(snapshot.change24h || 0), volume24h: Number(snapshot.volume24h || 0), volatility: "Moderate", candles: [] };
}
