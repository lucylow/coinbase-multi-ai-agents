export type CoinbaseErrorCode = "NOT_CONFIGURED" | "AUTHORIZATION_REQUIRED" | "UNSUPPORTED_CAPABILITY" | "WRITE_DISABLED" | "INVALID_RESPONSE" | "REQUEST_FAILED";
export class CoinbaseIntegrationError extends Error {
  constructor(public readonly code: CoinbaseErrorCode, message: string, options?: { cause?: unknown }) {
    super(message, options);
    this.name = "CoinbaseIntegrationError";
  }
}
export const notConfigured = (): never => { throw new CoinbaseIntegrationError("NOT_CONFIGURED", "Coinbase MCP transport is not configured; no account data is available."); };
export const authorizationRequired = (): never => { throw new CoinbaseIntegrationError("AUTHORIZATION_REQUIRED", "Coinbase MCP authorization must be completed by a supported host; this application does not implement custom OAuth."); };
