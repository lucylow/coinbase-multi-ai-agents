import type { CoinbaseStatus } from "@/models/domain";
import { CoinbaseCapabilityRegistry, type DiscoveredCapability } from "../../coinbase-capability-registry";
import { authorizationRequired } from "../errors/coinbase-errors";
import type { CoinbaseToolDescriptor } from "../models/coinbase-models";
import { classifyCoinbaseFailure, discoverCoinbaseCapabilities, emptyCoinbaseHealth, retryDelayMs, type CoinbaseIntegrationHealth } from "../models/capability-state";

export interface CoinbaseMcpSession {
  authorization: "authorized" | "pending";
  tools: CoinbaseToolDescriptor[];
}
export interface CoinbaseMcpHostTransport {
  connect(endpoint: string, signal: AbortSignal): Promise<CoinbaseMcpSession>;
  call?(toolName: string, input: Record<string, unknown>, signal: AbortSignal): Promise<unknown>;
}
const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export class CoinbaseConnectionManager {
  readonly registry = new CoinbaseCapabilityRegistry();
  private session: "disconnected" | "pending" | "authorized" = "disconnected";
  private health: CoinbaseIntegrationHealth = emptyCoinbaseHealth();
  constructor(public readonly endpoint: string, private readonly transport?: CoinbaseMcpHostTransport) {}

  async connect(timeoutMs = 8_000): Promise<CoinbaseStatus> {
    if (!this.transport) {
      this.session = "disconnected";
      this.health = emptyCoinbaseHealth();
      return {
        provider: "coinbase-mcp", status: "not-configured", endpoint: this.endpoint,
        authorization: "missing", capabilities: [], capabilityState: discoverCoinbaseCapabilities([], false, false),
        health: this.health,
        message: "No host-provided Coinbase MCP transport is configured. Demo fixtures remain separate.",
      };
    }
    const startedAt = Date.now();
    let finalError: unknown;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const result = await this.transport.connect(this.endpoint, controller.signal);
        const tools = result.tools.map((tool): DiscoveredCapability => ({
          name: tool.name, description: tool.description || "Discovered Coinbase MCP tool",
          readOnly: tool.readOnly, inputSchema: tool.inputSchema,
        }));
        this.registry.replace(tools);
        this.session = result.authorization === "authorized" ? "authorized" : "pending";
        const names = this.registry.list().map((tool) => tool.name);
        const validatedAt = new Date().toISOString();
        this.health = {
          connectionState: "connected", authenticationState: result.authorization,
          availableCapabilities: names, responseLatencyMs: Date.now() - startedAt,
          rateLimitWarning: false, permissionErrors: 0, syncStatus: "idle",
        };
        return {
          provider: "coinbase-mcp", status: result.authorization === "authorized" ? "read-only" : "awaiting-authorization",
          endpoint: this.endpoint, authorization: result.authorization, capabilities: names,
          capabilityState: discoverCoinbaseCapabilities(tools, true, result.authorization === "authorized", validatedAt),
          health: this.health, lastSyncAt: validatedAt,
          message: result.authorization === "authorized"
            ? "Coinbase MCP tools discovered through the host authorization session."
            : "Coinbase MCP authorization is pending in the supported host.",
        };
      } catch (error) {
        finalError = error;
      } finally { clearTimeout(timer); }
      if (attempt >= 2) break;
      const delay = retryDelayMs(attempt, finalError);
      if (delay === null) break;
      await wait(delay);
    }
    const failure = classifyCoinbaseFailure(finalError);
    this.session = "disconnected";
    this.health = {
      ...emptyCoinbaseHealth(), connectionState: "failed", lastFailedRequest: failure,
      responseLatencyMs: Date.now() - startedAt, rateLimitWarning: failure.rateLimited,
      permissionErrors: failure.permissionError ? 1 : 0, syncStatus: "failed",
    };
    return {
      provider: "coinbase-mcp", status: "failed", endpoint: this.endpoint, authorization: "missing",
      capabilities: [], capabilityState: discoverCoinbaseCapabilities([], false, false), health: this.health,
      message: failure.permissionError
        ? "Coinbase denied this connection; authentication and permission failures are not retried."
        : "Coinbase MCP connection failed after bounded transient retries; no account or market data is shown.",
    };
  }

  requireAuthorized(): void { if (this.session !== "authorized") authorizationRequired(); }

  async call(toolName: string, input: Record<string, unknown>): Promise<unknown> {
    this.requireAuthorized();
    if (!this.transport?.call) throw new Error("The host transport did not provide an MCP tool caller.");
    const tool = this.registry.get(toolName);
    if (!tool) throw new Error(`Unsupported Coinbase capability: ${toolName}`);
    if (!tool.readOnly) throw new Error(`WRITE_DISABLED: Coinbase MCP tool is not read-only: ${toolName}`);
    const startedAt = Date.now();
    this.health = { ...this.health, syncStatus: "syncing" };
    let finalError: unknown;
    for (let attempt = 0; attempt < 3; attempt += 1) {
      try {
        const result = await this.transport.call(toolName, input, new AbortController().signal);
        const completedAt = new Date().toISOString();
        this.health = {
          ...this.health, connectionState: "connected", authenticationState: "authorized",
          lastSuccessfulDataRetrieval: completedAt, responseLatencyMs: Date.now() - startedAt,
          syncStatus: "healthy", lastFailedRequest: undefined,
        };
        return result;
      } catch (error) {
        finalError = error;
      }
      if (attempt >= 2) break;
      const delay = retryDelayMs(attempt, finalError);
      if (delay === null) break;
      await wait(delay);
    }
    const failure = classifyCoinbaseFailure(finalError);
    this.health = {
      ...this.health, syncStatus: "degraded", responseLatencyMs: Date.now() - startedAt,
      lastFailedRequest: failure, rateLimitWarning: failure.rateLimited || this.health.rateLimitWarning,
      permissionErrors: this.health.permissionErrors + (failure.permissionError ? 1 : 0),
    };
    throw finalError;
  }

  get state() { return this.session; }
  get integrationHealth(): CoinbaseIntegrationHealth { return { ...this.health }; }
}
