export { CoinbaseCapabilityRegistry } from "../../coinbase-capability-registry";
export type { DiscoveredCapability } from "../../coinbase-capability-registry";
