import { CoinbaseIntegrationError } from "../errors/coinbase-errors";
import type { CoinbaseToolResult } from "../models/coinbase-models";
import { CoinbaseConnectionManager } from "./connection-manager";
export class CoinbaseToolDiscovery {
  constructor(private readonly connection: CoinbaseConnectionManager) {}
  list() { return this.connection.registry.list(); }
  hasReadOnly(name: string) { return this.connection.registry.get(name)?.readOnly === true; }
  async callReadOnly(name: string, input: Record<string, unknown> = {}): Promise<CoinbaseToolResult> {
    this.connection.requireAuthorized();
    const capability = this.connection.registry.get(name);
    if (!capability) throw new CoinbaseIntegrationError("UNSUPPORTED_CAPABILITY", `Coinbase MCP tool was not discovered: ${name}`);
    if (!capability.readOnly) throw new CoinbaseIntegrationError("WRITE_DISABLED", `Coinbase MCP tool is not read-only: ${name}`);
    const result = await this.connection.call(name, input);
    return (result && typeof result === "object" ? result : { structuredContent: result }) as CoinbaseToolResult;
  }
}
