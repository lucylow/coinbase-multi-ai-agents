import type { CoinbaseStatus, PortfolioBalance } from "@/models/domain";
import { CoinbaseMcpClient } from "./coinbase-mcp-client";

export interface CoinbaseProvider {
  status(): Promise<CoinbaseStatus>;
  getPortfolio(): Promise<PortfolioBalance[]>;
}

export const coinbaseProvider: CoinbaseProvider = {
  async status() {
    return new CoinbaseMcpClient().connect();
  },
  async getPortfolio() {
    throw new Error(
      "Live portfolio unavailable: Coinbase MCP authorization is not configured.",
    );
  },
};
