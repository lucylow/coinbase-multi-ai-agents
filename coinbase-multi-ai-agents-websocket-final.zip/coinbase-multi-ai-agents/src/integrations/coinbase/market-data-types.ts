export interface MarketTick {
  productId: string;
  price: string;
  timestamp: string;
  source: "coinbase" | "demo";
  isLive: boolean;
}

export interface MarketCandle {
  productId: string;
  start: number;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
}

export interface OrderBookSnapshot {
  productId: string;
  bids: Array<{ price: string; size: string }>;
  asks: Array<{ price: string; size: string }>;
  timestamp: string;
}

export type AdvancedTradeWsState = "idle" | "connecting" | "connected" | "stale" | "reconnecting" | "closed" | "error";
export interface AdvancedTradeWsStatus {
  state: AdvancedTradeWsState;
  subscribedProducts: string[];
  channels: string[];
  lastMessageAt?: string;
  lastTickAt?: string;
  reconnectAttempt: number;
  message?: string;
}
