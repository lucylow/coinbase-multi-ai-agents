import type { AdvancedTradeWsStatus, MarketTick } from "./market-data-types";

const ENDPOINT = "wss://advanced-trade-ws.coinbase.com";
const CHANNELS = ["ticker", "heartbeats", "status"] as const;
const MAX_PRODUCTS = 4;
const MAX_RECONNECTS = 5;
const STALE_AFTER_MS = 45_000;
type SocketLike = Pick<WebSocket, "readyState" | "send" | "close"> & Partial<Pick<WebSocket, "onopen" | "onerror" | "onclose" | "onmessage">>;
export interface AdvancedTradeWebSocketOptions {
  products: string[];
  onTick: (tick: MarketTick) => void;
  onStatus?: (status: AdvancedTradeWsStatus) => void;
  socketFactory?: (url: string) => SocketLike;
  now?: () => number;
}
const decimal = (value: unknown): string | undefined => {
  if (typeof value !== "string" && typeof value !== "number") return undefined;
  const text = String(value);
  return /^\d+(?:\.\d+)?$/.test(text) ? text : undefined;
};
const record = (value: unknown): Record<string, unknown> => value && typeof value === "object" ? value as Record<string, unknown> : {};

/** Public Advanced Trade market stream only. This does not connect to hosted MCP or user channels. */
export class AdvancedTradeWebSocketManager {
  private socket?: SocketLike;
  private reconnectTimer?: ReturnType<typeof setTimeout>;
  private staleTimer?: ReturnType<typeof setInterval>;
  private stableTimer?: ReturnType<typeof setTimeout>;
  private stopped = true;
  private attempt = 0;
  private connectedAt?: number;
  private lastMessageAt?: string;
  private lastTickAt?: string;
  private currentState: AdvancedTradeWsStatus["state"] = "idle";
  readonly products: string[];
  readonly channels = [...CHANNELS];
  private readonly createSocket: (url: string) => SocketLike;
  private readonly now: () => number;
  constructor(private readonly options: AdvancedTradeWebSocketOptions) {
    // Deduplicate and cap subscriptions to avoid accidental broad subscriptions.
    this.products = [...new Set(options.products.filter((id) => /^[A-Z0-9]+-[A-Z0-9]+$/.test(id)))].slice(0, MAX_PRODUCTS);
    this.createSocket = options.socketFactory || ((url) => new WebSocket(url));
    this.now = options.now || Date.now;
  }
  start(): void {
    if (!this.stopped || !this.products.length) return;
    this.stopped = false;
    this.connect(false);
    this.staleTimer = setInterval(() => {
      const last = this.lastTickAt ? Date.parse(this.lastTickAt) : this.connectedAt || 0;
      if (!this.stopped && last && this.now() - last > STALE_AFTER_MS) this.setState("stale", "Ticker data is stale; waiting for a fresh update.");
    }, 5_000);
  }
  stop(): void {
    this.stopped = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.staleTimer) clearInterval(this.staleTimer);
    if (this.stableTimer) clearTimeout(this.stableTimer);
    this.reconnectTimer = undefined;
    this.staleTimer = undefined;
    this.stableTimer = undefined;
    try { this.socket?.close(1000, "client stopped"); } catch { /* already closed */ }
    this.socket = undefined;
    this.setState("closed");
  }
  get status(): AdvancedTradeWsStatus {
    return { state: this.currentState, subscribedProducts: [...this.products], channels: [...this.channels], lastMessageAt: this.lastMessageAt, lastTickAt: this.lastTickAt, reconnectAttempt: this.attempt };
  }
  private setState(state: AdvancedTradeWsStatus["state"], message?: string): void {
    this.currentState = state;
    this.options.onStatus?.({ ...this.status, message });
  }
  private connect(reconnecting: boolean): void {
    if (this.stopped) return;
    this.setState(reconnecting ? "reconnecting" : "connecting");
    let socket: SocketLike;
    try { socket = this.createSocket(ENDPOINT); }
    catch { this.retry("WebSocket construction failed."); return; }
    this.socket = socket;
    socket.onopen = () => {
      if (this.stopped || this.socket !== socket) return;
      this.connectedAt = this.now();
      if (this.stableTimer) clearTimeout(this.stableTimer);
      this.stableTimer = setTimeout(() => { this.attempt = 0; }, 30_000);
      this.setState("connected");
      // Each channel requires its own subscribe message; keep the list deliberately small.
      socket.send(JSON.stringify({ type: "subscribe", channel: "ticker", product_ids: this.products }));
      socket.send(JSON.stringify({ type: "subscribe", channel: "heartbeats" }));
      socket.send(JSON.stringify({ type: "subscribe", channel: "status" }));
    };
    socket.onmessage = (event) => {
      if (this.stopped || this.socket !== socket) return;
      this.lastMessageAt = new Date(this.now()).toISOString();
      let message: Record<string, unknown>;
      try { message = record(JSON.parse(String(event.data))); }
      catch { return; }
      const type = String(message.type || "");
      if (type === "error") { this.setState("error", String(message.message || "Coinbase WebSocket error.")); return; }
      const channel = String(message.channel || "");
      if (channel === "ticker" || channel === "ticker_batch" || type === "ticker") this.consumeTickers(message);
      if (this.currentState === "stale" && channel === "heartbeats") return;
    };
    socket.onerror = () => { if (!this.stopped && this.socket === socket) this.setState("error", "Coinbase WebSocket transport error."); };
    socket.onclose = () => { if (!this.stopped && this.socket === socket) this.retry("Coinbase WebSocket closed."); };
  }
  private consumeTickers(message: Record<string, unknown>): void {
    const now = new Date(this.now()).toISOString();
    const events = Array.isArray(message.events) ? message.events : [];
    for (const rawEvent of events) {
      const event = record(rawEvent);
      const tickers = Array.isArray(event.tickers) ? event.tickers : [];
      for (const rawTicker of tickers) {
        const ticker = record(rawTicker);
        const productId = String(ticker.product_id || ticker.productId || "");
        const price = decimal(ticker.price);
        const timestampRaw = ticker.time || message.timestamp;
        const timestamp = timestampRaw ? new Date(String(timestampRaw)) : new Date(now);
        if (!productId || !this.products.includes(productId) || !price || !Number.isFinite(timestamp.getTime())) continue;
        this.lastTickAt = timestamp.toISOString();
        this.setState("connected");
        this.options.onTick({ productId, price, timestamp: timestamp.toISOString(), source: "coinbase", isLive: true });
      }
    }
  }
  private retry(message: string): void {
    this.socket = undefined;
    if (this.stopped) return;
    if (this.attempt >= MAX_RECONNECTS) { this.setState("error", `${message} Reconnect limit reached.`); return; }
    const delay = Math.min(16_000, 500 * 2 ** this.attempt);
    this.attempt += 1;
    this.setState("reconnecting", `${message} Reconnecting in ${delay} ms.`);
    this.reconnectTimer = setTimeout(() => this.connect(true), delay);
  }
}
