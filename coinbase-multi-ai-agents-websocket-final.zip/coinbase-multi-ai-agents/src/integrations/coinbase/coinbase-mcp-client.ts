import type { CoinbaseStatus } from "@/models/domain";
import { MCP_ENDPOINT } from "@/fixtures/demo";
import { CoinbaseCapabilityRegistry, type DiscoveredCapability } from "./coinbase-capability-registry";
import { classifyCoinbaseFailure, discoverCoinbaseCapabilities, emptyCoinbaseHealth, retryDelayMs } from "./coinbase/models/capability-state";

export interface CoinbaseMcpTransport {
  connect(endpoint: string, signal: AbortSignal): Promise<{
    authorization: "authorized" | "pending";
    capabilities: DiscoveredCapability[];
  }>;
}
const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export class CoinbaseMcpClient {
  readonly endpoint: string;
  readonly registry = new CoinbaseCapabilityRegistry();
  private readonly transport?: CoinbaseMcpTransport;
  constructor(options: { endpoint?: string; transport?: CoinbaseMcpTransport } = {}) {
    this.endpoint = options.endpoint || MCP_ENDPOINT;
    this.transport = options.transport;
  }

  async connect(timeoutMs = 8_000): Promise<CoinbaseStatus> {
    if (!this.transport) {
      return {
        provider: "coinbase-mcp", status: "not-configured", endpoint: this.endpoint,
        authorization: "missing", capabilities: [],
        capabilityState: discoverCoinbaseCapabilities([], false, false),
        health: emptyCoinbaseHealth(),
        message: "No official Coinbase MCP authorization/transport is configured. Demo fixtures are not account data.",
      };
    }
    const startedAt = Date.now();
    let finalError: unknown;
    // A small, finite retry budget. Authentication/permission failures are terminal.
    for (let attempt = 0; attempt < 3; attempt += 1) {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const result = await this.transport.connect(this.endpoint, controller.signal);
        this.registry.replace(result.capabilities);
        const authorized = result.authorization === "authorized";
        const now = new Date().toISOString();
        const capabilities = this.registry.list();
        const names = capabilities.map((capability) => capability.name);
        return {
          provider: "coinbase-mcp",
          status: authorized ? "read-only" : "awaiting-authorization",
          endpoint: this.endpoint,
          authorization: result.authorization,
          capabilities: names,
          capabilityState: discoverCoinbaseCapabilities(capabilities, true, authorized, now),
          health: {
            connectionState: "connected", authenticationState: authorized ? "authorized" : "pending",
            availableCapabilities: names, responseLatencyMs: Date.now() - startedAt,
            rateLimitWarning: false, permissionErrors: 0,
            // Discovering tools is not a successful account-data retrieval.
            syncStatus: "idle",
          },
          lastSyncAt: now,
          message: authorized
            ? "Authorized MCP session connected; only tools actually returned by Coinbase are considered available."
            : "MCP authorization is awaiting user approval; discovered tools are not treated as usable until authorized.",
        };
      } catch (error) {
        finalError = error;
      } finally {
        clearTimeout(timer);
      }
      if (attempt >= 2) break;
      const delay = retryDelayMs(attempt, finalError);
      if (delay === null) break;
      await wait(delay);
    }
    const failure = classifyCoinbaseFailure(finalError);
    return {
      provider: "coinbase-mcp", status: "failed", endpoint: this.endpoint,
      authorization: "missing", capabilities: [],
      capabilityState: discoverCoinbaseCapabilities([], false, false),
      health: {
        ...emptyCoinbaseHealth(), connectionState: "failed", lastFailedRequest: failure,
        responseLatencyMs: Date.now() - startedAt, rateLimitWarning: failure.rateLimited,
        permissionErrors: failure.permissionError ? 1 : 0, syncStatus: "failed",
      },
      message: failure.permissionError
        ? "Coinbase denied this connection. Check account permissions or authorization; authentication failures are not retried."
        : failure.rateLimited
          ? "Coinbase rate-limited the connection attempt. A warning is recorded and retrying is bounded."
          : "Coinbase MCP connection failed after bounded transient retries; no account or market data is shown.",
    };
  }

  async discoverCapabilities(): Promise<DiscoveredCapability[]> {
    return this.registry.list();
  }
}
