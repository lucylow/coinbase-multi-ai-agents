import type { MarketProduct, PortfolioBalance } from "@/models/domain";
import { markets as demoMarkets } from "@/fixtures/demo";
import { HttpAdvancedTradeProvider, type AdvancedTradeAccount, type AdvancedTradeProvider, type CandleGranularity } from "./advancedTradeProvider";

export const DEFAULT_PRODUCTS = ["BTC-USD", "ETH-USD", "SOL-USD", "USDC-USD"] as const;
export type SyncMode = "live-read-only" | "demo-fallback";
export interface MarketSyncResult { mode: SyncMode; asOf: string; markets: MarketProduct[]; discoveredProducts: string[]; unavailableProducts: string[]; granularity: string; intervalMs: number; warning?: string; }
export interface PortfolioSyncResult { mode: SyncMode; asOf: string; balances: PortfolioBalance[]; warning?: string; }

const granularityMs: Record<string, number> = { ONE_MINUTE: 60_000, FIVE_MINUTE: 300_000, FIFTEEN_MINUTE: 900_000, THIRTY_MINUTE: 1_800_000, ONE_HOUR: 3_600_000, TWO_HOUR: 7_200_000, SIX_HOUR: 21_600_000, ONE_DAY: 86_400_000 };
function toMarket(productId: string, product: Awaited<ReturnType<AdvancedTradeProvider["getProduct"]>>, candles: Awaited<ReturnType<AdvancedTradeProvider["getPublicCandles"]>>, intervalMs: number): MarketProduct {
  const price = Number(product.price || candles.at(-1)?.close || 0);
  const first = candles[0]?.close || price;
  const change24h = product.pricePercentageChange24h ?? (first ? ((price - first) / first) * 100 : 0);
  const volume24h = product.volume24h ?? candles.reduce((sum, candle) => sum + candle.volume * candle.close, 0);
  const annualized = candles.length > 2 ? Math.sqrt(24 * 365) * Math.sqrt(candles.slice(1).reduce((sum, candle, index) => {
    const prior = candles[index].close;
    return sum + (prior ? Math.log(candle.close / prior) ** 2 : 0);
  }, 0) / Math.max(candles.length - 1, 1)) * 100 : 0;
  const times = candles.map((candle) => Date.parse(candle.timestamp));
  const missingCandles = times.slice(1).reduce((count, time, index) => count + Math.max(0, Math.round((time - times[index]) / intervalMs) - 1), 0);
  return { productId, status: product.status, tradingDisabled: product.tradingDisabled, baseCurrencyId: product.baseCurrencyId, quoteCurrencyId: product.quoteCurrencyId, source: "coinbase-advanced-trade", dataAsOf: candles.at(-1)?.timestamp, dataQuality: { missingCandles, duplicateCandles: 0, invalidTimestamps: 0 }, price, change24h, volume24h, volatility: annualized > 80 ? "Elevated" : annualized > 35 ? "Moderate" : "Low", candles: candles.map((candle) => ({ time: candle.timestamp, sourceTimestamp: candle.sourceTimestamp, open: candle.open, high: candle.high, low: candle.low, close: candle.close, volume: candle.volume })) };
}

export async function syncPublicMarkets(options: { productIds?: readonly string[]; provider?: AdvancedTradeProvider; now?: Date; start?: string; end?: string; granularity?: CandleGranularity } = {}): Promise<MarketSyncResult> {
  const provider = options.provider || new HttpAdvancedTradeProvider();
  const end = options.now || new Date();
  const granularity = options.granularity || "ONE_HOUR";
  const intervalMs = granularityMs[granularity];
  if (!intervalMs) throw new Error("Unsupported Coinbase candle granularity.");
  const start = options.start ? new Date(options.start) : new Date(end.getTime() - 36 * intervalMs);
  const requestedEnd = options.end ? new Date(options.end) : end;
  if (process.env.NODE_ENV === "test" && !options.provider) {
    return { mode: "demo-fallback", asOf: end.toISOString(), markets: demoMarkets.map((item) => ({ ...item, source: "demo", dataAsOf: end.toISOString(), dataQuality: { missingCandles: 0, duplicateCandles: 0, invalidTimestamps: 0 } })), discoveredProducts: [], unavailableProducts: [...(options.productIds || DEFAULT_PRODUCTS)], granularity, intervalMs, warning: "Test runtime uses seeded demo markets; live Coinbase calls are disabled in tests." };
  }
  try {
    const discovered = await provider.listProducts();
    const available = new Map(discovered.filter((p) => p.status.toLowerCase() === "online").map((p) => [p.productId, p]));
    const selected = options.productIds || [...new Set([...DEFAULT_PRODUCTS, ...discovered.filter((p) => p.quoteCurrencyId === "USD" && p.status.toLowerCase() === "online").map((p) => p.productId)])];
    const supported = selected.filter((productId) => available.has(productId));
    const results = await Promise.allSettled(supported.map(async (productId) => {
      const [product, candles] = await Promise.all([provider.getProduct(productId), provider.getPublicCandles(productId, start.toISOString(), requestedEnd.toISOString(), granularity)]);
      return toMarket(productId, product, candles, intervalMs);
    }));
    const normalized = results.flatMap((result) => result.status === "fulfilled" ? [result.value] : []);
    const unavailableProducts = selected.filter((productId) => !available.has(productId) || !normalized.some((item) => item.productId === productId));
    if (!normalized.length) throw new Error("No requested Coinbase products were available for the selected range.");
    return { mode: "live-read-only", asOf: new Date().toISOString(), markets: normalized, discoveredProducts: discovered.map((p) => p.productId), unavailableProducts, granularity, intervalMs, warning: unavailableProducts.length ? `Unavailable Coinbase products: ${unavailableProducts.join(", ")}` : undefined };
  } catch {
    return { mode: "demo-fallback", asOf: end.toISOString(), markets: demoMarkets.map((item) => ({ ...item, source: "demo", dataAsOf: end.toISOString(), dataQuality: { missingCandles: 0, duplicateCandles: 0, invalidTimestamps: 0 } })), discoveredProducts: [], unavailableProducts: [...(options.productIds || DEFAULT_PRODUCTS)], granularity, intervalMs, warning: "Coinbase public market data was unavailable; seeded demonstration markets are shown instead." };
  }
}

function normalizeAccount(account: AdvancedTradeAccount, price: number): PortfolioBalance {
  const quantity = account.availableBalance;
  return { asset: account.currency, name: account.name || account.currency, productId: `${account.currency}-USD`, quantity, averageCost: price > 0 ? String(price) : "0", price: String(price), change24h: 0 };
}
export async function syncPortfolio(accounts: AdvancedTradeAccount[], prices: Record<string, number>): Promise<PortfolioSyncResult> {
  const balances = accounts.map((account) => normalizeAccount(account, prices[account.currency] || (account.currency === "USD" ? 1 : 0))).filter((item) => Number(item.quantity) > 0 && Number(item.price) > 0);
  return { mode: "live-read-only", asOf: new Date().toISOString(), balances };
}
export { HttpAdvancedTradeProvider };
