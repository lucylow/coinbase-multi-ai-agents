import { createAdvancedTradeRestJwt, type AdvancedTradeCredentials } from "./coinbase-advanced-auth";

export interface AdvancedTradeProduct {
  productId: string; baseCurrencyId: string; quoteCurrencyId: string; status: string;
  price?: string; pricePercentageChange24h?: number; volume24h?: number;
  baseDisplaySymbol?: string; quoteDisplaySymbol?: string;
  productType?: string; tradingDisabled?: boolean;
}
export interface AdvancedTradeCandle {
  timestamp: string; sourceTimestamp: string; open: number; high: number; low: number; close: number; volume: number;
}
export interface AdvancedTradeBook { productId: string; time?: string; bids: Array<{ price: number; size: number }>; asks: Array<{ price: number; size: number }>; }
export interface AdvancedTradeTrade { tradeId: string; productId: string; price: number; size: number; side: string; time: string; sourceTimestamp: string; }
export interface AdvancedTradeAccount { accountId: string; name?: string; currency: string; availableBalance: string; holdBalance: string; }
export type CandleGranularity = "ONE_MINUTE" | "FIVE_MINUTE" | "FIFTEEN_MINUTE" | "THIRTY_MINUTE" | "ONE_HOUR" | "TWO_HOUR" | "SIX_HOUR" | "ONE_DAY";
export interface AdvancedTradeProvider {
  getProduct(productId: string): Promise<AdvancedTradeProduct>;
  listProducts(): Promise<AdvancedTradeProduct[]>;
  getPublicCandles(productId: string, start: string, end: string, granularity: string): Promise<AdvancedTradeCandle[]>;
  getProductBook(productId: string, limit?: number): Promise<AdvancedTradeBook>;
  getBestBidAsk(productIds: string[]): Promise<Array<{ productId: string; bid?: number; ask?: number; time?: string }>>;
  getMarketTrades(productId: string, limit?: number): Promise<AdvancedTradeTrade[]>;
  getAccounts(): Promise<AdvancedTradeAccount[]>;
}
type FetchLike = typeof fetch;
const DEFAULT_BASE_URL = "https://api.coinbase.com";
const object = (value: unknown): Record<string, unknown> => value && typeof value === "object" ? value as Record<string, unknown> : {};
const numeric = (value: unknown, label: string): number => {
  const result = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(result)) throw new Error(`Invalid Coinbase numeric field: ${label}`);
  return result;
};
const utcTimestamp = (value: unknown): { timestamp: string; sourceTimestamp: string } => {
  const raw = String(value ?? "");
  const ms = /^\d+(?:\.\d+)?$/.test(raw) ? Number(raw) * 1000 : Date.parse(raw);
  if (!Number.isFinite(ms)) throw new Error(`Invalid Coinbase timestamp: ${raw}`);
  // Preserve the exact provider representation alongside a normalized UTC ISO value.
  return { timestamp: new Date(ms).toISOString(), sourceTimestamp: raw };
};
const productFrom = (raw: unknown): AdvancedTradeProduct => {
  const p = object(raw); const productId = String(p.product_id || p.productId || "");
  if (!productId) throw new Error("Coinbase product is missing product_id.");
  const numericOrUndefined = (v: unknown) => v == null ? undefined : numeric(v, productId);
  return {
    productId, baseCurrencyId: String(p.base_currency_id || productId.split("-")[0]),
    quoteCurrencyId: String(p.quote_currency_id || productId.split("-")[1] || ""),
    status: String(p.status || "UNKNOWN"), price: p.price == null ? undefined : String(p.price),
    pricePercentageChange24h: numericOrUndefined(p.price_percentage_change_24h),
    volume24h: numericOrUndefined(p.volume_24h), baseDisplaySymbol: p.base_display_symbol == null ? undefined : String(p.base_display_symbol),
    quoteDisplaySymbol: p.quote_display_symbol == null ? undefined : String(p.quote_display_symbol),
    productType: p.product_type == null ? undefined : String(p.product_type), tradingDisabled: Boolean(p.trading_disabled),
  };
};

/** Public Advanced Trade market reads require no credentials. Only account reads sign CDP REST JWTs. */
export class HttpAdvancedTradeProvider implements AdvancedTradeProvider {
  private readonly baseUrl: string; private readonly credentials?: AdvancedTradeCredentials; private readonly fetcher: FetchLike;
  constructor(options: { baseUrl?: string; credentials?: AdvancedTradeCredentials; fetcher?: FetchLike } = {}) {
    this.baseUrl = (options.baseUrl || process.env.COINBASE_ADVANCED_TRADE_URL || DEFAULT_BASE_URL).replace(/\/$/, "");
    this.credentials = options.credentials || (process.env.COINBASE_ADVANCED_API_KEY_NAME && process.env.COINBASE_ADVANCED_API_PRIVATE_KEY
      ? { keyName: process.env.COINBASE_ADVANCED_API_KEY_NAME, privateKey: process.env.COINBASE_ADVANCED_API_PRIVATE_KEY } : undefined);
    this.fetcher = options.fetcher || fetch;
  }
  private async request(path: string, authenticated = false): Promise<Record<string, unknown>> {
    const url = `${this.baseUrl}${path}`;
    if (authenticated && !this.credentials) throw new Error("Coinbase Advanced Trade account reads require separate CDP key-name and private-key credentials.");
    const response = await this.fetcher(url, { headers: { Accept: "application/json", ...(authenticated && this.credentials ? { Authorization: `Bearer ${createAdvancedTradeRestJwt(this.credentials, "GET", url)}` } : {}) }, cache: "no-store", signal: AbortSignal.timeout(6_000) });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(`Coinbase Advanced Trade request failed (${response.status}).`);
    return object(body);
  }
  async getProduct(productId: string): Promise<AdvancedTradeProduct> {
    const body = await this.request(`/api/v3/brokerage/market/products/${encodeURIComponent(productId)}`);
    return productFrom(body.product || body);
  }
  async listProducts(): Promise<AdvancedTradeProduct[]> {
    const body = await this.request("/api/v3/brokerage/market/products?limit=250");
    return (Array.isArray(body.products) ? body.products : []).map(productFrom);
  }
  async getPublicCandles(productId: string, start: string, end: string, granularity: string): Promise<AdvancedTradeCandle[]> {
    const from = Date.parse(start); const to = Date.parse(end);
    if (!Number.isFinite(from) || !Number.isFinite(to) || from >= to) throw new Error("Candle query requires valid start < end timestamps.");
    const query = new URLSearchParams({ start: String(Math.floor(from / 1000)), end: String(Math.floor(to / 1000)), granularity, limit: "350" });
    const body = await this.request(`/api/v3/brokerage/market/products/${encodeURIComponent(productId)}/candles?${query}`);
    const candles = (Array.isArray(body.candles) ? body.candles : []).map((raw) => {
      const c = object(raw); const time = utcTimestamp(c.start);
      return { ...time, open: numeric(c.open, "open"), high: numeric(c.high, "high"), low: numeric(c.low, "low"), close: numeric(c.close, "close"), volume: numeric(c.volume, "volume") };
    });
    return validateCandles(candles);
  }
  async getProductBook(productId: string, limit = 10): Promise<AdvancedTradeBook> {
    const query = new URLSearchParams({ product_id: productId, limit: String(limit) });
    const body = await this.request(`/api/v3/brokerage/market/product_book?${query}`);
    const book = object(body.pricebook || body);
    const levels = (rows: unknown) => (Array.isArray(rows) ? rows : []).map((raw) => {
      const level = object(raw); return { price: numeric(level.price, "book.price"), size: numeric(level.size, "book.size") };
    });
    return { productId: String(book.product_id || productId), time: book.time == null ? undefined : utcTimestamp(book.time).timestamp, bids: levels(book.bids), asks: levels(book.asks) };
  }
  async getBestBidAsk(productIds: string[]): Promise<Array<{ productId: string; bid?: number; ask?: number; time?: string }>> {
    if (!productIds.length) return [];
    const query = new URLSearchParams({ product_ids: productIds.join(",") });
    const body = await this.request(`/api/v3/brokerage/best_bid_ask?${query}`, true);
    const rows = Array.isArray(body.pricebooks) ? body.pricebooks : [];
    return rows.map((raw) => {
      const book = object(raw); const bid = Array.isArray(book.bids) ? object(book.bids[0]) : {}; const ask = Array.isArray(book.asks) ? object(book.asks[0]) : {};
      return { productId: String(book.product_id || ""), bid: bid.price == null ? undefined : numeric(bid.price, "bid"), ask: ask.price == null ? undefined : numeric(ask.price, "ask"), time: book.time == null ? undefined : utcTimestamp(book.time).timestamp };
    });
  }
  async getMarketTrades(productId: string, limit = 100): Promise<AdvancedTradeTrade[]> {
    const query = new URLSearchParams({ limit: String(limit) });
    const body = await this.request(`/api/v3/brokerage/market/products/${encodeURIComponent(productId)}/ticker?${query}`);
    const trades = Array.isArray(body.trades) ? body.trades : [];
    return trades.map((raw) => {
      const t = object(raw); const ts = utcTimestamp(t.time);
      return { tradeId: String(t.trade_id || t.tradeId || ""), productId, price: numeric(t.price, "trade.price"), size: numeric(t.size, "trade.size"), side: String(t.side || "UNKNOWN"), time: ts.timestamp, sourceTimestamp: ts.sourceTimestamp };
    });
  }
  async getAccounts(): Promise<AdvancedTradeAccount[]> {
    const body = await this.request("/api/v3/brokerage/accounts?limit=250", true);
    return (Array.isArray(body.accounts) ? body.accounts : []).map((raw) => {
      const a = object(raw); const available = object(a.available_balance); const hold = object(a.hold);
      return { accountId: String(a.uuid || "unknown"), name: a.name == null ? undefined : String(a.name), currency: String(a.currency || available.currency || "UNKNOWN"), availableBalance: String(available.value || "0"), holdBalance: String(hold.value || "0") };
    });
  }
}

export function validateCandles(candles: AdvancedTradeCandle[]): AdvancedTradeCandle[] {
  const seen = new Set<string>(); const output: AdvancedTradeCandle[] = [];
  for (const candle of [...candles].sort((a, b) => Date.parse(a.timestamp) - Date.parse(b.timestamp))) {
    const time = Date.parse(candle.timestamp);
    const sourceTime = /^\d+(?:\.\d+)?$/.test(candle.sourceTimestamp) ? Number(candle.sourceTimestamp) * 1000 : Date.parse(candle.sourceTimestamp);
    if (!Number.isFinite(time) || !Number.isFinite(sourceTime)) throw new Error("Coinbase candle timestamp is invalid.");
    if (seen.has(candle.timestamp)) throw new Error(`Duplicate Coinbase candle timestamp detected: ${candle.sourceTimestamp}`);
    if (![candle.open, candle.high, candle.low, candle.close, candle.volume].every(Number.isFinite) || candle.open <= 0 || candle.close <= 0 || candle.volume < 0 || candle.high < Math.max(candle.open, candle.close, candle.low) || candle.low > Math.min(candle.open, candle.close)) throw new Error("Coinbase candle has invalid OHLCV values.");
    seen.add(candle.timestamp); output.push(candle);
  }
  return output;
}

export class UnconfiguredAdvancedTradeProvider implements AdvancedTradeProvider {
  private unavailable(): never { throw new Error("Advanced Trade API is not configured; no request was sent."); }
  async getProduct(_productId: string): Promise<AdvancedTradeProduct> { return this.unavailable(); }
  async listProducts(): Promise<AdvancedTradeProduct[]> { return this.unavailable(); }
  async getPublicCandles(_productId: string, _start: string, _end: string, _granularity: string): Promise<AdvancedTradeCandle[]> { return this.unavailable(); }
  async getProductBook(_productId: string, _limit?: number): Promise<AdvancedTradeBook> { return this.unavailable(); }
  async getBestBidAsk(_productIds: string[]): Promise<Array<{ productId: string; bid?: number; ask?: number; time?: string }>> { return this.unavailable(); }
  async getMarketTrades(_productId: string, _limit?: number): Promise<AdvancedTradeTrade[]> { return this.unavailable(); }
  async getAccounts(): Promise<AdvancedTradeAccount[]> { return this.unavailable(); }
}
