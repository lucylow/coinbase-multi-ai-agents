"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  Bell,
  Bot,
  ChartNoAxesCombined,
  FileClock,
  LayoutDashboard,
  Menu,
  RefreshCw,
  Settings,
  Shield,
  UserRound,
  WalletCards,
  X,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";
import type {
  AgentTask,
  AuditEvent,
  CoinbaseStatus,
  MarketProduct,
  TradeProposal,
} from "@/models/domain";
import { balances, markets } from "@/fixtures/demo";
import { simulateAllocation } from "@/services/proposals";
import {
  loadAudit,
  loadProposals,
  loadTasks,
  resetDemoState,
  saveAudit,
  saveProposals,
  saveTasks,
} from "@/services/persistence";
import type { ViewName, ViewProps } from "./views";
import { AdvancedTradeWebSocketManager } from "@/integrations/coinbase/advanced-trade-websocket";
import type { AdvancedTradeWsStatus } from "@/integrations/coinbase/market-data-types";
import {
  AgentsView,
  LedgerView,
  MarketsView,
  OverviewView,
  PortfolioView,
  ProposalsView,
  RiskView,
} from "./views";

type NavItem = { name: ViewName; icon: LucideIcon };
type AdvancedTradeStatus = {
  status: string;
  authentication: string;
  credentialsConfigured: boolean;
  publicCapabilities: string[];
  accountReadConfigured: boolean;
  accountReadValidated: boolean;
  message: string;
};
const navigation: NavItem[] = [
  { name: "Overview", icon: LayoutDashboard },
  { name: "Coinbase Portfolio", icon: WalletCards },
  { name: "Agent Command Center", icon: Bot },
  { name: "Market Intelligence", icon: ChartNoAxesCombined },
  { name: "Risk Intelligence", icon: Shield },
  { name: "Trade Proposals", icon: Activity },
  { name: "Execution Ledger", icon: FileClock },
];

function event(
  action: string,
  outcome: string,
  actor: AuditEvent["actor"],
  references: string[],
  proposalId?: string,
  checks?: string[],
): AuditEvent {
  return {
    id: crypto.randomUUID(),
    timestamp: new Date().toISOString(),
    actor,
    action,
    outcome,
    dataMode: "demo",
    references,
    proposalId,
    checks,
  };
}

export default function CoinbaseApp() {
  const [section, setSection] = useState<ViewName>("Overview");
  const [tasks, setTasks] = useState<AgentTask[]>([]);
  const [proposals, setProposals] = useState<TradeProposal[]>([]);
  const [audit, setAudit] = useState<AuditEvent[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [busy, setBusy] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [noticeOpen, setNoticeOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [connection, setConnection] = useState<CoinbaseStatus | null>(null);
  const [advancedTradeStatus, setAdvancedTradeStatus] = useState<AdvancedTradeStatus | null>(null);
  const [marketSnapshots, setMarketSnapshots] = useState(markets);
  const [marketStreamStatus, setMarketStreamStatus] = useState<AdvancedTradeWsStatus>({ state: "idle", subscribedProducts: [], channels: [], reconnectAttempt: 0 });
  const [error, setError] = useState("");

  useEffect(() => {
    let stream: AdvancedTradeWebSocketManager | undefined;
    const savedTasks = loadTasks();
    setTasks(savedTasks);
    setProposals(loadProposals());
    const savedAudit = loadAudit();
    setAudit(savedAudit);
    setHydrated(true);
    void fetch("/api/markets/live")
      .then((response) => response.json())
      .then((payload: { data?: { markets?: typeof markets } }) => {
        if (payload.data?.markets?.length) setMarketSnapshots(payload.data.markets);
        const supported = payload.data?.markets?.filter((market) => market.source === "coinbase-advanced-trade").map((market) => market.productId).slice(0, 3) || [];
        if (supported.length) {
          stream = new AdvancedTradeWebSocketManager({
            products: supported,
            onStatus: setMarketStreamStatus,
            onTick: (tick) => setMarketSnapshots((previous) => previous.map((market) => market.productId === tick.productId
              ? { ...market, price: Number(tick.price), source: "coinbase-advanced-trade", dataAsOf: tick.timestamp }
              : market)),
          });
          stream.start();
        }
      })
      .catch(() => setMarketSnapshots(markets));
    void fetch("/api/coinbase/status")
      .then((response) => response.json())
      .then((payload: { data?: { mcp?: CoinbaseStatus; advancedTrade?: AdvancedTradeStatus } }) => {
        setConnection(payload.data?.mcp ?? null);
        setAdvancedTradeStatus(payload.data?.advancedTrade ?? null);
      })
      .catch(() => {
        setConnection(null);
        setAdvancedTradeStatus(null);
      });
    if (savedTasks.length === 0) {
      void fetch("/api/agents/tasks")
        .then((response) => response.json())
        .then((payload: { ok: boolean; data?: AgentTask[] }) => {
          if (!payload.ok || !payload.data?.length) return;
          saveTasks(payload.data);
          setTasks(payload.data);
          if (savedAudit.length === 0) {
            const seeded = event(
              "Five sample investigations loaded",
              "Deterministic DEMO AGENT SIMULATION reports; no provider data was accessed.",
              "system",
              payload.data.map((task) => task.id),
            );
            saveAudit([seeded]);
            setAudit([seeded]);
          }
        })
        .catch(() => undefined);
    }
    return () => stream?.stop();
  }, []);

  const persistTasks = (value: AgentTask[]) => {
    setTasks(value);
    saveTasks(value);
  };
  const persistProposals = (value: TradeProposal[]) => {
    setProposals(value);
    saveProposals(value);
  };
  const persistAudit = (value: AuditEvent[]) => {
    setAudit(value);
    saveAudit(value);
  };
  const addAudit = (item: AuditEvent) =>
    setAudit((previous) => {
      const next = [item, ...previous].slice(0, 100);
      saveAudit(next);
      return next;
    });

  const runInvestigation = async (
    objective = "Analyze my Coinbase portfolio and evaluate whether current allocation has excessive concentration.",
  ) => {
    setBusy(true);
    setError("");
    setSection("Agent Command Center");
    const pending: AgentTask = {
      id: `RUN-${crypto.randomUUID().slice(0, 8).toUpperCase()}`,
      objective,
      productIds: ["BTC-USD", "ETH-USD", "SOL-USD"],
      mode: "demo",
      status: "running",
      createdAt: new Date().toISOString(),
      findings: [],
      riskFlags: [],
    };
    persistTasks(
      [pending, ...tasks.filter((task) => task.status !== "running")].slice(
        0,
        30,
      ),
    );
    addAudit(
      event(
        "Five-agent investigation started",
        "Parallel research started in the DEMO AGENT SIMULATION workflow.",
        "agent",
        [pending.id, "demo:portfolio", "demo:markets"],
      ),
    );
    try {
      const startedAt = Date.now();
      const response = await fetch("/api/agents/investigate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ objective }),
      });
      const result = (await response.json()) as {
        ok: boolean;
        data?: AgentTask;
        error?: { message?: string };
      };
      if (!response.ok || !result.ok || !result.data)
        throw new Error(
          result.error?.message || "Analysis could not be completed.",
        );
      await new Promise((resolve) =>
        setTimeout(resolve, Math.max(0, 650 - (Date.now() - startedAt))),
      );
      const task = result.data;
      persistTasks(
        [task, ...tasks.filter((previous) => previous.id !== pending.id)].slice(
          0,
          30,
        ),
      );
      addAudit(
        event(
          "Five-agent investigation completed",
          task.finalRecommendation || "Research complete.",
          "agent",
          [
            task.id,
            ...task.findings.flatMap((finding) => finding.evidenceRefs),
          ],
        ),
      );
    } catch (caught) {
      const failed = {
        ...pending,
        status: "failed" as const,
        completedAt: new Date().toISOString(),
      };
      persistTasks(
        [
          failed,
          ...tasks.filter((previous) => previous.id !== pending.id),
        ].slice(0, 30),
      );
      addAudit(
        event(
          "Five-agent investigation failed",
          "No completed report was saved. Retry after correcting the request or service issue.",
          "system",
          [pending.id],
        ),
      );
      setError(
        caught instanceof Error
          ? caught.message
          : "Analysis failed. Please try again.",
      );
    } finally {
      setBusy(false);
    }
  };

  const createProposal = async () => {
    setError("");
    try {
      const response = await fetch("/api/proposals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productId: "ETH-USD",
          side: "BUY",
          orderType: "MARKET",
          proposedSize: "0.1",
          rationale:
            "Hypothetical small-size exposure review; not an investment recommendation.",
        }),
      });
      const result = (await response.json()) as {
        ok: boolean;
        data?: { proposal: TradeProposal; policy: { checks: string[] } };
        error?: { message?: string };
      };
      if (!response.ok || !result.ok || !result.data)
        throw new Error(
          result.error?.message || "Proposal could not be created.",
        );
      const proposal = result.data.proposal;
      persistProposals([proposal, ...proposals]);
      addAudit(
        event(
          "Simulation proposal created",
          `Policy status: ${proposal.riskStatus}; no Coinbase order was sent.`,
          "agent",
          [proposal.productId, "security:simulation-only"],
          proposal.id,
          result.data.policy.checks,
        ),
      );
      setSection("Trade Proposals");
    } catch (caught) {
      setError(
        caught instanceof Error
          ? caught.message
          : "Proposal could not be created.",
      );
    }
  };

  const decideProposal = async (
    id: string,
    decision: "approve" | "reject" | "analyze",
  ) => {
    const proposal = proposals.find((item) => item.id === id);
    if (!proposal) return;
    if (decision === "analyze") {
      const nextProposal = {
        ...proposal,
        reviewDecision: "analysis-requested" as const,
      };
      persistProposals(
        proposals.map((item) => (item.id === id ? nextProposal : item)),
      );
      addAudit(
        event(
          "Additional analysis requested",
          "A new five-agent review was started; proposal remains simulation-only.",
          "user",
          [id, proposal.productId],
          id,
        ),
      );
      await runInvestigation(
        `Review proposal ${id}: ${proposal.side} ${proposal.proposedSize} ${proposal.productId}; challenge the rationale and risks.`,
      );
      return;
    }
    if (decision === "reject") {
      const nextProposal = { ...proposal, reviewDecision: "rejected" as const };
      persistProposals(
        proposals.map((item) => (item.id === id ? nextProposal : item)),
      );
      addAudit(
        event(
          "Proposal rejected",
          "Rejected in the demo workspace. No exchange request was made.",
          "user",
          [id],
          id,
        ),
      );
      return;
    }
    if (proposal.riskStatus === "rejected") {
      setError(
        "This proposal was blocked by the independent policy engine and cannot be approved for simulation.",
      );
      return;
    }
    const market = markets.find(
      (item) => item.productId === proposal.productId,
    );
    if (!market) {
      setError("A synthetic price snapshot is unavailable for this product.");
      return;
    }
    const expectedPrice =
      proposal.orderType === "LIMIT" && proposal.proposedPrice
        ? Number(proposal.proposedPrice)
        : market.price;
    const preview = simulateAllocation(proposal, balances, expectedPrice);
    const nextProposal: TradeProposal = {
      ...proposal,
      reviewDecision: "approved-for-simulation",
      preview,
    };
    persistProposals(
      proposals.map((item) => (item.id === id ? nextProposal : item)),
    );
    addAudit(
      event(
        "Proposal approved for simulation",
        `Hypothetical preview generated only. No Coinbase order, transfer, or execution receipt exists. Estimated notional ${(proposal.notionalCents / 100).toFixed(2)} USD.`,
        "user",
        [id, proposal.productId, "security:no-financial-write"],
        id,
        [
          "Independent policy passed for simulation",
          "Human reviewed simulation only",
          "No external financial write",
        ],
      ),
    );
  };

  const resetWorkspace = () => {
    if (
      !window.confirm(
        "Reset the demo workspace? This clears browser-local analysis, proposals, and audit history only.",
      )
    )
      return;
    resetDemoState();
    setTasks([]);
    setProposals([]);
    setAudit([]);
    setError("");
    setProfileOpen(false);
    setSection("Overview");
  };

  const viewProps: ViewProps = useMemo(
    () => ({
      balances,
      markets: marketSnapshots,
      marketStreamStatus,
      tasks,
      proposals,
      audit,
      busy,
      onRunInvestigation: runInvestigation,
      onCreateProposal: createProposal,
      onProposalDecision: decideProposal,
    }),
    [tasks, proposals, audit, busy, marketSnapshots, marketStreamStatus],
  );
  const page =
    section === "Overview" ? (
      <OverviewView {...viewProps} />
    ) : section === "Coinbase Portfolio" ? (
      <PortfolioView {...viewProps} />
    ) : section === "Agent Command Center" ? (
      <AgentsView {...viewProps} />
    ) : section === "Market Intelligence" ? (
      <MarketsView {...viewProps} />
    ) : section === "Risk Intelligence" ? (
      <RiskView {...viewProps} />
    ) : section === "Trade Proposals" ? (
      <ProposalsView {...viewProps} />
    ) : (
      <LedgerView {...viewProps} />
    );

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNavOpen ? "mobile-open" : ""}`}>
        <div className="brand">
          <span className="brand-mark">
            <i />
            <i />
            <i />
          </span>
          <div className="brand-name">
            <b>COINBASE INTELLIGENCE</b>
            <small>RESEARCH WORKSTATION</small>
          </div>
          <button
            aria-label="Close navigation"
            className="icon-button mobile-close"
            onClick={() => setMobileNavOpen(false)}
          >
            <X size={17} />
          </button>
        </div>
        <div className="nav-label">WORKSPACE</div>
        <nav className="nav-list" aria-label="Primary navigation">
          {navigation.map(({ name, icon: Icon }) => (
            <button
              key={name}
              className={`nav-button ${section === name ? "active" : ""}`}
              onClick={() => {
                setSection(name);
                setMobileNavOpen(false);
              }}
            >
              <Icon size={16} />
              <span>{name}</span>
            </button>
          ))}
        </nav>
        <div className="nav-spacer" />
        <div className="sidebar-bottom">
          <div className="mode-card">
            <span className="mode-orb" />
            <div>
              <b>DEMO MODE ACTIVE</b>
              <small>Synthetic fixtures only</small>
            </div>
          </div>
          <div className="sidebar-foot">
            Independent research tool · not affiliated with Coinbase
          </div>
        </div>
      </aside>
      <div className="main-wrap">
        <header className="topbar">
          <div className="top-context">
            <button
              aria-label="Open navigation"
              className="top-icon mobile-menu"
              onClick={() => setMobileNavOpen(true)}
            >
              <Menu size={17} />
            </button>
            <span>Coinbase Intelligence</span>
            <span className="slash">/</span>
            <span>{section}</span>
            <span className="status-pill">
              <i className="status-dot" />
              {connection?.status === "connected" ||
              connection?.status === "read-only"
                ? "CONNECTED"
                : "DISCONNECTED"}
            </span>
            <span className="agent-indicator">
              <i />
              {busy ? "AGENTS WORKING" : "AGENTS READY"}
            </span>
          </div>
          <div className="top-actions">
            <span className="account-chip">COINBASE · DEMO</span>
            <button
              aria-label="Notifications"
              className="top-icon"
              onClick={() => {
                setNoticeOpen(!noticeOpen);
                setProfileOpen(false);
              }}
            >
              <Bell size={15} />
            </button>
            <button
              aria-label="Integration settings"
              className="top-icon"
              onClick={() => {
                setSettingsOpen(true);
                setNoticeOpen(false);
              }}
            >
              <Settings size={15} />
            </button>
            <button
              aria-label="User menu"
              className="top-icon"
              onClick={() => {
                setProfileOpen(!profileOpen);
                setNoticeOpen(false);
              }}
            >
              <UserRound size={15} />
            </button>
          </div>
          {noticeOpen && (
            <div className="header-popover">
              <b>Workspace notice</b>
              <span>
                Demo data active. Live Coinbase authorization is not configured.
              </span>
            </div>
          )}
          {profileOpen && (
            <div className="header-popover profile-popover">
              <b>Demo Operator</b>
              <span>Local research workspace</span>
              <button onClick={resetWorkspace}>
                <RefreshCw size={13} /> Reset demo workspace
              </button>
            </div>
          )}
        </header>
        <main className="content">
          {!hydrated ? (
            <div className="skeleton-note">Loading demo workspace…</div>
          ) : (
            page
          )}
          {error && (
            <div className="toast-error" role="alert">
              <span>{error}</span>
              <button aria-label="Dismiss error" onClick={() => setError("")}>
                <X size={14} />
              </button>
            </div>
          )}
        </main>
      </div>
      {settingsOpen && (
        <div
          className="modal-backdrop"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setSettingsOpen(false);
          }}
        >
          <aside className="settings-panel">
            <div className="settings-head">
              <div>
                <div className="eyebrow">CONNECTIONS & PREFERENCES</div>
                <h2>Integration settings</h2>
                <p>
                  Demo mode is always available; live access is never implied.
                </p>
              </div>
              <button
                className="icon-button"
                aria-label="Close settings"
                onClick={() => setSettingsOpen(false)}
              >
                <X size={17} />
              </button>
            </div>
            <div className="settings-section">
              <h3>Coinbase MCP</h3>
              <div className="connection-row">
                <Activity size={15} />
                <div>
                  <b>
                    {connection?.status === "connected" ||
                    connection?.status === "read-only"
                      ? "Read-only connected"
                      : connection?.status === "awaiting-authorization"
                        ? "Awaiting authorization"
                        : connection?.status === "failed"
                          ? "Connection failed"
                          : "Not configured"}
                  </b>
                  <span>
                    {connection?.message ||
                      "No authorization detected. No account data is being retrieved."}
                  </span>
                </div>
              </div>
              <div className="endpoint">
                {connection?.endpoint || "https://agents.coinbase.com/mcp"}
              </div>
              <div className="capability-box">
                <div>
                  <span>Authorization</span>
                  <b>{connection?.authorization?.toUpperCase() || "MISSING"}</b>
                </div>
                <div>
                  <span>Discovered capabilities</span>
                  <section>
                    {connection?.capabilities.length ? (
                      connection.capabilities.map((name) => (
                        <span className="tag" key={name}>
                          {name}
                        </span>
                      ))
                    ) : (
                      <span className="tag amber">NONE DISCOVERED</span>
                    )}
                  </section>
                </div>
                <small>
                  Last capability validation: {" "}
                  {connection?.capabilityState?.lastValidatedAt
                    ? new Date(connection.capabilityState.lastValidatedAt).toLocaleString()
                    : "Never"}
                </small>
              </div>
              <div className="capability-box">
                <div>
                  <span>Discovered access</span>
                  <section>
                    {([
                      ["Account read", connection?.capabilityState?.accountRead],
                      ["Portfolio read", connection?.capabilityState?.portfolioRead],
                      ["Market data", connection?.capabilityState?.marketData],
                      ["Product information", connection?.capabilityState?.productInfo],
                      ["Order preview", connection?.capabilityState?.orderPreview],
                      ["Order management", connection?.capabilityState?.orderManagement],
                      ["Trading", connection?.capabilityState?.trading],
                      ["x402 research payment", connection?.capabilityState?.x402Research],
                    ] as [string, boolean | undefined][]).map(([label, available]) => (
                      <span className={`tag ${available ? "" : "amber"}`} key={label}>
                        {label}: {available ? "available" : "not discovered"}
                      </span>
                    ))}
                  </section>
                </div>
                <small>
                  Missing: {connection?.capabilityState?.missingCapabilities?.join(", ") || "none reported"}
                </small>
                {(connection?.capabilityState?.regionEligibility || connection?.capabilityState?.accountEligibility) && (
                  <small>
                    Eligibility: {connection.capabilityState.regionEligibility || "region not exposed"} · {connection.capabilityState.accountEligibility || "account not exposed"}
                  </small>
                )}
              </div>
              <div className="capability-box">
                <div><span>Connection / authentication</span><b>{connection?.health?.connectionState || "unknown"} / {connection?.health?.authenticationState || connection?.authorization || "unknown"}</b></div>
                <div><span>Data synchronization</span><b>{connection?.health?.syncStatus || "unknown"}</b></div>
                <div><span>API response latency</span><b>{connection?.health?.responseLatencyMs !== undefined ? `${connection.health.responseLatencyMs} ms` : "Not measured"}</b></div>
                <div><span>Last successful data retrieval</span><b>{connection?.health?.lastSuccessfulDataRetrieval ? new Date(connection.health.lastSuccessfulDataRetrieval).toLocaleString() : "Never"}</b></div>
                <div><span>Rate limit warning / permission errors</span><b>{connection?.health ? `${connection.health.rateLimitWarning ? "Yes" : "No"} / ${connection.health.permissionErrors}` : "No health data"}</b></div>
                {connection?.health?.lastFailedRequest && (
                  <small className="amber">Last failed request ({new Date(connection.health.lastFailedRequest.at).toLocaleString()}): {connection.health.lastFailedRequest.message}</small>
                )}
              </div>
              <p className="settings-foot">
                Capabilities remain unavailable unless exposed by the authorized session. Discovery time is not reported as an account-data retrieval; this panel does not poll the hosted MCP endpoint.
              </p>
            </div>
            <div className="settings-section">
              <h3>Advanced Trade API</h3>
              <div className="connection-row">
                <WalletCards size={15} />
                <div>
                  <b>{advancedTradeStatus?.credentialsConfigured ? "CDP credentials configured · not yet validated" : "Public REST available · account credentials not configured"}</b>
                  <span>{advancedTradeStatus?.message || "Advanced Trade REST uses its own CDP credentials; they are never shared with Coinbase for Agents MCP."}</span>
                </div>
              </div>
              <div className="capability-box">
                <div><span>Authentication</span><b>{advancedTradeStatus?.authentication || "Separate CDP key + request-bound JWT"}</b></div>
                <div><span>Public capabilities</span><section>{(advancedTradeStatus?.publicCapabilities || ["product-information", "market-data", "candles"]).map((capability) => <span className="tag" key={capability}>{capability}</span>)}</section></div>
                <div><span>Account-read status</span><b>{advancedTradeStatus?.accountReadValidated ? "validated by Coinbase response" : advancedTradeStatus?.accountReadConfigured ? "credentials present; permissions unvalidated" : "CDP credentials missing"}</b></div>
              </div>
              <p className="settings-foot">
                REST product, candle, and account-read routes are separate from MCP. Trading/order methods are not exposed by this adapter; credential presence alone does not prove account permission.
              </p>
            </div>
            <div className="settings-section">
              <h3>Execution policy</h3>
              <div className="connection-row">
                <Shield size={15} />
                <div>
                  <b>Live execution disabled</b>
                  <span>
                    No order submission, withdrawal, deposit, transfer, or swap
                    route exists.
                  </span>
                </div>
              </div>
              <button className="button secondary" onClick={resetWorkspace}>
                <RefreshCw size={14} /> Reset demo workspace
              </button>
            </div>
            <p className="settings-foot">
              For a future live-read-only phase, configure Coinbase's official
              authorization and verify available MCP capabilities. Never put
              credentials in client code.
            </p>
          </aside>
        </div>
      )}
    </div>
  );
}
