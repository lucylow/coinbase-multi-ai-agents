"use client";

import React, { useState } from "react";
import {
  AlertTriangle,
  ArrowUpRight,
  CheckCircle2,
  ChevronDown,
  CircleHelp,
  Clock3,
  FileSearch,
  Gauge,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  WalletCards,
} from "lucide-react";
import type {
  AgentTask,
  AuditEvent,
  MarketProduct,
  PortfolioBalance,
  TradeProposal,
} from "@/models/domain";
import type { AdvancedTradeWsStatus } from "@/integrations/coinbase/market-data-types";
import {
  portfolioMetrics,
  formatMoney,
  historicalVolatility,
  rsi,
  atr,
  maxDrawdown,
  movingAverage,
  concentration,
} from "@/services/analytics";
import {
  applyMarketScenario,
  SCENARIOS,
  type MarketScenario,
} from "@/services/scenarios";
import { AllocationChart, PriceChart } from "./charts";

export type ViewName =
  | "Overview"
  | "Coinbase Portfolio"
  | "Agent Command Center"
  | "Market Intelligence"
  | "Risk Intelligence"
  | "Trade Proposals"
  | "Execution Ledger";
export interface ViewProps {
  balances: PortfolioBalance[];
  markets: MarketProduct[];
  marketStreamStatus?: AdvancedTradeWsStatus;
  tasks: AgentTask[];
  proposals: TradeProposal[];
  audit: AuditEvent[];
  busy: boolean;
  onRunInvestigation: (objective?: string) => void;
  onCreateProposal: () => void;
  onProposalDecision: (
    id: string,
    decision: "approve" | "reject" | "analyze",
  ) => void;
}

const presets = [
  "Analyze portfolio concentration and major exposure risks.",
  "Compare BTC and ETH volatility in the synthetic sample.",
  "Analyze the effect of a simulated 10% BTC decline.",
];

function SectionTitle({
  eyebrow,
  title,
  text,
  action,
}: {
  eyebrow: string;
  title: string;
  text: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="section-title">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{text}</p>
      </div>
      {action}
    </div>
  );
}

function Metric({
  label,
  value,
  change,
  icon: Icon,
  tone = "blue",
}: {
  label: string;
  value: string;
  change?: string;
  icon: React.ElementType;
  tone?: string;
}) {
  return (
    <div className="metric-card">
      <div className={`metric-icon ${tone}`}>
        <Icon size={17} />
      </div>
      <div className="metric-label">{label}</div>
      <div className="metric-value mono">{value}</div>
      {change && <div className="metric-foot">{change}</div>}
    </div>
  );
}

function Tag({
  children,
  tone = "muted",
}: {
  children: React.ReactNode;
  tone?: string;
}) {
  return <span className={`tag ${tone}`}>{children}</span>;
}

function Panel({
  title,
  subtitle,
  action,
  children,
  className = "",
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`panel ${className}`}>
      <div className="panel-heading">
        <div>
          <h2>{title}</h2>
          {subtitle && <p>{subtitle}</p>}
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function MarketStrip({ markets }: { markets: MarketProduct[] }) {
  return (
    <div className="market-strip">
      {markets.slice(0, 4).map((item) => (
        <div className="market-chip" key={item.productId}>
          <div className="market-chip-top">
            <span>{item.productId}</span>
            <Tag>{item.source === "coinbase-advanced-trade" ? "LIVE" : "DEMO"}</Tag>
          </div>
          <strong className="mono">
            ${item.price.toLocaleString("en-US", { maximumFractionDigits: 2 })}
          </strong>
          <span className={item.change24h >= 0 ? "positive" : "negative"}>
            {item.change24h >= 0 ? "+" : ""}
            {item.change24h.toFixed(2)}%
          </span>
        </div>
      ))}
    </div>
  );
}

export function OverviewView(props: ViewProps) {
  const metrics = portfolioMetrics(props.balances);
  const selected =
    props.markets.find((item) => item.productId === "BTC-USD") ||
    props.markets[0];
  const recent = props.audit.slice(0, 4);
  const dailyMovePct = metrics.rows.reduce(
    (sum, row) => sum + row.allocation * row.change24h,
    0,
  );
  const roster = [
    {
      id: "portfolio-analyst",
      name: "Portfolio Analyst",
      role: "Allocation and PnL",
    },
    {
      id: "market-intelligence",
      name: "Market Intelligence",
      role: "Coinbase pair research",
    },
    {
      id: "quant-research",
      name: "Quant Research",
      role: "Indicators and scenarios",
    },
    { id: "risk-officer", name: "Risk Officer", role: "Adversarial challenge" },
    {
      id: "verification-audit",
      name: "Verification & Audit",
      role: "Independent review",
    },
  ];
  return (
    <>
      <SectionTitle
        eyebrow="COMMAND OVERVIEW · SYNTHETIC WORKSPACE"
        title="Portfolio intelligence"
        text="A transparent demo view of your Coinbase research environment."
        action={
          <button
            className="button primary"
            onClick={() => props.onRunInvestigation()}
            disabled={props.busy}
          >
            <Sparkles size={16} />
            {props.busy ? "Analysis running…" : "Run multi-agent analysis"}
          </button>
        }
      />
      <div className="banner demo-banner">
        <span className="banner-dot" />
        <div>
          <strong>DEMO MODE</strong>
          <span>
            {" "}
            All portfolio and market figures below are synthetic fixtures — not
            Coinbase account balances or live prices.
          </span>
        </div>
      </div>
      <div className="metric-grid four">
        <Metric
          label="Demo portfolio value"
          value={formatMoney(metrics.totalCents, { compact: true })}
          change="Coinbase Demo Portfolio 01"
          icon={WalletCards}
        />
        <Metric
          label="Unrealized PnL"
          value={formatMoney(metrics.totalPnlCents)}
          change={`Daily simulated move ${dailyMovePct > 0 ? "+" : ""}${dailyMovePct.toFixed(2)}% · synthetic`}
          icon={TrendingUp}
          tone="green"
        />
        <Metric
          label="Available stablecoin"
          value={formatMoney(
            metrics.rows.find((row) => row.asset === "USDC")?.valueCents ?? 0,
          )}
          change="USDC · synthetic balance"
          icon={Gauge}
          tone="cyan"
        />
        <Metric
          label="Largest exposure"
          value={`${(Math.max(...metrics.rows.map((row) => row.allocation)) * 100).toFixed(0)}%`}
          change="BTC concentration · review"
          icon={AlertTriangle}
          tone="amber"
        />
      </div>
      <div className="content-grid two-one">
        <Panel
          title="Market pulse"
          subtitle="36-hour synthetic BTC-USD sample"
          action={<Tag>DEMO SNAPSHOT</Tag>}
        >
          {selected && (
            <>
              <PriceChart market={selected} />
              <div className="chart-footer">
                <span>
                  Sample only · fixture timestamp 05 Nov 2026 20:00 UTC
                </span>
                <span className="market-price">
                  ${selected.price.toLocaleString()}{" "}
                  <i
                    className={
                      selected.change24h >= 0 ? "positive" : "negative"
                    }
                  >
                    {selected.change24h > 0 ? "+" : ""}
                    {selected.change24h.toFixed(2)}%
                  </i>
                </span>
              </div>
            </>
          )}
        </Panel>
        <Panel title="Allocation" subtitle="Weight by synthetic market value">
          <div className="allocation-wrap">
            <AllocationChart items={props.balances} />
            <div className="allocation-legend">
              {metrics.rows.map((row, index) => (
                <div key={row.asset} className="legend-row">
                  <span className={`legend-dot color-${index}`} />
                  <span>{row.asset}</span>
                  <b>{(row.allocation * 100).toFixed(1)}%</b>
                </div>
              ))}
            </div>
          </div>
        </Panel>
      </div>
      <div className="content-grid two-one">
        <Panel
          title="Market watch"
          subtitle="Coinbase pair naming · fixtures only"
        >
          <MarketStrip markets={props.markets} />
        </Panel>
        <Panel
          title="Agent activity"
          subtitle="Persisted demo workspace"
          action={<Tag tone="green">{props.tasks.length} RUNS</Tag>}
        >
          {recent.length ? (
            <div className="activity-list">
              {recent.map((item) => (
                <div className="activity-row" key={item.id}>
                  <span className="activity-dot" />
                  <div>
                    <b>{item.action}</b>
                    <span>{item.outcome}</span>
                  </div>
                  <time>
                    {new Date(item.timestamp).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </time>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-note">
              Start an investigation to create the first auditable event.
            </div>
          )}
        </Panel>
      </div>
      <Panel
        title="Specialist agent status"
        subtitle="Five independent read-only research roles · deterministic demo execution"
      >
        <div className="agent-status-grid">
          {roster.map((agent) => {
            const completed = props.tasks.filter(
              (task) =>
                task.status === "completed" &&
                task.findings.some((item) => item.agentId === agent.id),
            );
            const latestTask = completed[0];
            const finding = latestTask?.findings.find(
              (item) => item.agentId === agent.id,
            );
            const running = props.tasks.find(
              (task) => task.status === "running",
            );
            return (
              <div className="agent-status-card" key={agent.id}>
                <div>
                  <b>{agent.name}</b>
                  <small>{agent.role}</small>
                </div>
                <span
                  className={`agent-state ${running ? "running" : latestTask ? "completed" : "idle"}`}
                >
                  {running ? "RUNNING" : latestTask ? "DONE" : "READY"}
                </span>
                <small className="agent-snapshot">
                  {completed.length} tasks ·{" "}
                  {finding
                    ? `${Math.round(finding.confidence * 100)}% confidence`
                    : "no completed run"}
                </small>
                <p>
                  {running
                    ? `Current task: ${running.objective}`
                    : finding?.summary || "Waiting for an investigation task."}
                </p>
                <small className="agent-last">
                  {latestTask?.completedAt
                    ? `Last active ${new Date(latestTask.completedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
                    : "Last active —"}
                </small>
              </div>
            );
          })}
        </div>
      </Panel>
    </>
  );
}

export function PortfolioView({ balances }: ViewProps) {
  const metrics = portfolioMetrics(balances);
  return (
    <>
      <SectionTitle
        eyebrow="COINBASE ACCOUNT CONTEXT"
        title="Portfolio"
        text="Fictional seeded balances, separated from any authorized Coinbase account."
      />
      <div className="banner demo-banner">
        <span className="banner-dot" />
        <div>
          <strong>Coinbase Demo Portfolio 01</strong>
          <span>
            {" "}
            Synthetic account · snapshot 05 Nov 2026 20:00 UTC · no live
            credentials configured.
          </span>
        </div>
      </div>
      <div className="content-grid two-one">
        <Panel
          title="Allocation map"
          subtitle="Synthetic mark-to-fixture value"
        >
          <div className="allocation-wrap large">
            <AllocationChart items={balances} />
            <div className="allocation-legend">
              {metrics.rows.map((row, index) => (
                <div key={row.asset} className="legend-row">
                  <span className={`legend-dot color-${index}`} />
                  <span>{row.name}</span>
                  <b>{(row.allocation * 100).toFixed(1)}%</b>
                </div>
              ))}
            </div>
          </div>
        </Panel>
        <Panel title="Portfolio summary" subtitle="No account sync performed">
          <div className="summary-list">
            <div>
              <span>Total value</span>
              <b className="mono">{formatMoney(metrics.totalCents)}</b>
            </div>
            <div>
              <span>Unrealized demo PnL</span>
              <b
                className={`mono ${metrics.totalPnlCents >= 0 ? "positive" : "negative"}`}
              >
                {metrics.totalPnlCents >= 0 ? "+" : ""}
                {formatMoney(metrics.totalPnlCents)}
              </b>
            </div>
            <div>
              <span>Source</span>
              <Tag>FIXTURE</Tag>
            </div>
            <div>
              <span>Live sync</span>
              <Tag tone="amber">NOT CONFIGURED</Tag>
            </div>
          </div>
          <div className="note-box">
            <CircleHelp size={16} />
            <span>
              Connecting is not simulated: configure official Coinbase
              authorization before any live read-only data can appear.
            </span>
          </div>
        </Panel>
      </div>
      <Panel
        title="Asset balances"
        subtitle="Quantity, fixture price, demo value and unrealized PnL"
      >
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Asset</th>
                <th>Quantity</th>
                <th>Demo price</th>
                <th>Value</th>
                <th>Unrealized PnL</th>
                <th>Allocation</th>
              </tr>
            </thead>
            <tbody>
              {metrics.rows.map((row) => (
                <tr key={row.asset}>
                  <td>
                    <div className="asset-name">
                      <span className="asset-symbol">
                        {row.asset.slice(0, 1)}
                      </span>
                      <div>
                        <b>{row.name}</b>
                        <small>{row.productId}</small>
                      </div>
                    </div>
                  </td>
                  <td className="mono">
                    {row.quantity} {row.asset}
                  </td>
                  <td className="mono">
                    ${Number(row.price).toLocaleString()}
                  </td>
                  <td className="mono">{formatMoney(row.valueCents)}</td>
                  <td
                    className={`mono ${row.pnlCents >= 0 ? "positive" : "negative"}`}
                  >
                    {row.pnlCents >= 0 ? "+" : ""}
                    {formatMoney(row.pnlCents)}
                  </td>
                  <td>
                    <div className="allocation-cell">
                      <span>{(row.allocation * 100).toFixed(1)}%</span>
                      <div>
                        <i style={{ width: `${row.allocation * 100}%` }} />
                      </div>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </>
  );
}

export function AgentsView({ tasks, busy, onRunInvestigation }: ViewProps) {
  const [objective, setObjective] = useState("");
  const [selectedTaskId, setSelectedTaskId] = useState<string | undefined>();
  const selected =
    tasks.find((task) => task.status === "running") ||
    tasks.find((task) => task.id === selectedTaskId) ||
    tasks[0];
  return (
    <>
      <SectionTitle
        eyebrow="HIERARCHICAL RESEARCH PIPELINE"
        title="Agent command center"
        text="Parallel research, then a risk challenge and independent verification."
        action={
          <button
            className="button primary"
            disabled={busy}
            onClick={() => onRunInvestigation()}
          >
            <Sparkles size={16} />
            {busy ? "Orchestrating…" : "Start investigation"}
          </button>
        }
      />
      <div className="banner agent-banner">
        <Sparkles size={16} />
        <span>
          <strong>DEMO AGENT SIMULATION</strong> · deterministic calculations
          over seeded data; no external LLM is running.
        </span>
      </div>
      {busy && (
        <div className="run-progress">
          <span className="progress-pulse" />
          <div>
            <b>Orchestrator running</b>
            <span>
              Parallel portfolio, market, and quantitative research → risk
              challenge → independent verification.
            </span>
          </div>
        </div>
      )}
      <form
        className="objective-form"
        onSubmit={(event) => {
          event.preventDefault();
          const value = objective.trim();
          onRunInvestigation(
            value ||
              "Analyze my Coinbase portfolio and evaluate whether current allocation has excessive concentration.",
          );
          setObjective("");
        }}
      >
        <input
          value={objective}
          onChange={(event) => setObjective(event.target.value)}
          maxLength={500}
          placeholder="Ask a Coinbase-specific portfolio research question…"
          aria-label="Investigation objective"
        />
        <button className="button primary" disabled={busy}>
          <Sparkles size={15} />
          Investigate
        </button>
      </form>
      <div className="preset-row">
        {presets.map((preset) => (
          <button
            key={preset}
            className="preset-button"
            onClick={() => onRunInvestigation(preset)}
            disabled={busy}
          >
            {preset}
            <ArrowUpRight size={14} />
          </button>
        ))}
      </div>
      <div className="agent-flow">
        {[
          "Orchestrator",
          "Portfolio Analyst",
          "Market Intelligence",
          "Quant Research",
          "Risk Officer",
          "Verification",
        ].map((name, index) => (
          <div
            key={name}
            className={`flow-step ${index === 0 || index > 3 ? "sequential" : ""}`}
          >
            <span className="flow-index">
              {String(index + 1).padStart(2, "0")}
            </span>
            <b>{name}</b>
            <small>
              {index === 0
                ? "Task routing"
                : index < 4
                  ? "Parallel research"
                  : "Independent review"}
            </small>
          </div>
        ))}
      </div>
      {selected ? (
        selected.status === "running" ? (
          <TaskProgress task={selected} />
        ) : selected.status === "failed" ? (
          <Panel
            title={selected.objective}
            subtitle={`${selected.id} · failed`}
          >
            <div className="empty-note">
              This task did not produce a completed report. Correct the
              objective or retry the investigation.
            </div>
          </Panel>
        ) : (
          <TaskReport task={selected} />
        )
      ) : (
        <div className="empty-panel">
          <FileSearch size={25} />
          <b>No investigation yet</b>
          <span>
            Run a multi-agent analysis to inspect evidence, metrics, dissent,
            and the verification report.
          </span>
        </div>
      )}
      {tasks.length > 1 && (
        <Panel
          title="Investigation history"
          subtitle="Select a prior persisted demo task"
        >
          <div className="history-list">
            {tasks.map((task) => (
              <button
                className={`history-row ${task.id === selected?.id ? "active" : ""}`}
                key={task.id}
                onClick={() => setSelectedTaskId(task.id)}
              >
                <span className="mono">{task.id}</span>
                <b>{task.objective}</b>
                <Tag tone="green">{task.status}</Tag>
              </button>
            ))}
          </div>
        </Panel>
      )}
      <Panel
        title="Specialist roster"
        subtitle="Distinct task handlers · read-only analysis"
      >
        <div className="roster-grid">
          {[
            {
              n: "01",
              name: "Portfolio Analyst",
              role: "Allocation, exposure and PnL",
              color: "blue",
            },
            {
              n: "02",
              name: "Market Intelligence",
              role: "Coinbase market snapshot analysis",
              color: "cyan",
            },
            {
              n: "03",
              name: "Quant Research",
              role: "Indicators and scenario metrics",
              color: "violet",
            },
            {
              n: "04",
              name: "Risk Officer",
              role: "Adversarial review and internal veto",
              color: "amber",
            },
            {
              n: "05",
              name: "Verification & Audit",
              role: "Independent arithmetic and evidence review",
              color: "green",
            },
          ].map((agent) => (
            <div key={agent.name} className="roster-card">
              <span className={`roster-icon ${agent.color}`}>{agent.n}</span>
              <div>
                <b>{agent.name}</b>
                <small>{agent.role}</small>
              </div>
              <Tag tone="green">READY</Tag>
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}

function TaskProgress({ task }: { task: AgentTask }) {
  const stages = [
    { label: "Portfolio Analyst", state: "Processing" },
    { label: "Market Intelligence", state: "Processing" },
    { label: "Quant Research", state: "Processing" },
    { label: "Risk Officer challenge", state: "Queued" },
    { label: "Verification & Audit", state: "Queued" },
  ];
  return (
    <Panel title={task.objective} subtitle={`${task.id} · research running`}>
      <div className="task-progress-banner">
        <span className="progress-pulse" />
        <div>
          <b>DEMO AGENT SIMULATION</b>
          <span>
            Independent calculations on seeded portfolio and market fixtures.
          </span>
        </div>
      </div>
      <div className="task-progress-list">
        {stages.map((stage) => (
          <div key={stage.label}>
            <span
              className={`task-stage-dot ${stage.state === "Complete" ? "done" : stage.state === "Processing" ? "active" : ""}`}
            />
            <b>{stage.label}</b>
            <span>{stage.state}</span>
          </div>
        ))}
      </div>
      <p className="task-progress-note">
        Risk challenge and numerical verification complete in sequence before
        the final report is accepted.
      </p>
    </Panel>
  );
}

function TaskReport({ task }: { task: AgentTask }) {
  return (
    <Panel
      title={task.objective}
      subtitle={`${task.id} · completed ${new Date(task.completedAt || task.createdAt).toLocaleString()}`}
      action={
        <Tag tone={task.status === "completed" ? "green" : "red"}>
          {task.status.toUpperCase()}
        </Tag>
      }
    >
      <div className="consensus">
        <ShieldCheck size={18} />
        <div>
          <b>Research conclusion</b>
          <span>{task.finalRecommendation}</span>
          <small className="agreement-note">
            Agreement is similarity of agent research conclusions, not
            probability of investment success.
          </small>
        </div>
        <div className="agreement">
          <b>{Math.round((task.agreementScore || 0) * 100)}%</b>
          <small>agent agreement</small>
        </div>
      </div>
      <div className="finding-list">
        {task.findings.map((finding) => (
          <details key={finding.id} className="finding-card">
            <summary>
              <span className={`finding-marker ${finding.agentId}`} />
              <b>{finding.agentId.replaceAll("-", " ")}</b>
              <span className="finding-summary">{finding.summary}</span>
              <span className="confidence">
                {Math.round(finding.confidence * 100)}% conf.
              </span>
              <ChevronDown size={15} />
            </summary>
            <div className="finding-body">
              <div className="finding-columns">
                <div>
                  <h4>Findings</h4>
                  {finding.findings.map((item) => (
                    <p key={item}>{item}</p>
                  ))}
                </div>
                <div>
                  <h4>Calculations</h4>
                  {finding.calculations.map((item) => (
                    <p key={item} className="mono">
                      {item}
                    </p>
                  ))}
                </div>
              </div>
              <div className="evidence-row">
                <span>Evidence</span>
                {finding.evidenceRefs.map((ref) => (
                  <Tag key={ref}>{ref}</Tag>
                ))}
              </div>
              <div className="evidence-row">
                <span>Assumptions</span>
                {finding.assumptions.map((item) => (
                  <Tag key={item}>{item}</Tag>
                ))}
              </div>
              {finding.metrics && (
                <div className="evidence-row">
                  <span>Structured metrics</span>
                  {Object.entries(finding.metrics).map(([key, value]) => (
                    <Tag key={key}>
                      {key}: {value}
                    </Tag>
                  ))}
                </div>
              )}
              {finding.riskFlags.length > 0 && (
                <div className="risk-inline">
                  {finding.riskFlags.map((flag) => (
                    <span key={flag}>
                      <AlertTriangle size={13} />
                      {flag}
                    </span>
                  ))}
                </div>
              )}
              {finding.dissent && (
                <div className="dissent">Dissent: {finding.dissent}</div>
              )}
            </div>
          </details>
        ))}
      </div>
      {task.decisionReview && (
        <div className="evidence-row decision-meta">
          <span>Decision review</span>
          <Tag>{task.decisionReview.participatingAgents.length} AGENTS</Tag>
          <Tag>
            {(task.decisionReview.evidenceCoverage * 100).toFixed(0)}% evidence
            coverage
          </Tag>
          <Tag tone="amber">HUMAN REVIEW REQUIRED</Tag>
          {task.decisionReview.unresolvedDisagreements.map((item) => (
            <Tag key={item}>Dissent: {item}</Tag>
          ))}
        </div>
      )}
    </Panel>
  );
}

export function MarketsView({ markets, marketStreamStatus }: ViewProps) {
  const [selected, setSelected] = useState(markets[0]?.productId || "BTC-USD");
  const [scenario, setScenario] = useState<MarketScenario>("Baseline sample");
  const baseMarket =
    markets.find((item) => item.productId === selected) || markets[0];
  if (!baseMarket)
    return (
      <div className="empty-panel">
        <b>No synthetic market fixtures are available.</b>
      </div>
    );
  const active = applyMarketScenario(baseMarket, scenario);
  const isLive = baseMarket.source === "coinbase-advanced-trade";
  const closes = active.candles.map((item) => item.close);
  const sma7 = movingAverage(closes, 7).at(-1) || 0;
  const sma20 = movingAverage(closes, 20).at(-1) || 0;
  return (
    <>
      <SectionTitle
        eyebrow="COINBASE MARKET INTELLIGENCE"
        title="Market intelligence"
        text={isLive ? "Read-only public Coinbase Advanced Trade market data. Public quotes may be cached; no private account connection is implied." : "Seeded demo market history is shown because live Coinbase public market data was unavailable."}
      />
      <div className="scenario-bar">
        <div>
          <b>Scenario lens</b>
          <span>Hypothetical transformation of the {isLive ? "retrieved Coinbase sample" : "seeded demo sample"} only.</span>
        </div>
        <select
          value={scenario}
          onChange={(event) =>
            setScenario(event.target.value as MarketScenario)
          }
        >
          {SCENARIOS.map((name) => (
            <option key={name}>{name}</option>
          ))}
        </select>
        <>
          <Tag>{isLive ? "COINBASE LIVE-READ-ONLY" : "DEMO FALLBACK"}</Tag>
          <Tag tone={marketStreamStatus?.state === "connected" ? "green" : "amber"}>
            STREAM {marketStreamStatus?.state?.toUpperCase() || "IDLE"}
          </Tag>
        </>
      </div>
      <div className="market-tabs">
        {markets.map((item) => (
          <button
            className={selected === item.productId ? "active" : ""}
            key={item.productId}
            onClick={() => setSelected(item.productId)}
          >
            {item.productId}
          </button>
        ))}
      </div>
      <div className="content-grid two-one">
        <Panel
          title={`${active.productId} · ${scenario.toLowerCase()}`}
          subtitle={`${baseMarket.dataQuality?.missingCandles || 0} missing intervals · stream ${marketStreamStatus?.state || "idle"}${marketStreamStatus?.lastTickAt ? ` · last tick ${marketStreamStatus.lastTickAt}` : ""} · UTC timestamps`}
          action={<Tag>{isLive ? "READ ONLY" : "DEMO"}</Tag>}
        >
          <PriceChart market={active} />
          <div className="chart-footer">
            <span>
              {isLive ? `Coinbase source timestamp: ${active.dataAsOf || "not provided"}` : "Generated fixture history · never a current market quote"}
            </span>
            <span className="market-price mono">
              ${active.price.toLocaleString()}
            </span>
          </div>
        </Panel>
        <Panel
          title="Quant snapshot"
          subtitle="Descriptive metrics, not forecasts"
        >
          <div className="quant-metrics">
            <div>
              <span>24h sample change</span>
              <b className={active.change24h >= 0 ? "positive" : "negative"}>
                {active.change24h >= 0 ? "+" : ""}
                {active.change24h.toFixed(2)}%
              </b>
            </div>
            <div>
              <span>RSI (14)</span>
              <b>{rsi(closes).toFixed(1)}</b>
            </div>
            <div>
              <span>ATR (14)</span>
              <b>${atr(active.candles).toFixed(2)}</b>
            </div>
            <div>
              <span>Sample volatility</span>
              <b>{historicalVolatility(closes).toFixed(1)}%</b>
            </div>
            <div>
              <span>Max drawdown</span>
              <b>{maxDrawdown(closes).toFixed(2)}%</b>
            </div>
            <div>
              <span>Volume sample</span>
              <b>${(active.volume24h / 1e6).toFixed(0)}M</b>
            </div>
            <div>
              <span>SMA (7)</span>
              <b className="mono">
                ${sma7.toLocaleString("en-US", { maximumFractionDigits: 2 })}
              </b>
            </div>
            <div>
              <span>SMA (20)</span>
              <b className="mono">
                ${sma20.toLocaleString("en-US", { maximumFractionDigits: 2 })}
              </b>
            </div>
          </div>
          <div className="note-box">
            <CircleHelp size={15} />
            <span>
              Technical values are descriptive calculations, not investment
              advice or predictive certainty.
            </span>
          </div>
        </Panel>
      </div>
      <Panel
        title="Coinbase pair watch"
        subtitle="Fixture values carry a persistent demo label"
      >
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Product</th>
                <th>Sample price</th>
                <th>24h move</th>
                <th>Sample volume</th>
                <th>Volatility tag</th>
              </tr>
            </thead>
            <tbody>
              {markets.map((market) => (
                <tr key={market.productId}>
                  <td className="mono">
                    <b>{market.productId}</b>
                  </td>
                  <td className="mono">${market.price.toLocaleString()}</td>
                  <td
                    className={market.change24h >= 0 ? "positive" : "negative"}
                  >
                    {market.change24h > 0 ? "+" : ""}
                    {market.change24h.toFixed(2)}%
                  </td>
                  <td className="mono">
                    ${(market.volume24h / 1e6).toFixed(0)}M
                  </td>
                  <td>
                    <Tag
                      tone={
                        market.volatility === "Elevated" ? "amber" : "muted"
                      }
                    >
                      {market.volatility.toUpperCase()}
                    </Tag>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </>
  );
}

export function RiskView({ balances }: ViewProps) {
  const metrics = portfolioMetrics(balances);
  const maxRow = [...metrics.rows].sort(
    (a, b) => b.allocation - a.allocation,
  )[0];
  return (
    <>
      <SectionTitle
        eyebrow="INDEPENDENT POLICY MONITOR"
        title="Risk intelligence"
        text="Policy checks run outside the agent/LLM layer; live execution is disabled."
      />
      <div className="banner risk-banner">
        <ShieldCheck size={18} />
        <div>
          <b>Execution boundary active</b>
          <span>
            No live orders, withdrawals, deposits, transfers, swaps or financial
            writes can be initiated from this app.
          </span>
        </div>
        <Tag tone="green">ENFORCED</Tag>
      </div>
      <div className="metric-grid three">
        <Metric
          label="Largest position"
          value={`${(maxRow.allocation * 100).toFixed(1)}% ${maxRow.asset}`}
          change="Review concentration"
          icon={AlertTriangle}
          tone="amber"
        />
        <Metric
          label="Concentration index"
          value={concentration(metrics.rows).toFixed(3)}
          change="Sum of squared asset weights"
          icon={Gauge}
          tone="violet"
        />
        <Metric
          label="Data freshness"
          value="DEMO"
          change="Synthetic fixture · not a live sync"
          icon={Clock3}
          tone="cyan"
        />
      </div>
      <Panel
        title="Risk register"
        subtitle="Transparent flags and hard policy status"
      >
        <div className="risk-register">
          <div className="risk-entry high">
            <span>
              <AlertTriangle size={15} />
            </span>
            <div>
              <b>Elevated asset concentration</b>
              <small>
                {maxRow.asset} is {(maxRow.allocation * 100).toFixed(1)}% of
                demo portfolio. Internal review is required; this is not an
                execution instruction.
              </small>
            </div>
            <Tag tone="amber">REVIEW</Tag>
          </div>
          <div className="risk-entry">
            <span>
              <CircleHelp size={15} />
            </span>
            <div>
              <b>Synthetic pricing and history</b>
              <small>
                Market samples are fixtures and cannot be used as live price or
                liquidity evidence.
              </small>
            </div>
            <Tag>DATA</Tag>
          </div>
          <div className="risk-entry">
            <span>
              <ShieldCheck size={15} />
            </span>
            <div>
              <b>Unsupported financial writes blocked</b>
              <small>
                Policy engine returns false for live execution independent of
                model or agent output.
              </small>
            </div>
            <Tag tone="green">PASS</Tag>
          </div>
          <div className="risk-entry">
            <span>
              <Clock3 size={15} />
            </span>
            <div>
              <b>Fees and slippage are illustrative</b>
              <small>
                Proposal previews use a demo estimate, not Coinbase fee quotes
                or an execution receipt.
              </small>
            </div>
            <Tag>SIMULATION</Tag>
          </div>
        </div>
      </Panel>
      <Panel
        title="Exposure by asset"
        subtitle="Marked to synthetic fixture prices"
      >
        <div className="exposure-list">
          {metrics.rows.map((row) => (
            <div className="exposure-row" key={row.asset}>
              <span>{row.asset}</span>
              <div className="exposure-track">
                <i style={{ width: `${row.allocation * 100}%` }} />
              </div>
              <b>{(row.allocation * 100).toFixed(1)}%</b>
              <span className="mono">{formatMoney(row.valueCents)}</span>
            </div>
          ))}
        </div>
      </Panel>
    </>
  );
}

export function ProposalsView({
  proposals,
  onCreateProposal,
  onProposalDecision,
}: ViewProps) {
  return (
    <>
      <SectionTitle
        eyebrow="HYPOTHETICAL ORDER REVIEW"
        title="Trade proposals"
        text="Every proposal is simulation-only. Approval never creates or submits a Coinbase order."
        action={
          <button className="button primary" onClick={onCreateProposal}>
            <Sparkles size={15} />
            Generate demo proposal
          </button>
        }
      />
      <div className="banner demo-banner">
        <span className="banner-dot" />
        <div>
          <strong>SIMULATION ONLY</strong>
          <span>
            {" "}
            No exchange connection, order preview endpoint, or live financial
            write is used.
          </span>
        </div>
      </div>
      {proposals.length === 0 ? (
        <div className="empty-panel">
          <FileSearch size={25} />
          <b>No proposals yet</b>
          <span>
            Create a sample proposal to review risk checks and the simulated
            order preview workflow.
          </span>
        </div>
      ) : (
        <div className="proposal-list">
          {proposals.map((proposal) => {
            const finalized =
              proposal.reviewDecision === "approved-for-simulation" ||
              proposal.reviewDecision === "rejected";
            return (
              <div className="panel proposal-card" key={proposal.id}>
                <div className="proposal-heading">
                  <div>
                    <div className="eyebrow">{proposal.id} · SIMULATION</div>
                    <h2>
                      <span
                        className={
                          proposal.side === "BUY" ? "positive" : "negative"
                        }
                      >
                        {proposal.side}
                      </span>{" "}
                      {proposal.productId}
                    </h2>
                  </div>
                  <Tag
                    tone={proposal.riskStatus === "rejected" ? "red" : "green"}
                  >
                    {proposal.reviewDecision
                      ? proposal.reviewDecision
                          .replaceAll("-", " ")
                          .toUpperCase()
                      : proposal.riskStatus.toUpperCase()}
                  </Tag>
                </div>
                <div className="proposal-grid">
                  <div>
                    <span>Order type</span>
                    <b>{proposal.orderType}</b>
                  </div>
                  <div>
                    <span>Proposed size</span>
                    <b className="mono">{proposal.proposedSize}</b>
                  </div>
                  <div>
                    <span>Estimated notional</span>
                    <b className="mono">
                      {formatMoney(proposal.notionalCents)}
                    </b>
                  </div>
                  <div>
                    <span>Illustrative fee</span>
                    <b className="mono">${proposal.estimatedFees}</b>
                  </div>
                  <div>
                    <span>Price assumption</span>
                    <b className="mono">
                      {proposal.proposedPrice
                        ? `$${proposal.proposedPrice}`
                        : "Synthetic snapshot"}
                    </b>
                  </div>
                  <div>
                    <span>Execution mode</span>
                    <b>Simulation only</b>
                  </div>
                </div>
                <p className="proposal-rationale">{proposal.rationale}</p>
                <div className="proposal-support">
                  <span>Supporting agents</span>
                  <b>
                    {proposal.supportingAgentIds
                      .map((agent) => agent.replaceAll("-", " "))
                      .join(" · ")}
                  </b>
                </div>
                {proposal.riskFlags.length > 0 && (
                  <div className="proposal-flags">
                    {proposal.riskFlags.map((flag) => (
                      <Tag key={flag} tone="amber">
                        {flag}
                      </Tag>
                    ))}
                  </div>
                )}
                {proposal.preview && (
                  <div className="preview-box">
                    <b>
                      <CheckCircle2 size={15} /> Hypothetical preview · no
                      exchange receipt
                    </b>
                    <span>
                      Expected ${proposal.preview.expectedPrice} · estimated
                      slippage ${proposal.preview.slippage} · resulting
                      allocation{" "}
                      {(proposal.preview.resultingAllocation * 100).toFixed(1)}%
                      · portfolio{" "}
                      {formatMoney(proposal.preview.resultingPortfolioCents)}.
                    </span>
                  </div>
                )}
                {!finalized && (
                  <div className="proposal-actions">
                    <button
                      className="button primary small"
                      onClick={() => onProposalDecision(proposal.id, "approve")}
                      disabled={proposal.riskStatus === "rejected"}
                    >
                      Approve for simulation
                    </button>
                    <button
                      className="button secondary small"
                      onClick={() => onProposalDecision(proposal.id, "analyze")}
                    >
                      Request analysis
                    </button>
                    <button
                      className="button quiet small"
                      onClick={() => onProposalDecision(proposal.id, "reject")}
                    >
                      Reject
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}

export function LedgerView({ audit, tasks, proposals }: ViewProps) {
  const entries = [...audit].sort((a, b) =>
    b.timestamp.localeCompare(a.timestamp),
  );
  return (
    <>
      <SectionTitle
        eyebrow="AUDITABILITY AND SIMULATION HISTORY"
        title="Execution ledger"
        text="A local demo ledger of research actions, policy checks, and simulated proposal decisions."
      />
      <div className="metric-grid three">
        <Metric
          label="Audit events"
          value={String(audit.length)}
          change="Persisted in this browser"
          icon={FileSearch}
        />
        <Metric
          label="Completed investigations"
          value={String(
            tasks.filter((task) => task.status === "completed").length,
          )}
          change="Five-agent runs"
          icon={Sparkles}
          tone="cyan"
        />
        <Metric
          label="Simulation proposals"
          value={String(proposals.length)}
          change="No exchange receipts"
          icon={WalletCards}
          tone="violet"
        />
      </div>
      <Panel
        title="Activity timeline"
        subtitle="Source mode and action outcome are retained"
      >
        <div className="ledger-list">
          {entries.length ? (
            entries.map((item) => (
              <div className="ledger-event" key={item.id}>
                <div className={`ledger-mark ${item.actor}`}>
                  <span />
                </div>
                <div className="ledger-main">
                  <div>
                    <b>{item.action}</b>
                    <Tag>{item.dataMode.toUpperCase()}</Tag>
                  </div>
                  <p>{item.outcome}</p>
                  <div className="ledger-meta">
                    <span>{item.actor}</span>
                    <span>
                      {item.references.join(" · ") || "No external inputs"}
                    </span>
                    {item.proposalId && <span>{item.proposalId}</span>}
                  </div>
                  {item.checks && (
                    <div className="ledger-checks">
                      {item.checks.map((check) => (
                        <span key={check}>
                          <CheckCircle2 size={12} />
                          {check}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
                <time>{new Date(item.timestamp).toLocaleString()}</time>
              </div>
            ))
          ) : (
            <div className="empty-note">
              No events recorded. Investigation and simulated proposal actions
              will be recorded here.
            </div>
          )}
        </div>
      </Panel>
    </>
  );
}
