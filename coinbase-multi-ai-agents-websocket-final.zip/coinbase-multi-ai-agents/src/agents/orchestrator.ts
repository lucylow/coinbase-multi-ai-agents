import { randomUUID } from "node:crypto";
import type { AgentTask } from "@/models/domain";
import { DEMO_AS_OF } from "@/fixtures/demo";
import {
  AGENTS,
  marketIntelligence,
  portfolioAnalyst,
  quantitativeResearch,
  riskOfficer,
  verificationAgent,
} from "./specialists";

export async function runInvestigation(objective: string): Promise<AgentTask> {
  const cleaned = objective.trim();
  if (cleaned.length < 8 || cleaned.length > 500)
    throw new Error("Objective must be between 8 and 500 characters.");
  const id = `INV-${randomUUID().slice(0, 8).toUpperCase()}`;
  const [portfolio, market, quant] = await Promise.all([
    portfolioAnalyst(id, cleaned),
    marketIntelligence(id),
    quantitativeResearch(id),
  ]);
  const research = [portfolio, market, quant];
  const risk = await riskOfficer(id, research);
  const verification = await verificationAgent(id, [...research, risk]);
  const findings = [...research, risk, verification];
  const riskFlags = [
    ...new Set(findings.flatMap((finding) => finding.riskFlags)),
  ];
  const verificationPassed = !verification.riskFlags.some((flag) =>
    flag.includes("failed"),
  );
  const stanceCounts = findings.reduce((counts, finding) => {
    const stance = finding.stance || "market-neutral";
    counts.set(stance, (counts.get(stance) || 0) + 1);
    return counts;
  }, new Map<string, number>());
  const agreementScore = findings.length
    ? Math.max(...stanceCounts.values()) / findings.length
    : 0;
  const recommendation = verificationPassed
    ? "Continue with research review only. The demo snapshot shows material concentration risk; no live action is authorized or available."
    : "Hold the summary for correction because independent verification detected a numerical inconsistency.";
  const decisionReview = {
    decisionId: `DEC-${id}`,
    taskId: id,
    participatingAgents: findings.map((finding) => finding.agentId),
    agreementScore,
    unresolvedDisagreements: [
      ...new Set(
        findings
          .filter((finding) => finding.dissent)
          .map((finding) => finding.dissent!),
      ),
    ],
    riskFlags,
    evidenceCoverage:
      findings.filter((finding) => finding.evidenceRefs.length > 0).length /
      findings.length,
    recommendation,
    humanApprovalRequired: true,
  };
  const task: AgentTask = {
    id,
    objective: cleaned,
    productIds: ["BTC-USD", "ETH-USD", "SOL-USD"],
    mode: "demo",
    status: verificationPassed ? "completed" : "failed",
    createdAt: DEMO_AS_OF,
    completedAt: new Date().toISOString(),
    findings,
    finalRecommendation: recommendation,
    agreementScore: decisionReview.agreementScore,
    riskFlags,
    decisionReview,
  };
  return task;
}

export function agentRoster() {
  return AGENTS;
}
