import { describe, expect, it } from "vitest";
import { AdvancedTradeWebSocketManager } from "@/integrations/coinbase/advanced-trade-websocket";

describe("Advanced Trade public WebSocket manager", () => {
  it("uses a bounded supported product list and emits validated string-price ticker updates", () => {
    const sockets: Array<Record<string, any>> = [];
    const ticks: unknown[] = [];
    const manager = new AdvancedTradeWebSocketManager({
      products: ["BTC-USD", "ETH-USD", "SOL-USD", "DOGE-USD", "BTC-USD", "bad pair"],
      socketFactory: () => {
        const socket: Record<string, any> = { readyState: 0, sent: [], send(message: string) { this.sent.push(JSON.parse(message)); }, close() {} };
        sockets.push(socket); return socket as never;
      },
      onTick: (tick) => ticks.push(tick),
    });
    manager.start();
    const socket = sockets[0];
    socket.onopen?.({} as Event);
    expect(socket.sent.map((item: { channel: string }) => item.channel)).toEqual(["ticker", "heartbeats", "status"]);
    expect(socket.sent[0].product_ids).toEqual(["BTC-USD", "ETH-USD", "SOL-USD", "DOGE-USD"]);
    socket.onmessage?.({ data: JSON.stringify({ channel: "ticker", events: [{ tickers: [
      { product_id: "BTC-USD", price: "67123.45000000", time: "2026-11-05T12:00:00Z" },
      { product_id: "FAKE-USD", price: "4.2", time: "2026-11-05T12:00:00Z" },
      { product_id: "ETH-USD", price: "NaN", time: "2026-11-05T12:00:00Z" },
    ] }] }) } as MessageEvent);
    expect(ticks).toHaveLength(1);
    expect(ticks[0]).toMatchObject({ productId: "BTC-USD", price: "67123.45000000", source: "coinbase", isLive: true });
    manager.stop();
    expect(manager.status.state).toBe("closed");
  });
});
