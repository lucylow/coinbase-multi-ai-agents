import { describe, expect, it } from "vitest";
import { markets } from "@/fixtures/demo";
import { applyMarketScenario } from "@/services/scenarios";

describe("synthetic market scenarios", () => {
  it("changes the view for bullish, bearish, and liquidity stress scenarios", () => {
    const btc = markets.find((market) => market.productId === "BTC-USD")!;
    const originalClose = btc.candles.at(-1)?.close;
    const bullish = applyMarketScenario(btc, "Bullish momentum");
    const bearish = applyMarketScenario(btc, "Bearish momentum");
    const stressed = applyMarketScenario(btc, "Liquidity deterioration");
    expect(bullish.candles.at(-1)?.close).toBeGreaterThan(
      bearish.candles.at(-1)?.close ?? 0,
    );
    expect(stressed.volume24h).toBeLessThan(btc.volume24h);
    expect(btc.candles.at(-1)?.close).toBe(originalClose);
  });
});
