import { describe, expect, it } from "vitest";
import { GET as getSampleTasks } from "../app/api/agents/tasks/route";
import { POST as postInvestigation } from "../app/api/agents/investigate/route";

describe("investigation routes", () => {
  it("returns five complete demo analyses without claiming live data", async () => {
    const response = await getSampleTasks();
    const payload = await response.json();
    expect(response.status).toBe(200);
    expect(payload.source).toBe("DEMO AGENT SIMULATION");
    expect(payload.data).toHaveLength(5);
    for (const task of payload.data) {
      expect(task.mode).toBe("demo");
      expect(task.status).toBe("completed");
      expect(task.findings).toHaveLength(5);
      expect(task.decisionReview.humanApprovalRequired).toBe(true);
    }
  });

  it("returns a client-correctable response for malformed and invalid requests", async () => {
    const malformed = await postInvestigation(
      new Request("http://local/api/agents/investigate", {
        method: "POST",
        body: "{",
        headers: { "content-type": "application/json" },
      }),
    );
    const invalid = await postInvestigation(
      new Request("http://local/api/agents/investigate", {
        method: "POST",
        body: JSON.stringify({ objective: "x" }),
        headers: { "content-type": "application/json" },
      }),
    );
    expect(malformed.status).toBe(400);
    expect(invalid.status).toBe(400);
  });
});
