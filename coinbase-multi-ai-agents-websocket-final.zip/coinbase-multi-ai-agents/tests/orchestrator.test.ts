import { describe, expect, it } from "vitest";
import { runInvestigation } from "@/agents/orchestrator";
import { verificationAgent } from "@/agents/specialists";
import { balances } from "@/fixtures/demo";
import { portfolioMetrics } from "@/services/analytics";
import type { AgentFinding } from "@/models/domain";

describe("five-agent orchestration", () => {
  it("runs research in parallel, then risk and independent verification", async () => {
    const result = await runInvestigation("Review BTC concentration risk");
    expect(result.status).toBe("completed");
    expect(result.findings.map((finding) => finding.agentId)).toEqual([
      "portfolio-analyst",
      "market-intelligence",
      "quant-research",
      "risk-officer",
      "verification-audit",
    ]);
    expect(result.riskFlags.length).toBeGreaterThan(0);
    expect(result.finalRecommendation).toContain("no live action");
    expect(result.decisionReview?.humanApprovalRequired).toBe(true);
    expect(result.decisionReview?.agreementScore).toBe(result.agreementScore);
    expect(result.findings.every((finding) => finding.stance)).toBe(true);
  });
  it("flags an inconsistent structured claim using an independent arithmetic path", async () => {
    const actual = portfolioMetrics(balances).totalCents;
    const badClaim: AgentFinding = {
      id: "bad",
      agentId: "portfolio-analyst",
      taskId: "test",
      summary: "bad",
      findings: [],
      calculations: [],
      evidenceRefs: ["demo"],
      assumptions: [],
      confidence: 0.99,
      riskFlags: [],
      requiresReview: false,
      status: "completed",
      metrics: { portfolioValueCents: actual + 1 },
    };
    const verified = await verificationAgent("test", [badClaim]);
    expect(verified.riskFlags).toContain("Numerical verification failed");
    expect(verified.stance).toBe("verification-fail");
  });
});
