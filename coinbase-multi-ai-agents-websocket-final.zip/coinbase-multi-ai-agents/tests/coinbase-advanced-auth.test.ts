import { generateKeyPairSync, verify } from "node:crypto";
import { describe, expect, it } from "vitest";
import { createAdvancedTradeRestJwt } from "@/integrations/coinbase/coinbase-advanced-auth";
import { HttpAdvancedTradeProvider } from "@/integrations/coinbase/advancedTradeProvider";

const parts = (token: string) => token.split(".");
const decode = (value: string) => JSON.parse(Buffer.from(value, "base64url").toString("utf8"));

describe("Advanced Trade CDP JWT authentication", () => {
  it("creates a short-lived REST JWT bound to method, host, and path using Ed25519", () => {
    const { privateKey, publicKey } = generateKeyPairSync("ed25519");
    const token = createAdvancedTradeRestJwt({
      keyName: "organizations/org/apiKeys/key",
      privateKey: privateKey.export({ type: "pkcs8", format: "pem" }).toString(),
    }, "GET", "https://api.coinbase.com/api/v3/brokerage/accounts?limit=10", 1_800_000_000);
    const [headerPart, payloadPart, signaturePart] = parts(token);
    const header = decode(headerPart);
    const payload = decode(payloadPart);
    expect(header.alg).toBe("EdDSA");
    expect(header.kid).toBe("organizations/org/apiKeys/key");
    expect(payload.iss).toBe("cdp");
    expect(payload.nbf).toBe(1_800_000_000);
    expect(payload.exp).toBe(1_800_000_120);
    expect(payload.uri).toBe("GET api.coinbase.com/api/v3/brokerage/accounts");
    expect(verify(null, Buffer.from(`${headerPart}.${payloadPart}`), publicKey, Buffer.from(signaturePart, "base64url"))).toBe(true);
  });

  it("uses independent authentication only for account reads, not public market data", async () => {
    const { privateKey } = generateKeyPairSync("ed25519");
    const headers: Headers[] = [];
    const provider = new HttpAdvancedTradeProvider({
      baseUrl: "https://api.coinbase.com",
      credentials: {
        keyName: "organizations/org/apiKeys/advanced-only",
        privateKey: privateKey.export({ type: "pkcs8", format: "pem" }).toString(),
      },
      fetcher: async (_input, init) => {
        headers.push(new Headers(init?.headers));
        return new Response(JSON.stringify({ product: { product_id: "BTC-USD", price: "1" }, accounts: [] }), { status: 200 });
      },
    });
    await provider.getProduct("BTC-USD");
    await provider.getAccounts();
    expect(headers[0].has("authorization")).toBe(false);
    const accountJwt = headers[1].get("authorization")?.replace(/^Bearer /, "") || "";
    expect(decode(parts(accountJwt)[1]).uri).toBe("GET api.coinbase.com/api/v3/brokerage/accounts");
  });
});
