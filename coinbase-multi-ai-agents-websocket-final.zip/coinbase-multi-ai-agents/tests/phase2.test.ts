import { describe, expect, it } from "vitest";
import { HttpAdvancedTradeProvider } from "@/integrations/coinbase/advancedTradeProvider";
import { backtestSmaCrossover, stressPortfolio } from "@/services/research";
import { balances, markets } from "@/fixtures/demo";

describe("Phase 2 read-only Coinbase adapter", () => {
  it("normalizes public product and candle responses without credentials", async () => {
    const provider = new HttpAdvancedTradeProvider({
      baseUrl: "https://example.test",
      fetcher: async (input) => new Response(String(input).includes("candles")
        ? JSON.stringify({ candles: [{ start: "2", open: "10", high: "12", low: "9", close: "11", volume: "4" }, { start: "1", open: "9", high: "10", low: "8", close: "9", volume: "3" }] })
        : JSON.stringify({ product: { product_id: "BTC-USD", base_currency_id: "BTC", quote_currency_id: "USD", status: "online", price: "11" } }), { status: 200, headers: { "content-type": "application/json" } }),
    });
    const product = await provider.getProduct("BTC-USD");
    const candles = await provider.getPublicCandles("BTC-USD", "2026-01-01T00:00:00Z", "2026-01-01T02:00:00Z", "ONE_HOUR");
    expect(product.price).toBe("11");
    expect(candles.map((candle) => candle.close)).toEqual([9, 11]);
  });
});

describe("Phase 2 quantitative research", () => {
  it("produces a reproducible SMA backtest and benchmark", () => {
    const result = backtestSmaCrossover("BTC-USD", markets[0].candles, 100_000);
    expect(result.strategy).toBe("sma-crossover");
    expect(result.candles).toBe(36);
    expect(result.assumptions.length).toBeGreaterThan(1);
  });
  it("shocks each portfolio asset and preserves a transparent loss calculation", () => {
    const result = stressPortfolio(balances, { BTC: -0.2, ETH: -0.2, SOL: -0.2, USDC: 0 }, "20% crypto drawdown");
    expect(result.lossCents).toBeLessThan(0);
    expect(result.portfolioAfterCents).toBe(result.portfolioBeforeCents + result.lossCents);
    expect(result.methodology).toContain("liquidity impact");
  });
});
