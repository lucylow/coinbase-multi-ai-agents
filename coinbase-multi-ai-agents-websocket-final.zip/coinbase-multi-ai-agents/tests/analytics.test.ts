import { describe, expect, it } from "vitest";
import { balances } from "@/fixtures/demo";
import {
  compareDecimals,
  moneyCents,
  portfolioMetrics,
  rsi,
  historicalVolatility,
  maxDrawdown,
} from "@/services/analytics";
import { evaluateProposal, liveExecutionAllowed } from "@/services/policy";

describe("demo financial calculations", () => {
  it("computes fixture portfolio value and PnL in integer cents", () => {
    const result = portfolioMetrics(balances);
    expect(result.totalCents).toBe(7_865_400);
    expect(result.totalPnlCents).toBe(476_100);
    expect(
      result.rows.reduce((sum, row) => sum + row.allocation, 0),
    ).toBeCloseTo(1, 10);
  });
  it("rejects excess precision and computes exact cents", () => {
    expect(moneyCents("12.34")).toBe(1234);
    expect(() => moneyCents("1.123456789")).toThrow();
    expect(compareDecimals("0.10000000", "0.1")).toBe(0);
    expect(compareDecimals("1.00000001", "1")).toBe(1);
  });
  it("calculates RSI, volatility, and drawdown on deterministic series", () => {
    expect(rsi([1, 2, 3, 4, 5], 2)).toBe(100);
    expect(historicalVolatility([10, 10, 10])).toBe(0);
    expect(maxDrawdown([10, 12, 9, 11])).toBeCloseTo(25);
  });
});

describe("independent simulation policy", () => {
  it("allows a small supported simulation and flags concentration", () => {
    const result = evaluateProposal(
      {
        productId: "ETH-USD",
        side: "BUY",
        orderType: "MARKET",
        proposedSize: "0.1",
      },
      balances,
    );
    expect(result.allowedForSimulation).toBe(true);
    expect(result.notionalCents).toBe(34_500);
    expect(result.riskFlags).toContain(
      "Elevated portfolio concentration requires review",
    );
  });
  it("rejects an unsupported product and never enables live execution", () => {
    const result = evaluateProposal(
      {
        productId: "DOGE-USD",
        side: "BUY",
        orderType: "MARKET",
        proposedSize: "1",
      },
      balances,
    );
    expect(result.allowedForSimulation).toBe(false);
    expect(liveExecutionAllowed()).toBe(false);
  });
  it("hard-stops unsupported order primitives instead of allowing simulation", () => {
    const result = evaluateProposal(
      {
        productId: "ETH-USD",
        side: "HOLD" as "BUY",
        orderType: "STOP" as "MARKET",
        proposedSize: "0.1",
      },
      balances,
    );
    expect(result.allowedForSimulation).toBe(false);
    expect(result.feeCents).toBe(207);
  });
});
