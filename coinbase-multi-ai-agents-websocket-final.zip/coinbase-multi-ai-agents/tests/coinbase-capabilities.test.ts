import { describe, expect, it } from "vitest";
import type { DiscoveredCapability } from "@/integrations/coinbase/coinbase-capability-registry";
import { discoverCoinbaseCapabilities, retryDelayMs } from "@/integrations/coinbase/coinbase/models/capability-state";

describe("Coinbase capability discovery", () => {
  it("returns no assumed capabilities when discovery is empty", () => {
    const state = discoverCoinbaseCapabilities([], false, false);
    expect(state.connected).toBe(false);
    expect(state.authenticated).toBe(false);
    expect(state.portfolioRead).toBe(false);
    expect(state.trading).toBe(false);
    expect(state.x402Research).toBe(false);
    expect(state.missingCapabilities).toContain("market-data");
  });

  it("maps only capabilities evidenced by discovered tools", () => {
    const tools: DiscoveredCapability[] = [
      { name: "list_accounts", description: "Read account balances", readOnly: true },
      { name: "get_market_product", description: "Read product and market data", readOnly: true },
      { name: "preview_order", description: "Preview order", readOnly: true },
      { name: "place_order", description: "Submit trade order", readOnly: false },
      { name: "x402_research_payment", description: "Pay for research", readOnly: false },
    ];
    const state = discoverCoinbaseCapabilities(tools, true, true, "2026-11-05T00:00:00.000Z");
    expect(state.accountRead).toBe(true);
    expect(state.marketData).toBe(true);
    expect(state.productInfo).toBe(true);
    expect(state.orderPreview).toBe(true);
    expect(state.trading).toBe(true);
    expect(state.x402Research).toBe(true);
    expect(state.portfolioRead).toBe(false);
    expect(state.missingCapabilities).toContain("portfolio-reading");
    expect(state.lastValidatedAt).toBe("2026-11-05T00:00:00.000Z");
  });

  it("backs off transient failures but never retries auth/permission errors", () => {
    expect(retryDelayMs(0, new Error("temporary network failure"))).toBe(500);
    expect(retryDelayMs(1, new Error("Coinbase rate limit 429"))).toBe(1_000);
    expect(retryDelayMs(0, new Error("401 invalid authentication token"))).toBeNull();
    expect(retryDelayMs(0, new Error("403 permission denied"))).toBeNull();
  });
});
