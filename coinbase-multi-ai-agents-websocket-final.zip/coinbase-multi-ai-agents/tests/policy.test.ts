import { describe, expect, it } from "vitest";
import { balances, DEMO_AS_OF } from "@/fixtures/demo";
import { evaluateProposal } from "@/services/policy";

const input = {
  productId: "ETH-USD",
  side: "BUY" as const,
  orderType: "MARKET" as const,
  proposedSize: "0.1",
};

describe("market freshness policy", () => {
  it("permits a valid simulation with the fixture’s declared as-of timestamp", () => {
    expect(
      evaluateProposal(input, balances, DEMO_AS_OF).allowedForSimulation,
    ).toBe(true);
  });
  it("marks old market context for human review but keeps demo simulation explicit", () => {
    const result = evaluateProposal(
      input,
      balances,
      "2020-01-01T00:00:00.000Z",
    );
    expect(result.riskFlags).toContain("Market data is stale");
    expect(result.allowedForSimulation).toBe(true);
  });
  it("rejects amounts over configured precision and sells exceeding holdings", () => {
    expect(
      evaluateProposal({ ...input, proposedSize: "0.123456789" }, balances)
        .riskFlags,
    ).toContain("Amount precision exceeds 8 decimal places");
    const sell = evaluateProposal(
      {
        productId: "BTC-USD",
        side: "SELL",
        orderType: "MARKET",
        proposedSize: "2",
      },
      balances,
    );
    expect(sell.riskFlags).toContain(
      "Sell size exceeds available demo balance",
    );
    expect(sell.allowedForSimulation).toBe(false);
  });
  it("rejects a buy when demo USDC cannot cover notional plus the illustrative fee", () => {
    const result = evaluateProposal({ ...input, proposedSize: "1" }, balances);
    expect(result.notionalCents).toBe(345_000);
    expect(result.riskFlags).toContain(
      "Insufficient demo USDC for notional and illustrative fee",
    );
    expect(result.allowedForSimulation).toBe(false);
  });
});
