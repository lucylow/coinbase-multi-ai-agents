import { describe, expect, it } from "vitest";
import { CoinbaseCapabilityRegistry } from "@/integrations/coinbase/coinbase-capability-registry";
import { CoinbaseMcpClient } from "@/integrations/coinbase/coinbase-mcp-client";

describe("Coinbase MCP boundary", () => {
  it("does not claim a connection or discover tools without authorized transport", async () => {
    const client = new CoinbaseMcpClient();
    const status = await client.connect();
    expect(status.status).toBe("not-configured");
    expect(status.authorization).toBe("missing");
    expect(await client.discoverCapabilities()).toEqual([]);
  });
  it("exposes only discovered read-only capabilities and rejects write calls", () => {
    const registry = new CoinbaseCapabilityRegistry();
    registry.replace([
      {
        name: "market-data",
        description: "Authorized read only",
        readOnly: true,
      },
    ]);
    expect(registry.assertAvailable("market-data", "read").name).toBe(
      "market-data",
    );
    expect(() => registry.assertAvailable("market-data", "write")).toThrow(
      /disabled/,
    );
    expect(() => registry.assertAvailable("place-order", "read")).toThrow(
      /Unsupported/,
    );
  });
});
