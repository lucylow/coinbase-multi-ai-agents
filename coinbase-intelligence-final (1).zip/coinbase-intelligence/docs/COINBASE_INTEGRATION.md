# Coinbase and Base integration inventory

This document describes the current repository, not a roadmap promise. Credentials, environment variables, endpoint configuration, and UI labels are not treated as proof of a working or authorized provider.

## Integration inventory

| Capability | Existing implementation | Current evidence | Incomplete / explicitly not claimed |
|---|---|---|---|
| Advanced Trade public reads | `src/integrations/coinbase/advancedTradeProvider.ts`, `marketData.ts` | Public product metadata probe, supported candles, product book, best bid/ask, trades; market parsing rejects invalid candle data. Idempotent GETs have one bounded retry for network timeout, 429, or 5xx; terminal 4xx errors are typed and sanitized. | No order create/cancel path. Account authentication is separately gated; the health endpoint does not call account endpoints or validate credentials. Provider uses `Number` for several market values, so this layer is not an arbitrary-precision accounting engine. |
| Portfolio profiles | `src/services/portfolio/portfolio-workspace-manager.ts` | Server-side profile references, explicit workspace mappings, authorized portfolio enumeration before breakdown reads, opt-in `COINBASE_PORTFOLIO_READS_ENABLED`. | Process-local history; production use requires an authenticated/private application perimeter and durable repository. |
| WebSocket | `src/integrations/coinbase/advanced-trade-websocket.ts` | Public ticker, heartbeat, and status subscriptions; bounded products; validated string prices; finite reconnect attempts and stale ticker status. | Not a Level-2 book engine; no trade/candle/user channels, subscription acknowledgments, sequence reconciliation, or server-side session health. The health API therefore reports WebSocket availability as unverified. |
| Coinbase MCP | `coinbase-mcp-client.ts`, nested `coinbase/client/`, capability registry, read-only adapters | Host-injected transport, discovered capabilities, bounded retry in existing client, authorization-aware status; no synthetic tool discovery. | No transport is configured by default. No new generic tool gateway was added by this change; an authorized host-provided MCP session is required. |
| Coinbase environment modes | `src/integrations/coinbase/integration-health.ts` | `DEMO` is default; unknown modes and a sandbox request without matching, valid HTTPS values for `COINBASE_SANDBOX_API_URL` and `COINBASE_ADVANCED_TRADE_URL` fall back to DEMO. Production modes are reported read-only; trading is a hardcoded false status. | Mode resolution is descriptive and health-reporting; it does not retarget existing credentials or supply an official sandbox configuration. Do not set a sandbox override until independently verified. |
| Capability health | `integration-health.ts`, `GET /api/integrations/health`, Integration Health Center | Separates `configured`, `available`, and `authenticated`; probes public product metadata and Base Sepolia chain ID; MCP uses the existing status adapter. Records latency only for those three probes. Account, WebSocket, wallet, policy, and x402 states remain unknown/unavailable where not verified. Server results are cached for 30 seconds; generic failures avoid echoing credential-bearing URLs. | No persistent metrics backend, rate-limit utilization telemetry, alerting, or authenticated perimeter is added by this health endpoint. |
| Coinbase Wallet/CDP wallet | `src/integrations/coinbase-wallet/wallet-sdk.ts`, EIP-712 and EIP-7702 modules | User-owned EIP-1193 discovery, Base Sepolia network check, authorization data validation. | The SDK status remains unconfigured; no CDP server wallet, ERC-4337 smart account, bundler, paymaster, key creation, or server signing. |
| Base RPC | `base-network-config.ts`, `base-rpc-service.ts`, `/api/onchain/status` | Explicit Base mainnet/Sepolia chain IDs; independent `BASE_MAINNET_RPC_URL` and `BASE_SEPOLIA_RPC_URL` settings; legacy `BASE_RPC_URL` is Sepolia-only; RPC `eth_chainId` check rejects mismatches with timeout. | No full block/log indexer, gas estimator, receipt/contract registry verification, or RPC monitor. Chain ID probe alone does not verify deployed contract addresses. |
| Policy / spend permissions | `policy-engine/`, `spend-permissions/`, existing simulation policy | Local deterministic validation and explicit remote policy-client boundary. | Remote CDP policy client operations remain unavailable; local spend-permission checks are advisory and do not authorize transactions. |
| x402 / payments | `x402-provider/server.ts`, `payment-acceptance/status.ts` | Demo resource/status and explicit ineligibility/configuration reporting. | No verified facilitator, payment verification, settlement adapter, real payment ledger, or autonomous agent spend. |
| ERC-8004 / reputation | `services/agent-identity/`, `services/agent-reputation/`, draft interfaces | Internal identity and reputation abstractions plus draft protocol interfaces. | Internal agent IDs are not asserted to be registered identities; no active registry deployment/verified identity read is claimed. |
| Attestations / verifiable compute | `ResearchAttestationRegistry.sol`, `ResearchBatchAnchor.sol`, `verifiable-compute/` | Commitment-oriented contract/service foundations and demo/mock status are separately labelled. | No claim of a real RISC Zero proof, TEE execution, public registry deployment, transaction confirmation, or hardware-backed privacy. |
| Governance | `AgentCouncilGovernor.sol`, Integration and Governance Centers | Weighted-council EIP-712/ERC-1271 controller source, exact selector checks, timelock scheduling, read-only status. | No deployed governor/timelock, role wiring, verified onchain state reader, production deployment, or enabled write. |

## Health API semantics

`GET /api/integrations/health` is read-only. It makes only a public BTC-USD product metadata request, a Base Sepolia chain-ID request, and the existing MCP status call; the probe snapshot is memoized for 30 seconds per server process. It does not request account balances, sign, create orders, submit transactions, pay a facilitator, or query mainnet.

`configured` means local configuration/implementation prerequisites are present, not that the provider is available. `available` can be `null` when the server cannot verify a browser-specific or account-protected capability. `authenticated` is true only for a provider response that explicitly confirms authorization. No private key, token, account response, or upstream credential-bearing URL is returned.

## Explicit app environment

`COINBASE_ENVIRONMENT` accepts `DEMO`, `SANDBOX`, `PRODUCTION_READ_ONLY`, or `PRODUCTION_RESTRICTED`; unset and invalid values resolve to `DEMO`. `SANDBOX` is only selected when `COINBASE_SANDBOX_API_URL` and the existing provider's `COINBASE_ADVANCED_TRADE_URL` are valid, matching HTTPS endpoints; the operator remains responsible for verifying the target. `PRODUCTION_READ_ONLY` status requires the existing portfolio-read opt-in and a server-side credential pair. This status check does not prove an authenticated web-app perimeter, so keep private portfolio routes disabled on public unauthenticated deployments. `PRODUCTION_RESTRICTED` does not enable any write path. `ENABLE_LIVE_EXECUTION` cannot enable trading.

## Checks

- `pnpm typecheck`
- `pnpm test`
- `pnpm build`
- `pnpm contracts:check`

The Foundry test source requires Forge to execute; `contracts:check` compiles contracts/tests and enforces the EIP-170 deployed bytecode limit for production source contracts. Compilation alone is not a substitute for running Foundry tests or completing a Base Sepolia deployment/role-wiring review.
