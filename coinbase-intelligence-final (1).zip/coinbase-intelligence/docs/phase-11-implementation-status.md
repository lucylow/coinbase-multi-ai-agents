# Phase 11 upgrade — implementation status

This archive adds a first, testable Phase 11 infrastructure layer while retaining the existing Phase 8–10 project. It is **not** a claim that the ten-page specification is fully implemented or production-ready. All current financial writes remain disabled.

## Added foundations

- **Smart accounts:** architecture-specific profile validation, verified chain/address matching, legal lifecycle transitions, and append-only application audit events. EOA, ERC-4337, EIP-7702, and Coinbase smart accounts keep distinct signing mechanisms.
- **Account abstraction:** a typed UserOperation lifecycle manager with idempotency, explicit approval checks, expiration, and receipt-gated executed/reverted states. It does not build/sign operations with a wallet or submit to a bundler.
- **Authorization:** scoped network/asset/contract/recipient/operation spending controls; each authorization is limited to one chain and one asset so base-unit budget arithmetic stays meaningful; shared in-process reservations; idempotent settlement/release; revocation records. Settlement requires a caller-supplied verified receipt from an independently implemented adapter.
- **Agent economy:** an auditable, idempotent service-intent ledger that requires policy approval, a budget reservation reference, evidence hash, and verified payment receipt before settlement. There is no payment transport or cross-system atomicity claim.
- **Chain identity:** explicit chain allowlist and provider chain-ID matching; EVM token identity is chain plus contract address (or chain-specific native token), not ticker.
- **Indexing:** confirmation-aware in-memory canonical block checkpoints with fork detection, orphan reporting, and reorg events. Durable persistence, RPC log ingestion, backfill, and derived-record rollback are not yet implemented.
- **Financial data:** decimal-safe fixed-point valuation with price/balance provenance, quote/asset matching, freshness, and price discrepancy flags. This is not yet an accounting ledger or exchange/wallet reconciliation service.
- **Automation:** validated bounded event rules with deduplication, cooldown, max-execution limits, verified-event gating, and human approval support. Supported actions are limited to research, notification, and research-record updates; there is no financial action type.
- **Command center:** a UI uses existing integration-health and Base RPC status APIs and explicitly separates verified runtime observations from local code foundations.

## Safety and deployment boundaries

These modules use in-memory storage and are suitable for local application workflows/tests only; they do not provide cross-process locking, durable audit retention, or transaction isolation across server instances. Production requires an authenticated user/tenant boundary, database-backed atomic reservations/idempotency, trusted receipt verification, policy-engine integration, operational key controls, and independent security review. Local “verified” booleans and event hashes are claims from the caller, not cryptographic proof by themselves.

The following remain intentionally out of scope/unavailable in this drop: live signing, ERC-4337 bundler/paymaster connections, smart-account factory deployment, on-chain delegation changes/revocation, bridge execution, agent-to-agent payment execution, durable chain indexing, contract upgrades or treasury transfer authority, proof generation, arbitrary event-triggered financial execution, and production CI deployment. Do not describe these as connected or live.

## Verification

Run `pnpm install`, then `pnpm typecheck`, `pnpm test`, `pnpm build`, and `pnpm contracts:check`. Foundry commands are only applicable where Foundry is installed. Tests cover policy boundaries, lifecycle constraints, idempotency, finality, settlement receipt requirements, decimal-safe arithmetic, and automation bounds.
