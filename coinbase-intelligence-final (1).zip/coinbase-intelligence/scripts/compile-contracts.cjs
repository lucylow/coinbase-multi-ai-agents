const fs = require("node:fs");
const path = require("node:path");
const solc = require("solc");

const root = path.resolve(__dirname, "..");
const sourceRoots = ["contracts/src", "contracts/test"];
const sources = {};

function collect(directory) {
  for (const entry of fs.readdirSync(path.join(root, directory), { withFileTypes: true })) {
    const relative = path.posix.join(directory, entry.name);
    const absolute = path.join(root, relative);
    if (entry.isDirectory()) collect(relative);
    else if (entry.isFile() && entry.name.endsWith(".sol")) {
      sources[relative] = { content: fs.readFileSync(absolute, "utf8") };
    }
  }
}
sourceRoots.forEach(collect);

function findImports(importPath) {
  const candidates = [path.resolve(root, importPath), path.resolve(root, "node_modules", importPath)];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
      return { contents: fs.readFileSync(candidate, "utf8") };
    }
  }
  return { error: `Import not found: ${importPath}` };
}

const input = {
  language: "Solidity",
  sources,
  settings: {
    optimizer: { enabled: true, runs: 200 },
    viaIR: true,
    evmVersion: "cancun",
    outputSelection: { "*": { "*": ["abi", "evm.bytecode.object", "evm.deployedBytecode.object"] } },
  },
};
const output = JSON.parse(solc.compile(JSON.stringify(input), { import: findImports }));
const diagnostics = output.errors ?? [];
for (const item of diagnostics) {
  const line = `${item.severity.toUpperCase()}: ${item.formattedMessage.trim()}`;
  console[item.severity === "error" ? "error" : "warn"](line);
}
const errors = diagnostics.filter((item) => item.severity === "error");
if (errors.length) process.exit(1);
const compiled = Object.values(output.contracts ?? {}).reduce((count, contracts) => count + Object.keys(contracts).length, 0);
for (const [source, contracts] of Object.entries(output.contracts ?? {})) {
  if (!source.startsWith("contracts/src/")) continue;
  for (const [name, artifact] of Object.entries(contracts)) {
    const bytecode = artifact.evm?.deployedBytecode?.object;
    if (source === "contracts/src/AgentCouncilGovernor.sol" && name === "AgentCouncilGovernor") {
      console.log(`AgentCouncilGovernor deployed bytecode: ${bytecode.length / 2} bytes (EIP-170 limit 24576).`);
    }
    if (bytecode && bytecode.length / 2 > 24_576) {
      console.error(`ERROR: ${source}:${name} deployed bytecode is ${bytecode.length / 2} bytes (EIP-170 limit 24576).`);
      process.exitCode = 1;
    }
  }
}
if (process.exitCode) process.exit(process.exitCode);
console.log(`Solidity compilation passed: ${compiled} contracts/interfaces using solc ${solc.version()}.`);
