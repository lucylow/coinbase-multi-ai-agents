export type UserOperationStatus = "created" | "validated" | "simulated" | "awaiting_approval" | "signed" | "submitted" | "pending" | "included" | "executed" | "reverted" | "reconciled" | "cancelled" | "expired";
export interface UserOperationRecord {
  id: string; idempotencyKey: string; chainId: number; sender: `0x${string}`; entryPoint: `0x${string}`; entryPointVersion: "0.6" | "0.7";
  nonce: string; callData: `0x${string}`; status: UserOperationStatus; userOpHash?: `0x${string}`; transactionHash?: `0x${string}`; receiptVerified: boolean; outcome?: "success" | "revert"; expiresAt: string; updatedAt: string;
}
export interface OperationEvent { id: string; operationId: string; from: UserOperationStatus | null; to: UserOperationStatus; at: string; note: string }
const TRANSITIONS: Record<UserOperationStatus, readonly UserOperationStatus[]> = {
  created: ["validated", "cancelled", "expired"], validated: ["simulated", "cancelled", "expired"], simulated: ["awaiting_approval", "cancelled", "expired"],
  awaiting_approval: ["signed", "cancelled", "expired"], signed: ["submitted", "cancelled", "expired"], submitted: ["pending", "included"],
  pending: ["included"], included: ["executed", "reverted"], executed: ["reconciled"], reverted: ["reconciled"], reconciled: [], cancelled: [], expired: [],
};
export class UserOperationManager {
  private readonly records = new Map<string, UserOperationRecord>();
  private readonly eventLog: OperationEvent[] = [];
  create(input: Omit<UserOperationRecord, "status" | "receiptVerified" | "updatedAt" | "userOpHash" | "transactionHash" | "outcome">, now = new Date()): UserOperationRecord {
    const existing = [...this.records.values()].find((op) => op.idempotencyKey === input.idempotencyKey);
    if (existing) {
      if (existing.chainId !== input.chainId || existing.sender.toLowerCase() !== input.sender.toLowerCase() || existing.entryPoint.toLowerCase() !== input.entryPoint.toLowerCase() || existing.entryPointVersion !== input.entryPointVersion || existing.nonce !== input.nonce || existing.callData !== input.callData || existing.expiresAt !== input.expiresAt) throw new Error("Idempotency key is already bound to a different operation.");
      return structuredClone(existing);
    }
    if (this.records.has(input.id)) throw new Error("UserOperation ID already exists.");
    if (!input.id || !input.idempotencyKey || !input.chainId || !/^0x[0-9a-fA-F]{40}$/.test(input.sender) || !/^0x[0-9a-fA-F]{40}$/.test(input.entryPoint)) throw new Error("UserOperation identifiers, chain, sender, and EntryPoint must be valid.");
    if (!/^0x([0-9a-fA-F]{2})*$/.test(input.callData)) throw new Error("UserOperation callData must be even-length hex.");
    if (!/^\d+$/.test(input.nonce) || BigInt(input.nonce) < 0n) throw new Error("UserOperation nonce must be a non-negative integer string.");
    if (!Number.isFinite(Date.parse(input.expiresAt)) || Date.parse(input.expiresAt) <= now.getTime()) throw new Error("UserOperation expiration must be in the future.");
    const record: UserOperationRecord = { ...input, status: "created", receiptVerified: false, updatedAt: now.toISOString() };
    this.records.set(record.id, record); this.event(record.id, null, "created", "Operation created; no wallet signature or network submission has occurred.", now);
    return structuredClone(record);
  }
  transition(id: string, status: UserOperationStatus, options: { note: string; userApproved?: boolean; signature?: `0x${string}`; userOpHash?: `0x${string}`; receipt?: { transactionHash: `0x${string}`; success: boolean; verified: boolean } }, now = new Date()): UserOperationRecord {
    const op = this.records.get(id); if (!op) throw new Error("Unknown UserOperation.");
    if (!TRANSITIONS[op.status].includes(status)) throw new Error(`Illegal UserOperation transition: ${op.status} → ${status}.`);
    if (!options.note.trim()) throw new Error("Transition audit note is required.");
    if (Date.parse(op.expiresAt) <= now.getTime() && !["cancelled", "expired"].includes(status)) throw new Error("Expired UserOperation cannot advance.");
    if (status === "signed" && (!options.userApproved || !options.signature || !/^0x(?:[0-9a-fA-F]{2})+$/.test(options.signature))) throw new Error("Explicit user approval and a valid signature are required before signed state.");
    if (options.userOpHash && !/^0x[0-9a-fA-F]{64}$/.test(options.userOpHash)) throw new Error("Bundler operation hash must be a 32-byte hash.");
    if (status === "submitted" && (!op.userOpHash && !options.userOpHash)) throw new Error("Bundler operation hash is required; submission must be tracked.");
    if (status === "executed" || status === "reverted") {
      if (!options.receipt?.verified || !/^0x[0-9a-fA-F]{64}$/.test(options.receipt.transactionHash)) throw new Error("Execution outcome requires a verified on-chain receipt.");
      if ((status === "executed") !== options.receipt.success) throw new Error("Receipt outcome conflicts with requested operation state.");
    }
    if (options.userOpHash) op.userOpHash = options.userOpHash;
    if (status === "executed" || status === "reverted") { op.receiptVerified = true; op.outcome = options.receipt!.success ? "success" : "revert"; op.transactionHash = options.receipt!.transactionHash; }
    const from = op.status; op.status = status; op.updatedAt = now.toISOString();
    this.event(id, from, status, options.note, now);
    return structuredClone(op);
  }
  get(id: string): UserOperationRecord | undefined { const item = this.records.get(id); return item ? structuredClone(item) : undefined; }
  list(): UserOperationRecord[] { return [...this.records.values()].map((item) => structuredClone(item)); }
  history(id?: string): OperationEvent[] { return this.eventLog.filter((item) => !id || item.operationId === id).map((item) => ({ ...item })); }
  private event(operationId: string, from: UserOperationStatus | null, to: UserOperationStatus, note: string, now = new Date()) { if (!note.trim()) throw new Error("Transition audit note is required."); this.eventLog.push({ id: `${operationId}:${this.eventLog.length + 1}`, operationId, from, to, at: now.toISOString(), note }); }
}
