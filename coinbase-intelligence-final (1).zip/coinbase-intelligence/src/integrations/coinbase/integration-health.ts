import { HttpAdvancedTradeProvider } from "./advancedTradeProvider";
import { coinbaseProvider } from "./coinbase-provider";
import { readChainId } from "@/integrations/base/base-rpc-service";
import { walletSdkStatus } from "@/integrations/coinbase-wallet/wallet-sdk";

export type CoinbaseEnvironment = "DEMO" | "SANDBOX" | "PRODUCTION_READ_ONLY" | "PRODUCTION_RESTRICTED";
export interface IntegrationCapability {
  id: string;
  configured: boolean;
  available: boolean | null;
  authenticated: boolean | null;
  lastCheckedAt: string | null;
  responseLatencyMs: number | null;
  lastSuccessfulCheckAt: string | null;
  lastError: string | null;
  requiredConfiguration: string[];
  supportedOperations: string[];
  accessMode: "read-only" | "write-capable";
  note?: string;
}
export interface IntegrationHealthSnapshot {
  environment: { mode: CoinbaseEnvironment; defaulted: boolean; productionReadOnlyOptIn: boolean; tradingEnabled: false; warning: string | null };
  checkedAt: string;
  capabilities: Record<string, IntegrationCapability>;
}

type Env = Record<string, string | undefined>;
type ProbeAdapters = {
  marketData: () => Promise<unknown>;
  baseRpc: () => Promise<unknown>;
  mcp: () => Promise<{ status: string; authorization: string; message?: string; capabilities?: string[] }>;
};

const MODES: CoinbaseEnvironment[] = ["DEMO", "SANDBOX", "PRODUCTION_READ_ONLY", "PRODUCTION_RESTRICTED"];
const credentialPair = (env: Env) => Boolean(env.COINBASE_ADVANCED_API_KEY_NAME?.trim() && env.COINBASE_ADVANCED_API_PRIVATE_KEY?.trim());
const failureSummary = (name: string) => `${name} health check failed; see server-side logs for provider details.`;
function normalizedHttpsEndpoint(value: string | undefined): string | null {
  if (!value) return null;
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" || url.username || url.password) return null;
    return url.toString().replace(/\/$/, "");
  } catch { return null; }
}

export function resolveCoinbaseEnvironment(env: Env) {
  const raw = env.COINBASE_ENVIRONMENT?.trim().toUpperCase();
  const selected = raw && MODES.includes(raw as CoinbaseEnvironment) ? raw as CoinbaseEnvironment : "DEMO";
  const sandbox = normalizedHttpsEndpoint(env.COINBASE_SANDBOX_API_URL);
  const providerEndpoint = normalizedHttpsEndpoint(env.COINBASE_ADVANCED_TRADE_URL);
  const mode = selected === "SANDBOX" && (!sandbox || sandbox !== providerEndpoint) ? "DEMO" : selected;
  const productionReadOnlyOptIn = selected === "PRODUCTION_READ_ONLY" && env.COINBASE_PORTFOLIO_READS_ENABLED === "true" && credentialPair(env);
  const warning = raw && !MODES.includes(raw as CoinbaseEnvironment)
    ? "Unknown COINBASE_ENVIRONMENT; safely defaulted to DEMO."
    : selected === "SANDBOX" && mode === "DEMO"
      ? "Sandbox mode requires COINBASE_SANDBOX_API_URL and COINBASE_ADVANCED_TRADE_URL to be matching verified HTTPS endpoints; effective mode is DEMO."
      : selected.startsWith("PRODUCTION") && !productionReadOnlyOptIn
        ? "Production reads are not enabled: explicit PRODUCTION_READ_ONLY mode, read opt-in, and server-side credentials are all required."
        : selected === "PRODUCTION_RESTRICTED"
          ? "Restricted production remains read-only in this application; no order, transfer, signing, or settlement path is implemented."
          : null;
  return { mode, defaulted: !raw || !MODES.includes(raw as CoinbaseEnvironment) || mode !== selected, productionReadOnlyOptIn, tradingEnabled: false as const, warning };
}

const capability = (id: string, props: Partial<IntegrationCapability> = {}): IntegrationCapability => ({
  id, configured: false, available: null, authenticated: null, lastCheckedAt: null, responseLatencyMs: null, lastSuccessfulCheckAt: null,
  lastError: null, requiredConfiguration: [], supportedOperations: [], accessMode: "read-only", ...props,
});

export async function buildIntegrationHealth(env: Env = process.env, adapters: ProbeAdapters = {
  marketData: () => new HttpAdvancedTradeProvider().getProduct("BTC-USD"),
  baseRpc: () => readChainId("base-sepolia", env.BASE_SEPOLIA_RPC_URL || env.BASE_RPC_URL),
  mcp: () => coinbaseProvider.status(),
}, now = new Date()) : Promise<IntegrationHealthSnapshot> {
  const checkedAt = now.toISOString();
  const environment = resolveCoinbaseEnvironment(env);
  const timedProbe = async <T,>(probe: () => Promise<T>) => {
    const startedAt = Date.now();
    try { return { status: "fulfilled" as const, value: await probe(), latencyMs: Date.now() - startedAt }; }
    catch (reason) { return { status: "rejected" as const, reason, latencyMs: Date.now() - startedAt }; }
  };
  const [market, base, mcp] = await Promise.all([
    timedProbe(adapters.marketData), timedProbe(adapters.baseRpc), timedProbe(adapters.mcp),
  ]);
  const mcpResult = mcp.status === "fulfilled" ? mcp.value : null;
  const keyConfigured = credentialPair(env);
  const portfolioOptIn = env.COINBASE_PORTFOLIO_READS_ENABLED === "true";
  const policyConfigured = Boolean(env.CDP_POLICY_ENGINE_URL && env.CDP_POLICY_ENGINE_TOKEN);

  return {
    environment,
    checkedAt,
    capabilities: {
      advancedTradeRead: capability("advancedTradeRead", {
        configured: keyConfigured && portfolioOptIn,
        available: null,
        authenticated: null,
        requiredConfiguration: ["COINBASE_PORTFOLIO_READS_ENABLED=true", "server-side CDP key name/private key", "protected authenticated application perimeter"],
        supportedOperations: ["account reads", "authorized portfolio reads"],
        note: keyConfigured && portfolioOptIn ? "Credentials and opt-in are present, but account access has not been probed in this health check." : "No account endpoint is called by the health check; configuration is not proof of authentication.",
      }),
      marketData: capability("marketData", {
        configured: true,
        available: market.status === "fulfilled",
        authenticated: false,
        lastCheckedAt: checkedAt,
        responseLatencyMs: market.latencyMs,
        lastSuccessfulCheckAt: market.status === "fulfilled" ? checkedAt : null,
        lastError: market.status === "rejected" ? failureSummary("Public Coinbase market data") : null,
        requiredConfiguration: ["Internet access to Coinbase public market endpoints"],
        supportedOperations: ["public product metadata", "public market data", "candles", "order-book snapshot"],
      }),
      websocket: capability("websocket", {
        configured: true,
        available: null,
        authenticated: false,
        requiredConfiguration: ["browser access to Coinbase public WebSocket endpoint"],
        supportedOperations: ["browser ticker stream", "heartbeats", "status"],
        note: "WebSocket health is browser-session-specific and is reported by the live market-stream status, not probed from this server endpoint.",
      }),
      mcp: capability("mcp", {
        configured: Boolean(mcpResult && mcpResult.status !== "not-configured"),
        available: mcpResult ? mcpResult.status !== "failed" && mcpResult.status !== "not-configured" : false,
        authenticated: mcpResult ? mcpResult.authorization === "authorized" : false,
        lastCheckedAt: checkedAt,
        responseLatencyMs: mcp.latencyMs,
        lastSuccessfulCheckAt: mcpResult && mcpResult.status !== "failed" && mcpResult.status !== "not-configured" ? checkedAt : null,
        lastError: mcp.status === "rejected" ? failureSummary("Coinbase MCP") : mcpResult?.status === "failed" ? failureSummary("Coinbase MCP") : null,
        requiredConfiguration: ["host-provided official MCP transport", "user authorization"],
        supportedOperations: mcpResult?.capabilities?.filter((name: string) => name.trim()) ?? [],
        note: "Capabilities are usable only when discovered in an authorized session and permitted by the read-only gateway.",
      }),
      cdpWallet: capability("cdpWallet", {
        configured: walletSdkStatus.configured,
        available: null,
        authenticated: null,
        requiredConfiguration: ["official wallet SDK integration", "explicit user wallet connection"],
        supportedOperations: ["wallet discovery in a user-initiated browser flow"],
        note: walletSdkStatus.note,
      }),
      baseRpc: capability("baseRpc", {
        configured: true,
        available: base.status === "fulfilled",
        authenticated: false,
        lastCheckedAt: checkedAt,
        responseLatencyMs: base.latencyMs,
        lastSuccessfulCheckAt: base.status === "fulfilled" ? checkedAt : null,
        lastError: base.status === "rejected" ? failureSummary("Base Sepolia RPC") : null,
        requiredConfiguration: ["Base Sepolia JSON-RPC endpoint (defaults to the public endpoint)"],
        supportedOperations: ["chain ID verification"],
        note: base.status === "fulfilled" ? "RPC returned the expected Base Sepolia chain ID." : "This probe verifies chain ID only; it does not verify configured contract addresses or state.",
      }),
      policyEngine: capability("policyEngine", {
        configured: policyConfigured,
        available: false,
        requiredConfiguration: ["CDP policy endpoint", "server-side policy token", "supported official SDK adapter"],
        supportedOperations: [],
        note: policyConfigured ? "Endpoint/token are configured, but the official policy adapter is not implemented or health-verified." : "No remote policy adapter is configured; local safeguards remain independent.",
      }),
      spendPermissions: capability("spendPermissions", {
        configured: true,
        available: true,
        authenticated: false,
        requiredConfiguration: [],
        supportedOperations: ["local permission validation only"],
        note: "Local validation is advisory; no CDP spend-permission SDK operation or transaction authority is configured.",
      }),
      x402Payments: capability("x402Payments", {
        configured: Boolean(env.X402_FACILITATOR_URL),
        available: false,
        requiredConfiguration: ["verified facilitator", "supported network/asset", "explicit payment policy", "settlement adapter"],
        supportedOperations: [],
        note: "Facilitator configuration alone does not verify payment requirements, payment authorization, or settlement; the settlement adapter remains unavailable.",
      }),
    },
  };
}

let cached: { expiresAt: number; snapshot: Promise<IntegrationHealthSnapshot> } | undefined;
export function getIntegrationHealth(env: Env = process.env, now = Date.now()): Promise<IntegrationHealthSnapshot> {
  if (cached && cached.expiresAt > now) return cached.snapshot;
  const snapshot = buildIntegrationHealth(env);
  cached = { expiresAt: now + 30_000, snapshot };
  return snapshot;
}
export function resetIntegrationHealthCacheForTests() { cached = undefined; }
