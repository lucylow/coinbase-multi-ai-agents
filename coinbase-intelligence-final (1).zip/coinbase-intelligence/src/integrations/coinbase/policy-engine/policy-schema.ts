export type PolicyOperation = "signEvmTransaction" | "sendEvmTransaction" | "signEvmTypedData" | "prepareUserOperation" | "sendUserOperation";
export type AgentPolicyProfile = "RESEARCH" | "QUANTITATIVE" | "RESEARCH_PROCUREMENT" | "BLOCKCHAIN_OPERATIONS" | "AUDIT";
export type PolicyRule = { operation: PolicyOperation; chains: number[]; contracts?: string[]; destinations?: string[]; maxValueWei?: string; requiresUserApproval: boolean };
export type PolicyProfile = { id: AgentPolicyProfile; description: string; rules: PolicyRule[]; denyByDefault: true };

const noWrites: PolicyRule[] = [];
export const POLICY_PROFILES: Record<AgentPolicyProfile, PolicyProfile> = {
  RESEARCH: { id: "RESEARCH", description: "Read-only research; no wallet signing.", rules: noWrites, denyByDefault: true },
  QUANTITATIVE: { id: "QUANTITATIVE", description: "Analysis and proposal generation; no wallet signing.", rules: noWrites, denyByDefault: true },
  RESEARCH_PROCUREMENT: { id: "RESEARCH_PROCUREMENT", description: "Prepare payment proposals; execution requires a separate owner-approved flow.", rules: noWrites, denyByDefault: true },
  BLOCKCHAIN_OPERATIONS: { id: "BLOCKCHAIN_OPERATIONS", description: "Restricted Base Sepolia registry operations with explicit approval.", rules: [{ operation: "prepareUserOperation", chains: [84532], requiresUserApproval: true }], denyByDefault: true },
  AUDIT: { id: "AUDIT", description: "Read-only verification and reconciliation.", rules: noWrites, denyByDefault: true },
};
