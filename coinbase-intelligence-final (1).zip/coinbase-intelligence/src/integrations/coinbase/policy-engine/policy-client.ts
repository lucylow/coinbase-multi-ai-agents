export class PolicyEngineUnavailableError extends Error { constructor(message = "Coinbase CDP Policy Engine is not configured.") { super(message); this.name = "PolicyEngineUnavailableError"; } }

export type PolicyEngineClient = { configured: boolean; listPolicies(): Promise<never>; getPolicy(id: string): Promise<never>; validateRemoteOperation(input: unknown): Promise<never> };
export function createPolicyEngineClient(): PolicyEngineClient {
  const configured = Boolean(process.env.CDP_POLICY_ENGINE_URL && process.env.CDP_POLICY_ENGINE_TOKEN);
  const unavailable = async (): Promise<never> => { throw new PolicyEngineUnavailableError(configured ? "CDP Policy Engine SDK adapter is pending exact account/API-version configuration." : undefined); };
  return { configured, listPolicies: unavailable, getPolicy: unavailable, validateRemoteOperation: unavailable };
}
