import { POLICY_PROFILES, type AgentPolicyProfile, type PolicyOperation } from "./policy-schema";

export type PolicySimulationRequest = { profile: AgentPolicyProfile; operation: PolicyOperation; chainId: number; contractAddress?: string; destination?: string; valueWei?: string; userApproved: boolean };
export type PolicySimulationResult = { allowed: boolean; source: "LOCAL_SIMULATION"; matchedRule?: string; reasons: string[]; requiresUserApproval: boolean };
export function simulatePolicy(request: PolicySimulationRequest): PolicySimulationResult {
  const profile = POLICY_PROFILES[request.profile];
  const rule = profile.rules.find((candidate) => candidate.operation === request.operation && candidate.chains.includes(request.chainId) && (!candidate.contracts || (request.contractAddress && candidate.contracts.includes(request.contractAddress.toLowerCase()))) && (!candidate.destinations || (request.destination && candidate.destinations.includes(request.destination.toLowerCase()))) && (!candidate.maxValueWei || BigInt(request.valueWei || "0") <= BigInt(candidate.maxValueWei)));
  if (!rule) return { allowed: false, source: "LOCAL_SIMULATION", reasons: [`${profile.id} is deny-by-default and has no matching rule.`], requiresUserApproval: false };
  if (rule.requiresUserApproval && !request.userApproved) return { allowed: false, source: "LOCAL_SIMULATION", matchedRule: rule.operation, reasons: ["Fresh owner approval is required."], requiresUserApproval: true };
  return { allowed: true, source: "LOCAL_SIMULATION", matchedRule: rule.operation, reasons: ["Local rule matched. This is not proof of a CDP Policy Engine decision."], requiresUserApproval: rule.requiresUserApproval };
}
