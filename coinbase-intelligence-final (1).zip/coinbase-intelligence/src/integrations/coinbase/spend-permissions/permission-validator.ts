export type AgentSpendPermission = { id: string; agentId: string; smartAccount: string; network: "base-sepolia"; assetAddress: string; spenderAddress: string; maximumPerTransaction: string; maximumTotal: string; spentTotal?: string; validAfter: string; validUntil: string; approved: boolean; revoked: boolean; createdAt: string };
export type PermissionCheck = { ok: boolean; reason?: string };
const address = (value: string) => /^0x[0-9a-fA-F]{40}$/.test(value);
export function validateSpendPermission(permission: AgentSpendPermission, request: { network: string; assetAddress: string; spenderAddress: string; amount: string; now?: string }): PermissionCheck {
  if (permission.network !== "base-sepolia" || request.network !== "base-sepolia") return { ok: false, reason: "Spend permissions are restricted to Base Sepolia." };
  if (![permission.assetAddress, permission.spenderAddress, request.assetAddress, request.spenderAddress].every(address)) return { ok: false, reason: "Token and spender addresses must be valid EVM addresses." };
  if (permission.assetAddress.toLowerCase() !== request.assetAddress.toLowerCase()) return { ok: false, reason: "Asset is not permitted." };
  if (permission.spenderAddress.toLowerCase() !== request.spenderAddress.toLowerCase()) return { ok: false, reason: "Spender is not permitted." };
  if (!permission.approved || permission.revoked) return { ok: false, reason: "Permission is not approved or has been revoked." };
  const now = Date.parse(request.now || new Date().toISOString());
  if (!Number.isFinite(now) || now < Date.parse(permission.validAfter) || now > Date.parse(permission.validUntil)) return { ok: false, reason: "Permission is outside its validity window." };
  try { const amount = BigInt(request.amount); if (amount < 0n || amount > BigInt(permission.maximumPerTransaction) || amount + BigInt(permission.spentTotal || "0") > BigInt(permission.maximumTotal)) return { ok: false, reason: "Amount exceeds the permission allowance." }; }
  catch { return { ok: false, reason: "Amounts must be non-negative integer base units." }; }
  return { ok: true };
}
