import { BASE_NETWORKS, type BaseNetwork } from "./base-network-config";

export class BaseRpcError extends Error {
  constructor(message: string, readonly code?: number) { super(message); this.name = "BaseRpcError"; }
}

export function resolveBaseRpcUrl(network: BaseNetwork, env: Record<string, string | undefined> = process.env): string {
  const configured = network === "base-sepolia"
    ? env.BASE_SEPOLIA_RPC_URL || env.BASE_RPC_URL
    : env.BASE_MAINNET_RPC_URL;
  return configured || (network === "base-sepolia" ? "https://sepolia.base.org" : "https://mainnet.base.org");
}

export async function readChainId(network: BaseNetwork, rpcUrl?: string, signal?: AbortSignal): Promise<number> {
  const url = rpcUrl || resolveBaseRpcUrl(network);
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8_000);
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "eth_chainId", params: [] }),
      signal: signal ? AbortSignal.any([signal, controller.signal]) : controller.signal,
      cache: "no-store",
    });
    if (!response.ok) throw new BaseRpcError(`Base RPC returned HTTP ${response.status}`);
    const payload = await response.json() as { result?: string; error?: { message?: string; code?: number } };
    if (payload.error) throw new BaseRpcError("Base RPC request failed.", payload.error.code);
    if (!payload.result || !/^0x[0-9a-f]+$/i.test(payload.result)) throw new BaseRpcError("Base RPC returned an invalid chain ID");
    const chainId = Number.parseInt(payload.result, 16);
    if (chainId !== BASE_NETWORKS[network].chainId) throw new BaseRpcError(`RPC chain mismatch: expected ${BASE_NETWORKS[network].chainId}, received ${chainId}`);
    return chainId;
  } catch (error) {
    if (error instanceof BaseRpcError) throw error;
    throw new BaseRpcError("Base RPC transport failed or timed out.");
  } finally { clearTimeout(timeout); }
}
