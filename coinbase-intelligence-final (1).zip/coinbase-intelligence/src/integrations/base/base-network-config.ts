export const BASE_NETWORKS = {
  "base-sepolia": { chainId: 84532, name: "Base Sepolia", explorer: "https://sepolia.basescan.org" },
  base: { chainId: 8453, name: "Base Mainnet", explorer: "https://basescan.org" },
} as const;

export type BaseNetwork = keyof typeof BASE_NETWORKS;

export function explorerTransactionUrl(network: BaseNetwork, hash: string): string | null {
  if (!/^0x[0-9a-fA-F]{64}$/.test(hash)) return null;
  return `${BASE_NETWORKS[network].explorer}/tx/${hash}`;
}

export function isAllowedChainId(chainId: number, write = false): boolean {
  return write ? chainId === BASE_NETWORKS["base-sepolia"].chainId : chainId === 8453 || chainId === 84532;
}
