import { isAddress, getAddress } from "viem";

export type AccountArchitecture = "eoa" | "erc4337" | "eip7702" | "coinbase_smart_account";
export type AccountStatus = "discovered" | "validated" | "network_verified" | "permissions_configured" | "ready" | "monitored" | "suspended" | "revoked";
export interface SmartAccountProfile {
  accountId: string;
  address: `0x${string}`;
  chainId: number;
  architecture: AccountArchitecture;
  capabilities: string[];
  isDeployed: boolean;
  isVerified: boolean;
  authorizationStatus: "unauthorized" | "pending" | "authorized" | "revoked";
  status: AccountStatus;
  signingMechanism: "eoa_signature" | "account_abstraction" | "delegated_eoa" | "coinbase_cdp";
  lastVerifiedAt?: string;
}
export interface AccountEvent { id: string; accountId: string; from: AccountStatus | null; to: AccountStatus; at: string; reason: string }

const NEXT: Record<AccountStatus, readonly AccountStatus[]> = {
  discovered: ["validated", "suspended", "revoked"],
  validated: ["network_verified", "suspended", "revoked"],
  network_verified: ["permissions_configured", "suspended", "revoked"],
  permissions_configured: ["ready", "suspended", "revoked"],
  ready: ["monitored", "suspended", "revoked"],
  monitored: ["suspended", "revoked"],
  suspended: ["validated", "network_verified", "permissions_configured", "ready", "monitored", "revoked"],
  revoked: [],
};
const SIGNER: Record<AccountArchitecture, SmartAccountProfile["signingMechanism"]> = {
  eoa: "eoa_signature", erc4337: "account_abstraction", eip7702: "delegated_eoa", coinbase_smart_account: "coinbase_cdp",
};

export function validateAccountProfile(input: SmartAccountProfile): SmartAccountProfile {
  if (!input.accountId.trim()) throw new Error("Account ID is required.");
  if (!isAddress(input.address)) throw new Error("Account address must be a valid EVM address.");
  if (!Number.isSafeInteger(input.chainId) || input.chainId <= 0) throw new Error("A positive, verified chain ID is required.");
  if (input.signingMechanism !== SIGNER[input.architecture]) throw new Error(`Signing mechanism does not match ${input.architecture}.`);
  if (input.architecture === "eoa" && input.capabilities.includes("user_operation")) throw new Error("EOA profiles cannot claim ERC-4337 UserOperation support.");
  if (input.isVerified && !input.lastVerifiedAt) throw new Error("Verified profiles require a verification timestamp.");
  return { ...input, address: getAddress(input.address), capabilities: [...new Set(input.capabilities)] };
}

export class SmartAccountManager {
  private readonly profiles = new Map<string, SmartAccountProfile>();
  private readonly events: AccountEvent[] = [];
  discover(profile: SmartAccountProfile): SmartAccountProfile {
    const valid = validateAccountProfile(profile);
    if (this.profiles.has(valid.accountId)) throw new Error("Account ID already exists.");
    if (valid.isVerified || valid.authorizationStatus !== "unauthorized" || valid.lastVerifiedAt) throw new Error("Discovered accounts cannot assert prior verification or authorization.");
    const duplicate = [...this.profiles.values()].some((item) => item.chainId === valid.chainId && item.address.toLowerCase() === valid.address.toLowerCase());
    if (duplicate) throw new Error("This address is already registered for the chain.");
    if (valid.status !== "discovered") throw new Error("New accounts must begin in discovered state.");
    this.profiles.set(valid.accountId, valid);
    this.record(valid.accountId, null, "discovered", "Account discovered; ownership and network still require independent verification.");
    return structuredClone(valid);
  }
  get(accountId: string): SmartAccountProfile | undefined { const value = this.profiles.get(accountId); return value ? structuredClone(value) : undefined; }
  list(): SmartAccountProfile[] { return [...this.profiles.values()].map((item) => structuredClone(item)); }
  transition(accountId: string, to: AccountStatus, reason: string, evidence?: { verifiedChainId?: number; verifiedAddress?: string; authorizedByUser?: boolean }, now = new Date()): SmartAccountProfile {
    if (!reason.trim()) throw new Error("Lifecycle transitions require an audit reason.");
    const item = this.profiles.get(accountId);
    if (!item) throw new Error("Unknown account.");
    if (!NEXT[item.status].includes(to)) throw new Error(`Illegal account lifecycle transition: ${item.status} → ${to}.`);
    if (to === "network_verified" && evidence?.verifiedChainId !== item.chainId) throw new Error("Connected provider chain ID must match the declared chain.");
    if (to === "network_verified" && (!evidence?.verifiedAddress || evidence.verifiedAddress.toLowerCase() !== item.address.toLowerCase())) throw new Error("Provider address must match the registered account.");
    if (to === "permissions_configured" && !evidence?.authorizedByUser) throw new Error("Explicit user authorization is required to configure account permissions.");
    if (to === "ready" && (!evidence?.authorizedByUser || item.authorizationStatus !== "authorized")) throw new Error("User authorization and configured permissions are required before ready state.");
    const from = item.status;
    item.status = to;
    if (to === "network_verified") item.isVerified = true;
    if (to === "permissions_configured") item.authorizationStatus = "authorized";
    if (to === "revoked") item.authorizationStatus = "revoked";
    if (to === "suspended" && item.authorizationStatus === "authorized") item.authorizationStatus = "pending";
    item.lastVerifiedAt = to === "network_verified" ? now.toISOString() : item.lastVerifiedAt;
    this.record(accountId, from, to, reason, now);
    return structuredClone(item);
  }
  history(accountId?: string): AccountEvent[] { return this.events.filter((event) => !accountId || event.accountId === accountId).map((item) => ({ ...item })); }
  private record(accountId: string, from: AccountStatus | null, to: AccountStatus, reason: string, now = new Date()) {
    if (!reason.trim()) throw new Error("Lifecycle transitions require an audit reason.");
    this.events.push({ id: `${accountId}:${this.events.length + 1}`, accountId, from, to, at: now.toISOString(), reason });
  }
}
