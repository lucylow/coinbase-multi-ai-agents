import { getAddress, isAddress } from "viem";

export interface ChainDefinition {
  chainId: number; name: string; nativeCurrency: string; explorerUrl: string; isTestnet: boolean; isEnabled: boolean;
  supportsEvm: boolean; finalityConfirmations: number; supportedCapabilities: string[];
}
export interface CanonicalToken {
  canonicalId: string; symbol: string; name: string; chainId: number; contractAddress?: `0x${string}`; decimals: number; verificationStatus: "verified" | "unverified";
}
export const DEFAULT_CHAINS: readonly ChainDefinition[] = [
  { chainId: 8453, name: "Base Mainnet", nativeCurrency: "ETH", explorerUrl: "https://basescan.org", isTestnet: false, isEnabled: true, supportsEvm: true, finalityConfirmations: 20, supportedCapabilities: ["read_rpc", "logs"] },
  { chainId: 84532, name: "Base Sepolia", nativeCurrency: "ETH", explorerUrl: "https://sepolia.basescan.org", isTestnet: true, isEnabled: true, supportsEvm: true, finalityConfirmations: 2, supportedCapabilities: ["read_rpc", "logs", "simulation"] },
];
export class ChainRegistry {
  private readonly chains = new Map<number, ChainDefinition>();
  constructor(chains: readonly ChainDefinition[] = DEFAULT_CHAINS) { for (const chain of chains) this.register(chain); }
  register(chain: ChainDefinition): void {
    if (!Number.isSafeInteger(chain.chainId) || chain.chainId <= 0) throw new Error("Chain ID must be a positive integer.");
    if (!chain.name.trim() || !/^https:\/\//.test(chain.explorerUrl)) throw new Error("Chain name and HTTPS explorer URL are required.");
    if (!Number.isSafeInteger(chain.finalityConfirmations) || chain.finalityConfirmations < 0) throw new Error("Finality confirmations must be a non-negative integer.");
    if (this.chains.has(chain.chainId)) throw new Error(`Chain ${chain.chainId} is already registered.`);
    this.chains.set(chain.chainId, structuredClone(chain));
  }
  get(chainId: number): ChainDefinition | undefined { const chain = this.chains.get(chainId); return chain ? structuredClone(chain) : undefined; }
  listEnabled(): ChainDefinition[] { return [...this.chains.values()].filter((chain) => chain.isEnabled).map((chain) => structuredClone(chain)); }
  verifyProviderChain(expectedChainId: number, providerChainId: number): ChainDefinition {
    const chain = this.chains.get(expectedChainId);
    if (!chain || !chain.isEnabled) throw new Error("Requested chain is not enabled in the local registry.");
    if (providerChainId !== expectedChainId) throw new Error(`Provider chain mismatch: expected ${expectedChainId}, received ${providerChainId}.`);
    return structuredClone(chain);
  }
}
export function canonicalizeToken(input: Omit<CanonicalToken, "canonicalId" | "contractAddress"> & { contractAddress?: string }): CanonicalToken {
  if (!Number.isSafeInteger(input.chainId) || input.chainId <= 0) throw new Error("Token chain ID is invalid.");
  if (!Number.isSafeInteger(input.decimals) || input.decimals < 0 || input.decimals > 36) throw new Error("Token decimals must be between 0 and 36.");
  if (!input.symbol.trim() || !input.name.trim()) throw new Error("Token name and symbol are required metadata.");
  if (input.contractAddress !== undefined && !isAddress(input.contractAddress)) throw new Error("Token contract address must be a valid EVM address.");
  const address = input.contractAddress ? getAddress(input.contractAddress) : undefined;
  const canonicalId = address ? `eip155:${input.chainId}/erc20:${address.toLowerCase()}` : `eip155:${input.chainId}/native`;
  return { ...input, contractAddress: address, canonicalId };
}
