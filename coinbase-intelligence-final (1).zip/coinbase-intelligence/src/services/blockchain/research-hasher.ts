import { keccak256, stringToHex } from "viem";

export type ResearchSourceMode = "DEMO" | "COINBASE_MARKET_DATA" | "COINBASE_ACCOUNT_DATA" | "BASE_ONCHAIN_DATA" | "MIXED_SOURCES";
export type ResearchReceiptInput = { taskId: string; agentId: string; output: unknown; evidence: unknown[]; datasetSnapshot: unknown; sourceMode: ResearchSourceMode; salt?: string };

function normalize(value: unknown): unknown {
  if (typeof value === "number" && Number.isFinite(value)) return Number(value.toString());
  if (Array.isArray(value)) return value.map(normalize);
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => [key, normalize(item)]));
  return value;
}
export function canonicalize(value: unknown): string { return JSON.stringify(normalize(value)); }
export function evmHash(value: unknown): `0x${string}` { return keccak256(stringToHex(canonicalize(value))); }
export function createResearchHashes(input: ResearchReceiptInput) {
  const salt = input.salt || "";
  const taskIdHash = evmHash({ taskId: input.taskId, salt });
  const outputHash = evmHash({ output: input.output, salt });
  const evidenceRoot = evmHash({ evidence: input.evidence, salt });
  const datasetSnapshotHash = evmHash({ datasetSnapshot: input.datasetSnapshot, salt });
  const agentIdHash = evmHash({ agentId: input.agentId });
  return { taskIdHash, outputHash, evidenceRoot, datasetSnapshotHash, agentIdHash };
}
export function verifyResearchOutput(output: unknown, expectedHash: `0x${string}`, salt = ""): boolean { return evmHash({ output, salt }).toLowerCase() === expectedHash.toLowerCase(); }
