import { keccak256, stringToHex } from "viem";
import { simulatePolicy, type PolicySimulationRequest } from "@/integrations/coinbase/policy-engine/policy-validator";
export type OnchainExecutionIntent = { id: string; taskId: string; agentId: string; operation: string; chainId: number; walletAddress: string; contractAddress: string; functionSelector: string; calldataHash: `0x${string}`; maximumValue: string; maximumGas: string; policyId?: string; riskReviewId: string; approvalRequired: boolean; expiresAt: string; status: "draft" | "validated" | "rejected" | "awaiting_approval" | "approved" | "submitted" | "confirmed" | "failed" };
export type CouncilReview = { requestingAgent: "approved" | "rejected"; quantitative: "approved" | "rejected"; risk: "approved" | "rejected"; security: "approved" | "rejected"; verification: "approved" | "rejected" };
export function hashIntentPayload(input: Pick<OnchainExecutionIntent, "chainId" | "contractAddress" | "functionSelector" | "calldataHash" | "maximumValue" | "agentId" | "expiresAt">): `0x${string}` { return keccak256(stringToHex(JSON.stringify(input))); }
export function authorizeIntent(intent: OnchainExecutionIntent, council: CouncilReview, policy: PolicySimulationRequest, now = new Date()): { ok: boolean; reason: string } {
  if (intent.chainId !== 84532 || policy.chainId !== 84532) return { ok: false, reason: "Only Base Sepolia writes are eligible." };
  if (Date.parse(intent.expiresAt) <= now.getTime()) return { ok: false, reason: "Authorization has expired." };
  if (!/^0x[0-9a-fA-F]{40}$/.test(intent.walletAddress) || !/^0x[0-9a-fA-F]{40}$/.test(intent.contractAddress)) return { ok: false, reason: "Wallet and contract addresses are invalid." };
  if (!Object.values(council).every((value) => value === "approved")) return { ok: false, reason: "The transaction review council did not approve every mandatory review." };
  const decision = simulatePolicy(policy); if (!decision.allowed) return { ok: false, reason: `Policy rejected: ${decision.reasons.join(" ")}` };
  if (intent.approvalRequired && !policy.userApproved) return { ok: false, reason: "Fresh user approval is required." };
  return { ok: true, reason: "Intent passed local validation and advisory council review; CDP enforcement and final signing remain separate." };
}
