import { keccak256, stringToHex } from "viem";
export const MERKLE_DOMAIN = "COINBASE_INTELLIGENCE|RESEARCH_LEAF|v1";
export type ResearchLeafInput = { taskIdHash: `0x${string}`; agentId: `0x${string}`; outputHash: `0x${string}`; evidenceRoot: `0x${string}`; receiptId?: `0x${string}` };
export function canonicalLeaf(input: ResearchLeafInput): `0x${string}` { if (!input.taskIdHash || !input.agentId || !input.outputHash || !input.evidenceRoot) throw new Error("Research leaf is missing a required hash."); return keccak256(stringToHex(JSON.stringify([MERKLE_DOMAIN, input.taskIdHash.toLowerCase(), input.agentId.toLowerCase(), input.outputHash.toLowerCase(), input.evidenceRoot.toLowerCase(), (input.receiptId || "0x").toLowerCase()]))); }
