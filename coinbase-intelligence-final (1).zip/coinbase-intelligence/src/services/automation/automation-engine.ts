export type AutomationAction = { type: "start_research" | "notify_user" | "update_research_record"; target?: string; payload?: Record<string, string> };
export interface AutomationCondition { path: string; operator: "eq" | "gte" | "lte" | "contains"; value: string }
export interface AutomationRule { id: string; name: string; eventType: string; conditions: AutomationCondition[]; match: "all" | "any"; actions: AutomationAction[]; enabled: boolean; cooldownSeconds: number; maxExecutions: number; requiresHumanApproval: boolean }
export interface AutomationEvent { eventId: string; eventType: string; occurredAt: string; verified: boolean; payload: Record<string, unknown> }
export interface AutomationDecision { ruleId: string; eventId: string; status: "matched" | "rejected" | "awaiting_approval" | "executed" | "duplicate"; reasons: string[]; actions: AutomationAction[]; at: string }
function getPath(object: Record<string, unknown>, path: string): unknown { return path.split(".").reduce<unknown>((value, key) => value && typeof value === "object" ? (value as Record<string, unknown>)[key] : undefined, object); }
function conditionPasses(condition: AutomationCondition, payload: Record<string, unknown>): boolean {
  const actual = getPath(payload, condition.path); if (actual === undefined || actual === null) return false;
  if (condition.operator === "eq") return String(actual) === condition.value;
  if (condition.operator === "contains") return Array.isArray(actual) ? actual.map(String).includes(condition.value) : String(actual).includes(condition.value);
  const a = Number(actual), b = Number(condition.value); if (!Number.isFinite(a) || !Number.isFinite(b)) return false;
  return condition.operator === "gte" ? a >= b : a <= b;
}
export class AutomationEngine {
  private readonly rules = new Map<string, AutomationRule>(); private readonly seen = new Set<string>(); private readonly pendingApprovals = new Set<string>(); private readonly counts = new Map<string, number>(); private readonly lastRun = new Map<string, number>(); private readonly decisions: AutomationDecision[] = [];
  register(rule: AutomationRule): void {
    if (!rule.id || !rule.name || !rule.eventType || rule.conditions.length === 0 || rule.actions.length === 0) throw new Error("Rules require identifiers, an event type, conditions, and bounded actions.");
    if (!Number.isSafeInteger(rule.cooldownSeconds) || rule.cooldownSeconds < 0 || !Number.isSafeInteger(rule.maxExecutions) || rule.maxExecutions < 1) throw new Error("Rules require non-negative cooldown and positive maximum execution limits.");
    if (rule.actions.some((action) => !["start_research", "notify_user", "update_research_record"].includes(action.type))) throw new Error("Financial actions are not supported by event automation.");
    if (this.rules.has(rule.id)) throw new Error("Automation rule ID already exists.");
    this.rules.set(rule.id, structuredClone(rule));
  }
  setEnabled(ruleId: string, enabled: boolean): AutomationRule { const rule = this.rules.get(ruleId); if (!rule) throw new Error("Unknown automation rule."); rule.enabled = enabled; return structuredClone(rule); }
  evaluate(event: AutomationEvent, now = new Date()): AutomationDecision[] {
    const results: AutomationDecision[] = [];
    for (const rule of this.rules.values()) {
      if (rule.eventType !== event.eventType || !rule.enabled) continue;
      const key = `${rule.id}:${event.eventId}`;
      if (this.seen.has(key)) { results.push(this.result(rule.id, event.eventId, "duplicate", ["Event already evaluated for this rule."], [], now)); continue; }
      this.seen.add(key);
      const reasons: string[] = [];
      if (!event.verified) reasons.push("Event is not independently verified.");
      const conditionMatches = rule.match === "all" ? rule.conditions.every((c) => conditionPasses(c, event.payload)) : rule.conditions.some((c) => conditionPasses(c, event.payload));
      if (!conditionMatches) reasons.push("Rule conditions did not match.");
      if ((this.counts.get(rule.id) ?? 0) >= rule.maxExecutions) reasons.push("Maximum execution count reached.");
      const last = this.lastRun.get(rule.id); if (last !== undefined && now.getTime() - last < rule.cooldownSeconds * 1000) reasons.push("Rule cooldown is active.");
      if (reasons.length) { results.push(this.result(rule.id, event.eventId, "rejected", reasons, [], now)); continue; }
      if (rule.requiresHumanApproval) { this.pendingApprovals.add(key); results.push(this.result(rule.id, event.eventId, "awaiting_approval", ["Matching event queued for user approval; no action executed."], rule.actions, now)); continue; }
      this.counts.set(rule.id, (this.counts.get(rule.id) ?? 0) + 1); this.lastRun.set(rule.id, now.getTime());
      results.push(this.result(rule.id, event.eventId, "executed", ["Bounded research/notification action issued; financial execution is unsupported."], rule.actions, now));
    }
    return results;
  }
  approve(ruleId: string, eventId: string, now = new Date()): AutomationDecision {
    const rule = this.rules.get(ruleId); if (!rule || !rule.requiresHumanApproval) throw new Error("No approval-gated rule exists.");
    if (!rule.enabled) throw new Error("Disabled automation rule cannot be approved.");
    if ((this.counts.get(rule.id) ?? 0) >= rule.maxExecutions) throw new Error("Maximum execution count reached.");
    const key = `${ruleId}:${eventId}`;
    if (!this.pendingApprovals.has(key)) throw new Error("No pending approval exists for this event.");
    const last = this.lastRun.get(ruleId); if (last !== undefined && now.getTime() - last < rule.cooldownSeconds * 1000) throw new Error("Rule cooldown is active.");
    this.pendingApprovals.delete(key); this.counts.set(rule.id, (this.counts.get(rule.id) ?? 0) + 1); this.lastRun.set(rule.id, now.getTime());
    return this.result(ruleId, eventId, "executed", ["Human approval recorded; bounded non-financial actions issued."], rule.actions, now);
  }
  history(): AutomationDecision[] { return this.decisions.map((item) => structuredClone(item)); }
  listRules(): AutomationRule[] { return [...this.rules.values()].map((item) => structuredClone(item)); }
  private result(ruleId: string, eventId: string, status: AutomationDecision["status"], reasons: string[], actions: AutomationAction[], now: Date): AutomationDecision { const d = { ruleId, eventId, status, reasons, actions: structuredClone(actions), at: now.toISOString() }; this.decisions.push(d); return structuredClone(d); }
}
