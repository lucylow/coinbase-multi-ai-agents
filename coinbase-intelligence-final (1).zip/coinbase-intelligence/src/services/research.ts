import type { Candle, PortfolioBalance } from "@/models/domain";
import { maxDrawdown, portfolioMetrics } from "./analytics";

export interface BacktestResult {
  strategy: "sma-crossover";
  productId: string;
  candles: number;
  initialCapitalCents: number;
  finalCapitalCents: number;
  totalReturnPct: number;
  maxDrawdownPct: number;
  trades: number;
  benchmarkReturnPct: number;
  assumptions: string[];
}
export interface StressResult {
  scenario: string;
  portfolioBeforeCents: number;
  portfolioAfterCents: number;
  lossCents: number;
  lossPct: number;
  assetShocks: Record<string, number>;
  methodology: string;
}

export function backtestSmaCrossover(productId: string, candles: Candle[], initialCapitalCents = 100_000): BacktestResult {
  if (candles.length < 22) throw new Error("At least 22 candles are required for an SMA crossover backtest.");
  if (!Number.isSafeInteger(initialCapitalCents) || initialCapitalCents <= 0) throw new Error("Initial capital must be a positive safe integer in cents.");
  for (let index = 0; index < candles.length; index += 1) {
    const candle = candles[index];
    const timestamp = Date.parse(candle.time);
    if (!Number.isFinite(timestamp) || (index > 0 && Date.parse(candles[index - 1].time) >= timestamp) || ![candle.open, candle.high, candle.low, candle.close, candle.volume].every(Number.isFinite) || candle.low <= 0 || candle.high < candle.low || candle.open < candle.low || candle.open > candle.high || candle.close < candle.low || candle.close > candle.high || candle.volume < 0) {
      throw new Error(`Invalid or out-of-order OHLCV candle at index ${index}.`);
    }
  }
  let cash = initialCapitalCents;
  let units = 0;
  let trades = 0;
  const equity: number[] = [];
  let pendingLong: boolean | null = null;
  const sma = (index: number, period: number) => candles.slice(index - period + 1, index + 1).reduce((sum, candle) => sum + candle.close, 0) / period;
  for (let index = 0; index < candles.length; index += 1) {
    // A signal observed at the prior close can only execute at this bar's open.
    if (pendingLong !== null) {
      if (pendingLong && units === 0) { units = cash / candles[index].open; cash = 0; trades += 1; }
      else if (!pendingLong && units > 0) { cash = units * candles[index].open; units = 0; trades += 1; }
      pendingLong = null;
    }
    equity.push(cash + units * candles[index].close);
    const short = index >= 6 ? sma(index, 7) : NaN;
    const long = index >= 19 ? sma(index, 20) : NaN;
    if (Number.isFinite(short) && Number.isFinite(long) && short !== long) pendingLong = short > long;
  }
  const finalCapital = equity.at(-1) || initialCapitalCents;
  const benchmark = candles[0].close ? (candles.at(-1)!.close / candles[0].close - 1) * 100 : 0;
  return { strategy: "sma-crossover", productId, candles: candles.length, initialCapitalCents, finalCapitalCents: Math.round(finalCapital), totalReturnPct: (finalCapital / initialCapitalCents - 1) * 100, maxDrawdownPct: maxDrawdown(equity), trades, benchmarkReturnPct: benchmark, assumptions: ["Long-only; no leverage or shorting.", "Signals are calculated at candle close and filled at the next candle open; the final-bar signal is not executed.", "Fees, spread, and slippage are excluded from this research estimate."] };
}

export function stressPortfolio(portfolio: PortfolioBalance[], shocks: Record<string, number>, scenario = "custom shock"): StressResult {
  const before = portfolioMetrics(portfolio).totalCents;
  const after = portfolio.reduce((sum, item) => {
    const shock = shocks[item.asset] ?? 0;
    return sum + Math.round(Number(item.quantity) * Number(item.price) * 100 * (1 + shock));
  }, 0);
  const loss = after - before;
  return { scenario, portfolioBeforeCents: before, portfolioAfterCents: after, lossCents: loss, lossPct: before ? (loss / before) * 100 : 0, assetShocks: shocks, methodology: "Position value is shocked independently by asset percentage and summed in integer cents; no correlations, liquidity impact, or rebalancing are assumed." };
}
