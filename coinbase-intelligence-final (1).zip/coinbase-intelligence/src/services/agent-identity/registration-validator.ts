export type AgentService = { name: string; endpoint: string; version?: string; skills?: string[]; domains?: string[] };
export type AgentRegistrationFile = { type: "https://eips.ethereum.org/EIPS/eip-8004" | "https://eips.ethereum.org/EIPS/eip-8004#registration-v1"; name: string; description: string; image: string; services: AgentService[]; x402Support?: boolean; active: boolean; registrations: Array<{ agentId: number; agentRegistry: string }>; supportedTrust?: string[] };
const allowedServiceNames = new Set(["web", "MCP", "A2A", "OASF", "ENS", "DID", "email"]);
export function validateRegistrationFile(value: unknown): { ok: true; file: AgentRegistrationFile } | { ok: false; errors: string[] } {
  const errors: string[] = []; const item = value as Partial<AgentRegistrationFile>;
  if (!item || (item.type !== "https://eips.ethereum.org/EIPS/eip-8004" && item.type !== "https://eips.ethereum.org/EIPS/eip-8004#registration-v1")) errors.push("type must match the pinned ERC-8004 registration format.");
  if (!item.name || typeof item.name !== "string") errors.push("name is required."); if (typeof item.description !== "string") errors.push("description is required."); if (typeof item.image !== "string") errors.push("image is required."); if (typeof item.active !== "boolean") errors.push("active is required.");
  if (!Array.isArray(item.services)) errors.push("services must be an array."); else for (const service of item.services) { if (!service || !allowedServiceNames.has(service.name)) errors.push(`unsupported service name: ${service?.name || "missing"}.`); if (!service?.endpoint || typeof service.endpoint !== "string") errors.push("every service requires an endpoint."); }
  if (!Array.isArray(item.registrations)) errors.push("registrations must be an array."); else for (const registration of item.registrations) if (!Number.isSafeInteger(registration.agentId) || registration.agentId < 1 || !/^eip155:\d+:0x[0-9a-fA-F]{40}$/.test(registration.agentRegistry)) errors.push("registrations contain an invalid ERC-8004 reference.");
  return errors.length ? { ok: false, errors } : { ok: true, file: item as AgentRegistrationFile };
}
