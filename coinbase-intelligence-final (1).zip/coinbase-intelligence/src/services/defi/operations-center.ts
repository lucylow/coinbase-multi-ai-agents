import { z } from "zod";

export const StrategyRequestSchema = z.object({
  objective: z.string().trim().min(12).max(500),
  chainId: z.literal(84532).default(84532),
  simulationOnly: z.literal(true).default(true),
});

export type StrategyRequest = z.infer<typeof StrategyRequestSchema>;

export type AgentCapability = {
  agent: string;
  access: "read-only" | "simulation-only";
  allowedActions: string[];
  deniedActions: string[];
};

const capabilities: AgentCapability[] = [
  { agent: "DeFi Discovery", access: "read-only", allowedActions: ["discover_verified_markets", "read_protocol_metadata"], deniedActions: ["deposit", "borrow", "swap"] },
  { agent: "Rate Analyst", access: "read-only", allowedActions: ["compare_sourced_rates"], deniedActions: ["deposit", "borrow", "swap"] },
  { agent: "Liquidity Analyst", access: "read-only", allowedActions: ["read_liquidity", "estimate_withdrawal_depth"], deniedActions: ["add_liquidity", "withdraw"] },
  { agent: "Quantitative Allocator", access: "simulation-only", allowedActions: ["model_hypothetical_allocation"], deniedActions: ["submit_transaction", "borrow"] },
  { agent: "Protocol Risk", access: "read-only", allowedActions: ["review_verified_protocol_data"], deniedActions: ["submit_transaction", "approve_own_action"] },
  { agent: "Independent Auditor", access: "read-only", allowedActions: ["verify_calculations", "review_receipts"], deniedActions: ["sign_transaction", "mutate_policy"] },
];

export function getOperationsCenterStatus() {
  return {
    product: "Coinbase AgentKit Operations Center",
    mode: "demo",
    agentKit: { status: "not-configured", packageInstalled: false, message: "No AgentKit wallet or action provider is configured; no capability is inferred." },
    walletProvider: { status: "none", ownership: "none", chainId: null },
    selectedNetwork: { name: "Base Sepolia", chainId: 84532, source: "configured development default", liveWrites: false },
    actionProviders: [],
    capabilities,
    protocols: ["Compound", "Morpho", "Moonwell"].map((name) => ({ name, status: "unverified", marketCount: null, source: null })),
    dataNotice: "No protocol markets, rates, balances, vault addresses, swap quotes, or liquidity values are available until a verified provider is configured.",
    financialWritesEnabled: false as const,
  };
}

export function createStrategyResearch(request: StrategyRequest) {
  const normalized = StrategyRequestSchema.parse(request);
  const status = getOperationsCenterStatus();
  return {
    id: `DEFI-${crypto.randomUUID()}`,
    objective: normalized.objective,
    chainId: normalized.chainId,
    executionMode: "simulation" as const,
    status: "draft" as const,
    allocations: [],
    modeledYield: null,
    estimatedFees: null,
    riskFlags: ["Provider data is unavailable; no yield or fee estimate was fabricated.", "No verified markets are registered for the selected network."],
    supportingAgents: status.capabilities.map((item) => item.agent),
    sourceReferences: [],
    createdAt: new Date().toISOString(),
    policyDecision: { allowedForSimulation: true, liveExecutionAllowed: false, reason: "Research-only draft; live financial writes are disabled by design." },
  };
}
