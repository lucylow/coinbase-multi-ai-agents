import type { Candle } from "@/models/domain";
import type { AdvancedTradeBook } from "@/integrations/coinbase/advancedTradeProvider";

export interface MicrostructureBook extends AdvancedTradeBook {
  source: "coinbase-advanced-trade" | "demo";
}

export interface MicrostructureMetrics {
  bestBid: number | null;
  bestAsk: number | null;
  spread: number | null;
  spreadBps: number | null;
  midPrice: number | null;
  bidDepthBase: number;
  askDepthBase: number;
  bidDepthUsd: number;
  askDepthUsd: number;
  imbalance: number | null;
  oneWaySpreadCostOn1000: number | null;
  momentumPct: number | null;
  realizedVolPct: number | null;
  bids: Array<{ price: number; size: number }>;
  asks: Array<{ price: number; size: number }>;
}

const validLevels = (levels: AdvancedTradeBook["bids"]) =>
  levels.filter(
    (level) =>
      Number.isFinite(level.price) &&
      Number.isFinite(level.size) &&
      level.price > 0 &&
      level.size > 0,
  );

/**
 * Calculates descriptive top-of-book statistics. Depth is limited to the levels
 * supplied in the snapshot; it is not a measure of all available liquidity.
 */
export function calculateMicrostructure(
  book: AdvancedTradeBook | null | undefined,
  candles: Candle[],
  options: { depthNotionalUsd?: number; momentumBars?: number; volatilityBars?: number } = {},
): MicrostructureMetrics {
  const bids = validLevels(book?.bids ?? []).sort((a, b) => b.price - a.price);
  const asks = validLevels(book?.asks ?? []).sort((a, b) => a.price - b.price);
  const bestBid = bids[0]?.price ?? null;
  const bestAsk = asks[0]?.price ?? null;
  const crossed = bestBid !== null && bestAsk !== null && bestBid >= bestAsk;
  const spread = bestBid !== null && bestAsk !== null && !crossed ? bestAsk - bestBid : null;
  const midPrice = spread !== null ? (bestAsk! + bestBid!) / 2 : null;
  const bidDepthBase = bids.reduce((sum, level) => sum + level.size, 0);
  const askDepthBase = asks.reduce((sum, level) => sum + level.size, 0);
  const bidDepthUsd = bids.reduce((sum, level) => sum + level.price * level.size, 0);
  const askDepthUsd = asks.reduce((sum, level) => sum + level.price * level.size, 0);
  const totalDepth = bidDepthBase + askDepthBase;
  const closes = candles
    .map((candle) => candle.close)
    .filter((close) => Number.isFinite(close) && close > 0);
  const momentumBars = options.momentumBars ?? 5;
  const volatilityBars = options.volatilityBars ?? 20;
  const momentumStart = closes.length - momentumBars - 1;
  const momentumPct =
    momentumBars > 0 && momentumStart >= 0
      ? (closes.at(-1)! / closes[momentumStart] - 1) * 100
      : null;
  const recentCloses = closes.slice(-(volatilityBars + 1));
  const recentReturns = recentCloses
    .slice(1)
    .map((close, index) => Math.log(close / recentCloses[index]))
    .filter(Number.isFinite);
  // Square root of summed squared log returns: unannualized realized volatility
  // across the most recent volatilityBars candle-to-candle returns.
  const realizedVolPct =
    recentReturns.length > 0
      ? Math.sqrt(recentReturns.reduce((sum, value) => sum + value ** 2, 0)) * 100
      : null;
  const depthNotionalUsd = options.depthNotionalUsd ?? 1_000;
  const validSpread = spread !== null && midPrice !== null && midPrice > 0;

  return {
    bestBid,
    bestAsk,
    spread,
    spreadBps: validSpread ? (spread! / midPrice!) * 10_000 : null,
    midPrice,
    bidDepthBase,
    askDepthBase,
    bidDepthUsd,
    askDepthUsd,
    imbalance: totalDepth > 0 ? (bidDepthBase - askDepthBase) / totalDepth : null,
    oneWaySpreadCostOn1000:
      validSpread && depthNotionalUsd >= 0
        ? (depthNotionalUsd * spread!) / (2 * midPrice!)
        : null,
    momentumPct,
    realizedVolPct,
    bids,
    asks,
  };
}

/** Stable, intentionally synthetic depth for the demo UI; never represents exchange liquidity. */
export function createDemoOrderBook(
  productId: string,
  referencePrice: number,
  timestamp: string,
  levelCount = 10,
): MicrostructureBook {
  const safePrice = Number.isFinite(referencePrice) && referencePrice > 0 ? referencePrice : 1;
  const spread = safePrice * 0.0006;
  const tick = safePrice * 0.0002;
  const seed = [...productId].reduce((sum, char) => sum + char.charCodeAt(0), 0);
  const bids = Array.from({ length: levelCount }, (_, index) => ({
    price: safePrice - spread / 2 - index * tick,
    size: 0.04 + ((seed + index * 17) % 37) / 100,
  }));
  const asks = Array.from({ length: levelCount }, (_, index) => ({
    price: safePrice + spread / 2 + index * tick,
    size: 0.04 + ((seed + index * 29 + 11) % 41) / 100,
  }));
  return { productId, bids, asks, time: timestamp, source: "demo" };
}
