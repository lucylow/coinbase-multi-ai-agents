export interface ObservedBlock { chainId: number; number: bigint; hash: `0x${string}`; parentHash: `0x${string}`; observedAt: string }
export interface ReorgEvent { id: string; chainId: number; ancestorNumber: string; orphanedHashes: string[]; replacementHash: string; detectedAt: string }
export interface BlockStatus extends ObservedBlock { finalized: boolean }
export type ReorgResult = { type: "accepted"; block: BlockStatus } | { type: "reorg"; block: BlockStatus; event: ReorgEvent; orphaned: BlockStatus[] };
export class ReorgAwareIndexer {
  private readonly canonical = new Map<number, BlockStatus[]>(); private readonly confirmations: Map<number, number>; private readonly reorgs: ReorgEvent[] = [];
  constructor(finalityByChain: Readonly<Record<number, number>>) {
    this.confirmations = new Map(Object.entries(finalityByChain).map(([id, count]) => [Number(id), count]));
    if ([...this.confirmations.values()].some((n) => !Number.isSafeInteger(n) || n < 0)) throw new Error("Finality policies must be non-negative integer confirmation counts.");
  }
  ingest(block: ObservedBlock, canonicalParentHash?: string): ReorgResult {
    const policy = this.confirmations.get(block.chainId); if (policy === undefined) throw new Error("Chain has no explicit finality policy.");
    if (block.number < 0n || !/^0x[0-9a-fA-F]{64}$/.test(block.hash) || !/^0x[0-9a-fA-F]{64}$/.test(block.parentHash)) throw new Error("Block number and hashes are invalid.");
    const blocks = this.canonical.get(block.chainId) ?? [];
    const existing = blocks.find((item) => item.number === block.number);
    if (existing?.hash === block.hash) return { type: "accepted", block: structuredClone(existing) };
    if (blocks.length === 0) {
      if (block.number !== 0n && canonicalParentHash !== block.parentHash) throw new Error("Initial block requires its parent hash to be independently confirmed.");
      const status = { ...structuredClone(block), finalized: false }; this.canonical.set(block.chainId, [status]); return { type: "accepted", block: structuredClone(status) };
    }
    const head = blocks[blocks.length - 1];
    if (block.number === head.number + 1n && block.parentHash === head.hash) {
      const status = { ...structuredClone(block), finalized: false }; blocks.push(status); this.updateFinality(block.chainId); return { type: "accepted", block: structuredClone(status) };
    }
    const parent = blocks.find((item) => item.hash === block.parentHash && item.number + 1n === block.number);
    if (!parent) throw new Error("Cannot accept non-contiguous block without a known canonical parent; perform a trusted resync.");
    const orphaned = blocks.splice(blocks.indexOf(parent) + 1).map((item) => ({ ...item, finalized: false }));
    const status = { ...structuredClone(block), finalized: false }; blocks.push(status); this.updateFinality(block.chainId);
    const event: ReorgEvent = { id: `reorg:${block.chainId}:${this.reorgs.length + 1}`, chainId: block.chainId, ancestorNumber: parent.number.toString(), orphanedHashes: orphaned.map((item) => item.hash), replacementHash: block.hash, detectedAt: new Date().toISOString() };
    this.reorgs.push(event); return { type: "reorg", block: structuredClone(status), event: structuredClone(event), orphaned: structuredClone(orphaned) };
  }
  head(chainId: number): BlockStatus | undefined { const v = this.canonical.get(chainId)?.at(-1); return v ? structuredClone(v) : undefined; }
  blocks(chainId: number): BlockStatus[] { return (this.canonical.get(chainId) ?? []).map((item) => structuredClone(item)); }
  reorgHistory(): ReorgEvent[] { return this.reorgs.map((item) => structuredClone(item)); }
  private updateFinality(chainId: number) { const items = this.canonical.get(chainId)!; const depth = this.confirmations.get(chainId)!; const head = items[items.length - 1].number; for (const block of items) block.finalized = head - block.number >= BigInt(depth); }
}
