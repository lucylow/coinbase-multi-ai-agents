export type AgentTransactionState = "proposed" | "policy_approved" | "budget_reserved" | "service_completed" | "evidence_verified" | "payment_simulated" | "settled" | "disputed" | "failed" | "cancelled";
export interface AgentTransactionIntent {
  intentId: string; idempotencyKey: string; buyerAgentId: string; sellerAgentId: string; serviceId: string; requestedOutput: string;
  maximumBudget: string; paymentAsset: string; chainId: number; expiresAt: string; requiresVerification: boolean; approvalStatus: "pending" | "approved" | "rejected";
}
export interface SettlementRecord { intent: AgentTransactionIntent; state: AgentTransactionState; evidenceHash?: `0x${string}`; paymentReceipt?: { txHash: `0x${string}`; verified: boolean; amount: string }; updatedAt: string }
export interface SettlementEvent { id: string; intentId: string; from: AgentTransactionState | null; to: AgentTransactionState; at: string; note: string }
const ALLOWED: Record<AgentTransactionState, readonly AgentTransactionState[]> = {
  proposed: ["policy_approved", "cancelled", "failed"], policy_approved: ["budget_reserved", "cancelled", "failed"], budget_reserved: ["service_completed", "cancelled", "failed"],
  service_completed: ["evidence_verified", "payment_simulated", "disputed", "failed"], evidence_verified: ["payment_simulated", "disputed", "failed"], payment_simulated: ["settled", "disputed", "failed"],
  settled: [], disputed: ["settled", "failed"], failed: [], cancelled: [],
};
export class AgentTransactionLedger {
  private readonly records = new Map<string, SettlementRecord>(); private readonly byKey = new Map<string, string>(); private readonly events: SettlementEvent[] = [];
  create(intent: AgentTransactionIntent, now = new Date()): SettlementRecord {
    const existingId = this.byKey.get(intent.idempotencyKey);
    if (existingId) { const existing = this.records.get(existingId)!; if (existing.intent.buyerAgentId !== intent.buyerAgentId || existing.intent.sellerAgentId !== intent.sellerAgentId || existing.intent.serviceId !== intent.serviceId || existing.intent.maximumBudget !== intent.maximumBudget || existing.intent.paymentAsset !== intent.paymentAsset || existing.intent.chainId !== intent.chainId || existing.intent.expiresAt !== intent.expiresAt || existing.intent.requiresVerification !== intent.requiresVerification) throw new Error("Idempotency key is already bound to another service intent."); return structuredClone(existing); }
    if (!intent.intentId || !intent.idempotencyKey || !intent.buyerAgentId || !intent.sellerAgentId || !intent.serviceId || intent.buyerAgentId === intent.sellerAgentId) throw new Error("Transaction parties and service identifiers must be valid and distinct.");
    if (!/^\d+$/.test(intent.maximumBudget) || BigInt(intent.maximumBudget) <= 0n) throw new Error("Maximum budget must be positive integer base units.");
    if (!Number.isSafeInteger(intent.chainId) || intent.chainId <= 0 || !Number.isFinite(Date.parse(intent.expiresAt)) || Date.parse(intent.expiresAt) <= now.getTime()) throw new Error("Intent chain or expiration is invalid.");
    if (this.records.has(intent.intentId)) throw new Error("Intent ID already exists.");
    const record = { intent: structuredClone(intent), state: "proposed" as const, updatedAt: now.toISOString() };
    this.records.set(intent.intentId, record); this.byKey.set(intent.idempotencyKey, intent.intentId); this.log(intent.intentId, null, "proposed", "Intent recorded; this is not payment authorization.", now);
    return structuredClone(record);
  }
  transition(intentId: string, to: AgentTransactionState, options: { note: string; userApproved?: boolean; policyPassed?: boolean; reservationId?: string; evidenceHash?: `0x${string}`; payment?: { txHash: `0x${string}`; verified: boolean; amount: string } }, now = new Date()): SettlementRecord {
    const r = this.records.get(intentId); if (!r) throw new Error("Unknown agent transaction intent.");
    if (!ALLOWED[r.state].includes(to)) throw new Error(`Illegal settlement transition: ${r.state} → ${to}.`);
    if (!options.note.trim()) throw new Error("Settlement transition requires an audit note.");
    if (Date.parse(r.intent.expiresAt) <= now.getTime() && !["cancelled", "failed"].includes(to)) throw new Error("Expired intent cannot advance.");
    if (to === "policy_approved" && (!options.policyPassed || r.intent.approvalStatus !== "approved" || !options.userApproved)) throw new Error("Policy approval and explicit user approval are both required.");
    if (to === "budget_reserved" && !options.reservationId) throw new Error("A budget reservation reference is required.");
    if (to === "evidence_verified" && (!options.evidenceHash || !/^0x[0-9a-fA-F]{64}$/.test(options.evidenceHash))) throw new Error("Verified evidence must have a content hash.");
    if (to === "payment_simulated" && r.intent.requiresVerification && !r.evidenceHash) throw new Error("Required service evidence must be verified before payment simulation.");
    if (to === "settled") {
      const p = options.payment;
      if (!p?.verified || !/^0x[0-9a-fA-F]{64}$/.test(p.txHash) || !/^\d+$/.test(p.amount)) throw new Error("Settlement requires a verified payment receipt.");
      if (BigInt(p.amount) > BigInt(r.intent.maximumBudget)) throw new Error("Payment exceeds the approved intent budget.");
      if (r.intent.requiresVerification && !r.evidenceHash) throw new Error("Required service evidence must be verified before settlement.");
      r.paymentReceipt = { ...p, amount: BigInt(p.amount).toString() };
    }
    if (to === "evidence_verified") r.evidenceHash = options.evidenceHash;
    const from = r.state; r.state = to; r.updatedAt = now.toISOString(); this.log(intentId, from, to, options.note, now);
    return structuredClone(r);
  }
  get(id: string): SettlementRecord | undefined { const record = this.records.get(id); return record ? structuredClone(record) : undefined; }
  list(): SettlementRecord[] { return [...this.records.values()].map((record) => structuredClone(record)); }
  history(id?: string): SettlementEvent[] { return this.events.filter((event) => !id || event.intentId === id).map((event) => ({ ...event })); }
  private log(intentId: string, from: AgentTransactionState | null, to: AgentTransactionState, note: string, now = new Date()) { if (!note.trim()) throw new Error("Settlement transition requires an audit note."); this.events.push({ id: `${intentId}:${this.events.length + 1}`, intentId, from, to, at: now.toISOString(), note }); }
}
