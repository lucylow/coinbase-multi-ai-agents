export interface PriceObservation { sourceId: string; assetId: string; quoteCurrency: string; priceMicros: string; timestamp: string; methodology: "trade" | "midpoint" | "oracle" | "demo" }
export interface BalanceObservation { accountId: string; assetId: string; quantityBaseUnits: string; tokenDecimals: number; sourceId: string; observedAt: string }
export interface ValuationSnapshot { accountId: string; assetId: string; quantityBaseUnits: string; tokenDecimals: number; priceMicros: string; quoteCurrency: string; valueMicros: string; balanceSource: string; priceSource: string; priceTimestamp: string; calculationVersion: "fixed-point-v1"; freshness: "fresh" | "stale" }
const integer = (value: string, label: string) => { if (!/^\d+$/.test(value)) throw new Error(`${label} must be a non-negative integer string.`); return BigInt(value); };
export function valueBalance(balance: BalanceObservation, price: PriceObservation, now = new Date(), maxAgeMs = 60_000): ValuationSnapshot {
  const qty = integer(balance.quantityBaseUnits, "Quantity"), priceMicros = integer(price.priceMicros, "Price");
  if (!Number.isSafeInteger(balance.tokenDecimals) || balance.tokenDecimals < 0 || balance.tokenDecimals > 36) throw new Error("Token decimals must be between 0 and 36.");
  if (balance.assetId !== price.assetId) throw new Error("Price and balance must refer to the same canonical asset ID.");
  if (!price.quoteCurrency || !price.sourceId || !balance.sourceId) throw new Error("Valuation provenance is required.");
  const time = Date.parse(price.timestamp); if (!Number.isFinite(time) || time > now.getTime() + 30_000) throw new Error("Price timestamp is invalid or in the future.");
  const valueMicros = qty * priceMicros / (10n ** BigInt(balance.tokenDecimals));
  return { accountId: balance.accountId, assetId: balance.assetId, quantityBaseUnits: qty.toString(), tokenDecimals: balance.tokenDecimals, priceMicros: priceMicros.toString(), quoteCurrency: price.quoteCurrency, valueMicros: valueMicros.toString(), balanceSource: balance.sourceId, priceSource: price.sourceId, priceTimestamp: new Date(time).toISOString(), calculationVersion: "fixed-point-v1", freshness: now.getTime() - time <= maxAgeMs ? "fresh" : "stale" };
}
export function comparePrices(observations: readonly PriceObservation[], warningBps = 100, criticalBps = 500): { assetId: string; deviationBps: number; status: "normal" | "warning" | "critical"; outlier: boolean } {
  if (observations.length < 2) throw new Error("At least two prices are required to detect discrepancies.");
  const first = observations[0];
  if (observations.some((p) => p.assetId !== first.assetId || p.quoteCurrency !== first.quoteCurrency)) throw new Error("Prices with different assets or quote currencies are not comparable.");
  const values = observations.map((p) => integer(p.priceMicros, "Price"));
  const sorted = [...values].sort((a, b) => a < b ? -1 : a > b ? 1 : 0); const median = sorted[Math.floor(sorted.length / 2)];
  if (median === 0n) throw new Error("Median price must be positive.");
  const spread = sorted[sorted.length - 1] - sorted[0]; const bps = Number(spread * 10_000n / median);
  const status = bps >= criticalBps ? "critical" : bps >= warningBps ? "warning" : "normal";
  return { assetId: first.assetId, deviationBps: bps, status, outlier: status !== "normal" };
}
