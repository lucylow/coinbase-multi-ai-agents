export type AgentBudget = { id: string; agentId: string; network: "base-sepolia"; assetAddress?: string; assetSymbol: string; maximumPerTransaction: string; maximumPerDay: string; maximumPerMonth: string; spentToday: string; spentThisMonth: string; pendingAmount: string; approvedBy: string; validUntil: string; mode: "simulation" | "restricted"; status: "pending" | "active" | "expired" | "revoked" };
export type BudgetReservation = { idempotencyKey: string; budgetId: string; amount: string; status: "reserved" | "settled" | "released"; createdAt: string };
export class BudgetController {
  private readonly reservations = new Map<string, BudgetReservation>();
  reserve(budget: AgentBudget, amount: string, idempotencyKey: string, now = new Date()): BudgetReservation {
    const existing = this.reservations.get(idempotencyKey); if (existing) { if (existing.budgetId !== budget.id || existing.amount !== amount) throw new Error("Idempotency key is bound to a different budget request."); return existing; }
    if (budget.status !== "active" || Date.parse(budget.validUntil) < now.getTime()) throw new Error("Budget is not active or has expired.");
    const requested = BigInt(amount); const pending = BigInt(budget.pendingAmount); const daily = BigInt(budget.spentToday); const monthly = BigInt(budget.spentThisMonth);
    if (requested < 0n || requested > BigInt(budget.maximumPerTransaction)) throw new Error("Request exceeds per-transaction budget.");
    if (daily + pending + requested > BigInt(budget.maximumPerDay)) throw new Error("Request exceeds daily budget.");
    if (monthly + pending + requested > BigInt(budget.maximumPerMonth)) throw new Error("Request exceeds monthly budget.");
    if (budget.mode !== "simulation") throw new Error("Restricted budget requires the separately authorized payment workflow.");
    const reservation = { idempotencyKey, budgetId: budget.id, amount, status: "reserved" as const, createdAt: now.toISOString() }; this.reservations.set(idempotencyKey, reservation); budget.pendingAmount = (pending + requested).toString(); return reservation;
  }
  settle(budget: AgentBudget, key: string) { const reservation = this.require(budget, key, "reserved"); const amount = BigInt(reservation.amount); budget.pendingAmount = (BigInt(budget.pendingAmount) - amount).toString(); budget.spentToday = (BigInt(budget.spentToday) + amount).toString(); budget.spentThisMonth = (BigInt(budget.spentThisMonth) + amount).toString(); reservation.status = "settled"; return reservation; }
  release(budget: AgentBudget, key: string) { const reservation = this.require(budget, key, "reserved"); budget.pendingAmount = (BigInt(budget.pendingAmount) - BigInt(reservation.amount)).toString(); reservation.status = "released"; return reservation; }
  private require(budget: AgentBudget, key: string, status: BudgetReservation["status"]) { const item = this.reservations.get(key); if (!item || item.budgetId !== budget.id || item.status !== status) throw new Error("Reservation is missing, already finalized, or belongs to another budget."); return item; }
}
