const ADDRESS = /^0x[a-fA-F0-9]{40}$/;

function configuredAddress(value: string | undefined) {
  if (!value) return { status: "not-configured" as const, address: null };
  if (!ADDRESS.test(value) || /^0x0{40}$/i.test(value)) return { status: "invalid-configuration" as const, address: null };
  return { status: "configured-unverified" as const, address: value };
}

export function getGovernanceStatus(env: Record<string, string | undefined> = process.env) {
  const mode = env.GOVERNANCE_MODE === "testnet" ? "testnet" : "demo";
  const requestedChainId = Number(env.GOVERNANCE_CHAIN_ID ?? "84532");
  const chainId = Number.isSafeInteger(requestedChainId) && requestedChainId === 84532 ? 84532 : null;
  const enabled = env.GOVERNANCE_ENABLED === "true";
  const governor = configuredAddress(env.AGENT_COUNCIL_GOVERNOR_ADDRESS);
  const timelock = configuredAddress(env.GOVERNANCE_TIMELOCK_ADDRESS);
  const policyRegistry = configuredAddress(env.GOVERNED_POLICY_REGISTRY_ADDRESS);
  const completeAddressSet = [governor, timelock].every((item) => item.status === "configured-unverified");

  return {
    mode,
    enabled,
    chain: { name: "Base Sepolia", expectedChainId: 84532, configuredChainId: chainId, verified: false },
    controller: governor,
    timelock,
    policyRegistry,
    council: { signerCount: null, standardThreshold: null, criticalThreshold: null, signerSetVersion: null, source: "not-read-from-chain" },
    proposals: { pending: null, approved: null, queued: null, executable: null, executed: null, source: "not-read-from-chain" },
    execution: { mainnetWritesEnabled: false, testnetWritesEnabled: false, submissionsEnabled: false },
    readiness: enabled && mode === "testnet" && chainId === 84532 && completeAddressSet ? "configured-awaiting-chain-verification" : "read-only-unavailable",
    notice: "Governance addresses and counts are not trusted until queried from Base Sepolia and independently verified. This endpoint does not sign, approve, queue, or execute proposals.",
  };
}
