import type { AdvancedTradeProduct } from "@/integrations/coinbase/advancedTradeProvider";
import type { PortfolioSnapshot } from "./portfolio-workspace-manager";

export interface PublicPriceReader {
  getProduct(productId: string): Promise<AdvancedTradeProduct>;
}

export interface PortfolioXrayPosition {
  asset: string;
  quantity: number | null;
  reportedValueFiat: number | null;
  price: number | null;
  priceProductId: string | null;
  priceAsOf: string | null;
  valuationMethod: "public-market-price" | "provider-reported-value" | "unavailable";
  valueFiat: number | null;
  allocationPct: number | null;
  priceWarning?: string;
}

export interface PortfolioXrayResult {
  providerId: string;
  provider: string;
  portfolioId: string;
  portfolioName: string;
  currency: string;
  mode: "demo" | "live-read-only";
  portfolioAsOf: string;
  retrievedAt: string;
  reportedPortfolioTotalFiat: number | null;
  coveredSpotTotalFiat: number | null;
  allocationBasis: "covered-spot-subtotal" | "unavailable";
  positions: PortfolioXrayPosition[];
  coverage: "complete" | "partial" | "unavailable";
  warnings: string[];
  readOnly: true;
}

function finite(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

/** Retrieve public market prices for identifiable spot assets and calculate covered spot allocations. */
export async function runPortfolioXray(
  snapshot: PortfolioSnapshot,
  priceReader: PublicPriceReader,
  options: { retrievedAt?: string; concurrency?: number } = {},
): Promise<PortfolioXrayResult> {
  const retrievedAt = options.retrievedAt || new Date().toISOString();
  const warnings = [...snapshot.missingData];
  if (snapshot.positions.length > 100) warnings.push("Only the first 100 returned spot positions were processed for this X-ray.");
  const inputPositions = snapshot.positions.slice(0, 100);
  const symbols = [...new Set(inputPositions.map((position) => position.asset.toUpperCase()))]
    .filter((asset) => asset !== snapshot.currency.toUpperCase());
  const products = new Map<string, AdvancedTradeProduct | null>();
  const concurrency = Math.max(1, Math.min(8, Math.floor(options.concurrency ?? 4)));
  for (let index = 0; index < symbols.length; index += concurrency) {
    await Promise.all(symbols.slice(index, index + concurrency).map(async (asset) => {
      try {
        products.set(asset, await priceReader.getProduct(`${asset}-${snapshot.currency.toUpperCase()}`));
      } catch {
        products.set(asset, null);
      }
    }));
  }

  const priced: PortfolioXrayPosition[] = inputPositions.map((position) => {
    const asset = position.asset.toUpperCase();
    const quantity = position.quantity;
    const reportedValueFiat = position.valueFiat;
    if (asset === snapshot.currency.toUpperCase()) {
      const value = quantity !== null && finite(quantity) ? quantity : reportedValueFiat;
      return {
        asset: position.asset,
        quantity,
        reportedValueFiat,
        price: 1,
        priceProductId: `${asset}-${snapshot.currency.toUpperCase()}`,
        priceAsOf: retrievedAt,
        valuationMethod: value === null ? "unavailable" : "public-market-price",
        valueFiat: value,
        allocationPct: null,
        priceWarning: "Fiat quote currency valued at par; no market conversion is needed.",
      };
    }
    const product = products.get(asset);
    const productId = `${asset}-${snapshot.currency.toUpperCase()}`;
    const price = product && product.productId === productId && product.baseCurrencyId.toUpperCase() === asset && product.quoteCurrencyId.toUpperCase() === snapshot.currency.toUpperCase()
      ? Number(product.price)
      : NaN;
    const marketPriceValid = Boolean(product && product.status.toLowerCase() === "online" && !product.tradingDisabled && Number.isFinite(price) && price > 0);
    if (marketPriceValid && quantity !== null && finite(quantity) && quantity >= 0) {
      return {
        asset: position.asset,
        quantity,
        reportedValueFiat,
        price,
        priceProductId: productId,
        priceAsOf: retrievedAt,
        valuationMethod: "public-market-price",
        valueFiat: quantity * price,
        allocationPct: null,
      };
    }
    const warning = !product
      ? `No public ${productId} market price was available; provider-reported fiat value is used when available.`
      : !marketPriceValid
        ? `${productId} is not online with a valid current price; provider-reported fiat value is used when available.`
        : "Quantity is missing or invalid; provider-reported fiat value is used when available.";
    return {
      asset: position.asset,
      quantity,
      reportedValueFiat,
      price: null,
      priceProductId: productId,
      priceAsOf: null,
      valuationMethod: reportedValueFiat !== null && finite(reportedValueFiat) ? "provider-reported-value" : "unavailable",
      valueFiat: reportedValueFiat !== null && finite(reportedValueFiat) ? reportedValueFiat : null,
      allocationPct: null,
      priceWarning: warning,
    };
  });

  const coveredSpotTotalFiat = priced.reduce((sum, position) => sum + (position.valueFiat ?? 0), 0);
  const hasUnvaluedPositions = priced.some((position) => position.valueFiat === null);
  const usedReportedFallback = priced.some((position) => position.valuationMethod === "provider-reported-value");
  const allPositionsProcessed = snapshot.positions.length === inputPositions.length;
  const allMarketPriced = priced.every((position) => position.valuationMethod === "public-market-price");
  const coverage: PortfolioXrayResult["coverage"] = priced.length === 0 || coveredSpotTotalFiat <= 0
    ? "unavailable"
    : hasUnvaluedPositions || usedReportedFallback || snapshot.coverage !== "complete" || !allPositionsProcessed || !allMarketPriced
      ? "partial"
      : "complete";
  if (usedReportedFallback) warnings.push("Some positions use Coinbase-reported fiat values because a current matching public market price was unavailable; the X-ray mixes valuation timestamps/methods.");
  if (snapshot.totalValueFiat !== null) warnings.push("The account-reported total is from the portfolio snapshot time; X-ray values use refreshed public prices where available. The two totals are not assumed to reconcile across different observation times.");
  if (hasUnvaluedPositions) warnings.push("One or more positions could not be valued; their allocation is unavailable and the covered spot subtotal is incomplete.");
  if (snapshot.missingData.some((item) => /non-spot|perpetual|futures|equities|prediction-market/i.test(item))) warnings.push("Non-spot positions are not included in this spot X-ray.");
  const positions = priced.map((position) => ({
    ...position,
    allocationPct: position.valueFiat !== null && coveredSpotTotalFiat > 0 ? position.valueFiat / coveredSpotTotalFiat * 100 : null,
  }));
  return {
    providerId: snapshot.providerId,
    provider: snapshot.provider,
    portfolioId: snapshot.portfolioId,
    portfolioName: snapshot.portfolioName,
    currency: snapshot.currency,
    mode: snapshot.provider === "demo" ? "demo" : "live-read-only",
    portfolioAsOf: snapshot.asOf,
    retrievedAt,
    reportedPortfolioTotalFiat: snapshot.totalValueFiat,
    coveredSpotTotalFiat: coveredSpotTotalFiat > 0 ? coveredSpotTotalFiat : null,
    allocationBasis: coveredSpotTotalFiat > 0 ? "covered-spot-subtotal" : "unavailable",
    positions,
    coverage,
    warnings: [...new Set([...warnings, ...positions.flatMap((position) => position.priceWarning ? [position.priceWarning] : [])])],
    readOnly: true,
  };
}
