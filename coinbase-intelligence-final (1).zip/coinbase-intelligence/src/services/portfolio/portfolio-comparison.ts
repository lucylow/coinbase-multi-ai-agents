import type { PortfolioSnapshot } from "./portfolio-workspace-manager";

export interface AlignedPortfolioSnapshots {
  left: PortfolioSnapshot;
  right: PortfolioSnapshot;
  offsetMilliseconds: number;
  alignedAt: string;
}

export interface AllocationDifference {
  asset: string;
  leftAllocationPct: number | null;
  rightAllocationPct: number | null;
  differencePercentagePoints: number | null;
  interpretation: string;
}

export interface TargetAllocationDifference {
  asset: string;
  currentAllocationPct: number | null;
  targetAllocationPct: number;
  differencePercentagePoints: number | null;
}

/** Choose the closest available timestamps; ties prefer the pair with the most recent observation. */
export function alignPortfolioSnapshots(
  leftHistory: PortfolioSnapshot[],
  rightHistory: PortfolioSnapshot[],
): AlignedPortfolioSnapshots | null {
  let best: AlignedPortfolioSnapshots | null = null;
  let bestLatestTime = Number.NEGATIVE_INFINITY;
  for (const left of leftHistory) {
    const leftTime = Date.parse(left.asOf);
    if (!Number.isFinite(leftTime)) continue;
    for (const right of rightHistory) {
      if (left.currency !== right.currency) continue;
      const rightTime = Date.parse(right.asOf);
      if (!Number.isFinite(rightTime)) continue;
      const offsetMilliseconds = Math.abs(leftTime - rightTime);
      const latest = Math.max(leftTime, rightTime);
      if (!best || offsetMilliseconds < best.offsetMilliseconds || (offsetMilliseconds === best.offsetMilliseconds && latest > bestLatestTime)) {
        best = { left, right, offsetMilliseconds, alignedAt: new Date(Math.min(leftTime, rightTime)).toISOString() };
        bestLatestTime = latest;
      }
    }
  }
  return best;
}

/** Compare reported allocations without treating a missing position as a confirmed zero. */
export function comparePortfolioAllocations(
  left: PortfolioSnapshot,
  right: PortfolioSnapshot,
): { differences: AllocationDifference[]; warnings: string[] } {
  if (left.currency !== right.currency) {
    return { differences: [], warnings: [`Currencies differ (${left.currency} vs ${right.currency}); no FX conversion was applied, so allocations were not compared.`] };
  }
  const leftByAsset = new Map(left.positions.map((position) => [position.asset, position]));
  const rightByAsset = new Map(right.positions.map((position) => [position.asset, position]));
  const assets = [...new Set([...leftByAsset.keys(), ...rightByAsset.keys()])].sort();
  const differences = assets.map((asset) => {
    const leftPosition = leftByAsset.get(asset);
    const rightPosition = rightByAsset.get(asset);
    const leftAllocationPct = leftPosition?.allocation === null || leftPosition?.allocation === undefined ? null : leftPosition.allocation * 100;
    const rightAllocationPct = rightPosition?.allocation === null || rightPosition?.allocation === undefined ? null : rightPosition.allocation * 100;
    const differencePercentagePoints = leftAllocationPct !== null && rightAllocationPct !== null ? leftAllocationPct - rightAllocationPct : null;
    const interpretation = differencePercentagePoints === null
      ? `${asset} is missing or unvalued in one comparison context; absence is not assumed to mean a zero allocation.`
      : differencePercentagePoints > 0.005
        ? `${asset} has a higher reported allocation in ${left.portfolioName} by ${differencePercentagePoints.toFixed(2)} percentage points.`
        : differencePercentagePoints < -0.005
          ? `${asset} has a higher reported allocation in ${right.portfolioName} by ${Math.abs(differencePercentagePoints).toFixed(2)} percentage points.`
          : `${asset} reported allocations are approximately equal.`;
    return { asset, leftAllocationPct, rightAllocationPct, differencePercentagePoints, interpretation };
  });
  const warnings: string[] = [];
  if (left.provider !== right.provider || left.portfolioId !== right.portfolioId) warnings.push("Portfolio allocation differences describe observed composition, not relative performance; prices, holdings, cash flows, fees, and coverage can all differ.");
  if (left.coverage !== "complete" || right.coverage !== "complete") warnings.push("At least one snapshot has partial or unknown coverage; differences describe reported positions only.");
  if (left.positions.some((position) => position.allocation === null) || right.positions.some((position) => position.allocation === null)) warnings.push("Some allocations are unavailable; missing positions are not treated as zero.");
  return { differences, warnings };
}

/** Compare an explicitly supplied 100%-target (percent units) with a reported snapshot. */
export function compareCurrentToTargetAllocation(
  snapshot: PortfolioSnapshot,
  targetPercent: Record<string, number>,
): TargetAllocationDifference[] {
  const positions = new Map(snapshot.positions.map((position) => [position.asset.toUpperCase(), position]));
  const targets = Object.fromEntries(Object.entries(targetPercent).map(([asset, weight]) => [asset.toUpperCase(), weight]));
  return [...new Set([...positions.keys(), ...Object.keys(targets)])].sort().map((asset) => {
    const position = positions.get(asset);
    const currentAllocationPct = position?.allocation !== null && position?.allocation !== undefined
      ? position.allocation * 100
      : !position && snapshot.coverage === "complete" ? 0 : null;
    const targetAllocationPct = targets[asset] ?? 0;
    return {
      asset,
      currentAllocationPct,
      targetAllocationPct,
      differencePercentagePoints: currentAllocationPct === null ? null : currentAllocationPct - targetAllocationPct,
    };
  });
}
