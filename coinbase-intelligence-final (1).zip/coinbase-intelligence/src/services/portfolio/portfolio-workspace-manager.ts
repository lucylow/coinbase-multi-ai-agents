import { randomUUID } from "node:crypto";
import type {
  AdvancedTradePortfolioBreakdown,
  AdvancedTradePortfolioProvider,
} from "@/integrations/coinbase/advancedTradeProvider";
import { HttpAdvancedTradeProvider } from "@/integrations/coinbase/advancedTradeProvider";
import { balances as demoBalances, DEMO_AS_OF } from "@/fixtures/demo";

export const DEMO_PORTFOLIO_ID = "demo-portfolio-01";
export const DEFAULT_PORTFOLIO_WORKSPACE_ID = "research:portfolio-analyst";
export const DEFAULT_PORTFOLIO_STRATEGY_ID = "portfolio-analysis";

export type PortfolioProviderKind = "coinbase-advanced-trade" | "coinbase-for-agents" | "coinbase-mcp" | "demo";
export interface AuthorizedPortfolio {
  providerId: string;
  provider: PortfolioProviderKind;
  portfolioId: string;
  name: string;
  type: string;
  deleted: boolean;
  mode: "demo" | "live-read-only";
}
export interface PortfolioPositionSnapshot {
  asset: string;
  accountId?: string;
  quantity: number | null;
  valueFiat: number | null;
  availableToTradeFiat: number | null;
  costBasisFiat: number | null;
  averageEntryPrice: number | null;
  isCash?: boolean;
  allocation: number | null;
}
export interface PortfolioSnapshot {
  snapshotId: string;
  providerId: string;
  provider: PortfolioProviderKind;
  portfolioId: string;
  portfolioName: string;
  portfolioType: string;
  currency: string;
  asOf: string;
  retrievedAt: string;
  totalValueFiat: number | null;
  cashEquivalentFiat: number | null;
  positions: PortfolioPositionSnapshot[];
  coverage: "complete" | "partial" | "unknown";
  missingData: string[];
}
export interface PortfolioWorkspaceMapping {
  workspaceId: string;
  strategyId: string;
  providerId: string;
  portfolioId: string;
  /** True only for a mapping supplied by explicit server-side configuration. */
  explicitlyConfigured: true;
}
export interface PortfolioPositionChange {
  asset: string;
  previousQuantity: number | null;
  currentQuantity: number | null;
  quantityChange: number | null;
  quantityChangePct: number | null;
  previousValueFiat: number | null;
  currentValueFiat: number | null;
  valueChangeFiat: number | null;
  state: "changed" | "newly-observed" | "missing-from-latest";
}
export interface PortfolioSnapshotComparison {
  previousSnapshotId?: string;
  portfolioValueChangeFiat: number | null;
  portfolioValueChangePct: number | null;
  valueChangeCaveat: string;
  positionChanges: PortfolioPositionChange[];
  unusualMovements: string[];
  missingData: string[];
}
export interface PortfolioSnapshotRepository {
  latest(providerId: string, portfolioId: string): Promise<PortfolioSnapshot | null> | PortfolioSnapshot | null;
  history?(providerId: string, portfolioId: string): Promise<PortfolioSnapshot[]> | PortfolioSnapshot[];
  save(snapshot: PortfolioSnapshot): Promise<void> | void;
}
export interface PortfolioSourceAdapter {
  providerId: string;
  provider: PortfolioProviderKind;
  listPortfolios(): Promise<Array<{ portfolioId: string; name: string; type: string; deleted: boolean }>>;
  getPortfolioBreakdown(portfolioId: string): Promise<AdvancedTradePortfolioBreakdown>;
}

export class InMemoryPortfolioSnapshotRepository implements PortfolioSnapshotRepository {
  private readonly snapshots = new Map<string, PortfolioSnapshot[]>();
  constructor(private readonly maxPerPortfolio = 30) {}
  latest(providerId: string, portfolioId: string): PortfolioSnapshot | null {
    const items = this.snapshots.get(this.key(providerId, portfolioId)) || [];
    const latest = items.at(-1);
    return latest ? this.clone(latest) : null;
  }
  history(providerId: string, portfolioId: string): PortfolioSnapshot[] {
    return (this.snapshots.get(this.key(providerId, portfolioId)) || []).map((snapshot) => this.clone(snapshot));
  }
  save(snapshot: PortfolioSnapshot): void {
    const key = this.key(snapshot.providerId, snapshot.portfolioId);
    const items = this.snapshots.get(key) || [];
    items.push(this.clone(snapshot));
    this.snapshots.set(key, items.slice(-this.maxPerPortfolio));
  }
  private clone(snapshot: PortfolioSnapshot): PortfolioSnapshot {
    return { ...snapshot, positions: snapshot.positions.map((position) => ({ ...position })), missingData: [...snapshot.missingData] };
  }
  private key(providerId: string, portfolioId: string) {
    return `${providerId}\u0000${portfolioId}`;
  }
}

export interface PortfolioWorkspaceManagerOptions {
  sources?: PortfolioSourceAdapter[];
  mappings?: PortfolioWorkspaceMapping[];
  repository?: PortfolioSnapshotRepository;
  movementThresholdPct?: number;
  movementThresholdFiat?: number;
  configWarnings?: string[];
}

export interface PortfolioListingResult {
  portfolios: AuthorizedPortfolio[];
  sourceWarnings: string[];
}

export interface PortfolioSnapshotResult {
  snapshot: PortfolioSnapshot;
  comparison: PortfolioSnapshotComparison;
  history: PortfolioSnapshot[];
}

export type MappedStrategyPortfolioResult =
  | { status: "unmapped"; snapshot: PortfolioSnapshot; comparison: PortfolioSnapshotComparison; history: PortfolioSnapshot[] }
  | { status: "mapped"; mapping: PortfolioWorkspaceMapping; snapshot: PortfolioSnapshot; comparison: PortfolioSnapshotComparison; history: PortfolioSnapshot[] }
  | { status: "unavailable"; message: string };

function finite(value: number | null | undefined): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function numberFromAmount(amount: { value: string; currency: string } | undefined, expectedCurrency: string): number | null {
  if (!amount || amount.currency.toUpperCase() !== expectedCurrency.toUpperCase()) return null;
  const value = Number(amount.value);
  return Number.isFinite(value) ? value : null;
}
function quantityChangePct(previous: number, current: number): number | null {
  if (previous === 0) return current === 0 ? 0 : null;
  return ((current - previous) / Math.abs(previous)) * 100;
}

export function normalizeAdvancedTradePortfolioSnapshot(
  providerId: string,
  result: AdvancedTradePortfolioBreakdown,
  options: { currency?: string; retrievedAt?: string } = {},
): PortfolioSnapshot {
  const currency = (options.currency || "USD").toUpperCase();
  const retrievedAt = options.retrievedAt || new Date().toISOString();
  const missingData: string[] = [];
  const positions = result.spotPositions.map((position) => {
    const valueFiat = finite(position.totalBalanceFiat);
    const quantity = finite(position.totalBalanceCrypto);
    const costBasisFiat = numberFromAmount(position.costBasis, currency);
    const averageEntryPrice = numberFromAmount(position.averageEntryPrice, currency);
    if (valueFiat === null) missingData.push(`${position.asset}: reported fiat market value is missing or invalid.`);
    if (quantity === null) missingData.push(`${position.asset}: crypto quantity is missing or invalid.`);
    if (position.costBasis && costBasisFiat === null) missingData.push(`${position.asset}: cost basis is not reported in ${currency}.`);
    else if (!position.costBasis) missingData.push(`${position.asset}: cost basis is not provided; PnL is unavailable.`);
    return {
      asset: position.asset,
      accountId: position.accountUuid,
      quantity,
      valueFiat,
      availableToTradeFiat: finite(position.availableToTradeFiat),
      costBasisFiat,
      averageEntryPrice,
      isCash: position.isCash,
      allocation: null,
    } satisfies PortfolioPositionSnapshot;
  });
  const reportedTotal = numberFromAmount(result.portfolioBalances.totalBalance, currency);
  const cashEquivalentFiat = numberFromAmount(result.portfolioBalances.totalCashEquivalentBalance, currency);
  const spotTotal = positions.reduce((sum, position) => sum + (position.valueFiat ?? 0), 0);
  const totalValueFiat = reportedTotal ?? (positions.length ? spotTotal : null);
  if (reportedTotal === null) missingData.push(`Portfolio total balance in ${currency} was not returned; total uses the sum of reported spot-position values where available.`);
  if (reportedTotal !== null && positions.length && positions.every((position) => position.valueFiat !== null)) {
    const unallocatedDifference = reportedTotal - spotTotal;
    if (Math.abs(unallocatedDifference) > Math.max(0.01, Math.abs(reportedTotal) * 0.0001)) {
      missingData.push(`Reported total differs from returned spot-position values by ${unallocatedDifference.toFixed(2)} ${currency}; the difference is not attributed to a spot asset.`);
    }
  }
  if (!positions.length && totalValueFiat !== null && totalValueFiat !== 0) missingData.push("Portfolio value is reported but no spot positions were returned.");
  if (result.nonSpotPositionCounts.perpetuals) missingData.push(`${result.nonSpotPositionCounts.perpetuals} perpetual position(s) are not included in spot allocation rows.`);
  if (result.nonSpotPositionCounts.futures) missingData.push(`${result.nonSpotPositionCounts.futures} futures position(s) are not included in spot allocation rows.`);
  if (result.nonSpotPositionCounts.predictionMarkets) missingData.push(`${result.nonSpotPositionCounts.predictionMarkets} prediction-market position(s) are not included in spot allocation rows.`);
  if (result.nonSpotPositionCounts.equities) missingData.push(`${result.nonSpotPositionCounts.equities} equity position(s) are not included in spot allocation rows.`);
  if (reportedTotal !== null && positions.some((position) => position.valueFiat === null)) missingData.push("Allocation coverage is incomplete because one or more spot-position values are missing.");

  const denominator = reportedTotal ?? spotTotal;
  const allocated = positions.map((position) => ({
    ...position,
    allocation: denominator > 0 && position.valueFiat !== null ? position.valueFiat / denominator : null,
  }));
  return {
    snapshotId: randomUUID(),
    providerId,
    provider: "coinbase-advanced-trade",
    portfolioId: result.portfolio.uuid,
    portfolioName: result.portfolio.name,
    portfolioType: result.portfolio.type,
    currency,
    asOf: retrievedAt,
    retrievedAt,
    totalValueFiat,
    cashEquivalentFiat,
    positions: allocated,
    coverage: !missingData.length ? "complete" : positions.length || totalValueFiat !== null ? "partial" : "unknown",
    missingData: [...new Set(missingData)],
  };
}

export function createDemoPortfolioSnapshot(retrievedAt = DEMO_AS_OF): PortfolioSnapshot {
  const raw = demoBalances.map((balance) => {
    const quantity = Number(balance.quantity);
    const price = Number(balance.price);
    const cost = Number(balance.averageCost);
    return { balance, quantity, price, value: quantity * price, cost: quantity * cost };
  });
  const totalValueFiat = raw.reduce((sum, item) => sum + item.value, 0);
  return {
    snapshotId: randomUUID(),
    providerId: "demo",
    provider: "demo",
    portfolioId: DEMO_PORTFOLIO_ID,
    portfolioName: "Coinbase Demo Portfolio 01",
    portfolioType: "DEMO",
    currency: "USD",
    asOf: retrievedAt,
    retrievedAt,
    totalValueFiat,
    cashEquivalentFiat: raw.find((item) => item.balance.asset === "USDC")?.value ?? 0,
    positions: raw.map(({ balance, quantity, price, value, cost }) => ({
      asset: balance.asset,
      quantity,
      valueFiat: value,
      availableToTradeFiat: value,
      costBasisFiat: cost,
      averageEntryPrice: price,
      allocation: totalValueFiat > 0 ? value / totalValueFiat : null,
    })),
    coverage: "complete",
    missingData: ["Demo balances and prices are synthetic fixtures, not Coinbase account information."],
  };
}

export function comparePortfolioSnapshots(
  previous: PortfolioSnapshot | null,
  current: PortfolioSnapshot,
  thresholds: { movementThresholdPct?: number; movementThresholdFiat?: number } = {},
): PortfolioSnapshotComparison {
  const movementThresholdPct = thresholds.movementThresholdPct ?? 25;
  const movementThresholdFiat = thresholds.movementThresholdFiat ?? 100;
  const missingData: string[] = [];
  if (!previous) {
    missingData.push("No prior snapshot is stored; historical value changes and balance-movement checks are unavailable.");
    return {
      portfolioValueChangeFiat: null,
      portfolioValueChangePct: null,
      valueChangeCaveat: "Portfolio valuation change can reflect market prices, fees, activity, or missing data; it is not by itself a transfer or cash-flow measure.",
      positionChanges: [],
      unusualMovements: [],
      missingData,
    };
  }
  if (previous.currency !== current.currency) {
    missingData.push("Snapshots use different currencies and cannot be compared without FX normalization.");
    return {
      previousSnapshotId: previous.snapshotId,
      portfolioValueChangeFiat: null,
      portfolioValueChangePct: null,
      valueChangeCaveat: "Different quote currencies; no FX conversion was applied.",
      positionChanges: [],
      unusualMovements: [],
      missingData,
    };
  }
  const priorByAsset = new Map(previous.positions.map((position) => [position.asset, position]));
  const currentByAsset = new Map(current.positions.map((position) => [position.asset, position]));
  const positionChanges: PortfolioPositionChange[] = [];
  const unusualMovements: string[] = [];

  for (const [asset, before] of priorByAsset) {
    const after = currentByAsset.get(asset);
    if (!after) {
      positionChanges.push({ asset, previousQuantity: before.quantity, currentQuantity: null, quantityChange: null, quantityChangePct: null, previousValueFiat: before.valueFiat, currentValueFiat: null, valueChangeFiat: null, state: "missing-from-latest" });
      missingData.push(`${asset} appeared in the previous snapshot but is absent now; absence is not treated as a confirmed zero balance.`);
      continue;
    }
    if (before.quantity === null || after.quantity === null) {
      missingData.push(`${asset}: quantity comparison is unavailable because at least one snapshot lacks quantity.`);
      continue;
    }
    const quantityChange = after.quantity - before.quantity;
    const quantityChangePct = quantityChangePctValue(before.quantity, after.quantity);
    const valueChangeFiat = before.valueFiat !== null && after.valueFiat !== null ? after.valueFiat - before.valueFiat : null;
    if (quantityChange !== 0 || valueChangeFiat !== 0) {
      positionChanges.push({ asset, previousQuantity: before.quantity, currentQuantity: after.quantity, quantityChange, quantityChangePct, previousValueFiat: before.valueFiat, currentValueFiat: after.valueFiat, valueChangeFiat, state: "changed" });
    }
    const materialValue = Math.abs(valueChangeFiat ?? 0) >= movementThresholdFiat;
    const significantQuantity = quantityChangePct === null ? Math.abs(after.valueFiat ?? 0) >= movementThresholdFiat : Math.abs(quantityChangePct) >= movementThresholdPct;
    if (materialValue && significantQuantity) {
      unusualMovements.push(`${asset} quantity changed ${quantityChangePct === null ? "from zero or a missing prior balance" : `${quantityChangePct > 0 ? "+" : ""}${quantityChangePct.toFixed(1)}%`}; observed position-value change ${valueChangeFiat! >= 0 ? "+" : ""}${valueChangeFiat!.toFixed(2)} ${current.currency}. Cause is unknown and no transfer is inferred.`);
    }
  }
  for (const [asset, after] of currentByAsset) {
    if (priorByAsset.has(asset)) continue;
    positionChanges.push({ asset, previousQuantity: null, currentQuantity: after.quantity, quantityChange: null, quantityChangePct: null, previousValueFiat: null, currentValueFiat: after.valueFiat, valueChangeFiat: null, state: "newly-observed" });
    if (Math.abs(after.valueFiat ?? 0) >= movementThresholdFiat) {
      unusualMovements.push(`${asset} is newly observed at ${after.valueFiat!.toFixed(2)} ${current.currency}; no cause or transfer is inferred.`);
    }
  }

  const portfolioValueChangeFiat = previous.totalValueFiat !== null && current.totalValueFiat !== null
    ? current.totalValueFiat - previous.totalValueFiat
    : null;
  const portfolioValueChangePct = previous.totalValueFiat && portfolioValueChangeFiat !== null
    ? (portfolioValueChangeFiat / Math.abs(previous.totalValueFiat)) * 100
    : null;
  missingData.push(...current.missingData);
  return {
    previousSnapshotId: previous.snapshotId,
    portfolioValueChangeFiat,
    portfolioValueChangePct,
    valueChangeCaveat: "Portfolio valuation change can reflect market prices, fees, activity, or missing data; it is not by itself a transfer or cash-flow measure.",
    positionChanges,
    unusualMovements,
    missingData: [...new Set(missingData)],
  };
}

function quantityChangePctValue(previous: number, current: number): number | null {
  return quantityChangePct(previous, current);
}

export function portfolioConcentration(snapshot: PortfolioSnapshot) {
  const allocated = snapshot.positions.filter((position) => position.allocation !== null && position.allocation > 0);
  return {
    hhi: allocated.reduce((sum, position) => sum + position.allocation! ** 2, 0),
    largestAllocation: allocated.reduce((max, position) => Math.max(max, position.allocation!), 0),
    topThreeAllocation: [...allocated]
      .sort((a, b) => (b.allocation || 0) - (a.allocation || 0))
      .slice(0, 3)
      .reduce((sum, position) => sum + (position.allocation || 0), 0),
    positionCount: allocated.length,
  };
}

function parseJsonArray<T>(value: string | undefined, label: string): { items: T[]; warning?: string } {
  if (!value?.trim()) return { items: [] };
  try {
    const parsed: unknown = JSON.parse(value);
    if (!Array.isArray(parsed)) return { items: [], warning: `${label} must be a JSON array; configuration was ignored.` };
    return { items: parsed as T[] };
  } catch {
    return { items: [], warning: `${label} is not valid JSON; configuration was ignored.` };
  }
}

interface PortfolioCredentialProfileConfig {
  profileId?: string;
  keyNameEnv?: string;
  privateKeyEnv?: string;
}
interface PortfolioWorkspaceMappingConfig {
  workspaceId?: string;
  strategyId?: string;
  providerId?: string;
  portfolioId?: string;
}

export class PortfolioWorkspaceManager {
  private readonly sources: PortfolioSourceAdapter[];
  private readonly mappings: PortfolioWorkspaceMapping[];
  private readonly repository: PortfolioSnapshotRepository;
  private readonly thresholds: { movementThresholdPct: number; movementThresholdFiat: number };
  private readonly configWarnings: string[];

  constructor(options: PortfolioWorkspaceManagerOptions = {}) {
    this.sources = options.sources || [];
    this.mappings = options.mappings || [];
    this.repository = options.repository || new InMemoryPortfolioSnapshotRepository();
    this.thresholds = {
      movementThresholdPct: options.movementThresholdPct ?? 25,
      movementThresholdFiat: options.movementThresholdFiat ?? 100,
    };
    this.configWarnings = options.configWarnings || [];
  }

  async listAuthorizedPortfolios(): Promise<PortfolioListingResult> {
    const portfolios: AuthorizedPortfolio[] = [{
      providerId: "demo",
      provider: "demo",
      portfolioId: DEMO_PORTFOLIO_ID,
      name: "Coinbase Demo Portfolio 01",
      type: "DEMO",
      deleted: false,
      mode: "demo",
    }];
    const sourceWarnings = [...this.configWarnings];
    const results = await Promise.all(this.sources.map(async (source) => {
      try {
        const rows = await source.listPortfolios();
        return { source, rows };
      } catch {
        sourceWarnings.push(`${source.providerId}: could not list portfolios. Check server-side read permissions and key scope.`);
        return { source, rows: [] as Awaited<ReturnType<PortfolioSourceAdapter["listPortfolios"]>> };
      }
    }));
    for (const { source, rows } of results) {
      for (const row of rows) {
        if (row.deleted || !row.portfolioId) continue;
        portfolios.push({ providerId: source.providerId, provider: source.provider, portfolioId: row.portfolioId, name: row.name, type: row.type, deleted: false, mode: "live-read-only" });
      }
    }
    return { portfolios, sourceWarnings };
  }

  explicitMappings(): PortfolioWorkspaceMapping[] {
    return this.mappings.filter((mapping) => mapping.explicitlyConfigured === true).map((mapping) => ({ ...mapping }));
  }

  configuredProfileCount(): number {
    return this.sources.length;
  }

  async loadSnapshot(providerId: string, portfolioId: string): Promise<PortfolioSnapshotResult> {
    let snapshot: PortfolioSnapshot;
    if (providerId === "demo" && portfolioId === DEMO_PORTFOLIO_ID) {
      snapshot = createDemoPortfolioSnapshot();
    } else {
      const source = this.sources.find((item) => item.providerId === providerId);
      if (!source) throw new Error("This portfolio data source is not configured.");
      const authorized = (await source.listPortfolios()).find((portfolio) => portfolio.portfolioId === portfolioId && !portfolio.deleted);
      if (!authorized) throw new Error("The configured API key did not authorize access to this portfolio.");
      const result = await source.getPortfolioBreakdown(portfolioId);
      if (result.portfolio.uuid !== portfolioId || result.portfolio.deleted) throw new Error("Coinbase returned a different or deleted portfolio context.");
      snapshot = normalizeAdvancedTradePortfolioSnapshot(providerId, result);
    }
    const previous = await this.repository.latest(providerId, portfolioId);
    const comparison = comparePortfolioSnapshots(previous, snapshot, this.thresholds);
    await this.repository.save(snapshot);
    const history = this.repository.history
      ? await this.repository.history(providerId, portfolioId)
      : previous ? [previous, snapshot] : [snapshot];
    return { snapshot, comparison, history };
  }

  async getMappedStrategySnapshot(workspaceId: string, strategyId: string): Promise<MappedStrategyPortfolioResult> {
    const matches = this.mappings.filter((mapping) => mapping.workspaceId === workspaceId && mapping.strategyId === strategyId);
    if (!matches.length) {
      const loaded = await this.loadSnapshot("demo", DEMO_PORTFOLIO_ID);
      return { status: "unmapped", ...loaded };
    }
    if (matches.length !== 1 || matches[0].explicitlyConfigured !== true) {
      return { status: "unavailable", message: "Portfolio workspace mapping is ambiguous or not explicitly configured; no live portfolio was selected." };
    }
    const mapping = matches[0];
    try {
      const loaded = await this.loadSnapshot(mapping.providerId, mapping.portfolioId);
      return { status: "mapped", mapping, ...loaded };
    } catch {
      return { status: "unavailable", message: "The explicitly mapped Coinbase portfolio could not be authorized or retrieved. Demo data was not substituted." };
    }
  }
}

export function createPortfolioSourceAdapter(
  providerId: string,
  provider: AdvancedTradePortfolioProvider,
): PortfolioSourceAdapter {
  return {
    providerId,
    provider: "coinbase-advanced-trade",
    async listPortfolios() {
      return (await provider.listPortfolios()).map((portfolio) => ({ portfolioId: portfolio.uuid, name: portfolio.name, type: portfolio.type, deleted: portfolio.deleted }));
    },
    getPortfolioBreakdown: (portfolioId) => provider.getPortfolioBreakdown(portfolioId, "USD"),
  };
}

export function createConfiguredPortfolioWorkspaceManager(
  options: { repository?: PortfolioSnapshotRepository } = {},
): PortfolioWorkspaceManager {
  const configWarnings: string[] = [];
  const profileConfig = parseJsonArray<PortfolioCredentialProfileConfig>(process.env.COINBASE_ADVANCED_PORTFOLIO_PROFILES_JSON, "COINBASE_ADVANCED_PORTFOLIO_PROFILES_JSON");
  const mappingConfig = parseJsonArray<PortfolioWorkspaceMappingConfig>(process.env.COINBASE_PORTFOLIO_WORKSPACE_MAPPINGS_JSON, "COINBASE_PORTFOLIO_WORKSPACE_MAPPINGS_JSON");
  if (profileConfig.warning) configWarnings.push(profileConfig.warning);
  if (mappingConfig.warning) configWarnings.push(mappingConfig.warning);

  const profiles: PortfolioCredentialProfileConfig[] = [];
  if (process.env.COINBASE_ADVANCED_API_KEY_NAME && process.env.COINBASE_ADVANCED_API_PRIVATE_KEY) {
    profiles.push({ profileId: "default", keyNameEnv: "COINBASE_ADVANCED_API_KEY_NAME", privateKeyEnv: "COINBASE_ADVANCED_API_PRIVATE_KEY" });
  }
  profiles.push(...profileConfig.items);
  const liveReadsEnabled = process.env.COINBASE_PORTFOLIO_READS_ENABLED === "true";
  if (!profiles.length) configWarnings.push("No authorized Advanced Trade portfolio profiles are configured; only the synthetic demo portfolio is available.");
  else if (!liveReadsEnabled) configWarnings.push("Live Coinbase portfolio reads are disabled. Enable them only on a private or authenticated deployment after reviewing data exposure.");
  const seen = new Set<string>();
  const sources: PortfolioSourceAdapter[] = [];
  for (const profile of liveReadsEnabled ? profiles : []) {
    const profileId = profile.profileId?.trim();
    const keyNameEnv = profile.keyNameEnv?.trim();
    const privateKeyEnv = profile.privateKeyEnv?.trim();
    if (!profileId || !keyNameEnv || !privateKeyEnv || !/^[A-Z][A-Z0-9_]*$/.test(keyNameEnv) || !/^[A-Z][A-Z0-9_]*$/.test(privateKeyEnv)) {
      configWarnings.push("An Advanced Trade credential profile has invalid identifiers or environment-variable references and was ignored.");
      continue;
    }
    if (seen.has(profileId)) {
      configWarnings.push(`Duplicate Advanced Trade profile '${profileId}' was ignored.`);
      continue;
    }
    seen.add(profileId);
    const keyName = process.env[keyNameEnv];
    const privateKey = process.env[privateKeyEnv];
    if (!keyName || !privateKey) {
      configWarnings.push(`Advanced Trade profile '${profileId}' is missing one or more referenced server-side credentials.`);
      continue;
    }
    const provider = new HttpAdvancedTradeProvider({
      credentials: { keyName, privateKey },
    });
    sources.push(createPortfolioSourceAdapter(profileId, provider));
  }

  const mappings: PortfolioWorkspaceMapping[] = [];
  for (const entry of mappingConfig.items) {
    const workspaceId = entry.workspaceId?.trim();
    const strategyId = entry.strategyId?.trim();
    const providerId = entry.providerId?.trim();
    const portfolioId = entry.portfolioId?.trim();
    if (!workspaceId || !strategyId || !providerId || !portfolioId) {
      configWarnings.push("An incomplete portfolio workspace mapping was ignored.");
      continue;
    }
    mappings.push({ workspaceId, strategyId, providerId, portfolioId, explicitlyConfigured: true });
  }
  return new PortfolioWorkspaceManager({ sources, mappings, repository: options.repository || sharedSnapshotRepository, configWarnings });
}

const sharedSnapshotRepository = new InMemoryPortfolioSnapshotRepository(30);
let configuredManager: PortfolioWorkspaceManager | undefined;
export function getConfiguredPortfolioWorkspaceManager(): PortfolioWorkspaceManager {
  configuredManager ||= createConfiguredPortfolioWorkspaceManager({ repository: sharedSnapshotRepository });
  return configuredManager;
}
