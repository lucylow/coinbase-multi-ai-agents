import type { PortfolioSnapshot } from "./portfolio-workspace-manager";

export interface AdvancedPortfolioMetricsOptions {
  /** Explicit annual risk-free rate in decimal form (e.g. 0.04 for 4%). Never defaulted. */
  riskFreeRateAnnual?: number;
  /** Explicit observation frequency assumption used only for annualization and Sharpe. */
  periodsPerYear?: number;
  dailyWindowToleranceHours?: number;
}

export interface AdvancedPortfolioMetrics {
  asOf: string;
  historyPointCount: number;
  totalPortfolioValue: number | null;
  allocations: Array<{ asset: string; value: number | null; allocationPct: number | null; isCash: boolean }>;
  cashAllocationPct: number | null;
  assetConcentrationHHI: number | null;
  concentrationScore: number | null;
  effectiveHoldings: number | null;
  largestHoldings: Array<{ asset: string; value: number | null; allocationPct: number | null }>;
  allocationDrift: Array<{ asset: string; previousAllocationPct: number | null; currentAllocationPct: number | null; changePercentagePoints: number | null }>;
  dailyChange: { amount: number | null; returnPct: number | null; referenceAsOf?: string; unavailableReason?: string };
  simpleReturnPct: number | null;
  cumulativeReturnPct: number | null;
  volatilityPct: number | null;
  annualizedVolatilityPct: number | null;
  maximumDrawdownPct: number | null;
  recoveryTimeDays: number | null;
  recoveredFromMaximumDrawdown: boolean | null;
  sharpeRatio: number | null;
  riskFreeRateAnnual: number | null;
  periodsPerYear: number | null;
  sharpeUnavailableReason?: string;
  returnObservationCount: number;
  historicalCovariance: { assets: string[]; matrix: Array<Array<number | null>>; observationCount: number };
  assetCorrelation: { assets: string[]; matrix: Array<Array<number | null>>; observationCount: number };
  volatilityContributionPct: Array<{ asset: string; contributionPct: number }>;
  volatilityContributionUnavailableReason?: string;
  dataWarnings: string[];
}

interface DatedValue {
  date: number;
  snapshot: PortfolioSnapshot;
}

function isFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value);
}

function sampleStdDev(values: number[]): number | null {
  if (values.length < 2) return null;
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  const variance = values.reduce((sum, value) => sum + (value - mean) ** 2, 0) / (values.length - 1);
  return Math.sqrt(Math.max(0, variance));
}

function sampleCovariance(left: number[], right: number[]): number | null {
  if (left.length !== right.length || left.length < 2) return null;
  const leftMean = left.reduce((sum, value) => sum + value, 0) / left.length;
  const rightMean = right.reduce((sum, value) => sum + value, 0) / right.length;
  return left.reduce((sum, value, index) => sum + (value - leftMean) * (right[index] - rightMean), 0) / (left.length - 1);
}

function isRegularCadence(points: DatedValue[]): boolean {
  if (points.length < 3) return false;
  const intervals = points.slice(1).map((point, index) => point.date - points[index].date);
  if (intervals.some((interval) => interval <= 0)) return false;
  const sorted = [...intervals].sort((a, b) => a - b);
  const median = sorted[Math.floor(sorted.length / 2)];
  return intervals.every((interval) => Math.abs(interval - median) / median <= 0.1);
}

function drawdownMetrics(points: DatedValue[]): {
  maximumDrawdownPct: number | null;
  recoveryTimeDays: number | null;
  recovered: boolean | null;
} {
  if (points.length < 2) return { maximumDrawdownPct: null, recoveryTimeDays: null, recovered: null };
  let peakValue = points[0].snapshot.totalValueFiat!;
  let peakIndex = 0;
  let troughIndex = 0;
  let maxDrawdown = 0;
  let maxPeakIndex = 0;
  for (let index = 1; index < points.length; index += 1) {
    const value = points[index].snapshot.totalValueFiat!;
    if (value > peakValue) {
      peakValue = value;
      peakIndex = index;
    }
    const drawdown = (peakValue - value) / peakValue;
    if (drawdown > maxDrawdown) {
      maxDrawdown = drawdown;
      maxPeakIndex = peakIndex;
      troughIndex = index;
    }
  }
  if (maxDrawdown === 0) return { maximumDrawdownPct: 0, recoveryTimeDays: 0, recovered: true };
  const maxPeak = points[maxPeakIndex].snapshot.totalValueFiat!;
  for (let index = troughIndex + 1; index < points.length; index += 1) {
    if (points[index].snapshot.totalValueFiat! >= maxPeak) {
      return {
        maximumDrawdownPct: maxDrawdown * 100,
        recoveryTimeDays: (points[index].date - points[maxPeakIndex].date) / 86_400_000,
        recovered: true,
      };
    }
  }
  return { maximumDrawdownPct: maxDrawdown * 100, recoveryTimeDays: null, recovered: false };
}

function snapshotPositionMap(snapshot: PortfolioSnapshot) {
  return new Map(snapshot.positions.map((position) => [position.asset, position]));
}

/**
 * Calculate snapshot-based portfolio metrics. Returns are simple and unadjusted for external cash flows.
 * Covariance/correlation use common snapshot-to-snapshot observations, not daily market bars.
 */
export function calculateAdvancedPortfolioMetrics(
  current: PortfolioSnapshot,
  history: PortfolioSnapshot[] = [],
  options: AdvancedPortfolioMetricsOptions = {},
): AdvancedPortfolioMetrics {
  const dataWarnings: string[] = ["Historical portfolio returns and drawdown use reported total values and are not adjusted for deposits, withdrawals, transfers, fees, or other external cash flows."];
  const contextHistory = history.filter((snapshot) => snapshot.providerId === current.providerId && snapshot.portfolioId === current.portfolioId);
  if (contextHistory.some((snapshot) => snapshot.currency !== current.currency)) dataWarnings.push("Snapshots in other currencies were excluded; no foreign-exchange normalization was applied.");
  const sourceHistory = [...contextHistory.filter((snapshot) => snapshot.currency === current.currency), current];
  const byTimestamp = new Map<number, PortfolioSnapshot>();
  for (const snapshot of sourceHistory) {
    const date = Date.parse(snapshot.asOf || snapshot.retrievedAt);
    if (!Number.isFinite(date)) {
      dataWarnings.push("A snapshot with an invalid timestamp was excluded from historical metrics.");
      continue;
    }
    if (snapshot.totalValueFiat === null || !Number.isFinite(snapshot.totalValueFiat) || snapshot.totalValueFiat <= 0) {
      dataWarnings.push("A snapshot without a positive total value was excluded from return and drawdown metrics.");
      continue;
    }
    byTimestamp.set(date, snapshot);
  }
  const points: DatedValue[] = [...byTimestamp.entries()].map(([date, snapshot]) => ({ date, snapshot })).sort((a, b) => a.date - b.date);
  const latest = points.at(-1)?.snapshot || current;
  const total = isFiniteNumber(latest.totalValueFiat) ? latest.totalValueFiat : null;
  const allocations = latest.positions.map((position) => ({
    asset: position.asset,
    value: position.valueFiat,
    allocationPct: position.allocation === null ? null : position.allocation * 100,
    isCash: position.isCash === true,
  }));
  const positiveAllocations = latest.positions.filter((position) => position.allocation !== null && position.allocation > 0);
  const hhi = positiveAllocations.length ? positiveAllocations.reduce((sum, position) => sum + position.allocation! ** 2, 0) : null;
  const cashValue = latest.cashEquivalentFiat ?? latest.positions.filter((position) => position.isCash === true).reduce((sum, position) => sum + (position.valueFiat || 0), 0);
  const cashAllocationPct = total !== null && Number.isFinite(cashValue) ? (cashValue / total) * 100 : null;
  const allocationSum = positiveAllocations.reduce((sum, position) => sum + position.allocation!, 0);
  if (allocationSum < 0.99) dataWarnings.push("Reported asset allocations cover less than 99% of total portfolio value; concentration and diversification may understate unreported exposures.");
  if (latest.coverage !== "complete") dataWarnings.push("The latest portfolio snapshot is partial or unknown; derived exposure metrics cover only reported data.");
  const largestHoldings = [...latest.positions]
    .filter((position) => position.valueFiat !== null && position.valueFiat > 0)
    .sort((a, b) => (b.valueFiat || 0) - (a.valueFiat || 0))
    .slice(0, 5)
    .map((position) => ({ asset: position.asset, value: position.valueFiat, allocationPct: position.allocation === null ? null : position.allocation * 100 }));

  const prior = points.length > 1 ? points[points.length - 2].snapshot : null;
  const priorAllocations = prior ? snapshotPositionMap(prior) : new Map();
  const allocationDrift = latest.positions.map((position) => {
    const old = priorAllocations.get(position.asset);
    const priorPct = old?.allocation ?? null;
    const currentPct = position.allocation;
    return {
      asset: position.asset,
      previousAllocationPct: priorPct === null ? null : priorPct * 100,
      currentAllocationPct: currentPct === null ? null : currentPct * 100,
      changePercentagePoints: priorPct !== null && currentPct !== null ? (currentPct - priorPct) * 100 : null,
    };
  });
  if (!prior) dataWarnings.push("Portfolio drift is unavailable until a prior distinct snapshot is stored; this is snapshot-to-snapshot drift, not drift from a target allocation.");

  const dailyTarget = (points.at(-1)?.date ?? Date.now()) - 86_400_000;
  const toleranceMs = Math.max(0, options.dailyWindowToleranceHours ?? 2) * 3_600_000;
  const dailyReference = points.slice(0, -1)
    .map((point) => ({ point, distance: Math.abs(point.date - dailyTarget) }))
    .filter((candidate) => candidate.distance <= toleranceMs)
    .sort((a, b) => a.distance - b.distance)[0]?.point;
  const latestPoint = points.at(-1);
  const dailyChange = dailyReference && latestPoint
    ? {
        amount: latestPoint.snapshot.totalValueFiat! - dailyReference.snapshot.totalValueFiat!,
        returnPct: ((latestPoint.snapshot.totalValueFiat! / dailyReference.snapshot.totalValueFiat!) - 1) * 100,
        referenceAsOf: dailyReference.snapshot.asOf,
      }
    : { amount: null, returnPct: null, unavailableReason: "No stored snapshot is within the configured tolerance of 24 hours before the latest observation." };

  const portfolioReturns: number[] = [];
  for (let index = 1; index < points.length; index += 1) {
    const previous = points[index - 1].snapshot.totalValueFiat!;
    const currentValue = points[index].snapshot.totalValueFiat!;
    if (previous > 0) portfolioReturns.push(currentValue / previous - 1);
  }
  const simpleReturnPct = portfolioReturns.length ? portfolioReturns.at(-1)! * 100 : null;
  const cumulativeReturnPct = points.length >= 2
    ? (points.at(-1)!.snapshot.totalValueFiat! / points[0].snapshot.totalValueFiat! - 1) * 100
    : null;
  const volatility = sampleStdDev(portfolioReturns);
  const volatilityPct = volatility === null ? null : volatility * 100;
  const periodsPerYear = options.periodsPerYear;
  const cadenceIsRegular = isRegularCadence(points);
  const annualizedVolatilityPct = volatility !== null && isFiniteNumber(periodsPerYear) && periodsPerYear > 0 && cadenceIsRegular
    ? volatility * Math.sqrt(periodsPerYear) * 100
    : null;
  const drawdown = drawdownMetrics(points);
  if (portfolioReturns.length < 2) dataWarnings.push("At least three distinct positive-value snapshots are required for sample volatility and historical covariance.");
  if (points.length < 2) dataWarnings.push("At least two distinct positive-value snapshots are required for historical return and drawdown.");

  let sharpeRatio: number | null = null;
  let sharpeUnavailableReason: string | undefined;
  const riskFreeRateAnnual = options.riskFreeRateAnnual;
  if (!isFiniteNumber(riskFreeRateAnnual) || riskFreeRateAnnual <= -1 || !isFiniteNumber(periodsPerYear) || periodsPerYear <= 0) {
    sharpeUnavailableReason = "Sharpe ratio withheld: an explicit annual risk-free-rate assumption and periods-per-year assumption are both required.";
  } else if (!cadenceIsRegular) {
    sharpeUnavailableReason = "Sharpe ratio withheld: snapshot observations are insufficient or not regular enough for the declared annualization frequency.";
  } else if (portfolioReturns.length < 3) {
    sharpeUnavailableReason = "Sharpe ratio withheld: at least four distinct snapshots (three return observations) are required.";
  } else if (volatility === null || volatility <= 0) {
    sharpeUnavailableReason = "Sharpe ratio withheld: return volatility is zero or unavailable.";
  } else {
    const riskFreePerPeriod = (1 + riskFreeRateAnnual) ** (1 / periodsPerYear) - 1;
    const meanExcessReturn = portfolioReturns.reduce((sum, value) => sum + value - riskFreePerPeriod, 0) / portfolioReturns.length;
    sharpeRatio = (meanExcessReturn / volatility) * Math.sqrt(periodsPerYear);
  }

  const currentPositionMap = snapshotPositionMap(latest);
  const candidateAssets = [...new Set(latest.positions.map((position) => position.asset))].sort();
  const assetReturnSeries = new Map<string, Array<number | null>>();
  for (const asset of candidateAssets) {
    const series: Array<number | null> = [];
    for (let index = 1; index < points.length; index += 1) {
      const before = snapshotPositionMap(points[index - 1].snapshot).get(asset);
      const after = snapshotPositionMap(points[index].snapshot).get(asset);
      const beforePrice = before?.valueFiat !== null && before?.valueFiat !== undefined && before.quantity !== null && before.quantity > 0 ? before.valueFiat / before.quantity : null;
      const afterPrice = after?.valueFiat !== null && after?.valueFiat !== undefined && after.quantity !== null && after.quantity > 0 ? after.valueFiat / after.quantity : null;
      series.push(beforePrice !== null && afterPrice !== null && beforePrice > 0 ? afterPrice / beforePrice - 1 : null);
    }
    assetReturnSeries.set(asset, series);
  }
  const covarianceMatrix: Array<Array<number | null>> = [];
  const correlationMatrix: Array<Array<number | null>> = [];
  let minimumPairObservations = Number.POSITIVE_INFINITY;
  for (const leftAsset of candidateAssets) {
    const covarianceRow: Array<number | null> = [];
    const correlationRow: Array<number | null> = [];
    for (const rightAsset of candidateAssets) {
      const leftSeries = assetReturnSeries.get(leftAsset)!;
      const rightSeries = assetReturnSeries.get(rightAsset)!;
      const pairs = leftSeries.map((left, index) => ({ left, right: rightSeries[index] })).filter((pair): pair is { left: number; right: number } => pair.left !== null && pair.right !== null);
      minimumPairObservations = Math.min(minimumPairObservations, pairs.length);
      const covariance = pairs.length >= 2 ? sampleCovariance(pairs.map((pair) => pair.left), pairs.map((pair) => pair.right)) : null;
      const leftSd = pairs.length >= 2 ? sampleStdDev(pairs.map((pair) => pair.left)) : null;
      const rightSd = pairs.length >= 2 ? sampleStdDev(pairs.map((pair) => pair.right)) : null;
      covarianceRow.push(covariance);
      correlationRow.push(covariance !== null && leftSd !== null && rightSd !== null && leftSd > 0 && rightSd > 0 ? Math.max(-1, Math.min(1, covariance / (leftSd * rightSd))) : null);
    }
    covarianceMatrix.push(covarianceRow);
    correlationMatrix.push(correlationRow);
  }
  const commonObservationCount = Number.isFinite(minimumPairObservations) ? minimumPairObservations : 0;
  const completeCovariance = candidateAssets.length > 0 && covarianceMatrix.every((row) => row.every((value) => value !== null));
  let volatilityContributionPct: Array<{ asset: string; contributionPct: number }> = [];
  let volatilityContributionUnavailableReason: string | undefined;
  const weights = candidateAssets.map((asset) => currentPositionMap.get(asset)?.allocation ?? null);
  const weightSum = weights.reduce<number>((sum, weight) => sum + (weight ?? 0), 0);
  if (!completeCovariance || commonObservationCount < 2) {
    volatilityContributionUnavailableReason = "Volatility contribution requires at least three snapshots with common observations for every included asset.";
  } else if (weights.some((weight) => weight === null) || Math.abs(weightSum - 1) > 0.02) {
    volatilityContributionUnavailableReason = "Volatility contribution withheld because current reported asset weights do not reconcile to approximately 100%.";
  } else {
    const portfolioVariance = covarianceMatrix.reduce((sum, row, rowIndex) => sum + row.reduce((rowSum, covariance, columnIndex) => rowSum + weights[rowIndex]! * weights[columnIndex]! * covariance!, 0), 0);
    if (portfolioVariance <= 0) {
      volatilityContributionUnavailableReason = "Volatility contribution is unavailable because estimated portfolio variance is not positive.";
    } else {
      volatilityContributionPct = candidateAssets.map((asset, rowIndex) => {
        const covarianceWithPortfolio = covarianceMatrix[rowIndex].reduce((sum, covariance, columnIndex) => sum + covariance! * weights[columnIndex]!, 0);
        return { asset, contributionPct: (weights[rowIndex]! * covarianceWithPortfolio / portfolioVariance) * 100 };
      });
    }
  }

  return {
    asOf: latest.asOf,
    historyPointCount: points.length,
    totalPortfolioValue: total,
    allocations,
    cashAllocationPct,
    assetConcentrationHHI: hhi,
    concentrationScore: hhi === null ? null : hhi * 10_000,
    effectiveHoldings: hhi && hhi > 0 ? 1 / hhi : null,
    largestHoldings,
    allocationDrift,
    dailyChange,
    simpleReturnPct,
    cumulativeReturnPct,
    volatilityPct,
    annualizedVolatilityPct,
    maximumDrawdownPct: drawdown.maximumDrawdownPct,
    recoveryTimeDays: drawdown.recoveryTimeDays,
    recoveredFromMaximumDrawdown: drawdown.recovered,
    sharpeRatio,
    riskFreeRateAnnual: isFiniteNumber(riskFreeRateAnnual) ? riskFreeRateAnnual : null,
    periodsPerYear: isFiniteNumber(periodsPerYear) && periodsPerYear > 0 ? periodsPerYear : null,
    sharpeUnavailableReason,
    returnObservationCount: portfolioReturns.length,
    historicalCovariance: { assets: candidateAssets, matrix: covarianceMatrix, observationCount: commonObservationCount },
    assetCorrelation: { assets: candidateAssets, matrix: correlationMatrix, observationCount: commonObservationCount },
    volatilityContributionPct,
    volatilityContributionUnavailableReason,
    dataWarnings: [...new Set(dataWarnings)],
  };
}
