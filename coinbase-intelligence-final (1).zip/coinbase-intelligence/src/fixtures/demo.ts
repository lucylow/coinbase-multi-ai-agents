import type { Candle, MarketProduct, PortfolioBalance } from "@/models/domain";

export const DEMO_AS_OF = "2026-11-05T20:00:00.000Z";
export const DEMO_ACCOUNT = "Coinbase Demo Portfolio 01";
export const MCP_ENDPOINT =
  process.env.COINBASE_MCP_URL || "https://agents.coinbase.com/mcp";

export const balances: PortfolioBalance[] = [
  {
    asset: "BTC",
    name: "Bitcoin",
    productId: "BTC-USD",
    quantity: "0.85",
    averageCost: "62100",
    price: "67200",
    change24h: 2.84,
  },
  {
    asset: "ETH",
    name: "Ethereum",
    productId: "ETH-USD",
    quantity: "4.20",
    averageCost: "3280",
    price: "3450",
    change24h: 1.32,
  },
  {
    asset: "SOL",
    name: "Solana",
    productId: "SOL-USD",
    quantity: "32",
    averageCost: "151",
    price: "142",
    change24h: -3.16,
  },
  {
    asset: "USDC",
    name: "USD Coin",
    productId: "USDC-USD",
    quantity: "2500",
    averageCost: "1",
    price: "1",
    change24h: 0.01,
  },
  {
    asset: "ADA",
    name: "Cardano",
    productId: "ADA-USD",
    quantity: "850",
    averageCost: "0.62",
    price: "0.58",
    change24h: -1.15,
  },
  {
    asset: "LINK",
    name: "Chainlink",
    productId: "LINK-USD",
    quantity: "22",
    averageCost: "17.50",
    price: "18.75",
    change24h: 2.06,
  },
];

function makeCandles(
  base: number,
  drift: number,
  amplitude: number,
  volumeBase: number,
): Candle[] {
  return Array.from({ length: 36 }, (_, index) => {
    const wave =
      Math.sin(index * 0.73) * amplitude +
      Math.cos(index * 0.29) * amplitude * 0.42;
    const previous = base + drift * (index - 35) + wave;
    const close =
      base +
      drift * (index - 34) +
      Math.sin((index + 1) * 0.73) * amplitude +
      Math.cos((index + 1) * 0.29) * amplitude * 0.42;
    const time = new Date(
      Date.parse(DEMO_AS_OF) - (35 - index) * 60 * 60 * 1000,
    ).toISOString();
    return {
      time,
      open: Number(previous.toFixed(2)),
      high: Number((Math.max(previous, close) + amplitude * 0.18).toFixed(2)),
      low: Number((Math.min(previous, close) - amplitude * 0.18).toFixed(2)),
      close: Number(close.toFixed(2)),
      volume: Math.round(volumeBase * (0.7 + ((index * 17) % 11) / 20)),
    };
  });
}

export const markets: MarketProduct[] = [
  {
    productId: "BTC-USD",
    price: 67200,
    change24h: 2.84,
    volume24h: 1_428_000_000,
    volatility: "Moderate",
    candles: makeCandles(67200, 37, 480, 28500),
  },
  {
    productId: "ETH-USD",
    price: 3450,
    change24h: 1.32,
    volume24h: 682_000_000,
    volatility: "Moderate",
    candles: makeCandles(3450, 2.7, 34, 198000),
  },
  {
    productId: "SOL-USD",
    price: 142,
    change24h: -3.16,
    volume24h: 324_000_000,
    volatility: "Elevated",
    candles: makeCandles(142, -0.11, 2.8, 1_420_000),
  },
  {
    productId: "USDC-USD",
    price: 1,
    change24h: 0.01,
    volume24h: 91_000_000,
    volatility: "Low",
    candles: makeCandles(1, 0, 0.003, 81_000_000),
  },
  {
    productId: "ADA-USD",
    price: 0.58,
    change24h: -1.15,
    volume24h: 42_500_000,
    volatility: "Moderate",
    candles: makeCandles(0.58, -0.0004, 0.018, 2_100_000),
  },
  {
    productId: "LINK-USD",
    price: 18.75,
    change24h: 2.06,
    volume24h: 128_000_000,
    volatility: "Moderate",
    candles: makeCandles(18.75, 0.009, 0.38, 760_000),
  },
];

export const scenarioNames = [
  "Bullish momentum",
  "Bearish momentum",
  "Sideways market",
  "High volatility",
  "Liquidity deterioration",
] as const;
