import type { MarketProduct } from "@/models/domain";

function mean(values: number[]) { return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null; }
function sampleSd(values: number[]) {
  if (values.length < 2) return null;
  const average = mean(values)!;
  return Math.sqrt(values.reduce((sum, value) => sum + (value - average) ** 2, 0) / (values.length - 1));
}
export function logReturns(closes: number[]) {
  return closes.slice(1).map((close, index) => close > 0 && closes[index] > 0 ? Math.log(close / closes[index]) : Number.NaN).filter(Number.isFinite);
}
export function rollingVolatilityPct(closes: number[], window = 20) {
  if (!Number.isInteger(window) || window < 2) throw new Error("Rolling-volatility window must be an integer of at least two returns.");
  const values = logReturns(closes);
  return values.length < window ? null : values.map((_, index) => {
    if (index + 1 < window) return null;
    return sampleSd(values.slice(index + 1 - window, index + 1))! * 100;
  });
}
function median(values: number[]) {
  const ordered = [...values].sort((a, b) => a - b);
  if (!ordered.length) return null;
  const middle = Math.floor(ordered.length / 2);
  return ordered.length % 2 ? ordered[middle] : (ordered[middle - 1] + ordered[middle]) / 2;
}
export function detectVolumeAnomaly(market: MarketProduct, multiplier = 2.5) {
  const candles = market.candles;
  const rawLatest = candles.at(-1)?.volume;
  const latest = rawLatest !== undefined && Number.isFinite(rawLatest) && rawLatest >= 0 ? rawLatest : null;
  const baselineValues = candles.slice(-25, -1).map((candle) => candle.volume).filter((volume) => Number.isFinite(volume) && volume >= 0);
  const baseline = median(baselineValues);
  const validMultiplier = Number.isFinite(multiplier) && multiplier > 0;
  return { latestVolume: latest, baselineMedian: baseline, ratio: latest !== null && baseline !== null && baseline > 0 ? latest / baseline : null, anomaly: validMultiplier && latest !== null && baseline !== null && baseline > 0 && latest > baseline * multiplier, observations: baselineValues.length };
}
export function classifyMarketRegime(market: MarketProduct, intervalMs: number) {
  const closes = market.candles.map((candle) => candle.close).filter((close) => Number.isFinite(close) && close > 0);
  const recent = closes.slice(-Math.min(5, closes.length));
  const longer = closes.slice(-Math.min(20, closes.length));
  const recentMean = mean(recent);
  const longerMean = mean(longer);
  const trend = recentMean === null || longerMean === null || recentMean === longerMean ? "range" : recentMean > longerMean ? "uptrend" : "downtrend";
  const returns = logReturns(closes);
  const vol = sampleSd(returns);
  const periodsYear = intervalMs > 0 ? (365.25 * 24 * 60 * 60 * 1000) / intervalMs : NaN;
  const annualVolPct = vol !== null && Number.isFinite(periodsYear) ? vol * Math.sqrt(periodsYear) * 100 : null;
  const volatility = annualVolPct === null ? "insufficient-data" : annualVolPct >= 80 ? "high-volatility" : annualVolPct >= 35 ? "moderate-volatility" : "low-volatility";
  return { trend, volatility, annualVolPct, observations: returns.length, momentumPct: closes.length > 1 ? (closes.at(-1)! / closes[0] - 1) * 100 : null };
}
function alignedAssetReturns(markets: MarketProduct[]) {
  const maps = markets.map((market) => new Map(market.candles.map((candle) => [candle.time, candle.close])));
  const common = maps.length ? [...maps[0].keys()].filter((time) => maps.every((map) => map.has(time))).sort((a, b) => Date.parse(a) - Date.parse(b)) : [];
  return { timestamps: common, series: maps.map((map) => common.slice(1).map((time, index) => {
    const now = map.get(time)!; const before = map.get(common[index])!;
    return now > 0 && before > 0 ? Math.log(now / before) : Number.NaN;
  })) };
}
export function marketCorrelationMatrix(markets: MarketProduct[]) {
  const { timestamps, series } = alignedAssetReturns(markets);
  const assets = markets.map((market) => market.productId);
  const matrix = series.map((left) => series.map((right) => {
    const pairs = left.map((value, index) => [value, right[index]] as const).filter(([a, b]) => Number.isFinite(a) && Number.isFinite(b));
    if (pairs.length < 3) return null;
    const x = pairs.map(([a]) => a); const y = pairs.map(([, b]) => b);
    const mx = mean(x)!; const my = mean(y)!;
    const sx = sampleSd(x); const sy = sampleSd(y);
    if (!sx || !sy) return null;
    return pairs.reduce((sum, [a, b]) => sum + (a - mx) * (b - my), 0) / (pairs.length - 1) / (sx * sy);
  }));
  return { assets, matrix, alignedCandleCount: timestamps.length, returnCount: Math.max(0, timestamps.length - 1) };
}
function maxDrawdownPct(returns: number[]) {
  let wealth = 1; let peak = 1; let worst = 0;
  for (const value of returns) { wealth *= 1 + value; peak = Math.max(peak, wealth); if (peak > 0) worst = Math.max(worst, (peak - wealth) / peak); }
  return worst * 100;
}
function normalTwoSidedPValue(t: number) {
  // Large-sample normal-tail approximation to a two-sided paired t-test p-value.
  const x = Math.abs(t) / Math.sqrt(2);
  const erf = (z: number) => { const sign = z < 0 ? -1 : 1; z = Math.abs(z); const a1 = 0.254829592; const a2 = -0.284496736; const a3 = 1.421413741; const a4 = -1.453152027; const a5 = 1.061405429; const p = 0.3275911; const q = 1 / (1 + p * z); const y = 1 - (((((a5 * q + a4) * q) + a3) * q + a2) * q + a1) * q * Math.exp(-z * z); return sign * y; };
  return Math.max(0, Math.min(1, 1 - erf(x)));
}
/** Close-based SMA crossover: signal uses close t, returns start at t and accrue to close t+1. */
export function compareSmaToBuyHold(closes: number[], options: { fast?: number; slow?: number; costBpsPerTurn?: number; periodsPerYear?: number } = {}) {
  const fast = options.fast ?? 3; const slow = options.slow ?? 8; const costBpsPerTurn = options.costBpsPerTurn ?? 10;
  if (!Number.isInteger(fast) || !Number.isInteger(slow) || fast <= 0 || slow <= fast) throw new Error("Backtest SMA periods must be positive integers with fast < slow.");
  if (!Number.isFinite(costBpsPerTurn) || costBpsPerTurn < 0) throw new Error("Backtest one-way transaction cost must be a finite non-negative number of basis points.");
  if (options.periodsPerYear !== undefined && (!Number.isFinite(options.periodsPerYear) || options.periodsPerYear <= 0)) throw new Error("Backtest periods per year must be positive and finite when supplied.");
  const cost = costBpsPerTurn / 10_000;
  if (closes.some((value) => !Number.isFinite(value) || value <= 0)) throw new Error("Backtest closes must be finite positive prices.");
  if (closes.length <= slow + 1) return { status: "insufficient-data" as const, observations: Math.max(0, closes.length - slow - 1) };
  const sma = (end: number, period: number) => closes.slice(end - period + 1, end + 1).reduce((sum, value) => sum + value, 0) / period;
  const strategy: number[] = []; const benchmark: number[] = []; let held = 0;
  for (let index = slow - 1; index < closes.length - 1; index += 1) {
    const signal = sma(index, fast) > sma(index, slow) ? 1 : 0;
    const barReturn = closes[index + 1] / closes[index] - 1;
    const turnoverCost = Math.abs(signal - held) * cost;
    strategy.push(signal * barReturn - turnoverCost);
    benchmark.push(barReturn);
    held = signal;
  }
  const active = strategy.map((value, index) => value - benchmark[index]);
  const activeSd = sampleSd(active); const activeMean = mean(active);
  const tStatistic = activeSd && activeMean !== null ? activeMean / (activeSd / Math.sqrt(active.length)) : null;
  const strategySd = sampleSd(strategy); const rfAnnual = 0;
  const periodsYear = options.periodsPerYear;
  const riskFreePerPeriod = Number.isFinite(periodsYear) && periodsYear! > 0 ? (1 + rfAnnual) ** (1 / periodsYear!) - 1 : 0;
  const strategyMean = mean(strategy);
  const cumulativeReturnPct = (returns: number[]) => (returns.reduce((wealth, value) => wealth * (1 + value), 1) - 1) * 100;
  const observations = strategy.length;
  const t = tStatistic;
  return {
    status: "calculated" as const, observations, fast, slow, costBpsPerTurn,
    strategyReturnPct: cumulativeReturnPct(strategy), buyHoldReturnPct: cumulativeReturnPct(benchmark),
    strategyMaxDrawdownPct: maxDrawdownPct(strategy), buyHoldMaxDrawdownPct: maxDrawdownPct(benchmark),
    annualizedVolatilityPct: strategySd !== null && Number.isFinite(periodsYear) && periodsYear! > 0 ? strategySd * Math.sqrt(periodsYear!) * 100 : null,
    sharpeRatioZeroRiskFree: strategySd && strategyMean !== null && Number.isFinite(periodsYear) && periodsYear! > 0 ? (strategyMean - riskFreePerPeriod) / strategySd * Math.sqrt(periodsYear!) : null,
    pairedActiveReturnTStatistic: t,
    approximateTwoSidedPValue: t === null ? null : normalTwoSidedPValue(t),
    activeReturnMeanPctPerBar: activeMean === null ? null : activeMean * 100,
  };
}
