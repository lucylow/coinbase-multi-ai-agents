import { randomUUID } from "node:crypto";
import type { AgentAuditTrailEntry, AgentTask } from "@/models/domain";
import {
  DEFAULT_PORTFOLIO_STRATEGY_ID,
  DEFAULT_PORTFOLIO_WORKSPACE_ID,
  getConfiguredPortfolioWorkspaceManager,
} from "@/services/portfolio/portfolio-workspace-manager";
import {
  AGENTS,
  loadAgentMarketContext,
  marketIntelligence,
  portfolioAnalyst,
  quantitativeResearch,
  riskOfficer,
  verificationAgent,
} from "./specialists";

export async function runInvestigation(objective: string): Promise<AgentTask> {
  const cleaned = objective.trim();
  if (cleaned.length < 8 || cleaned.length > 500) throw new Error("Objective must be between 8 and 500 characters.");
  const id = `INV-${randomUUID().slice(0, 8).toUpperCase()}`;
  const manager = getConfiguredPortfolioWorkspaceManager();
  const [portfolioContext, marketContext] = await Promise.all([
    manager.getMappedStrategySnapshot(DEFAULT_PORTFOLIO_WORKSPACE_ID, DEFAULT_PORTFOLIO_STRATEGY_ID),
    loadAgentMarketContext(),
  ]);
  // Read sibling portfolios only when the objective explicitly asks for a comparison.
  // Internal research agent workspaces are not assumed to be separate Coinbase accounts.
  const wantsMultiPortfolioComparison = /\b(compare|comparison|versus|vs\.?|multiple|multi[- ]portfolio|between)\b/i.test(cleaned) && /\b(portfolio|account)s?\b/i.test(cleaned);
  const additionalSnapshots = [];
  if (wantsMultiPortfolioComparison && portfolioContext.status !== "unavailable") {
    const { portfolios } = await manager.listAuthorizedPortfolios();
    const current = portfolioContext.snapshot;
    const others = portfolios.filter((item) => item.providerId !== current.providerId || item.portfolioId !== current.portfolioId);
    const loaded = await Promise.all(others.map(async (item) => {
      try { return (await manager.loadSnapshot(item.providerId, item.portfolioId)).snapshot; }
      catch { return null; }
    }));
    additionalSnapshots.push(...loaded.filter((item): item is NonNullable<typeof item> => item !== null));
  }
  const [portfolio, market, quant] = await Promise.all([
    portfolioAnalyst(id, cleaned, portfolioContext, additionalSnapshots),
    marketIntelligence(id, marketContext),
    quantitativeResearch(id, marketContext),
  ]);
  const research = [portfolio, market, quant];
  const risk = await riskOfficer(id, research, portfolioContext.status === "unavailable" ? undefined : portfolioContext.snapshot, marketContext);
  const priorFindings = [...research, risk];
  const now = () => new Date().toISOString();
  const auditTrail: AgentAuditTrailEntry[] = [
    { action: "portfolio-context-read", status: portfolioContext.status === "unavailable" ? "failed" : portfolioContext.status === "mapped" ? "completed" : "partial", recordedAt: now(), references: portfolioContext.status === "unavailable" ? ["coinbase:portfolio-mapping:unavailable"] : [`portfolio-snapshot:${portfolioContext.snapshot.snapshotId}`, ...additionalSnapshots.map((item) => `portfolio-snapshot:${item.snapshotId}`)] },
    { action: "market-data-read", status: marketContext.sync.mode === "live-read-only" && !marketContext.sync.unavailableProducts.length ? "completed" : "partial", recordedAt: now(), references: marketContext.sync.markets.map((item) => `${item.source || "unknown"}:markets:${item.productId}`).concat(marketContext.bookSource === "unavailable" ? [] : [`${marketContext.bookSource}:orderbook:${marketContext.microstructureProductId}`]) },
    { action: "portfolio-analyst-complete", status: "completed", recordedAt: now(), references: portfolio.evidenceRefs },
    { action: "market-intelligence-complete", status: "completed", recordedAt: now(), references: market.evidenceRefs },
    { action: "quant-research-complete", status: "completed", recordedAt: now(), references: quant.evidenceRefs },
    { action: "risk-review-complete", status: "completed", recordedAt: now(), references: risk.evidenceRefs },
  ];
  const verification = await verificationAgent(id, priorFindings, portfolioContext.status === "unavailable" ? undefined : portfolioContext.snapshot, { marketContext, auditTrail });
  auditTrail.push({ action: "verification-audit-complete", status: verification.riskFlags.length ? "partial" : "completed", recordedAt: now(), references: verification.evidenceRefs });
  const findings = [...research, risk, verification];
  const riskFlags = [...new Set(findings.flatMap((finding) => finding.riskFlags))];
  const verificationPassed = !verification.riskFlags.some((flag) => flag.includes("failed"));
  const stanceCounts = findings.reduce((counts, finding) => {
    const stance = finding.stance || "market-neutral";
    counts.set(stance, (counts.get(stance) || 0) + 1);
    return counts;
  }, new Map<string, number>());
  const agreementScore = findings.length ? Math.max(...stanceCounts.values()) / findings.length : 0;
  const recommendation = portfolioContext.status === "unavailable"
    ? "Hold portfolio-dependent conclusions because the explicitly mapped Coinbase portfolio was unavailable; no demo substitution, trade, or transfer is authorized."
    : verificationPassed
      ? `Continue with research review only. ${portfolioContext.status === "mapped" ? "An explicitly mapped Coinbase read-only portfolio was analyzed." : "Demo fixture data was used because no live research-workspace mapping was configured."} no live action is authorized or available.`
      : "Hold the summary for correction because independent verification detected a source, calculation, unsupported claim, contract, or audit inconsistency.";
  const decisionReview = {
    decisionId: `DEC-${id}`, taskId: id, participatingAgents: findings.map((finding) => finding.agentId), agreementScore,
    unresolvedDisagreements: [...new Set(findings.filter((finding) => finding.dissent).map((finding) => finding.dissent!))],
    riskFlags, evidenceCoverage: findings.filter((finding) => finding.evidenceRefs.length > 0).length / findings.length,
    recommendation, humanApprovalRequired: true,
  };
  const task: AgentTask = {
    id, objective: cleaned, productIds: ["BTC-USD", "ETH-USD", "SOL-USD"],
    mode: portfolioContext.status === "mapped" ? "live-read-only" : portfolioContext.status === "unavailable" ? "unavailable" : "demo",
    status: verificationPassed ? "completed" : "failed", createdAt: new Date().toISOString(), completedAt: new Date().toISOString(),
    findings, contractVersion: "2.0", auditTrail, contextRefs: [...new Set(auditTrail.flatMap((event) => event.references))],
    finalRecommendation: recommendation, agreementScore: decisionReview.agreementScore, riskFlags, decisionReview,
  };
  return task;
}

export function agentRoster() { return AGENTS; }
