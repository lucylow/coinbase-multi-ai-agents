import type { AgentFinding, AgentToolTrace, AgentValidationCheck } from "@/models/domain";
import { balances, markets } from "@/fixtures/demo";
import { syncPublicMarkets, type MarketSyncResult } from "@/integrations/coinbase/marketData";
import { HttpAdvancedTradeProvider, type AdvancedTradeProvider } from "@/integrations/coinbase/advancedTradeProvider";
import { calculateMicrostructure, createDemoOrderBook, type MicrostructureMetrics } from "@/services/market-microstructure";
import { alignPortfolioSnapshots, comparePortfolioAllocations } from "@/services/portfolio/portfolio-comparison";
import { portfolioConcentration, type MappedStrategyPortfolioResult, type PortfolioSnapshot } from "@/services/portfolio/portfolio-workspace-manager";
import { classifyMarketRegime, compareSmaToBuyHold, detectVolumeAnomaly, marketCorrelationMatrix, rollingVolatilityPct } from "./research-analytics";
import {
  atr,
  maxDrawdown,
  movingAverage,
  rsi,
  simpleReturns,
} from "@/services/analytics";

export const AGENTS = [
  {
    id: "portfolio-analyst",
    name: "Portfolio Analyst",
    role: "History, exposure, drift and scenarios",
    color: "blue",
  },
  {
    id: "market-intelligence",
    name: "Market Intelligence",
    role: "Candles, microstructure and regimes",
    color: "cyan",
  },
  {
    id: "quant-research",
    name: "Quant Research",
    role: "Inference, strategies and backtests",
    color: "violet",
  },
  {
    id: "risk-officer",
    name: "Risk Officer",
    role: "Stress, liquidity and policy challenge",
    color: "amber",
  },
  {
    id: "verification-audit",
    name: "Verification & Audit",
    role: "Independent calculations and audit",
    color: "green",
  },
] as const;

function makeFinding(
  taskId: string,
  agentId: string,
  summary: string,
  findings: string[],
  calculations: string[],
  evidenceRefs: string[],
  riskFlags: string[],
  confidence: number,
  dissent?: string,
  metrics?: Record<string, number | string>,
  stance: AgentFinding["stance"] = "market-neutral",
  assumptions?: string[],
  toolTrace?: AgentToolTrace[],
  validationChecks?: AgentValidationCheck[],
): AgentFinding {
  return {
    id: `${taskId}-${agentId}`,
    agentId,
    taskId,
    summary,
    findings,
    calculations,
    evidenceRefs,
    assumptions: assumptions || [
      "All balances and prices are synthetic demonstration fixtures.",
      "No live Coinbase account was accessed.",
    ],
    confidence,
    riskFlags,
    requiresReview: riskFlags.length > 0,
    dissent,
    status: "completed",
    metrics,
    stance,
    ...(toolTrace ? { toolTrace } : {}),
    ...(validationChecks ? { validationChecks } : {}),
  };
}

export async function portfolioAnalyst(
  taskId: string,
  objective: string,
  context: MappedStrategyPortfolioResult,
  additionalSnapshots: PortfolioSnapshot[] = [],
): Promise<AgentFinding> {
  if (context.status === "unavailable") {
    return makeFinding(taskId, "portfolio-analyst", "Configured Coinbase portfolio context is unavailable", [context.message, "No demo balances were substituted for the explicitly mapped live portfolio."], ["Analysis stopped because the configured read-only portfolio could not be validated or retrieved."], ["coinbase:portfolio-mapping:unavailable"], ["Mapped portfolio data unavailable", "Portfolio analysis requires human review"], 0.2, undefined, { portfolioSource: "unavailable" }, "risk-flagged", ["A server-side workspace-to-portfolio mapping was configured, but the mapped portfolio could not be accessed.", "No live value, balance movement, or account identity was inferred."], [{ toolId: "portfolio-snapshot", source: "configured-mapping", status: "unavailable" }]);
  }

  const { snapshot, comparison, history } = context;
  const concentration = portfolioConcentration(snapshot);
  const ranked = [...snapshot.positions].filter((position) => position.allocation !== null).sort((a, b) => (b.allocation || 0) - (a.allocation || 0));
  const top = ranked[0];
  const valued = snapshot.positions.filter((position) => position.valueFiat !== null);
  const costCovered = valued.filter((position) => position.costBasisFiat !== null);
  const coveredPnl = costCovered.reduce((sum, position) => sum + position.valueFiat! - position.costBasisFiat!, 0);
  const portfolioValueCents = snapshot.totalValueFiat === null ? undefined : Math.round(snapshot.totalValueFiat * 100);
  const spotValueCents = Math.round(valued.reduce((sum, position) => sum + (position.valueFiat || 0), 0) * 100);
  const pnlCents = costCovered.length ? Math.round(coveredPnl * 100) : undefined;
  const prior = history.filter((item) => item.snapshotId !== snapshot.snapshotId && item.providerId === snapshot.providerId && item.portfolioId === snapshot.portfolioId && item.currency === snapshot.currency && Date.parse(item.asOf) < Date.parse(snapshot.asOf)).sort((a, b) => Date.parse(b.asOf) - Date.parse(a.asOf))[0];
  const previousByAsset = new Map((prior?.positions || []).map((position) => [position.asset, position]));
  const driftRows = snapshot.positions.flatMap((position) => {
    const before = previousByAsset.get(position.asset);
    return before?.allocation !== null && before?.allocation !== undefined && position.allocation !== null
      ? [{ asset: position.asset, pp: (position.allocation - before.allocation) * 100 }]
      : [];
  });
  const hhiContributions = ranked.map((position) => ({ asset: position.asset, contribution: position.allocation! ** 2 }));
  const stressLoss = top?.valueFiat !== null && top?.valueFiat !== undefined ? top.valueFiat * 0.1 : null;
  const spotSubtotal = spotValueCents / 100;
  const stressedPortfolioValue = stressLoss !== null && spotSubtotal > 0 ? spotSubtotal - stressLoss : null;
  const comparisonRequested = /\b(compare|comparison|versus|vs\.?|multiple|multi[- ]portfolio|between)\b/i.test(objective) && /\b(portfolio|account)s?\b/i.test(objective);
  const candidatePeers = additionalSnapshots.filter((peer) => peer.snapshotId !== snapshot.snapshotId);
  const currencyMismatchCount = candidatePeers.filter((peer) => peer.currency !== snapshot.currency).length;
  const peers = candidatePeers.filter((peer) => peer.currency === snapshot.currency);
  const peerSummaries = peers.map((peer) => {
    const aligned = alignPortfolioSnapshots([snapshot], [peer]);
    if (!aligned) return null;
    const result = comparePortfolioAllocations(snapshot, peer);
    const maxDifference = result.differences.reduce((max, row) => Math.max(max, Math.abs(row.differencePercentagePoints ?? 0)), 0);
    const largestDifferences = result.differences.filter((row) => row.differencePercentagePoints !== null).sort((a, b) => Math.abs(b.differencePercentagePoints!) - Math.abs(a.differencePercentagePoints!)).slice(0, 3).map((row) => `${row.asset} ${row.differencePercentagePoints! >= 0 ? "+" : ""}${row.differencePercentagePoints!.toFixed(2)} pp`);
    return { peer, offset: aligned.offsetMilliseconds, maxDifference, largestDifferences };
  }).filter((item): item is { peer: PortfolioSnapshot; offset: number; maxDifference: number; largestDifferences: string[] } => item !== null);
  const concentrationFlag = concentration.largestAllocation > 0.65;
  const partialFlag = snapshot.coverage !== "complete";
  const movementFlag = comparison.unusualMovements.length > 0;
  const riskFlags = [
    ...(concentrationFlag ? ["Elevated single-asset concentration"] : []),
    ...(partialFlag ? ["Portfolio data coverage is partial or incomplete"] : []),
    ...(movementFlag ? ["Unusual position-quantity movement observed"] : []),
  ];
  const live = snapshot.provider !== "demo";
  const findings = [
    snapshot.totalValueFiat === null ? "Portfolio total value is unavailable from the returned data." : `Reported portfolio value is ${snapshot.currency} ${snapshot.totalValueFiat.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}.`,
    top ? `${top.asset} is the largest reported exposure at ${((top.allocation || 0) * 100).toFixed(1)}% of reported portfolio value.` : "No position had enough value data to calculate an allocation.",
    `Concentration HHI is ${concentration.hhi.toFixed(4)} across ${concentration.positionCount} valued positions; HHI decomposition by asset: ${hhiContributions.map((row) => `${row.asset} ${(row.contribution * 10_000).toFixed(0)} points`).join(", ") || "unavailable"}.`,
    costCovered.length ? `Cost-basis PnL is ${snapshot.currency} ${coveredPnl >= 0 ? "+" : ""}${coveredPnl.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} for ${costCovered.length} of ${valued.length} valued positions; it is not full-portfolio PnL unless coverage is complete.` : "Cost-basis PnL is unavailable because no reported position had a comparable cost basis.",
    prior ? `Allocation drift versus the prior distinct snapshot: ${driftRows.map((row) => `${row.asset} ${row.pp >= 0 ? "+" : ""}${row.pp.toFixed(2)} percentage points`).join(" · ") || "no comparable allocation weights"}.` : "No earlier distinct same-currency snapshot is available for portfolio-history drift analysis.",
    ...ranked.slice(0, 5).map((position) => `Position exposure: ${position.asset} value ${position.valueFiat === null ? "unavailable" : `${snapshot.currency} ${position.valueFiat.toFixed(2)}`} · allocation ${((position.allocation || 0) * 100).toFixed(2)}% · quantity ${position.quantity === null ? "unavailable" : position.quantity}.`),
    stressLoss !== null && stressedPortfolioValue !== null ? `Illustrative single-factor scenario: a 10% mark-down in ${top!.asset}, all other reported spot values held constant, would reduce the reported spot subtotal by about ${snapshot.currency} ${stressLoss.toFixed(2)} (${(stressLoss / spotSubtotal * 100).toFixed(2)}%) to ${snapshot.currency} ${stressedPortfolioValue.toFixed(2)}; non-spot/unknown exposures excluded; not a forecast or allocation instruction.` : "Single-position scenario unavailable because a positive spot subtotal or largest-position value is missing.",
    prior ? `Portfolio valuation changed ${comparison.portfolioValueChangeFiat === null ? "by an unavailable amount" : `${comparison.portfolioValueChangeFiat >= 0 ? "+" : ""}${snapshot.currency} ${comparison.portfolioValueChangeFiat.toFixed(2)}`} versus the prior stored snapshot; valuation changes can reflect price, activity, fees, or missing data.` : "No prior stored snapshot is available for historical value comparison.",
    ...comparison.unusualMovements,
    ...peerSummaries.map(({ peer, maxDifference, offset, largestDifferences }) => `Authorized portfolio comparison: ${peer.portfolioName} differs from this context by up to ${maxDifference.toFixed(2)} allocation pp at a ${Math.round(offset / 60_000)}-minute timestamp offset${largestDifferences.length ? `; largest asset differences ${largestDifferences.join(", ")}` : ""}; this is composition, not relative performance.`),
    ...(comparisonRequested && !peerSummaries.length ? [currencyMismatchCount ? `${currencyMismatchCount} authorized peer context(s) had a different currency; no FX conversion was applied, so no peer allocation comparison was made.` : "No additional authorized same-currency portfolio context was available; no Coinbase portfolio was inferred from an internal research-agent workspace."] : []),
    ...snapshot.missingData.slice(0, 5),
  ];
  const calculations = [
    `Allocations: ${ranked.map((position) => `${position.asset} ${((position.allocation || 0) * 100).toFixed(1)}%`).join(" · ") || "unavailable"}`,
    `HHI = sum of squared allocation fractions; per-asset contribution points = weight² × 10,000; top-three share ${(concentration.topThreeAllocation * 100).toFixed(1)}%.`,
    `Effective holdings = 1 / HHI = ${concentration.hhi > 0 ? (1 / concentration.hhi).toFixed(2) : "unavailable"}.`,
    `Cost-basis PnL computed only on ${costCovered.length}/${valued.length} valued positions with cost basis.`,
    prior ? `Drift = current allocation − prior distinct snapshot allocation in percentage points; compared ${driftRows.length} position(s).` : "Historical drift not calculated: no earlier distinct snapshot.",
    `Illustrative scenario applies −10% only to the largest valued position; other holdings, quantities, correlations, fees, and cash flows are held unchanged.`,
    `Movement alert thresholds: ≥25% quantity change and $100 value change, or a newly observed position ≥$100; no movement cause is inferred.`,
    ...peerSummaries.map(({ peer, offset }) => `Compared only authorized context ${peer.providerId}/${peer.portfolioId} at timestamp offset ${offset} ms; no FX conversion.`),
    comparison.valueChangeCaveat,
  ];
  const evidenceRefs = [
    ...(live ? [`coinbase:${snapshot.provider}:portfolio:${snapshot.portfolioId}`, `coinbase:portfolio-snapshot:${snapshot.snapshotId}`] : ["demo:portfolio:balances", "demo:portfolio:allocation"]),
    ...(prior ? [`portfolio-history:${prior.snapshotId}`] : []),
    ...peerSummaries.map(({ peer }) => `coinbase:${peer.provider}:portfolio:${peer.portfolioId}`),
  ];
  const assumptions = live
    ? ["Portfolio data came from an explicitly configured authorized read-only Coinbase source.", "Allocations and exposures include reported spot positions; unsupported classes and missing fields are disclosed.", "The 10% scenario is a static one-factor shock, not a forecast, recommendation, or transaction.", "Balance and valuation changes do not establish transfers, trades, deposits, or withdrawals.", "Analysis is not investment advice."]
    : ["Balances/prices are synthetic demonstration fixtures; no live account was accessed for this unmapped workspace.", "The 10% scenario is illustrative only, not a forecast or transaction.", "Analysis is not investment advice."];
  return makeFinding(taskId, "portfolio-analyst", `Portfolio analysis complete for “${objective}” (${snapshot.portfolioName})`, findings, calculations, evidenceRefs, riskFlags, snapshot.coverage === "complete" ? 0.9 : 0.7, undefined, {
    portfolioSource: live ? snapshot.provider : "demo", portfolioId: snapshot.portfolioId,
    portfolioValueCents: portfolioValueCents ?? "unavailable", spotPositionValueCents: spotValueCents,
    ...(pnlCents === undefined ? {} : { costBasisPnlCents: pnlCents }),
    largestAsset: top?.asset || "unavailable", largestAllocation: concentration.largestAllocation,
    topThreeAllocation: concentration.topThreeAllocation, concentrationHhi: concentration.hhi,
    valuedPositionCount: valued.length, costBasisCoveredPositions: costCovered.length,
    dataCoverage: snapshot.coverage, unusualMovementCount: comparison.unusualMovements.length,
    effectiveHoldings: concentration.hhi > 0 ? 1 / concentration.hhi : 0,
    historicalSnapshotCount: history.length, driftedPositionCount: driftRows.length, multiPortfolioComparisonCount: peerSummaries.length,
    ...(stressLoss === null ? {} : { illustrativeLargestHoldingShockLossCents: Math.round(stressLoss * 100) }),
  }, riskFlags.length ? "risk-flagged" : "market-neutral", assumptions,
  [{ toolId: "portfolio-workspace-manager", source: live ? `coinbase:${snapshot.providerId}` : "demo:portfolio-fixtures", status: partialFlag ? "partial" : "success", retrievedAt: snapshot.retrievedAt, reference: `portfolio-snapshot:${snapshot.snapshotId}` },
   ...(prior ? [{ toolId: "portfolio-history", source: "bounded-snapshot-repository", status: "success" as const, retrievedAt: prior.asOf, reference: prior.snapshotId }] : []),
   ...peerSummaries.map(({ peer }) => ({ toolId: "authorized-portfolio-comparison", source: `coinbase:${peer.providerId}`, status: "success" as const, retrievedAt: peer.asOf, reference: peer.snapshotId }))],
  [
    { name: "portfolio-total-and-spot-subtotal", status: snapshot.totalValueFiat === null ? "not-run" : "passed", detail: `Reported total ${snapshot.totalValueFiat === null ? "unavailable" : `${snapshot.currency} ${snapshot.totalValueFiat.toFixed(2)}`}; spot subtotal ${snapshot.currency} ${(spotValueCents / 100).toFixed(2)}.` },
    { name: "allocation-coverage", status: snapshot.coverage === "complete" ? "passed" : "failed", detail: `Provider coverage is ${snapshot.coverage}; position-level values may omit unsupported exposures.` },
    { name: "historical-comparison", status: prior ? "passed" : "not-run", detail: prior ? `Aligned to previous distinct snapshot ${prior.snapshotId}.` : "No previous distinct snapshot in the same currency." },
  ]);
}

export interface AgentMarketContext {
  sync: MarketSyncResult;
  microstructure?: MicrostructureMetrics;
  microstructureProductId?: string;
  bookSource: "coinbase-advanced-trade" | "demo" | "unavailable";
  bookAsOf?: string;
}

export async function loadAgentMarketContext(): Promise<AgentMarketContext> {
  const provider: AdvancedTradeProvider | undefined = process.env.NODE_ENV === "test" ? undefined : new HttpAdvancedTradeProvider();
  const sync = provider ? await syncPublicMarkets({ provider, productIds: ["BTC-USD", "ETH-USD", "SOL-USD", "USDC-USD"] }) : await syncPublicMarkets();
  const reference = sync.markets.find((market) => market.productId === "BTC-USD") || sync.markets[0];
  if (!reference) return { sync, bookSource: "unavailable" };
  let book = null;
  let bookSource: AgentMarketContext["bookSource"] = "unavailable";
  let bookAsOf: string | undefined;
  if (provider && sync.mode === "live-read-only") {
    try { book = await provider.getProductBook(reference.productId, 10); bookSource = "coinbase-advanced-trade"; bookAsOf = book.time; } catch { /* The missing book is reported; never substitute synthetic depth into a live snapshot. */ }
  } else if (sync.mode === "demo-fallback") {
    book = createDemoOrderBook(reference.productId, reference.price, sync.asOf, 10);
    bookSource = "demo"; bookAsOf = sync.asOf;
  }
  return { sync, ...(book ? { microstructure: calculateMicrostructure(book, reference.candles) } : {}), microstructureProductId: reference.productId, bookSource, bookAsOf };
}

export async function marketIntelligence(taskId: string, supplied?: AgentMarketContext): Promise<AgentFinding> {
  const context = supplied || await loadAgentMarketContext();
  const { sync } = context;
  const sourceMarkets = sync.markets.length ? sync.markets : markets;
  const moving = sourceMarkets.filter((market) => market.productId !== "USDC-USD");
  if (!moving.length) return makeFinding(taskId, "market-intelligence", "No Coinbase USD products were available", ["No market series was available from Coinbase or demo fixtures."], [], ["market-data:empty"], ["Missing market inputs"], 0.3, undefined, undefined, "risk-flagged", undefined, [{ toolId: "coinbase-public-markets", source: sync.mode, status: "unavailable", retrievedAt: sync.asOf }]);
  const strongest = [...moving].sort((a, b) => b.change24h - a.change24h)[0];
  const weakest = [...moving].sort((a, b) => a.change24h - b.change24h)[0];
  const regime = classifyMarketRegime(strongest, sync.intervalMs);
  const volume = detectVolumeAnomaly(strongest);
  const micro = context.microstructure;
  const dataQualityFindings = moving.flatMap((market) => {
    const gaps = market.dataQuality?.missingCandles || 0;
    const lastTime = Date.parse(market.dataAsOf || "");
    const stale = Number.isFinite(lastTime) && Date.now() - lastTime > sync.intervalMs * 3;
    return [ ...(gaps ? [`${market.productId} has ${gaps} missing candle interval(s) in the requested sample.`] : []), ...(stale ? [`${market.productId} candle data is older than three requested intervals.`] : []) ];
  });
  const sourceName = sync.mode === "live-read-only" ? "Coinbase Advanced Trade public market data" : "seeded synthetic demo market data";
  const findings = [
    `${strongest.productId} leads the 24-hour cross-section at ${strongest.change24h.toFixed(2)}%; ${weakest.productId} is weakest at ${weakest.change24h.toFixed(2)}%.`,
    `${strongest.productId} regime label: ${regime.trend} / ${regime.volatility}; this descriptive classification is not a forecast.`,
    volume.observations >= 5 && volume.ratio !== null ? `${strongest.productId} latest candle volume is ${volume.ratio.toFixed(2)}× its preceding-candle median${volume.anomaly ? " (volume anomaly threshold exceeded)" : " (no anomaly threshold exceeded)"}.` : `${strongest.productId} volume-anomaly test withheld: ${volume.observations < 5 ? "fewer than five valid preceding-candle observations" : "latest candle volume or baseline median is invalid/unavailable"}.`,
    micro?.spread !== null && micro?.spread !== undefined ? `${context.bookSource} book for ${context.microstructureProductId}: bid/ask spread ${micro.spread.toFixed(8)} (${micro.spreadBps?.toFixed(2) ?? "—"} bps), midpoint ${micro.midPrice?.toFixed(8)}, estimated one-way spread cost on $1,000 notional $${micro.oneWaySpreadCostOn1000?.toFixed(4) ?? "—"}, supplied bid/ask depth ${micro.bidDepthUsd.toFixed(2)} / ${micro.askDepthUsd.toFixed(2)} quote units; candle momentum ${micro.momentumPct?.toFixed(2) ?? "—"}%, unannualized realized volatility ${micro.realizedVolPct?.toFixed(2) ?? "—"}%.` : `Order-book spread/depth unavailable for ${context.microstructureProductId || strongest.productId}; do not infer liquidity from candles.`,
    ...dataQualityFindings,
    `Source ${sourceName}; sample as of ${sync.asOf}; candle interval ${sync.granularity}; ${sync.unavailableProducts.length ? `unavailable products ${sync.unavailableProducts.join(", ")}` : "selected products available"}.`,
  ];
  const riskFlags = [ ...(sync.mode === "demo-fallback" ? ["Synthetic market snapshot; not suitable for execution"] : []), ...(sync.unavailableProducts.length ? ["Some requested trading pairs are not supported or available"] : []), ...(dataQualityFindings.length ? ["Market candle freshness/coverage requires review"] : []), ...(context.bookSource === "unavailable" ? ["Order-book snapshot unavailable"] : []) ];
  const marketRefs = moving.map((market) => `${market.source === "coinbase-advanced-trade" ? "coinbase-advanced-trade" : "demo"}:markets:${market.productId}`);
  return makeFinding(taskId, "market-intelligence", `${sync.mode === "live-read-only" ? "Live-read-only" : "Demo fallback"} market, candle, volume and order-book analysis`, findings,
    [ ...moving.map((market) => `${market.productId}: $${market.price.toLocaleString("en-US")} · 24h ${market.change24h > 0 ? "+" : ""}${market.change24h.toFixed(2)}% · 24h volume ${market.volume24h.toLocaleString("en-US")} · ${market.candles.length} candles`),
      `Regime rule: short mean of up to 5 closes vs long mean of up to 20; annualized volatility uses sample log-return standard deviation × sqrt(periods/year), ${regime.annualVolPct?.toFixed(2) ?? "unavailable"}%.`,
      `Volume anomaly: latest candle volume / median of preceding up to 24 candles; ${volume.ratio?.toFixed(2) ?? "unavailable"}×, threshold 2.5×, baseline n=${volume.observations}.`,
      ...(micro ? [`Microstructure spread ${micro.spread?.toFixed(8) ?? "unavailable"}; spread bps ${micro.spreadBps?.toFixed(2) ?? "unavailable"}; one-way spread cost on $1,000 ${micro.oneWaySpreadCostOn1000?.toFixed(4) ?? "unavailable"}; imbalance ${micro.imbalance?.toFixed(4) ?? "unavailable"}; candle momentum ${micro.momentumPct?.toFixed(3) ?? "unavailable"}%; unannualized short-term realized volatility ${micro.realizedVolPct?.toFixed(3) ?? "unavailable"}%; depth is limited to returned levels.`] : []),
    ], [...marketRefs, ...(context.bookSource === "unavailable" ? [] : [`${context.bookSource}:orderbook:${context.microstructureProductId}`])], riskFlags,
    sync.mode === "live-read-only" ? 0.86 : 0.7, "Market direction, order-book imbalance, or volume anomalies do not establish future price movements with certainty.",
    { productsAnalyzed: moving.length, strongest24hProduct: strongest.productId, candleCount: strongest.candles.length, annualizedVolatilityPct: regime.annualVolPct ?? "unavailable", volumeAnomalyRatio: volume.ratio ?? "unavailable", spreadBps: micro?.spreadBps ?? "unavailable", spreadCostOn1000: micro?.oneWaySpreadCostOn1000 ?? "unavailable", orderBookImbalance: micro?.imbalance ?? "unavailable", candleMomentumPct: micro?.momentumPct ?? "unavailable", shortTermRealizedVolPct: micro?.realizedVolPct ?? "unavailable" }, "market-neutral",
    [sync.mode === "live-read-only" ? "Coinbase public-market snapshots may be delayed/cached and are not private-account data." : "Market and synthetic order-book data are seeded demo data; no live Coinbase response was available.", "Displayed book depth is limited to the returned snapshot and can disappear; spread and imbalance are descriptive only."],
    [{ toolId: "coinbase-public-markets", source: sourceName, status: sync.unavailableProducts.length ? "partial" : "success", retrievedAt: sync.asOf, reference: marketRefs.join(",") }, { toolId: "public-order-book", source: context.bookSource, status: context.bookSource === "unavailable" ? "unavailable" : "success", retrievedAt: context.bookAsOf, reference: context.microstructureProductId }],
    [ { name: "market-product-source", status: sync.markets.length ? "passed" : "failed", detail: `${sync.markets.length} normalized product(s); mode=${sync.mode}.` }, { name: "candle-coverage", status: dataQualityFindings.length ? "failed" : "passed", detail: dataQualityFindings.join(" ") || "No gaps/stale intervals detected by configured checks." }, { name: "order-book-source", status: context.bookSource === "unavailable" ? "not-run" : "passed", detail: `${context.bookSource} book snapshot; depth only includes returned levels.` }]);
}

export async function quantitativeResearch(taskId: string, supplied?: AgentMarketContext): Promise<AgentFinding> {
  const context = supplied || await loadAgentMarketContext();
  const sync = context.sync;
  const productSet = sync.markets.length ? sync.markets : markets;
  const btc = productSet.find((market) => market.productId === "BTC-USD") || productSet[0];
  if (!btc) return makeFinding(taskId, "quant-research", "Quantitative research inputs unavailable", ["No historical candle series was available."], [], ["market-data:empty"], ["Historical inputs unavailable"], 0.2, undefined, undefined, "risk-flagged");
  const closes = btc.candles.map((candle) => candle.close);
  const vol = classifyMarketRegime(btc, sync.intervalMs).annualVolPct;
  const drawdown = maxDrawdown(closes);
  const sma7 = movingAverage(closes, 7).at(-1) || 0; const sma20 = movingAverage(closes, 20).at(-1) || 0;
  const returns = simpleReturns(closes);
  const rolling = rollingVolatilityPct(closes, Math.min(20, Math.max(2, closes.length - 1)));
  const backtest = compareSmaToBuyHold(closes, { fast: 3, slow: 8, costBpsPerTurn: 10, periodsPerYear: sync.intervalMs > 0 ? (365.25 * 86400000) / sync.intervalMs : undefined });
  const correlations = marketCorrelationMatrix(productSet);
  const pValue = backtest.status === "calculated" ? backtest.approximateTwoSidedPValue : null;
  const sampleWarning = returns.length < 30 ? "Return sample has fewer than 30 observations; inference is exploratory and serial dependence weakens the test assumptions." : "Approximate paired test assumes more independent observations than financial returns may provide.";
  const findings = [
    `Historical candle analysis uses ${btc.productId}, ${btc.candles.length} ${sync.granularity} bars from ${btc.dataAsOf || sync.asOf}; no look-ahead is intended.`,
    `Sample annualized volatility ${vol === null ? "unavailable" : `${vol.toFixed(2)}%`}; maximum close-to-close drawdown ${drawdown.toFixed(2)}%.`,
    `SMA(7)/SMA(20) descriptive trend: ${sma7 > sma20 ? "short mean above long mean" : sma7 < sma20 ? "short mean below long mean" : "approximately equal"}; not a predictive guarantee.`,
    backtest.status === "calculated" ? `Illustrative SMA(3/8) backtest: ${backtest.strategyReturnPct.toFixed(2)}% vs buy-and-hold ${backtest.buyHoldReturnPct.toFixed(2)}% after assumed 10 bps per one-way signal change; max drawdowns ${backtest.strategyMaxDrawdownPct.toFixed(2)}% vs ${backtest.buyHoldMaxDrawdownPct.toFixed(2)}%.` : "Backtest withheld because the historical candle sample is too short.",
    backtest.status === "calculated" ? `Paired active-return test H0: mean active return=0; t=${backtest.pairedActiveReturnTStatistic?.toFixed(3) ?? "unavailable"}, approximate two-sided p=${pValue?.toFixed(4) ?? "unavailable"}; ${sampleWarning}` : "Hypothesis test not run without a valid strategy/benchmark return pair.",
    `Asset correlation matrix uses ${correlations.returnCount} timestamp-aligned return pairs across ${correlations.assets.length} products; insufficient pairs are null.`,
  ];
  const validationChecks = [
    { name: "backtest-sample", status: backtest.status === "calculated" ? "passed" as const : "not-run" as const, detail: `${backtest.observations} next-bar observations; signal uses close t and earns return t→t+1.` },
    { name: "transaction-cost-assumption", status: backtest.status === "calculated" ? "passed" as const : "not-run" as const, detail: "10 bps per one-way position transition, explicitly illustrative; no fees/slippage calibration." },
    { name: "historical-data-adequacy", status: returns.length >= 30 ? "passed" as const : "failed" as const, detail: `${returns.length} return observations; ${sampleWarning}` },
  ];
  const riskFlags = [ ...(sync.mode === "demo-fallback" ? ["Quantitative sample is synthetic demo data"] : []), ...(returns.length < 30 ? ["Statistical sample is small; do not infer significance or forecast skill"] : []), ...(backtest.status !== "calculated" ? ["Strategy backtest unavailable"] : []) ];
  return makeFinding(taskId, "quant-research", "Historical, statistical and comparative strategy analysis completed", findings,
    [`${btc.productId} RSI(14): ${rsi(closes).toFixed(2)}`, `ATR(14): $${atr(btc.candles).toFixed(2)}`, `Annualized realized volatility: ${vol?.toFixed(2) ?? "unavailable"}% (sample std log returns × sqrt(${((365.25 * 86400000) / sync.intervalMs).toFixed(2)} periods/year))`, `Maximum drawdown: ${drawdown.toFixed(2)}%`, `SMA(7): $${sma7.toFixed(2)} · SMA(20): $${sma20.toFixed(2)}`, `Latest rolling volatility (${rolling?.length ?? 0}-bar rolling output): ${rolling?.at(-1)?.toFixed(4) ?? "unavailable"}% per bar`, ...(backtest.status === "calculated" ? [`Backtest cumulative return ${backtest.strategyReturnPct.toFixed(3)}%; buy-and-hold ${backtest.buyHoldReturnPct.toFixed(3)}%; turnover cost ${backtest.costBpsPerTurn} bps`, `Annualized volatility ${backtest.annualizedVolatilityPct?.toFixed(2) ?? "unavailable"}%; Sharpe ${backtest.sharpeRatioZeroRiskFree?.toFixed(3) ?? "unavailable"} using explicit 0% effective annual risk-free assumption; p-value normal-tail approximation ${pValue?.toFixed(4) ?? "unavailable"}`] : []), `Correlation matrix assets: ${correlations.assets.join(", ")}; aligned candle observations=${correlations.alignedCandleCount}`],
    [`${btc.source === "coinbase-advanced-trade" ? "coinbase-advanced-trade" : "demo"}:markets:${btc.productId}:candles`], riskFlags, returns.length >= 30 ? 0.75 : 0.58,
    "Backtest performance, p-values and correlations are descriptive of the supplied sample and can be unstable under serial correlation, costs, and regime changes.",
    { annualizedVolatilityPct: vol ?? "unavailable", maxDrawdownPct: drawdown, candleReturnCount: returns.length, backtestObservations: backtest.observations, strategyReturnPct: backtest.status === "calculated" ? backtest.strategyReturnPct : "unavailable", buyHoldReturnPct: backtest.status === "calculated" ? backtest.buyHoldReturnPct : "unavailable", strategyMaxDrawdownPct: backtest.status === "calculated" ? backtest.strategyMaxDrawdownPct : "unavailable", sharpeRatioZeroRiskFree: backtest.status === "calculated" ? backtest.sharpeRatioZeroRiskFree ?? "unavailable" : "unavailable", pairedActiveReturnP: pValue ?? "unavailable", correlationAssetCount: correlations.assets.length }, "market-neutral",
    [sync.mode === "live-read-only" ? "Coinbase public candles are historical market observations, not private account or executable price data." : "Synthetic demo candles only; no live Coinbase data was returned.", "SMA(3/8) assumes close-derived signal is applied to the following close-to-close bar; 10 bps one-way costs are a simple scenario, not a Coinbase fee schedule.", "Sharpe uses an explicitly declared 0% risk-free assumption; p-values use a normal-tail approximation and are not robust to serial dependence or multiple testing."],
    [{ toolId: "historical-candles", source: sync.mode, status: sync.unavailableProducts.length ? "partial" : "success", retrievedAt: sync.asOf, reference: btc.productId }, { toolId: "strategy-backtest", source: "SMA(3/8)-versus-buy-and-hold", status: backtest.status === "calculated" ? "success" : "unavailable", retrievedAt: sync.asOf, reference: btc.productId }], validationChecks);
}

export function explainProposalRejection(reasons: string[]): string[] {
  return [...new Set(reasons.map((reason) => reason.trim()).filter(Boolean))].map((reason) => `Proposal held/rejected: ${reason}. This is the policy reason supplied by the proposal evaluator, not an independent market prediction.`);
}

export async function riskOfficer(
  taskId: string,
  prior: AgentFinding[],
  snapshot?: PortfolioSnapshot,
  marketContext?: AgentMarketContext,
  proposalRejectionReasons: string[] = [],
): Promise<AgentFinding> {
  const analyst = prior.find((finding) => finding.agentId === "portfolio-analyst");
  const metrics = analyst?.metrics || {};
  const largestAllocation = typeof metrics.largestAllocation === "number" ? metrics.largestAllocation : 0;
  const largestAsset = typeof metrics.largestAsset === "string" ? metrics.largestAsset : "unavailable";
  const portfolioSource = typeof metrics.portfolioSource === "string" ? metrics.portfolioSource : "unavailable";
  const partial = metrics.dataCoverage === "partial" || metrics.dataCoverage === "unknown" || portfolioSource === "unavailable" || snapshot?.coverage !== undefined && snapshot.coverage !== "complete";
  const repeatedConcentration = prior.some((finding) => finding.riskFlags.some((flag) => /concentration/i.test(flag)));
  const stanceConflict = new Set(prior.map((finding) => finding.stance).filter(Boolean)).size > 1;
  const quant = prior.find((finding) => finding.agentId === "quant-research");
  const drawdown = typeof quant?.metrics?.strategyMaxDrawdownPct === "number" ? quant.metrics.strategyMaxDrawdownPct : typeof quant?.metrics?.maxDrawdownPct === "number" ? quant.metrics.maxDrawdownPct : null;
  const holdings = snapshot?.positions.filter((position) => position.valueFiat !== null && position.valueFiat > 0) || [];
  const estimatedShockLoss = holdings.reduce((loss, position) => loss + (position.isCash ? 0 : position.valueFiat! * 0.1), 0);
  const spotSubtotal = holdings.reduce((total, position) => total + position.valueFiat!, 0);
  const shockPct = spotSubtotal > 0 ? estimatedShockLoss / spotSubtotal * 100 : null;
  const marketProducts = marketContext?.sync.markets || [];
  const correlations = marketCorrelationMatrix(marketProducts);
  const correlatedPairs: string[] = [];
  const heldAssets = new Set(holdings.map((position) => position.asset.toUpperCase()));
  for (let i = 0; i < correlations.assets.length; i += 1) for (let j = i + 1; j < correlations.assets.length; j += 1) {
    const corr = correlations.matrix[i]?.[j];
    const leftAsset = correlations.assets[i].replace(/-USD$/, "").toUpperCase();
    const rightAsset = correlations.assets[j].replace(/-USD$/, "").toUpperCase();
    if (heldAssets.has(leftAsset) && heldAssets.has(rightAsset) && corr !== null && corr !== undefined && corr >= 0.75) correlatedPairs.push(`${correlations.assets[i]} / ${correlations.assets[j]} (r=${corr.toFixed(2)})`);
  }
  const book = marketContext?.microstructure;
  const bookAsset = marketContext?.microstructureProductId?.replace(/-USD$/, "");
  const bookPosition = holdings.find((position) => position.asset.toUpperCase() === bookAsset?.toUpperCase());
  const depthCoverage = book && bookPosition?.valueFiat && bookPosition.valueFiat > 0 ? Math.min(1, book.bidDepthUsd / bookPosition.valueFiat) * 100 : null;
  const marketQuality = marketProducts.flatMap((market) => [ ...(market.dataQuality?.missingCandles ? [`${market.productId} has ${market.dataQuality.missingCandles} candle gap(s)`] : []), ...(market.status && market.status.toLowerCase() !== "online" ? [`${market.productId} status is ${market.status}`] : []) ]);
  const proposalExplanations = explainProposalRejection(proposalRejectionReasons);
  const partialFindings = [...(snapshot?.missingData || []), ...marketQuality];
  const flags = [
    ...(largestAllocation > 0.65 ? ["Concentration warrants human review"] : []),
    ...(partial ? ["Portfolio inputs are incomplete or unavailable"] : []),
    ...(repeatedConcentration ? ["Concentration risk appears across independent findings"] : []),
    ...(shockPct !== null && shockPct >= 10 ? ["Illustrative portfolio stress loss exceeds 10% of reported spot subtotal"] : []),
    ...(correlatedPairs.length ? ["Highly correlated market exposures may amplify a common shock"] : []),
    ...(partialFindings.length ? ["Market or portfolio source-data quality requires challenge"] : []),
    ...(drawdown !== null && drawdown >= 20 ? ["Strategy/sample drawdown exceeds 20%"] : []),
    ...(depthCoverage !== null && depthCoverage < 10 ? ["Visible top-book bid depth covers less than 10% of the largest matched position"] : []),
    ...proposalRejectionReasons.map((reason) => `Proposal policy rejection: ${reason}`),
    "No automated trade or portfolio transfer is authorized",
    ...(stanceConflict ? ["Specialist stances differ; preserve dissent for human review"] : []),
  ];
  const marketFinding = prior.find((finding) => finding.agentId === "market-intelligence");
  const sourceNote = `${portfolioSource === "demo" ? "Synthetic demo portfolio" : portfolioSource === "unavailable" ? "Unavailable configured portfolio" : "Read-only Coinbase portfolio"}; ${marketFinding?.summary || "market evidence not available"}.`;
  const details = [
    largestAllocation > 0 ? `${largestAsset} is the largest measured exposure at ${(largestAllocation * 100).toFixed(1)}%.` : "No complete portfolio position was available for concentration measurement.",
    snapshot && spotSubtotal > 0 ? `Illustrative parallel −10% mark shock to all reported non-cash spot positions: estimated loss ${snapshot.currency} ${estimatedShockLoss.toFixed(2)} (${shockPct?.toFixed(2)}% of reported spot subtotal ${spotSubtotal.toFixed(2)}), before correlations, basis risk, gaps, fees, and liquidity.` : "Portfolio stress calculation unavailable because no positive reported spot subtotal is available.",
    correlatedPairs.length ? `Coinbase candle pairs with historical correlation ≥0.75: ${correlatedPairs.join("; ")}; correlation is sample-specific, not stable.` : "No sufficiently supported high-correlation pair identified from aligned historical candles; this does not establish diversification.",
    depthCoverage !== null ? `Liquidity stress: supplied ${marketContext?.microstructureProductId} bid-depth is ${depthCoverage.toFixed(2)}% of its reported position value at this snapshot; only returned book levels, not executable liquidation capacity.` : "Liquidity stress coverage unavailable: no matching live book/position exposure; candles do not measure executable depth.",
    drawdown !== null ? `Quant Research sample/strategy maximum drawdown is ${drawdown.toFixed(2)}%; inspect the benchmark, sample length, and cost assumptions before use.` : "Strategy drawdown is unavailable or withheld by Quant Research.",
    partialFindings.length ? `Data-quality challenges: ${partialFindings.slice(0, 5).join("; ")}.` : "No explicit missing-data warnings were supplied; freshness/venue completeness remain bounded by source fields.",
    ...proposalExplanations,
    "No recommendation should be treated as an order, a return forecast, or an instruction to move funds.",
  ];
  return makeFinding(taskId, "risk-officer", "Adversarial portfolio, market, liquidity and proposal risk review completed", details,
    [`Largest reported allocation: ${(largestAllocation * 100).toFixed(1)}%`, `Static parallel stress loss: ${snapshot && spotSubtotal > 0 ? `${snapshot.currency} ${estimatedShockLoss.toFixed(2)} (${shockPct?.toFixed(2) ?? "—"}% of spot subtotal)` : "unavailable"}`, `Historical high-correlation held pairs (threshold 0.75): ${correlatedPairs.join(", ") || "none identified"}`, `Visible bid depth coverage of matched holding: ${depthCoverage?.toFixed(2) ?? "unavailable"}%`, `Quant/sample max drawdown: ${drawdown?.toFixed(2) ?? "unavailable"}%`, "Automated live execution is disabled; portfolio transfers are not part of this workflow.", sourceNote],
    [...(analyst?.evidenceRefs || []), ...(marketFinding?.evidenceRefs || []), "security:live-execution-disabled", "security:no-portfolio-transfers"], flags, 0.93,
    "Market and strategy statistics do not neutralize concentration, liquidity, correlation, data-quality, or suitability concerns.",
    { shockLossPctOfReportedValue: shockPct ?? "unavailable", highCorrelationPairCount: correlatedPairs.length, matchedBookDepthCoveragePct: depthCoverage ?? "unavailable", strategyMaxDrawdownPct: drawdown ?? "unavailable", proposalRejectionReasonCount: proposalRejectionReasons.length }, "risk-flagged",
    ["The parallel 10% shock is static, excludes covariance/contagion and is not a prediction.", "Order-book depth is point-in-time, partial, and not a guarantee of executable fills.", "Portfolio comparison only includes explicitly authorized contexts and observed spot positions.", "This review is not investment advice and does not authorize execution."],
    [{ toolId: "portfolio-stress-engine", source: snapshot ? `snapshot:${snapshot.snapshotId}` : "portfolio-finding-only", status: snapshot && snapshot.coverage === "complete" ? "success" : "partial", retrievedAt: snapshot?.asOf, reference: snapshot?.snapshotId }, { toolId: "historical-correlation", source: marketContext?.sync.mode || "unavailable", status: marketProducts.length > 1 ? "success" : "partial", retrievedAt: marketContext?.sync.asOf }, { toolId: "order-book-liquidity-challenge", source: marketContext?.bookSource || "unavailable", status: book ? "success" : "unavailable", retrievedAt: marketContext?.bookAsOf }],
    [{ name: "stress-scenario", status: snapshot && spotSubtotal > 0 ? "passed" : "not-run", detail: "Static parallel −10% stress applied only to non-cash spot positions; denominator is reported spot subtotal." }, { name: "liquidity-depth", status: depthCoverage === null ? "not-run" : depthCoverage >= 10 ? "passed" : "failed", detail: depthCoverage === null ? "Matched order-book depth/position data unavailable." : `Returned bid depth covers ${depthCoverage.toFixed(2)}% of matched position value.` }, { name: "data-quality-challenge", status: partialFindings.length ? "failed" : "passed", detail: partialFindings.join("; ") || "No missing-data flags supplied." }]);
}

function independentValueCents(quantity: string, price: string): bigint {
  const scale = 100_000_000n;
  const parse = (value: string) => { const [whole, fraction = ""] = value.split("."); if (!/^\d+(?:\.\d{1,8})?$/.test(value)) throw new Error("Malformed demo decimal"); return BigInt(whole) * scale + BigInt((fraction + "0".repeat(8)).slice(0, 8)); };
  const qtyUnits = parse(quantity); const priceCents = (parse(price) * 100n + scale / 2n) / scale;
  return (qtyUnits * priceCents + scale / 2n) / scale;
}

export interface AgentVerificationContext {
  marketContext?: AgentMarketContext;
  auditTrail?: import("@/models/domain").AgentAuditTrailEntry[];
}

function independentlyRecomputeSmaStrategyReturn(closes: number[], fast = 3, slow = 8, oneWayCostBps = 10): number | null {
  if (closes.length <= slow + 1 || closes.some((price) => !Number.isFinite(price) || price <= 0)) return null;
  const average = (end: number, width: number) => {
    let total = 0;
    for (let index = end - width + 1; index <= end; index += 1) total += closes[index];
    return total / width;
  };
  let wealth = 1;
  let previousSignal = 0;
  for (let index = slow - 1; index < closes.length - 1; index += 1) {
    const signal = average(index, fast) > average(index, slow) ? 1 : 0;
    const nextBarReturn = closes[index + 1] / closes[index] - 1;
    const transitionCost = Math.abs(signal - previousSignal) * oneWayCostBps / 10_000;
    wealth *= 1 + signal * nextBarReturn - transitionCost;
    previousSignal = signal;
  }
  return (wealth - 1) * 100;
}

export async function verificationAgent(taskId: string, prior: AgentFinding[], snapshot?: PortfolioSnapshot, context: AgentVerificationContext = {}): Promise<AgentFinding> {
  const analyst = prior.find((finding) => finding.agentId === "portfolio-analyst");
  const source = typeof analyst?.metrics?.portfolioSource === "string" ? analyst.metrics.portfolioSource : typeof analyst?.metrics?.portfolioValueCents === "number" ? "demo" : "unavailable";
  const claimed = analyst?.metrics?.portfolioValueCents;
  let independentlyVerifiedCents: number | undefined; let claimedCents: number | undefined; let consistent: boolean | undefined;
  let verificationDescription: string; let claimedDescription: string;
  if (source === "unavailable" || typeof claimed !== "number") {
    verificationDescription = "Portfolio arithmetic verification was skipped because no numeric portfolio-value claim was made."; claimedDescription = "Portfolio analyst claim: unavailable";
  } else if (source === "demo") {
    const totalCents = balances.reduce((sum, item) => sum + independentValueCents(item.quantity, item.price), 0n);
    independentlyVerifiedCents = Number(totalCents); claimedCents = claimed; consistent = BigInt(claimed) === totalCents;
    verificationDescription = consistent ? "Independent BigInt recalculation of seeded balances matches the Portfolio Analyst claim." : "Recalculated demo portfolio value does not match the analyst claim; review the arithmetic.";
    claimedDescription = `Portfolio analyst claim: $${(claimed / 100).toLocaleString("en-US", { minimumFractionDigits: 2 })}`;
  } else {
    const claimedSpot = analyst?.metrics?.spotPositionValueCents;
    if (snapshot && typeof claimedSpot === "number") {
      const spotCents = snapshot.positions.reduce((sum, position) => sum + (position.valueFiat === null ? 0n : BigInt(Math.round(position.valueFiat * 100))), 0n);
      independentlyVerifiedCents = Number(spotCents); claimedCents = claimedSpot; consistent = BigInt(claimedSpot) === spotCents;
      verificationDescription = consistent ? "Independent arithmetic sum of reported Coinbase spot values matches the Portfolio Analyst subtotal." : "Recalculated Coinbase spot subtotal does not match the analyst claim.";
      claimedDescription = `Coinbase total ${claimed / 100}; spot subtotal ${claimedSpot / 100}.`;
    } else { verificationDescription = "Coinbase-reported total is not independently verifiable without a normalized spot snapshot."; claimedDescription = `Coinbase-reported portfolio value: $${(claimed / 100).toLocaleString("en-US", { minimumFractionDigits: 2 })}`; }
  }
  const requiredAgentIds = ["portfolio-analyst", "market-intelligence", "quant-research", "risk-officer"];
  const counts = new Map<string, number>(); for (const finding of prior) counts.set(finding.agentId, (counts.get(finding.agentId) || 0) + 1);
  const missingAgents = requiredAgentIds.filter((id) => counts.get(id) !== 1);
  const foreignTask = prior.filter((finding) => finding.taskId !== taskId);
  const noEvidence = prior.filter((finding) => finding.evidenceRefs.length === 0);
  const unsupportedClaims = prior.flatMap((finding) => [finding.summary, ...finding.findings, ...finding.calculations].filter((text) => /\b(guaranteed returns?|certain to rise|will definitely (rise|fall)|risk[- ]free profit|predicts? the price)\b/i.test(text)).map((text) => `${finding.agentId}: ${text}`));
  const snapshotValid = snapshot ? Number.isFinite(Date.parse(snapshot.asOf)) && snapshot.positions.every((position) => (position.valueFiat === null || Number.isFinite(position.valueFiat)) && (position.quantity === null || Number.isFinite(position.quantity))) : true;
  const market = context.marketContext;
  const candleRows = market?.sync.markets.flatMap((item) => item.candles) || [];
  const marketDataValid = Boolean(market?.sync.markets.length) && market!.sync.markets.every((product) => product.candles.length > 0 && product.candles.every((candle, index) => {
    const time = Date.parse(candle.time);
    const ordered = index === 0 || Date.parse(product.candles[index - 1].time) < time;
    return Number.isFinite(time) && ordered && Number.isFinite(candle.open) && Number.isFinite(candle.close) && Number.isFinite(candle.high) && Number.isFinite(candle.low) && candle.high >= candle.low && candle.open >= candle.low && candle.open <= candle.high && candle.close >= candle.low && candle.close <= candle.high && Number.isFinite(candle.volume) && candle.volume >= 0;
  }));
  const quant = prior.find((finding) => finding.agentId === "quant-research");
  let strategyCrossCheck: boolean | undefined;
  const btc = market?.sync.markets.find((item) => item.productId === "BTC-USD") || market?.sync.markets[0];
  if (btc && typeof quant?.metrics?.strategyReturnPct === "number") {
    const recomputed = independentlyRecomputeSmaStrategyReturn(btc.candles.map((candle) => candle.close));
    strategyCrossCheck = recomputed !== null && Math.abs(recomputed - quant.metrics.strategyReturnPct) < 1e-8;
  }
  const requiredAudit = ["portfolio-context-read", "market-data-read", "portfolio-analyst-complete", "market-intelligence-complete", "quant-research-complete", "risk-review-complete"];
  const auditEvents = context.auditTrail || [];
  const missingAudit = requiredAudit.filter((action) => {
    const matches = auditEvents.filter((event) => event.action === action);
    return matches.length !== 1 || !Number.isFinite(Date.parse(matches[0]?.recordedAt || "")) || matches[0]?.references.length === 0;
  });
  const checks: AgentValidationCheck[] = [
    { name: "portfolio-arithmetic", status: consistent === undefined ? "not-run" : consistent ? "passed" : "failed", detail: verificationDescription },
    { name: "agent-output-contract", status: missingAgents.length || foreignTask.length ? "failed" : "passed", detail: `Missing/duplicate required outputs: ${missingAgents.join(",") || "none"}; foreign-task outputs=${foreignTask.length}.` },
    { name: "source-evidence-coverage", status: noEvidence.length ? "failed" : "passed", detail: `Findings without source references=${noEvidence.length}.` },
    { name: "portfolio-source-data", status: snapshot ? snapshotValid ? "passed" : "failed" : "not-run", detail: snapshot ? `Snapshot ${snapshot.snapshotId} timestamp/position values checked.` : "No normalized snapshot supplied; portfolio source verification limited." },
    { name: "market-candle-source-data", status: market ? marketDataValid ? "passed" : "failed" : "not-run", detail: `${candleRows.length} candle(s) checked for timestamps, OHLC bounds, and non-negative volume.` },
    { name: "strategy-calculation", status: strategyCrossCheck === undefined ? "not-run" : strategyCrossCheck ? "passed" : "failed", detail: strategyCrossCheck === undefined ? "No comparable strategy return claim/data supplied." : "Re-ran SMA(3/8) next-bar backtest and cost assumption independently." },
    { name: "unsupported-certainty-claims", status: unsupportedClaims.length ? "failed" : "passed", detail: unsupportedClaims.length ? unsupportedClaims.join("; ") : "No unsupported guaranteed/absolute price claims detected by the narrow claim scanner." },
    { name: "audit-event-completeness", status: missingAudit.length ? "failed" : "passed", detail: missingAudit.length ? `Required audit actions missing: ${missingAudit.join(", ")}.` : `${requiredAudit.length} workflow read/research/risk events present.` },
  ];
  const failed = checks.filter((check) => check.status === "failed");
  const riskFlags = failed.map((check) => `${check.name} failed${check.name === "unsupported-certainty-claims" ? "" : ""}`);
  if (failed.length && !riskFlags.includes("Numerical verification failed") && checks.some((check) => check.name === "portfolio-arithmetic" && check.status === "failed")) riskFlags.push("Numerical verification failed");
  const evidenceRefs = [ ...(snapshot && snapshot.provider !== "demo" ? [`coinbase:portfolio-snapshot:${snapshot.snapshotId}`] : source === "demo" ? ["demo:portfolio:balances"] : []), ...(market ? [`market-sync:${market.sync.mode}:${market.sync.asOf}`] : []), "agent-findings:all", ...(context.auditTrail || []).map((event) => `audit:${event.action}`) ];
  return makeFinding(taskId, "verification-audit", failed.length ? "Independent verification found claims requiring correction or review" : "Independent numerical, source, output-consistency and audit review complete",
    [verificationDescription, `Output contract: ${missingAgents.length ? `missing/duplicated ${missingAgents.join(", ")}` : "all four upstream specialist outputs present exactly once"}.`, `Source checks: portfolio ${snapshotValid ? "valid or unavailable" : "invalid"}; market candles ${marketDataValid ? "valid" : "invalid"}.`, `Strategy recalculation: ${strategyCrossCheck === undefined ? "not applicable" : strategyCrossCheck ? "matched" : "mismatch"}.`, `Unsupported absolute-price claims: ${unsupportedClaims.length ? unsupportedClaims.join("; ") : "none detected"}.`, `Audit trail: ${requiredAudit.length - missingAudit.length}/${requiredAudit.length} required events present.`, source === "demo" ? "Demo provenance remains explicit; no live account access is asserted." : "Live-source claims are limited to the returned read-only snapshot and public market response."],
    [`Independent portfolio check: ${independentlyVerifiedCents === undefined ? "not available" : `$${(independentlyVerifiedCents / 100).toLocaleString("en-US", { minimumFractionDigits: 2 })}`}`, claimedDescription, ...checks.map((check) => `${check.name}: ${check.status} — ${check.detail}`)], evidenceRefs, riskFlags, failed.length ? 0.78 : 0.99, failed.length ? "Hold the summary until failed source, strategy, output, claim, or audit checks are addressed." : undefined,
    { independentlyVerifiedCents: independentlyVerifiedCents ?? "unavailable", claimedCents: claimedCents ?? "unavailable", validationChecksPassed: checks.filter((check) => check.status === "passed").length, validationChecksFailed: failed.length, missingAuditEvents: missingAudit.length, unsupportedClaimCount: unsupportedClaims.length, ...(strategyCrossCheck === undefined ? {} : { strategyCalculationMatched: strategyCrossCheck ? 1 : 0 }) }, failed.length ? "verification-fail" : "verification-pass",
    ["Numerical re-summing does not independently validate Coinbase valuations, completeness, cost-basis provenance, or custody.", "Source validation checks schema and observed timestamps, not authenticity of remote APIs.", "Unsupported-claim detection is a narrow rule-based scan and cannot establish truth of all prose."],
    [{ toolId: "independent-verifier", source: "agent-output-and-source-contracts", status: failed.length ? "partial" : "success", reference: evidenceRefs.join(",") }], checks);
}
