export interface AgentAuthorization {
  authorizationId: string; agentId: string; accountId: string; permissions: string[]; allowedNetworks: number[]; allowedContracts: string[]; allowedAssets: string[]; allowedRecipients: string[];
  maximumOperationValue: string; dailyBudget: string; expiresAt: string; requiresUserApproval: boolean; status: "active" | "expired" | "revoked" | "suspended";
}
export interface SpendRequest { idempotencyKey: string; authorizationId: string; operation: string; chainId: number; asset: string; contract: string; recipient: string; amount: string; userApproved: boolean }
export interface SpendReservation { idempotencyKey: string; authorizationId: string; operation: string; chainId: number; asset: string; contract: string; recipient: string; amount: string; status: "reserved" | "settled" | "released"; createdAt: string; settledAmount?: string; settledAt?: string; transactionHash?: string }
const addr = (s: string) => /^0x[0-9a-fA-F]{40}$/.test(s);
const uint = (s: string) => { if (!/^\d+$/.test(s)) throw new Error("Spend amounts must be non-negative integer base units."); return BigInt(s); };
export class SpendingLedger {
  private readonly policies = new Map<string, AgentAuthorization>();
  private readonly reservations = new Map<string, SpendReservation>();
  private readonly events: Array<{ id: string; type: string; authorizationId: string; reservationKey?: string; at: string; detail: string }> = [];
  register(policy: AgentAuthorization): void {
    if (!policy.authorizationId || !policy.agentId || !policy.accountId) throw new Error("Authorization identifiers are required.");
    uint(policy.maximumOperationValue); uint(policy.dailyBudget);
    if (policy.allowedNetworks.length !== 1 || policy.allowedNetworks.some((id) => !Number.isSafeInteger(id) || id <= 0) || policy.allowedAssets.length !== 1 || !policy.permissions.length) throw new Error("Each authorization must scope one chain and one asset so base-unit limits remain comparable; create separate authorizations for other scopes.");
    if ([...policy.allowedContracts, ...policy.allowedAssets, ...policy.allowedRecipients].some((address) => !addr(address))) throw new Error("All authorization allowlist entries must be valid EVM addresses.");
    if (!Number.isFinite(Date.parse(policy.expiresAt))) throw new Error("Authorization expiry must be an ISO-compatible date.");
    if (this.policies.has(policy.authorizationId)) throw new Error("Authorization ID already exists.");
    this.policies.set(policy.authorizationId, structuredClone(policy));
    this.event("AUTHORIZATION_REGISTERED", policy.authorizationId, undefined, "Application policy registered; this is not an on-chain delegation.");
  }
  reserve(request: SpendRequest, now = new Date()): SpendReservation {
    const prior = this.reservations.get(request.idempotencyKey);
    if (prior) {
      if (prior.authorizationId !== request.authorizationId || prior.operation !== request.operation || prior.amount !== request.amount || prior.chainId !== request.chainId || prior.asset.toLowerCase() !== request.asset.toLowerCase() || prior.contract.toLowerCase() !== request.contract.toLowerCase() || prior.recipient.toLowerCase() !== request.recipient.toLowerCase()) throw new Error("Idempotency key is bound to different spending parameters.");
      return structuredClone(prior);
    }
    const p = this.policies.get(request.authorizationId); if (!p) throw new Error("Authorization not found.");
    const amount = uint(request.amount);
    if (amount === 0n) throw new Error("Spend amount must be greater than zero.");
    if (p.status !== "active" || Date.parse(p.expiresAt) <= now.getTime()) throw new Error("Authorization is inactive or expired.");
    if (!addr(request.asset) || !addr(request.contract) || !addr(request.recipient)) throw new Error("Asset, contract, and recipient must be valid EVM addresses.");
    if (!p.allowedNetworks.includes(request.chainId)) throw new Error("Network is outside the authorization scope.");
    if (!p.permissions.includes(request.operation)) throw new Error("Operation is outside the authorization scope.");
    if (!p.allowedAssets.some((v) => v.toLowerCase() === request.asset.toLowerCase())) throw new Error("Asset is outside the authorization scope.");
    if (!p.allowedContracts.some((v) => v.toLowerCase() === request.contract.toLowerCase())) throw new Error("Contract is outside the authorization scope.");
    if (!p.allowedRecipients.some((v) => v.toLowerCase() === request.recipient.toLowerCase())) throw new Error("Recipient is outside the authorization scope.");
    if (amount > uint(p.maximumOperationValue)) throw new Error("Operation amount exceeds the per-operation limit.");
    if (p.requiresUserApproval && !request.userApproved) throw new Error("Fresh user approval is required for this operation.");
    const pending = [...this.reservations.values()].filter((r) => r.authorizationId === p.authorizationId && r.chainId === request.chainId && r.asset.toLowerCase() === request.asset.toLowerCase() && r.status === "reserved").reduce((sum, r) => sum + BigInt(r.amount), 0n);
    const midnightUtc = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
    const spentToday = [...this.reservations.values()].filter((r) => r.authorizationId === p.authorizationId && r.chainId === request.chainId && r.asset.toLowerCase() === request.asset.toLowerCase() && r.status === "settled" && r.settledAt && Date.parse(r.settledAt) >= midnightUtc).reduce((sum, r) => sum + BigInt(r.settledAmount ?? r.amount), 0n);
    if (spentToday + pending + amount > uint(p.dailyBudget)) throw new Error("Request exceeds the daily budget after outstanding reservations.");
    const reservation: SpendReservation = { idempotencyKey: request.idempotencyKey, authorizationId: p.authorizationId, operation: request.operation, chainId: request.chainId, asset: request.asset.toLowerCase(), contract: request.contract.toLowerCase(), recipient: request.recipient.toLowerCase(), amount: amount.toString(), status: "reserved", createdAt: now.toISOString() };
    this.reservations.set(request.idempotencyKey, reservation); this.event("SPEND_RESERVED", p.authorizationId, request.idempotencyKey, `Reserved ${amount} base units.`);
    return structuredClone(reservation);
  }
  settle(key: string, actualAmount: string, receipt: { verified: boolean; transactionHash: string }, now = new Date()): SpendReservation {
    const reservation = this.require(key, "reserved"); const actual = uint(actualAmount);
    if (!receipt.verified || !/^0x[0-9a-fA-F]{64}$/.test(receipt.transactionHash)) throw new Error("Only a verified transaction receipt can settle a reservation.");
    if (actual > BigInt(reservation.amount)) throw new Error("Actual spend exceeds reservation; settlement is blocked for reconciliation.");
    reservation.status = "settled"; reservation.settledAmount = actual.toString(); reservation.settledAt = now.toISOString(); reservation.transactionHash = receipt.transactionHash;
    this.event("SPEND_SETTLED", reservation.authorizationId, key, `Receipt ${receipt.transactionHash} verified; settled ${actual} base units.`);
    return structuredClone(reservation);
  }
  release(key: string, reason: string): SpendReservation { const item = this.require(key, "reserved"); if (!reason.trim()) throw new Error("Release requires an audit reason."); item.status = "released"; this.event("SPEND_RELEASED", item.authorizationId, key, reason); return structuredClone(item); }
  revoke(authorizationId: string, reason: string): AgentAuthorization { const p = this.policies.get(authorizationId); if (!p) throw new Error("Authorization not found."); if (!reason.trim()) throw new Error("Revocation requires a reason."); p.status = "revoked"; this.event("AUTHORIZATION_REVOKED", authorizationId, undefined, `${reason} Off-chain application permission only; on-chain delegation revocation is separate.`); return structuredClone(p); }
  getReservation(key: string): SpendReservation | undefined { const item = this.reservations.get(key); return item ? structuredClone(item) : undefined; }
  history(): ReadonlyArray<{ id: string; type: string; authorizationId: string; reservationKey?: string; at: string; detail: string }> { return this.events.map((event) => ({ ...event })); }
  private require(key: string, status: SpendReservation["status"]): SpendReservation { const item = this.reservations.get(key); if (!item || item.status !== status) throw new Error("Reservation not found or already finalized."); return item; }
  private event(type: string, authorizationId: string, reservationKey: string | undefined, detail: string) { this.events.push({ id: `spend:${this.events.length + 1}`, type, authorizationId, reservationKey, at: new Date().toISOString(), detail }); }
}
