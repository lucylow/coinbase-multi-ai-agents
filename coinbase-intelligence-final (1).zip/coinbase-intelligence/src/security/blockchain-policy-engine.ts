import { isAllowedChainId } from "@/integrations/base/base-network-config";

export type BlockchainOperation = "REGISTER_AGENT" | "UPDATE_AGENT" | "REGISTER_RESEARCH" | "VERIFY_RESEARCH" | "READ_CONTRACT";
export type BlockchainActionIntent = { id: string; taskId: string; network: "base-sepolia"; chainId: 84532; operation: BlockchainOperation; targetContract: string; functionName: string; encodedCallData: `0x${string}`; proposedBy: string; supportingAgents: string[]; requiresApproval: boolean; status: "proposed" | "validated" | "simulated" | "awaiting_approval" | "submitted" | "confirmed" | "failed" };

const WRITE_OPERATIONS = new Set<BlockchainOperation>(["REGISTER_AGENT", "UPDATE_AGENT", "REGISTER_RESEARCH"]);
const WRITE_KILL_SWITCH = process.env.BLOCKCHAIN_WRITE_KILL_SWITCH !== "false";
export function blockchainWritesEnabled(): boolean { return !WRITE_KILL_SWITCH; }
export function validateBlockchainIntent(intent: BlockchainActionIntent): { ok: true } | { ok: false; reason: string } {
  if (!intent.id || !intent.taskId || !intent.targetContract) return { ok: false, reason: "Intent is missing required identifiers." };
  if (!isAllowedChainId(intent.chainId, WRITE_OPERATIONS.has(intent.operation))) return { ok: false, reason: "Only Base Sepolia is allowed for writes." };
  if (!/^0x[0-9a-fA-F]{40}$/.test(intent.targetContract)) return { ok: false, reason: "Target contract must be a valid EVM address." };
  if (!/^0x[0-9a-fA-F]*$/.test(intent.encodedCallData)) return { ok: false, reason: "Call data must be hex encoded." };
  if (WRITE_OPERATIONS.has(intent.operation) && WRITE_KILL_SWITCH) return { ok: false, reason: "Blockchain write kill switch is active; read-only mode is enforced." };
  if (WRITE_OPERATIONS.has(intent.operation) && !intent.requiresApproval) return { ok: false, reason: "Every blockchain write requires explicit approval." };
  return { ok: true };
}
