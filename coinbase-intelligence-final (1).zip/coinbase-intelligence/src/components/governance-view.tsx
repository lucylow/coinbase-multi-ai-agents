"use client";

import { useEffect, useState } from "react";
import { Clock3, Shield, UsersRound } from "lucide-react";

type GovernanceStatus = {
  mode: string;
  enabled: boolean;
  chain: { name: string; expectedChainId: number; configuredChainId: number | null; verified: boolean };
  controller: { status: string; address: string | null };
  timelock: { status: string; address: string | null };
  council: { signerCount: number | null; standardThreshold: number | null; criticalThreshold: number | null; signerSetVersion: number | null; source: string };
  proposals: { pending: number | null; approved: number | null; queued: number | null; executable: number | null; executed: number | null; source: string };
  execution: { mainnetWritesEnabled: boolean; testnetWritesEnabled: boolean; submissionsEnabled: boolean };
  readiness: string;
  notice: string;
};

export function GovernanceView() {
  const [status, setStatus] = useState<GovernanceStatus | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    let cancelled = false;
    void fetch("/api/governance/status").then(async (response) => {
      if (!response.ok) throw new Error("Governance status is unavailable.");
      return response.json();
    }).then((payload) => { if (!cancelled && payload.ok) setStatus(payload.data); }).catch((caught) => {
      if (!cancelled) setError(caught instanceof Error ? caught.message : "Governance status is unavailable.");
    });
    return () => { cancelled = true; };
  }, []);

  const metric = (value: unknown) => value === null || value === undefined ? "Not read" : String(value);
  return <div className="section-content governance-center">
    <div className="section-title"><div><div className="eyebrow">PHASE 10 · GOVERNANCE INFRASTRUCTURE</div><h1>Onchain Governance Center</h1><p>Human council authorization, exact-action proposals, and delayed configuration changes. AI analysis is advisory only.</p></div><span className="status-pill">READ ONLY</span></div>
    <div className="governance-banner"><Shield size={18}/><div><b>Governance submissions are disabled</b><span>No proposal, signature, timelock, or execution action is exposed until contract deployment, role wiring, and chain-state verification are complete.</span></div><span>{status?.mode.toUpperCase() ?? "DEMO"}</span></div>
    {error && <div className="agentkit-error" role="alert">{error}</div>}
    <div className="governance-cards">
      <article><UsersRound size={16}/><span>Council</span><b>{metric(status?.council.signerCount)}</b><small>threshold: {metric(status?.council.standardThreshold)} / critical: {metric(status?.council.criticalThreshold)}</small></article>
      <article><Shield size={16}/><span>Governor</span><b>{status?.controller.status ?? "Loading"}</b><small>{status?.controller.address ?? "No verified address"}</small></article>
      <article><Clock3 size={16}/><span>Timelock</span><b>{status?.timelock.status ?? "Loading"}</b><small>{status?.timelock.address ?? "No verified address"}</small></article>
      <article><Clock3 size={16}/><span>Base Sepolia</span><b>{status?.chain.verified ? "Verified" : "Unverified"}</b><small>Expected chain ID 84532 · configured {metric(status?.chain.configuredChainId)}</small></article>
    </div>
    <div className="governance-columns">
      <section className="panel"><h2>Proposal activity</h2><p>Counts are sourced from chain state only when a verified reader is configured.</p><div className="governance-counts">{Object.entries(status?.proposals ?? { pending: null, approved: null, queued: null, executable: null, executed: null }).map(([key,value]) => <div key={key}><span>{key}</span><b>{metric(value)}</b></div>)}</div></section>
      <section className="panel"><h2>Governance lifecycle</h2><ol><li>Proposal binds a human-readable description to exact target, selector, and payload hash.</li><li>Distinct active human-controlled signers approve with direct calls or EIP-712 signatures checked by the contract.</li><li>Only allowlisted zero-value configuration actions can be queued through OpenZeppelin TimelockController.</li><li>Execution waits for the greater of the risk-tier delay and timelock minimum delay.</li></ol></section>
    </div>
    <p className="governance-notice">{status?.notice ?? "Loading status…"} This interface does not infer signer identities or count agent votes as council approvals.</p>
  </div>;
}
