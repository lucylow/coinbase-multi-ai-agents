"use client";

import { useEffect, useState } from "react";
import { Activity, AlertTriangle, CheckCircle2, CircleHelp, RefreshCw, XCircle } from "lucide-react";

type Capability = {
  id: string;
  configured: boolean;
  available: boolean | null;
  authenticated: boolean | null;
  lastCheckedAt: string | null;
  responseLatencyMs: number | null;
  lastSuccessfulCheckAt: string | null;
  lastError: string | null;
  requiredConfiguration: string[];
  supportedOperations: string[];
  accessMode: "read-only" | "write-capable";
  note?: string;
};
type Health = {
  environment: { mode: string; defaulted: boolean; productionReadOnlyOptIn: boolean; tradingEnabled: false; warning: string | null };
  checkedAt: string;
  capabilities: Record<string, Capability>;
};
const labels: Record<string, string> = {
  advancedTradeRead: "Advanced Trade account reads",
  marketData: "Advanced Trade public market data",
  websocket: "Public market WebSocket",
  mcp: "Coinbase MCP",
  cdpWallet: "CDP / Coinbase Wallet",
  baseRpc: "Base Sepolia RPC",
  policyEngine: "CDP Policy Engine",
  spendPermissions: "Spend permission validation",
  x402Payments: "x402 payments",
};
function truth(value: boolean | null) {
  if (value === null) return "Not verified";
  return value ? "Yes" : "No";
}
function StateIcon({ value }: { value: boolean | null }) {
  if (value === null) return <CircleHelp size={15} />;
  return value ? <CheckCircle2 size={15} /> : <XCircle size={15} />;
}

export function IntegrationHealthView() {
  const [health, setHealth] = useState<Health | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    void fetch("/api/integrations/health", { cache: "no-store" }).then(async (response) => {
      if (!response.ok) throw new Error("Integration health is unavailable.");
      return response.json();
    }).then((payload) => {
      if (!cancelled && payload.ok) { setHealth(payload.data); setError(""); }
    }).catch((caught) => {
      if (!cancelled) setError(caught instanceof Error ? caught.message : "Integration health is unavailable.");
    }).finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, []);

  const entries = Object.values(health?.capabilities ?? {});
  return <div className="section-content integration-health-center">
    <div className="section-title"><div><div className="eyebrow">TECHNICAL PLATFORM · CAPABILITY HEALTH</div><h1>Integration Health Center</h1><p>Connection/configuration is separated from a successful live check and from authorization.</p></div><span className="status-pill">READ ONLY</span></div>
    <div className="integration-env-banner"><Activity size={18}/><div><b>Environment: {health?.environment.mode ?? "DEMO"}</b><span>Trading and financial writes are disabled in every environment mode.</span></div>{loading && <RefreshCw size={15} className="integration-spin"/>}</div>
    {health?.environment.warning && <div className="integration-warning"><AlertTriangle size={15}/>{health.environment.warning}</div>}
    {error && <div className="agentkit-error" role="alert">{error}</div>}
    <div className="integration-capability-grid">
      {entries.map((item) => <article className="integration-capability-card" key={item.id}>
        <div className="integration-capability-heading"><div><b>{labels[item.id] ?? item.id}</b><small>{item.accessMode.toUpperCase()}</small></div><span className={`integration-availability ${item.available === null ? "unknown" : item.available ? "healthy" : "offline"}`}><StateIcon value={item.available}/>{item.available === null ? "UNVERIFIED" : item.available ? "AVAILABLE" : "UNAVAILABLE"}</span></div>
        <div className="integration-facts"><span>Configured</span><b>{truth(item.configured)}</b><span>Authenticated</span><b>{truth(item.authenticated)}</b><span>Last live check</span><b>{item.lastCheckedAt ? new Date(item.lastCheckedAt).toLocaleTimeString() : "Not probed"}</b><span>Latency</span><b>{item.responseLatencyMs === null ? "Not measured" : `${item.responseLatencyMs} ms`}</b><span>Last success</span><b>{item.lastSuccessfulCheckAt ? new Date(item.lastSuccessfulCheckAt).toLocaleTimeString() : "None recorded"}</b></div>
        {item.lastError && <p className="integration-error">{item.lastError}</p>}
        {item.note && <p className="integration-note">{item.note}</p>}
        {item.supportedOperations.length > 0 && <div className="integration-operations"><b>Operations</b><span>{item.supportedOperations.join(" · ")}</span></div>}
        {item.requiredConfiguration.length > 0 && <details><summary>Required configuration</summary><ul>{item.requiredConfiguration.map((required) => <li key={required}>{required}</li>)}</ul></details>}
      </article>)}
    </div>
    <p className="governance-notice">A configured endpoint or credential is not proof of authentication. This center performs only a public product metadata probe, a Base Sepolia chain-ID probe, and the existing MCP connection-status check. Account reads, signing, order submission, transfers, wallet execution, payments, and mainnet writes are not initiated here.{health?.checkedAt ? ` Checked ${new Date(health.checkedAt).toLocaleString()}; server probe results are cached for 30 seconds.` : ""}</p>
  </div>;
}
