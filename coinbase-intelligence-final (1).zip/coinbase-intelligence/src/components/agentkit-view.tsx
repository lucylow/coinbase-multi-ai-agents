"use client";

import { useEffect, useState } from "react";
import { Activity, AlertTriangle, Bot, LockKeyhole, ShieldCheck } from "lucide-react";

type Status = {
  agentKit: { status: string; message: string };
  walletProvider: { status: string; ownership: string; chainId: number | null };
  selectedNetwork: { name: string; chainId: number; liveWrites: boolean };
  actionProviders: { name: string; actions: string[] }[];
  capabilities: { agent: string; access: string; allowedActions: string[]; deniedActions: string[] }[];
  protocols: { name: string; status: string; marketCount: number | null }[];
  dataNotice: string;
  financialWritesEnabled: boolean;
};
type Proposal = { id: string; status: string; allocations: unknown[]; modeledYield: string | null; riskFlags: string[]; policyDecision: { reason: string } };

export function AgentKitView() {
  const [status, setStatus] = useState<Status | null>(null);
  const [proposal, setProposal] = useState<Proposal | null>(null);
  const [objective, setObjective] = useState("Analyze supported Base USDC lending opportunities and prepare a hypothetical allocation plan.");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => { void load(); }, []);

  async function load() {
    setError("");
    try {
      const response = await fetch("/api/agentkit/operations");
      const body = await response.json();
      if (!response.ok || !body.ok) throw new Error("Operations status is unavailable.");
      setStatus(body.data);
    } catch (e) { setError(e instanceof Error ? e.message : "Request failed."); }
  }
  async function plan() {
    setBusy(true); setError("");
    try {
      const response = await fetch("/api/agentkit/operations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ objective, chainId: 84532, simulationOnly: true }) });
      const body = await response.json();
      if (!response.ok || !body.ok) throw new Error(body.error?.message || "Could not create a research draft.");
      setProposal(body.data);
      if (!status) await load();
    } catch (e) { setError(e instanceof Error ? e.message : "Request failed."); }
    finally { setBusy(false); }
  }

  return <div className="section-content agentkit-center">
    <div className="section-title"><div><div className="eyebrow">PHASE 9 · RESEARCH ONLY</div><h1>Coinbase AgentKit Operations Center</h1><p>Agent-scoped DeFi intelligence with capability discovery, policy boundaries, and simulation-first planning.</p></div><button className="secondary-button" onClick={() => void load()}><Activity size={15}/> Refresh status</button></div>
    <div className="agentkit-banner"><ShieldCheck size={19}/><div><strong>Financial writes are disabled</strong><span>All requests are research or simulation only. No wallet signing or transaction submission is available.</span></div><span className="status-pill">DEMO</span></div>
    {error && <div className="agentkit-error" role="alert">{error}</div>}
    <div className="agentkit-metrics">
      <article><span>AgentKit</span><b>{status?.agentKit.status ?? "Not configured"}</b><small>{status?.agentKit.message ?? "No wallet/action provider configured."}</small></article>
      <article><span>Wallet provider</span><b>{status?.walletProvider.status ?? "None"}</b><small>Wallet ownership: {status?.walletProvider.ownership ?? "none"}</small></article>
      <article><span>Selected network</span><b>{status?.selectedNetwork.name ?? "Base Sepolia"}</b><small>Chain {status?.selectedNetwork.chainId ?? 84532} · live writes off</small></article>
      <article><span>Action providers</span><b>{status?.actionProviders.length ?? 0} discovered</b><small>Only explicitly discovered capabilities are shown.</small></article>
    </div>
    <div className="agentkit-grid">
      <section className="panel"><div className="panel-heading"><div><h2>Agent permissions</h2><p>Narrow role-based action boundaries. Execution authority is not granted to any agent.</p></div><Bot size={18}/></div>
        <div className="agentkit-roles">{(status?.capabilities ?? [
          { agent: "DeFi Discovery", access: "read-only", allowedActions: ["discover verified markets"], deniedActions: ["deposit", "borrow", "swap"] },
          { agent: "Rate Analyst", access: "read-only", allowedActions: ["compare sourced rates"], deniedActions: ["deposit", "borrow", "swap"] },
          { agent: "Liquidity Analyst", access: "read-only", allowedActions: ["read liquidity"], deniedActions: ["add liquidity", "withdraw"] },
          { agent: "Quantitative Allocator", access: "simulation-only", allowedActions: ["model hypothetical allocations"], deniedActions: ["submit transaction", "borrow"] },
          { agent: "Protocol Risk", access: "read-only", allowedActions: ["review protocol data"], deniedActions: ["submit transaction", "approve own action"] },
          { agent: "Independent Auditor", access: "read-only", allowedActions: ["verify calculations", "review receipts"], deniedActions: ["sign transaction", "mutate policy"] },
        ]).map((role) => <article key={role.agent}><div><b>{role.agent}</b><span className="status-pill">{role.access}</span></div><p>Allowed: {role.allowedActions.join(" · ")}</p><small>Denied: {role.deniedActions.join(" · ")}</small></article>)}</div>
      </section>
      <section className="panel"><div className="panel-heading"><div><h2>Protocol discovery</h2><p>No networks or markets are assumed from action names alone.</p></div><LockKeyhole size={17}/></div>
        <div className="agentkit-protocols">{(status?.protocols ?? ["Compound", "Morpho", "Moonwell"].map((name) => ({ name, status: "unverified", marketCount: null }))).map((protocol) => <div key={protocol.name}><b>{protocol.name}</b><span>{protocol.status}</span><small>{protocol.marketCount === null ? "No verified markets" : `${protocol.marketCount} markets`}</small></div>)}</div>
        <p className="agentkit-notice"><AlertTriangle size={15}/>{status?.dataNotice ?? "No protocol markets, rates, balances, vault addresses, swap quotes, or liquidity values are available until a verified provider is configured."}</p>
      </section>
    </div>
    <section className="panel agentkit-planner"><div className="panel-heading"><div><h2>Treasury strategy planner</h2><p>Produces a research draft only; missing source data stays missing instead of being filled with invented rates.</p></div><span className="status-pill">SIMULATION ONLY</span></div>
      <label htmlFor="defi-objective">Research objective</label><textarea id="defi-objective" maxLength={500} value={objective} onChange={(e) => setObjective(e.target.value)}/><button className="primary-button" disabled={busy || objective.trim().length < 12} onClick={() => void plan()}>{busy ? "Preparing research…" : "Prepare hypothetical strategy"}</button>
      {proposal && <div className="agentkit-result" role="status"><b>Research draft {proposal.id}</b><span>Status: {proposal.status} · allocations: {proposal.allocations.length} · modeled yield: {proposal.modeledYield ?? "Unavailable"}</span><span>{proposal.policyDecision.reason}</span><ul>{proposal.riskFlags.map((flag) => <li key={flag}>{flag}</li>)}</ul></div>}
    </section>
  </div>;
}
