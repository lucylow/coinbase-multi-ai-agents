"use client";
import { useCallback, useEffect, useState } from "react";
import { Activity, AlertTriangle, Blocks, CircleHelp, Database, LockKeyhole, RefreshCw, ShieldCheck, WalletCards, Workflow } from "lucide-react";

type Capability = { id: string; configured: boolean; available: boolean | null; authenticated: boolean | null; lastCheckedAt: string | null; responseLatencyMs: number | null; supportedOperations: string[]; accessMode: string; note?: string };
type HealthResponse = { environment?: { mode?: string; warning?: string | null }; checkedAt?: string; capabilities?: Record<string, Capability> };
type ChainStatus = { network: string; name: string; chainId: number; rpc: string; error?: string };
type OnchainResponse = { mode?: string; writesEnabled?: boolean; networks?: ChainStatus[]; contracts?: Record<string, string | null>; phase4?: { budgets?: { mode?: string; reservations?: string }; x402Provider?: { configured?: boolean; enabled?: boolean } }; phase7?: { risc0?: { configured?: boolean; mode?: string } }; phase8?: { walletSdk?: { configured?: boolean }; eip7702?: { enabled?: boolean } } };
type Card = { title: string; state: string; detail: string; icon: typeof Activity; tone: "good" | "warn" | "off" };
function status(capability?: Capability): string { if (!capability) return "NOT REPORTED"; if (capability.available === true) return "AVAILABLE"; if (capability.available === false) return "UNAVAILABLE"; return capability.configured ? "CONFIGURED · UNVERIFIED" : "NOT CONFIGURED"; }
function tone(capability?: Capability): Card["tone"] { return capability?.available === true ? "good" : capability?.configured ? "warn" : "off"; }
export function TechnicalCommandCenter() {
  const [health, setHealth] = useState<HealthResponse | null>(null); const [onchain, setOnchain] = useState<OnchainResponse | null>(null); const [error, setError] = useState(""); const [loading, setLoading] = useState(false); const [checkedAt, setCheckedAt] = useState("");
  const refresh = useCallback(async () => {
    setLoading(true); setError("");
    const [healthResult, onchainResult] = await Promise.allSettled([
      fetch("/api/integrations/health", { cache: "no-store" }).then(async (r) => { if (!r.ok) throw new Error("Integration health API failed."); return (await r.json()).data as HealthResponse; }),
      fetch("/api/onchain/status", { cache: "no-store" }).then(async (r) => { if (!r.ok) throw new Error("On-chain status API failed."); return await r.json() as OnchainResponse; }),
    ]);
    if (healthResult.status === "fulfilled") setHealth(healthResult.value); else setError(healthResult.reason instanceof Error ? healthResult.reason.message : "Integration health is unavailable.");
    if (onchainResult.status === "fulfilled") setOnchain(onchainResult.value); else setError((prior) => prior ? `${prior} On-chain status is unavailable.` : "On-chain status is unavailable.");
    setCheckedAt(new Date().toISOString()); setLoading(false);
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  const caps = health?.capabilities ?? {};
  const networks = onchain?.networks ?? [];
  const cards: Card[] = [
    { title: "Coinbase Advanced Trade", state: status(caps.advancedTradeRead), detail: `${caps.advancedTradeRead?.accessMode ?? "read-only"} · account reads require separate opt-in`, icon: Activity, tone: tone(caps.advancedTradeRead) },
    { title: "Base RPC", state: networks.length ? `${networks.filter((n) => n.rpc === "healthy").length}/${networks.length} RESPONDING` : "NOT PROBED", detail: networks.map((n) => `${n.name} (${n.chainId}): ${n.rpc}`).join(" · ") || "No chain result returned.", icon: Blocks, tone: networks.some((n) => n.rpc === "healthy") ? "good" : "warn" },
    { title: "Wallet & smart accounts", state: onchain?.phase8?.walletSdk?.configured ? "SDK CONFIGURED" : "NOT CONFIGURED", detail: `EIP-7702 enabled: ${onchain?.phase8?.eip7702?.enabled ? "yes" : "no"}. Smart-account lifecycle utilities are local application logic, not a connected signer.`, icon: WalletCards, tone: onchain?.phase8?.walletSdk?.configured ? "warn" : "off" },
    { title: "Account abstraction", state: "NOT CONFIGURED", detail: "No bundler, EntryPoint, or paymaster connection is established. UserOperation utilities do not submit transactions.", icon: Workflow, tone: "off" },
    { title: "Policy & spending", state: `${onchain?.phase4?.budgets?.mode ?? "UNKNOWN"} · ${onchain?.phase4?.budgets?.reservations ?? "reservation mode not reported"}`, detail: "Local policy and reservation checks are not an on-chain spend permission or payment authorization.", icon: LockKeyhole, tone: "warn" },
    { title: "Indexing & financial data", state: "LOCAL FOUNDATION", detail: "Reorg-aware checkpoint and source-attributed fixed-point valuation primitives are present; no durable indexing database is configured.", icon: Database, tone: "warn" },
    { title: "Proof infrastructure", state: onchain?.phase7?.risc0?.mode ?? (onchain?.phase7?.risc0?.configured ? "CONFIGURED · UNVERIFIED" : "NOT CONFIGURED"), detail: "Proof generation and verification require a configured independent provider; no proof is asserted by this panel.", icon: ShieldCheck, tone: onchain?.phase7?.risc0?.configured ? "warn" : "off" },
    { title: "Automation", state: "BOUNDED · APPLICATION ONLY", detail: "Rule engine supports verified event gating, deduplication, limits, and research/notification actions only; no financial actions.", icon: Workflow, tone: "warn" },
  ];
  return <main className="section-content technical-center">
    <div className="section-title"><div><div className="eyebrow">INFRASTRUCTURE · POLICY · RECONCILIATION</div><h1>Technical Command Center</h1><p>Verified runtime facts are separated from local implementation foundations and unavailable integrations.</p></div><button className="technical-refresh" onClick={() => void refresh()} disabled={loading}><RefreshCw size={14} className={loading ? "integration-spin" : ""}/>{loading ? "Checking" : "Refresh status"}</button></div>
    <div className="technical-banner"><AlertTriangle size={18}/><div><b>{health?.environment?.mode ?? "Environment status not loaded"} · read-only operations</b><span>Live signing, transfers, swaps, and autonomous financial writes are not wired in this release. Cards marked “local foundation” describe code primitives, not connected production services. No transaction is submitted from this view.</span></div><span className="status-pill">POLICY WRITE GATE: {onchain?.writesEnabled ? "OPEN" : "BLOCKED"}</span></div>
    {health?.environment?.warning && <div className="integration-warning"><AlertTriangle size={15}/>{health.environment.warning}</div>}
    {error && <div className="agentkit-error" role="alert">{error}</div>}
    <section className="technical-cards" aria-label="Infrastructure status">
      {cards.map((card) => <article key={card.title} className="technical-card"><div className="technical-card-head"><span className={`technical-icon ${card.tone}`}><card.icon size={16}/></span><span className={`technical-state ${card.tone}`}>{card.state}</span></div><h2>{card.title}</h2><p>{card.detail}</p></article>)}
    </section>
    <section className="technical-panel"><div className="technical-panel-title"><div><div className="eyebrow">NETWORKS & DEPLOYMENTS</div><h2>Configured Base network probes</h2></div><span className="status-pill">{networks.length} NETWORKS</span></div>
      {networks.length ? <div className="technical-network-list">{networks.map((network) => <article key={network.chainId}><div><b>{network.name}</b><span>{network.network} · chain {network.chainId} · {network.network === "base-sepolia" ? "testnet" : "mainnet"}</span></div><span className={`technical-state ${network.rpc === "healthy" ? "good" : "off"}`}>{network.rpc}{network.error ? ` · ${network.error}` : ""}</span></article>)}</div> : <p className="technical-muted"><CircleHelp size={14}/> Chain status has not been received.</p>}
      <div className="technical-contracts">{Object.entries(onchain?.contracts ?? {}).map(([name, address]) => <div key={name}><span>{name}</span><b>{address ?? "not configured"}</b></div>)}</div>
    </section>
    <p className="technical-footnote">Status fetched {checkedAt ? new Date(checkedAt).toLocaleString() : "not yet"}. Integration availability comes from the server health endpoint; Base chain state comes from a live chain-ID RPC probe. A configured credential or URL is not proof of authorization. {caps.advancedTradeRead?.note ?? ""}</p>
  </main>;
}
