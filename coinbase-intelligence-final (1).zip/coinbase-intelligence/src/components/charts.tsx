"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import type { MarketProduct, PortfolioBalance } from "@/models/domain";
import { portfolioMetrics } from "@/services/analytics";

const COLORS = ["#5c8dff", "#30c5e8", "#a18bff", "#65748b"];

export function PriceChart({ market }: { market: MarketProduct }) {
  const data = market.candles.map((candle) => ({
    ...candle,
    label: new Date(candle.time).toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }),
  }));
  return (
    <div className="chart-wrap">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{ top: 8, right: 6, left: -18, bottom: 0 }}
        >
          <defs>
            <linearGradient id="priceFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#4e82ff" stopOpacity={0.28} />
              <stop offset="100%" stopColor="#4e82ff" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid
            stroke="#222c3b"
            strokeDasharray="3 5"
            vertical={false}
          />
          <XAxis
            dataKey="label"
            tick={{ fill: "#76849a", fontSize: 10 }}
            axisLine={false}
            tickLine={false}
            minTickGap={35}
          />
          <YAxis
            domain={["auto", "auto"]}
            tick={{ fill: "#76849a", fontSize: 10 }}
            axisLine={false}
            tickLine={false}
            tickFormatter={(value: number) =>
              value >= 1000 ? `$${(value / 1000).toFixed(0)}k` : `$${value}`
            }
          />
          <Tooltip
            contentStyle={{
              background: "#101722",
              border: "1px solid #273347",
              borderRadius: 8,
              color: "#e8edf5",
            }}
            labelStyle={{ color: "#8fa0b6" }}
            formatter={(value) => [
              `$${Number(value).toLocaleString("en-US", { maximumFractionDigits: 2 })}`,
              market.source === "coinbase-advanced-trade" ? "Historical close" : "Synthetic close",
            ]}
          />
          <Area
            type="monotone"
            dataKey="close"
            stroke="#5c8dff"
            strokeWidth={2}
            fill="url(#priceFill)"
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function MarketVolumeChart({ market }: { market: MarketProduct }) {
  const data = market.candles.map((candle) => ({
    ...candle,
    label: new Date(candle.time).toLocaleString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }),
  }));
  return (
    <div className="volume-chart-wrap" aria-label={`${market.productId} candle volume history`}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 4, right: 6, left: -18, bottom: 0 }}>
          <CartesianGrid stroke="#222c3b" strokeDasharray="3 5" vertical={false} />
          <XAxis dataKey="label" tick={{ fill: "#76849a", fontSize: 9 }} axisLine={false} tickLine={false} minTickGap={38} />
          <YAxis tick={{ fill: "#76849a", fontSize: 9 }} axisLine={false} tickLine={false} />
          <Tooltip
            contentStyle={{ background: "#101722", border: "1px solid #273347", borderRadius: 8, color: "#e8edf5" }}
            labelStyle={{ color: "#8fa0b6" }}
            formatter={(value) => [Number(value).toLocaleString("en-US", { maximumFractionDigits: 4 }), "Base-asset volume"]}
          />
          <Bar dataKey="volume" fill="#30c5e8" fillOpacity={0.72} radius={[2, 2, 0, 0]} isAnimationActive={false} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function AllocationChart({ items }: { items: PortfolioBalance[] }) {
  const rows = portfolioMetrics(items).rows.map((row) => ({
    name: row.asset,
    value: row.valueCents,
  }));
  return (
    <div className="allocation-chart">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={rows}
            dataKey="value"
            nameKey="name"
            innerRadius="67%"
            outerRadius="88%"
            paddingAngle={3}
            stroke="none"
            isAnimationActive={false}
          >
            {rows.map((row, index) => (
              <Cell key={row.name} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              background: "#101722",
              border: "1px solid #273347",
              borderRadius: 8,
              color: "#e8edf5",
            }}
            formatter={(value) => [
              `$${(Number(value) / 100).toLocaleString("en-US", { maximumFractionDigits: 2 })}`,
              "Value",
            ]}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
