"use client";
import { useEffect, useState } from "react";
import { Blocks, ExternalLink, ShieldAlert } from "lucide-react";

type Status = { ok: boolean; mode: string; writesEnabled: boolean; networks: Array<{ network: string; name: string; chainId: number; explorer: string; rpc: string; error?: string }>; contracts: { agentRegistry: string | null; researchAttestationRegistry: string | null } };

export function OnchainView() {
  const [status, setStatus] = useState<Status | null>(null);
  const [error, setError] = useState("");
  useEffect(() => { fetch("/api/onchain/status").then((response) => response.json()).then((payload: Status) => setStatus(payload)).catch((reason: unknown) => setError(reason instanceof Error ? reason.message : "Unable to load onchain status.")); }, []);
  return <div className="page-stack">
    <div className="section-title"><div><div className="eyebrow">PHASE 3 · BASE INFRASTRUCTURE</div><h1>Onchain Control Center</h1><p>Read-only network and contract observability for the AI research workstation.</p></div><span className="status-pill"><Blocks size={14} /> TESTNET-SAFE</span></div>
    <div className="portfolio-warning"><ShieldAlert size={16} /> Mainnet writes are disabled. No wallet signing, payment, or contract submission is performed by this demo.</div>
    {error && <div className="error-banner">{error}</div>}
    <div className="metric-grid"><div className="metric-card"><div className="metric-label">Write policy</div><div className="metric-value">{status?.writesEnabled ? "Review required" : "Kill switch active"}</div><div className="metric-foot">Server-side enforcement</div></div><div className="metric-card"><div className="metric-label">Agent registry</div><div className="metric-value mono">{status?.contracts.agentRegistry || "Not deployed"}</div><div className="metric-foot">Base Sepolia only</div></div><div className="metric-card"><div className="metric-label">Research receipts</div><div className="metric-value mono">{status?.contracts.researchAttestationRegistry || "Not deployed"}</div><div className="metric-foot">Hash-only attestations</div></div></div>
    <section className="panel"><div className="panel-heading"><div><div className="eyebrow">NETWORK OVERVIEW</div><h2>Base RPC health</h2></div></div><div className="table-wrap"><table><thead><tr><th>Network</th><th>Chain ID</th><th>RPC</th><th>Explorer</th></tr></thead><tbody>{status?.networks.map((network) => <tr key={network.network}><td><b>{network.name}</b><small className="table-subtitle">{network.network === "base" ? "Read-only" : "Write-capable testnet"}</small></td><td className="mono">{network.chainId || "Unavailable"}</td><td><span className={`status-dot ${network.rpc === "healthy" ? "online" : "offline"}`} /> {network.rpc}</td><td><a href={network.explorer} target="_blank" rel="noreferrer">Basescan <ExternalLink size={13} /></a></td></tr>) || <tr><td colSpan={4}>Checking Base RPC endpoints…</td></tr>}</tbody></table></div></section>
    <section className="panel"><div className="panel-heading"><div><div className="eyebrow">ARCHITECTURE</div><h2>Phase 3 safety boundary</h2></div></div><p className="muted">The foundation keeps Coinbase/CDP signing behind an explicit integration seam. Research receipts use deterministic Keccak-256 hashes; hashes prove registration and timestamp, not research correctness. Contract addresses and balances remain unavailable until real testnet deployment and verified read-back.</p></section>
  </div>;
}
