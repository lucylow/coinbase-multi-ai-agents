export type DataMode = "demo" | "live-read-only";
export type AgentTaskMode = DataMode | "unavailable";
export type AgentStatus = "idle" | "running" | "completed" | "failed";
export type RiskStatus = "pending" | "approved-for-review" | "rejected";

export interface PortfolioBalance {
  asset: string;
  name: string;
  productId: string;
  quantity: string;
  averageCost: string;
  price: string;
  change24h: number;
}

export interface Candle {
  time: string;
  sourceTimestamp?: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface MarketProduct {
  productId: string;
  status?: string;
  tradingDisabled?: boolean;
  baseCurrencyId?: string;
  quoteCurrencyId?: string;
  source?: "coinbase-advanced-trade" | "demo";
  dataAsOf?: string;
  dataQuality?: { missingCandles: number; duplicateCandles: number; invalidTimestamps: number };
  price: number;
  change24h: number;
  volume24h: number;
  volatility: "Low" | "Moderate" | "Elevated";
  candles: Candle[];
}

export interface AgentToolTrace {
  toolId: string;
  source: string;
  status: "success" | "partial" | "unavailable";
  retrievedAt?: string;
  reference?: string;
}

export interface AgentValidationCheck {
  name: string;
  status: "passed" | "failed" | "not-run";
  detail: string;
}

export interface AgentAuditTrailEntry {
  action: string;
  status: "completed" | "partial" | "failed" | "skipped";
  recordedAt: string;
  references: string[];
}

export interface AgentTask {
  id: string;
  objective: string;
  productIds: string[];
  mode: AgentTaskMode;
  status: AgentStatus;
  createdAt: string;
  completedAt?: string;
  findings: AgentFinding[];
  /** Optional v2 context/audit additions; older saved Phase 1 tasks remain valid. */
  contractVersion?: "2.0";
  auditTrail?: AgentAuditTrailEntry[];
  contextRefs?: string[];
  finalRecommendation?: string;
  agreementScore?: number;
  riskFlags: string[];
  decisionReview?: DecisionReview;
}

export interface AgentFinding {
  id: string;
  agentId: string;
  taskId: string;
  summary: string;
  findings: string[];
  calculations: string[];
  evidenceRefs: string[];
  assumptions: string[];
  confidence: number;
  riskFlags: string[];
  requiresReview: boolean;
  dissent?: string;
  status: AgentStatus;
  toolTrace?: AgentToolTrace[];
  validationChecks?: AgentValidationCheck[];
  metrics?: Record<string, number | string>;
  stance?:
    | "risk-flagged"
    | "market-neutral"
    | "verification-pass"
    | "verification-fail";
}

export interface DecisionReview {
  decisionId: string;
  taskId: string;
  participatingAgents: string[];
  agreementScore: number;
  unresolvedDisagreements: string[];
  riskFlags: string[];
  evidenceCoverage: number;
  recommendation: string;
  humanApprovalRequired: boolean;
}

export interface TradeProposal {
  id: string;
  productId: string;
  side: "BUY" | "SELL";
  orderType: "MARKET" | "LIMIT";
  proposedSize: string;
  proposedPrice?: string;
  estimatedFees?: string;
  rationale: string;
  supportingAgentIds: string[];
  riskFlags: string[];
  /** Human-readable explanation of policy reasons when a simulation proposal is rejected. */
  rejectionExplanations?: string[];
  riskStatus: RiskStatus;
  executionMode: "simulation";
  createdAt: string;
  notionalCents: number;
  reviewDecision?:
    | "approved-for-simulation"
    | "rejected"
    | "analysis-requested";
  preview?: {
    expectedPrice: string;
    slippage: string;
    resultingAllocation: number;
    resultingPortfolioCents: number;
    resultingStablecoinCents: number;
  };
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor: "user" | "agent" | "policy" | "system";
  action: string;
  outcome: string;
  dataMode: DataMode;
  references: string[];
  proposalId?: string;
  checks?: string[];
}

export interface CoinbaseStatus {
  provider: "coinbase-mcp";
  status:
    | "not-configured"
    | "awaiting-authorization"
    | "connected"
    | "read-only"
    | "restricted"
    | "failed";
  endpoint: string;
  authorization: "missing" | "pending" | "authorized";
  capabilities: string[];
  capabilityState?: import("@/integrations/coinbase/coinbase/models/capability-state").CoinbaseCapabilityState;
  health?: import("@/integrations/coinbase/coinbase/models/capability-state").CoinbaseIntegrationHealth;
  lastSyncAt?: string;
  message: string;
}
