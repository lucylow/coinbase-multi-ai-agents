# Coinbase Intelligence

A demo-first Coinbase-specific portfolio research workstation. It demonstrates deterministic specialist agents, portfolio and market calculations, risk challenge, independent verification, simulation-only proposal review, and a local audit ledger. It is an independent demonstration application, not an official Coinbase product.

## Engineering hardening

The simulation boundary uses integer cents for notional and illustrative fees, exact 8-decimal comparisons for holdings, and hard-stops unsupported order primitives before a proposal can be approved. Browser-local demo history is best-effort and resilient to unavailable or quota-exceeded storage; it never represents remote persistence or exchange state. Investigation failures are logged server-side without returning internal error details to the browser.

## Quick start

Requirements: Node.js 22+ and pnpm 11.

```bash
cp .env.example .env.local
pnpm install
pnpm dev
```

Open `http://localhost:3000`. The application runs in DEMO mode without credentials. The fictional portfolio, prices, candles, returns, and derived performance figures are synthetic—not a Coinbase account or live market data. Coinbase connectivity is never shown as connected when authorization is missing.

## Phase 3 onchain foundation

Phase 3 adds an **Onchain Control Center** and a testnet-safe blockchain foundation without changing the existing simulation-only trading boundary. `GET /api/onchain/status` performs bounded `eth_chainId` checks against Base Sepolia and Base Mainnet and reports RPC health, explorer links, and configured contract addresses. Mainnet remains read-only. The server-side blockchain write kill switch is active by default, and no wallet signing, CDP Smart Account submission, x402 payment, or automatic contract deployment is implemented.

`contracts/src/AgentRegistry.sol` and `contracts/src/ResearchAttestationRegistry.sol` are standalone Solidity 0.8.24 contracts for manual Base Sepolia review/deployment. They use minimal identity/hash storage, administrator/attestor authorization, pause controls, duplicate protection, and events. `src/services/blockchain/research-hasher.ts` canonicalizes JSON and creates EVM Keccak-256 hashes for tamper-evident research receipts; a hash proves registration and timestamp, not research correctness. `src/security/blockchain-policy-engine.ts` rejects mainnet writes, malformed intents, missing approval, and writes while the kill switch is active.

New Phase 3 settings are documented in `.env.example`. Contract addresses must be supplied only after real testnet deployment and read-back verification; zero or fabricated addresses are never displayed as deployed contracts.

## Phase 4 controlled-execution foundation

The latest extension adds deny-by-default policy profiles, local policy simulation, normalized Smart Account spend-permission validation, append-only permission lifecycle events, exact-base-unit budget reservations with idempotency, a multi-agent authorization council, and deterministic Keccak Merkle batching/proofs. `contracts/src/ResearchBatchAnchor.sol` anchors a batch root on Base Sepolia when manually deployed and explicitly authorized; no deployment or submission is automatic.

The CDP Policy Engine, Smart Account spend permissions, x402 facilitator, and Coinbase Payment Acceptance are represented by backend-only seams that report `UNCONFIGURED` or `UNAVAILABLE` until the exact supported SDK/API version, credentials, account eligibility, and network capabilities are configured. Local policy results are labelled `LOCAL_SIMULATION` and are never presented as Coinbase-enforced decisions. Payment Acceptance is disabled unless business eligibility is explicitly configured. No private portfolio data is exposed through the first-party resource catalog, and no mainnet financial writes are enabled.

## Phase 5 ERC-8004 trust network

The trust-network foundation pins its compatibility boundary to the [ERC-8004 draft](https://eips.ethereum.org/EIPS/eip-8004) read on 2026-11-06. `contracts/src/ERC8004DraftInterfaces.sol` contains interface declarations only; it is not presented as a complete or deployed ERC-8004 implementation. The application adds draft-aware identity references, registration-file validation, validation request history, evidence-aware reputation summaries, and SSRF-resistant public endpoint checks. ERC-8004 registration IDs are kept separate from internal agent IDs, and a `registered` status requires a confirmed numeric token ID plus a registry reference.

The trust-network status is exposed through `GET /api/onchain/status`. It remains `DRAFT_ADAPTER_DEMO` until actual registry addresses, confirmed records, and compatibility tests are supplied. Payments remain external through the existing x402 boundary; reputation and validation do not imply payment settlement or factual correctness.

## Phase 6 escrow foundation

Phase 6 adds `contracts/src/AgentJobEscrow.sol`, a bounded Base Sepolia escrow design for multi-step agent jobs. It supports up to ten milestones, an allowlisted ERC-20 token, exact integer-unit funding, provider submission, buyer acceptance, disputes, authorized arbitration, token-specific pull withdrawals, and hash-only job/deliverable metadata. The TypeScript proposal validator rejects mainnet jobs, self-dealing, non-numeric ERC-8004 IDs, malformed hashes, expired deadlines, zero-value milestones, and more than ten milestones.

Escrow is intentionally proposal-only in this build. No USDC address is assumed, no contract is deployed automatically, and no CDP signing or payment release occurs without a verified token allowlist, deployed contract, confirmed allowance/funding, configured wallet path, and fresh user approval. x402 remains the separate mechanism for immediate paid requests; escrow is reserved for milestone-based agreements.

## Phase 7 verifiable-compute foundation

Phase 7 adds privacy-preserving, proof-ready computation primitives: salted domain-separated private-input commitments, selective disclosure, integer fixed-point concentration/drawdown/milestone workloads, proof-carrying receipt types, a RISC Zero adapter boundary, and a provider-neutral TEE interface with nonce, freshness, task-binding, and debug-mode checks. `contracts/src/AgentExecutionVerifier.sol` records outcomes from an authorized external verifier and allowlisted program image; it deliberately does not reimplement RISC Zero cryptography.

Demo hashes and ordinary model outputs are never labeled as zero-knowledge proofs, TEE attestations, or cryptographically verified receipts. The Phase 7 status is exposed through `GET /api/onchain/status`; raw private inputs are not published, and RISC Zero/AWS Nitro remain unavailable until their official verifier, guest image, trust store, and deployment configuration are supplied.

## Phase 8 wallet safety foundation

The wallet layer adds non-custodial EIP-1193 account/network discovery restricted to Base Sepolia, explicit user-wallet ownership labeling, EIP-712 authorization envelopes bound to an exact payload, contract, chain, nonce, and deadline, plus an EIP-7702 delegation lifecycle validator. Pending delegation is never treated as active, and no AI path can initiate delegation. The current Coinbase Wallet SDK remains an explicit integration boundary; deprecated OnchainKit is not added.

## Phase 9 AgentKit Operations Center foundation

The integrated AgentKit Operations Center adds a deny-by-default capability/status API, role-scoped read/simulation action declarations, and a schema-validated research-draft endpoint. Requests are restricted to simulation mode; AgentKit, wallet providers, and action providers are explicitly reported as unconfigured. Compound, Morpho, and Moonwell markets remain unverified until a real provider returns verifiable network data. When source data is unavailable, the planner leaves allocations, modeled yield, and fees empty rather than fabricating values. Financial writes, wallet signing, and transaction submission are not implemented.

## Phase 10 onchain governance foundation

`contracts/src/AgentCouncilGovernor.sol` is a non-custodial, weighted signer-council controller. It uses OpenZeppelin 5.6.1 `EIP712`, `SignatureChecker` (EOA/ERC-1271), and `ReentrancyGuard`; binds signatures to proposal ID, description/action hashes, risk tier, signer, signer-set version, nonce, chain and verifying contract through the EIP-712 domain; rejects duplicate signers; blocks unknown selectors, nonzero-value operations, and direct calls to the timelock; and queues approved batches through an external OpenZeppelin TimelockController. Queue delay is the maximum of the risk-tier delay and timelock minimum. All signer/threshold/selector changes are timelock-only. `GET /api/governance/status` and the Governance Center are read-only; configured addresses are still labelled unverified, and all signing/submission flags remain false.

This is a contract foundation, not a deployed or production-governed system. No TimelockController deployment, proposer/executor role assignment, Base RPC verification, deployment script, policy registry, onchain integration for application counts, or post-execution state read-back is included. Foundry regression test sources compile, but running them requires Forge, which is not bundled here. Do not migrate current contract administrators or enable writes until those setup and recovery tests are completed.

## Phase 10 Coinbase integration health and environment

`GET /api/integrations/health` and the Integration Health Center report configured, available, and authenticated as separate states for Advanced Trade account reads, public market data, browser WebSocket, MCP, wallet, Base RPC, CDP policy, local spend-permission checks, and x402. The endpoint performs a bounded public product metadata probe, Base Sepolia chain-ID probe, and the existing MCP status call; results are process-cached for 30 seconds. It does not read balances, sign, submit orders/transactions, or settle payments. Generic errors do not echo upstream URLs or credentials. The browser WebSocket additionally rejects nonpositive, duplicate, out-of-order, and far-future ticker events and reports event/drop counts. It still does not reconstruct Level 2 books or claim exchange sequence validation.

`COINBASE_ENVIRONMENT` is reported as DEMO by default and accepts DEMO, SANDBOX, PRODUCTION_READ_ONLY, and PRODUCTION_RESTRICTED. Unknown values default safely to DEMO; SANDBOX is only reported when `COINBASE_SANDBOX_API_URL` and the Advanced Trade URL override match as verified HTTPS URLs. Production mode labels do not enable execution. See [the integration capability inventory](docs/COINBASE_INTEGRATION.md) for existing components, verified capability semantics, and intentionally incomplete integrations.

Base RPC settings are separated into `BASE_SEPOLIA_RPC_URL` and `BASE_MAINNET_RPC_URL`, so the onchain status view no longer reuses a Sepolia endpoint for a mainnet probe. Legacy `BASE_RPC_URL` remains a Sepolia-only fallback.

## Application

The primary sections are Overview, Coinbase Portfolio, Agent Command Center, Market Intelligence, Risk Intelligence, Trade Proposals, Execution Ledger, AgentKit Operations Center, Onchain Governance Center, Integration Health Center, and Onchain Control Center. The dashboard is responsive, opens with synthetic market and allocation charts, and offers a Coinbase integration/settings panel.

Phase 2 adds small, composable research primitives instead of new infrastructure. `GET /api/markets/live` calls Coinbase Advanced Trade's public product and candle endpoints and returns `live-read-only` data or an explicit demo-safe fallback. `GET /api/coinbase/portfolio` lists portfolios visible to configured CDP keys and retrieves the official portfolio breakdown; it validates the portfolio against that key's authorized list, normalizes returned position fields, and never returns credentials. `POST /api/research/backtest` runs a long-only SMA(7/20) crossover backtest, while `POST /api/research/stress` applies transparent per-asset shocks to the demo portfolio.

The five isolated specialist agents are Portfolio Analyst, Market Intelligence, Quantitative Research, Risk Officer, and Verification & Audit. Independent portfolio, market, and quant analyses run concurrently; the orchestrator then performs risk challenge and a separate arithmetic/evidence review. Findings include calculations, fixture evidence, assumptions, confidence, risk flags, stance, and dissent. The agreement score measures alignment between agent conclusions—it is not an investment-success probability.

The original five agent IDs and order are retained and upgraded in place. Portfolio Analyst adds snapshot drift, per-asset HHI contribution, position exposure, a disclosed static −10% largest-holding scenario, and same-currency peer comparisons. Sibling portfolios are loaded only when the objective explicitly requests a portfolio comparison, and only from authorized contexts returned by the manager; internal agent workspaces are not interpreted as separate Coinbase accounts. Market Intelligence and Quant Research share one market-data context per investigation: Coinbase public products/candles and a matching public order book when available, or clearly marked demo data. The market agent adds candle regime/volume diagnostics and spread/depth/momentum measures; the quant agent adds a next-bar SMA(3/8) versus buy-and-hold backtest with a stated 10 bps transition cost, rolling volatility, aligned-market correlation, paired active-return test (normal-tail p-value approximation), and a Sharpe ratio that explicitly assumes a 0% annual risk-free rate. These small-sample diagnostics are descriptive, not forecasts or evidence of strategy skill. Risk Officer adds static parallel stress, historical correlation and partial-book liquidity challenges, strategy drawdown review, and exact policy-derived rejection explanations on rejected simulation proposals. Verification & Audit re-sums portfolio values independently, rechecks strategy returns through a separate calculation path, validates source/candle fields, checks the five-agent output contract and evidence, scans for unsupported certainty claims, and verifies required workflow audit events.

New agent outputs use an optional v2 task contract (`contractVersion: "2.0"`) with context references, typed source/tool traces, per-agent validation checks, and task-level audit events. Fields are optional so previously stored Phase 1 tasks remain readable. These rule-based agents still do not use an external LLM.

On a first clean browser workspace, `GET /api/agents/tasks` computes five example investigations over the same fixtures and saves them locally. User-triggered requests persist a running state, then a completed or failed report, with audit events. These deterministic reports are labeled **DEMO AGENT SIMULATION**; they are not generated by an external LLM or connected to an exchange.

Portfolio analytics include cents-safe total value, allocation, PnL, weighted simulated daily movement, simple returns, moving averages, RSI, ATR, sample volatility, maximum drawdown, and concentration. Market scenarios—bullish, bearish, sideways, high volatility, and liquidity deterioration—transform only the synthetic samples.

A proposal approval means **approve for simulation only**. The independent policy checks product, side, order type, size, precision, proposal limit, sample-data freshness, concentration, holdings, USDC coverage, and illustrative fee coverage. Hypothetical buy/sell previews apply signed asset and USDC changes and show indicative price, fee, slippage, and resulting portfolio. There is no live order submission, withdrawal, deposit, transfer, swap, or autonomous execution code path. Demo tasks, proposals, and audit records persist in browser local storage; reset affects only that browser’s demo state.

## Coinbase integration boundary

The server-side Coinbase for Agents MCP boundary uses `https://agents.coinbase.com/mcp`, with `COINBASE_MCP_URL` as an override. The connection manager accepts only a host-provided MCP transport, tracks disconnected/pending/authorized state, and discovers tools actually returned by that session. It does not implement custom OAuth, use Advanced Trade CDP credentials, or fabricate capabilities. The portfolio, product, market, preview, and fee adapters can call only discovered read-only tools; discovered write tools are rejected before invocation.

Coinbase Advanced Trade is a separate REST adapter. Public products, market data, and candles are read without private credentials. Portfolio reads use server-only CDP credentials to create short-lived JWTs and call `GET /api/v3/brokerage/portfolios` and `GET /api/v3/brokerage/portfolios/{portfolio_uuid}`. Coinbase documents a `view` scope and portfolio-scoped API keys; each configured profile is independent. Credentials are never shared with MCP or exposed to the browser. The adapter deliberately has no portfolio create/delete, transfer, or order-submission methods.

`src/services/portfolio/portfolio-workspace-manager.ts` lists only portfolios returned by each configured source, stores up to 30 snapshots per profile/portfolio in a bounded process-local repository, computes allocations, compares snapshots, and flags material quantity changes (default heuristic: at least 25% quantity change and $100 value change, or a newly observed position of at least $100). Valuation changes alone are not called balance movements, absent positions are not treated as zero, and the default repository is not durable across process restarts; inject a secure durable repository for production history. Actual reads require `COINBASE_PORTFOLIO_READS_ENABLED=true` and should only be enabled behind app authentication or on a private deployment. Multiple key profiles are declared with environment-variable references, not embedded secrets. `COINBASE_PORTFOLIO_WORKSPACE_MAPPINGS_JSON` is the only way to map a research workspace/strategy to a real portfolio. Without a mapping, Portfolio Analyst remains on demo data; if an explicit mapping fails authorization, it reports unavailable and does not substitute demo balances. Viewing a portfolio in the UI does not create an internal-agent mapping. Coinbase for Agents describes separate agent portfolios and user-set limits, but this app does not infer IDs or treat its internal research agents as Coinbase agents.

`src/services/portfolio/advanced-metrics.ts` calculates current total value, cash and asset weights, HHI concentration (0–10,000 score), effective holdings (`1 / HHI`), largest holdings, snapshot-to-snapshot allocation drift, a 24-hour change (only with a reference snapshot within ±2 hours), simple and cumulative observed returns, per-observation volatility, maximum drawdown and recovery time. Historical portfolio returns are not cash-flow adjusted. Covariance/correlation use aligned implied unit-price returns derived from snapshot value divided by quantity, rather than balance changes that may reflect trading. Volatility contribution uses current reported weights and the covariance matrix and is withheld when coverage does not reconcile. Sharpe and annualized volatility require regular timestamps plus explicit `PORTFOLIO_SNAPSHOT_PERIODS_PER_YEAR`; Sharpe additionally requires an explicit `PORTFOLIO_RISK_FREE_RATE_ANNUAL`, displays both assumptions, and converts the effective annual rate using `(1 + rate)^(1 / periodsPerYear) - 1`. No risk-free rate or sampling frequency is assumed.

The Portfolio Intelligence comparison panel can compare any two portfolios returned by the configured read-only profiles (including demo/live), or manually selected snapshots from their bounded histories. The default pair is the closest common-currency timestamp pair; the panel shows the time offset and warns when it exceeds five minutes. No FX conversion or interpolation is done. Allocation changes are shown in percentage points; an absent position is not presumed to be zero. Current-versus-target comparison accepts explicit user-entered JSON weights that must total 100%; this is display-only and does not create orders. `RUN COINBASE PORTFOLIO X-RAY` calls `POST /api/coinbase/portfolio/xray`: it reloads the selected authorized balance snapshot, fetches public Coinbase product prices for spot holdings where a matching online quote exists, normalizes quantity × price, and calculates allocations over the covered spot subtotal. It identifies provider-reported value fallbacks, unavailable prices, demo balances, and timing/coverage caveats. The X-ray cannot trade, transfer, or mutate a portfolio.

The official TypeScript Advanced Trade SDK is presented by Coinbase as a sample SDK. Its published package delegates runtime requests to a core package listed only as a development dependency, so it is not adopted as a production runtime dependency here. The typed HTTP adapter remains the integration seam and follows Coinbase's documented CDP JWT format; an official maintained SDK can replace that seam when Coinbase provides one that fits this TypeScript application. The official Python SDK remains useful for Python integrations, but is not imported across this app's TypeScript runtime.

Capability discovery normalizes tools actually returned by the authorized session into account-read, portfolio-read, market-data, product-info, order-preview, order-management, trading, and x402 research-payment flags. A flag is true only when a discovered tool name or description supports it; region/account eligibility is left unknown unless the provider explicitly exposes it. The Integration settings panel shows discovered and missing categories, connection/authentication, API latency, last successful data retrieval, last failure, rate-limit and permission signals, and sync state. MCP tool-call health is tracked by the host connection manager; capability discovery is not counted as an account-data retrieval. Transient network, timeout, server, and rate-limit failures get at most two exponential-backoff retries. Authentication and permission errors are terminal, and the UI does not poll the hosted Coinbase MCP endpoint.

The market-data layer discovers supported Coinbase USD products instead of assuming requested pairs exist. It requests BTC-USD, ETH-USD, SOL-USD, and USDC-USD where available, then includes additional online USD products returned by discovery. Product metadata/status, historical candles at supported intervals, public product book, market trades, and authenticated best-bid/ask reads are exposed through the Advanced Trade adapter. Candle values are numeric-validated, ordered, checked for duplicates and OHLCV consistency, and gap-counted by interval; each record retains Coinbase's source timestamp beside normalized UTC ISO time. The Market Intelligence Agent and Market Intelligence page use fetched read-only market data when available and show seeded fixtures with explicit demo labeling when unavailable. No market-data route performs trading.

The browser optionally opens Coinbase Advanced Trade's public WebSocket endpoint directly (never MCP or the private user feed). It subscribes to ticker for at most four REST-discovered products, plus heartbeats and status, with one subscribe message per channel. Reconnects use capped exponential backoff and stop after five failed attempts; data becomes stale when no ticker arrives for 45 seconds. Incoming ticker messages are schema/value checked and normalized to `MarketTick` string prices; candle and order-book contracts also retain price/size decimals as strings. A new tick updates the frontend snapshot, while REST and demo fixtures remain available if streaming is down. The socket is started once on page load and closed on component teardown.

## API surface

- `GET /api/health`
- `GET /api/overview`
- `GET /api/markets`
- `GET /api/agents`
- `GET /api/agents/tasks`
- `POST /api/agents/investigate`
- `GET /api/coinbase/status`
- `GET /api/markets/live`
- `GET /api/coinbase/portfolio`
- `POST /api/coinbase/portfolio/xray`
- `POST /api/research/backtest`
- `POST /api/research/stress`
- `POST /api/proposals`
- `GET /api/onchain/status`
- `GET /api/agentkit/operations`
- `POST /api/agentkit/operations`
- `GET /api/governance/status`
- `GET /api/integrations/health`

Only implemented routes are exposed. `/manus-routes.json` declares the sole page route `/` and excludes API routes.

## Configuration

`.env.example` contains only environment variables the code reads:

- `COINBASE_MCP_URL=https://agents.coinbase.com/mcp` selects the configured MCP endpoint URL.
- `ENABLE_LIVE_EXECUTION=false` records a requested-mode flag for visibility. It cannot enable real execution; the application hard-disables live execution in code.
- `COINBASE_ADVANCED_TRADE_URL=https://api.coinbase.com` optionally overrides the public Advanced Trade host for testing.
- `COINBASE_ADVANCED_API_KEY_NAME` and `COINBASE_ADVANCED_API_PRIVATE_KEY` are optional, server-only CDP credentials for one Advanced Trade profile.
- `COINBASE_ADVANCED_PORTFOLIO_PROFILES_JSON` can declare additional profiles by referencing server-side secret environment variables; do not place private keys in the JSON value.
- `COINBASE_PORTFOLIO_READS_ENABLED=true` explicitly opts in to live account reads. Enable only behind user authentication or on a private deployment.
- `COINBASE_PORTFOLIO_WORKSPACE_MAPPINGS_JSON` explicitly maps `{workspaceId, strategyId, providerId, portfolioId}`. It defaults to no mappings.
- `PORTFOLIO_RISK_FREE_RATE_ANNUAL` optionally declares the annual risk-free rate as a decimal (for example, `0.04` for 4%); no value is assumed.
- `PORTFOLIO_SNAPSHOT_PERIODS_PER_YEAR` optionally declares the sampling frequency used for annualization; the stored observations must also be regular enough for the calculation.

No Coinbase credentials, LLM key, third-party financial data key, or database configuration is required. Do not put secrets in browser code or commit `.env.local`.

## Architecture

```mermaid
flowchart LR
  U[User] --> F[Next.js App Router]
  F --> A[Typed API routes]
  A --> O[Agent orchestrator]
  O --> P[Portfolio analyst]
  O --> M[Market intelligence]
  O --> Q[Quant research]
  P --> R[Independent risk challenge]
  M --> R
  Q --> R
  R --> V[Verification & audit]
  V --> C[Coinbase provider boundary]
  C --> D[Demo fixtures or future authorized data]
  V --> L[Browser-local audit ledger]
```

`app/` contains the App Router shell and API handlers. `src/models` defines shared TypeScript contracts, `src/fixtures` owns synthetic data, `src/services` contains calculations, policy, scenarios, proposal simulations, and local persistence, `src/agents` contains specialist handlers and orchestration, `src/integrations/coinbase` contains the MCP and separate Advanced Trade boundaries, and `tests/` has the focused Vitest suite.

## Checks

```bash
pnpm typecheck
pnpm test
pnpm build
pnpm contracts:check
```

The current focused suite covers portfolio and technical calculations, policy rejection (including stale fixtures and insufficient cash), scenario isolation, signed BUY/SELL previews, Coinbase capability boundaries and HTTP response normalization, agent orchestration/verification mismatch, seeded investigation retrieval, quantitative backtesting, stress testing, and malformed request handling.

## Limitations and roadmap

This foundation deliberately does not implement Coinbase OAuth or a custom remote MCP transport; authorization must be completed by a supported host and injected as a transport. Demo history is local to one browser; portfolio comparison history is bounded process memory unless a durable repository is injected. MCP adapters are read-only, and all proposals remain simulation-only. A production continuation should add validated/account-scoped persistence and complete independent security review before considering any live financial operation.


## Phase 11 foundations

This update adds architecture-aware smart-account lifecycle validation, a receipt-gated ERC-4337 operation state machine, scoped in-process spending reservations, agent-service settlement reconciliation, explicit chain/token identity, reorg-aware block checkpoints, source-attributed fixed-point valuation, bounded research-only automation, and a technical command center that consumes the existing health and Base RPC probes. These are local foundations rather than complete production services: no new wallet signing, bundler/paymaster submission, bridge, payment, persistent indexer, or treasury transfer path is enabled. See [`docs/phase-11-implementation-status.md`](docs/phase-11-implementation-status.md) for the implementation matrix, non-goals, and deployment prerequisites.
