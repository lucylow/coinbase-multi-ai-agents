import { NextResponse } from "next/server";
import { HttpAdvancedTradeProvider } from "@/integrations/coinbase/advancedTradeProvider";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const productId = (params.get("productId") || "").trim();
  const requestedLimit = Number(params.get("limit") || 10);
  if (!/^[A-Z0-9]+-[A-Z0-9]+$/.test(productId)) {
    return NextResponse.json(
      { ok: false, error: "Provide a valid productId such as BTC-USD." },
      { status: 400 },
    );
  }
  if (!Number.isInteger(requestedLimit) || requestedLimit < 1 || requestedLimit > 50) {
    return NextResponse.json(
      { ok: false, error: "Order-book limit must be an integer from 1 to 50." },
      { status: 400 },
    );
  }

  try {
    const book = await new HttpAdvancedTradeProvider().getProductBook(productId, requestedLimit);
    return NextResponse.json({
      ok: true,
      data: {
        ...book,
        source: "coinbase-advanced-trade",
        asOf: book.time || new Date().toISOString(),
      },
    });
  } catch {
    return NextResponse.json(
      { ok: false, error: "Public Coinbase order-book data is currently unavailable." },
      { status: 502 },
    );
  }
}
