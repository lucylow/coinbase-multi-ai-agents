import { NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { balances } from "@/fixtures/demo";
import { evaluateProposal } from "@/services/policy";
import type { TradeProposal } from "@/models/domain";
import { explainProposalRejection } from "@/agents/specialists";

const proposalSchema = z.object({
  productId: z.enum(["BTC-USD", "ETH-USD", "SOL-USD", "USDC-USD"]),
  side: z.enum(["BUY", "SELL"]),
  orderType: z.enum(["MARKET", "LIMIT"]),
  proposedSize: z.string().regex(/^\d+(?:\.\d{1,8})?$/),
  proposedPrice: z.string().optional(),
  rationale: z.string().min(8).max(500),
});

export async function POST(request: Request) {
  const body: unknown = await request.json().catch(() => null);
  const parsed = proposalSchema.safeParse(body);
  if (!parsed.success)
    return NextResponse.json(
      {
        ok: false,
        error: { code: "INVALID_INPUT", message: "Proposal input is invalid." },
      },
      { status: 400 },
    );
  const checked = evaluateProposal(parsed.data, balances);
  const proposal: TradeProposal = {
    id: `SIM-${randomUUID().slice(0, 8).toUpperCase()}`,
    ...parsed.data,
    estimatedFees: (checked.feeCents / 100).toFixed(2),
    supportingAgentIds: ["portfolio-analyst", "quant-research", "risk-officer"],
    riskFlags: checked.riskFlags,
    rejectionExplanations: checked.allowedForSimulation ? [] : explainProposalRejection(checked.riskFlags),
    riskStatus: checked.allowedForSimulation
      ? "approved-for-review"
      : "rejected",
    executionMode: "simulation",
    createdAt: new Date().toISOString(),
    notionalCents: checked.notionalCents,
  };
  return NextResponse.json(
    { ok: true, data: { proposal, policy: checked } },
    { status: 201 },
  );
}
