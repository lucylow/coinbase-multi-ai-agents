import { NextResponse } from "next/server";
import { getIntegrationHealth } from "@/integrations/coinbase/integration-health";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export async function GET() {
  const data = await getIntegrationHealth();
  return NextResponse.json({ ok: true, data }, { headers: { "Cache-Control": "no-store" } });
}
