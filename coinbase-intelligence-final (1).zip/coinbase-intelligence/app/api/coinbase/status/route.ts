import { NextResponse } from "next/server";
import { coinbaseProvider } from "@/integrations/coinbase/coinbase-provider";
import { getConfiguredPortfolioWorkspaceManager } from "@/services/portfolio/portfolio-workspace-manager";

export async function GET() {
  const portfolioProfileCount = getConfiguredPortfolioWorkspaceManager().configuredProfileCount();
  const credentialsDeclared = Boolean(
    (process.env.COINBASE_ADVANCED_API_KEY_NAME && process.env.COINBASE_ADVANCED_API_PRIVATE_KEY) ||
      process.env.COINBASE_ADVANCED_PORTFOLIO_PROFILES_JSON,
  );
  const portfolioReadsEnabled = process.env.COINBASE_PORTFOLIO_READS_ENABLED === "true";
  const advancedTradeCredentialsConfigured = credentialsDeclared;
  return NextResponse.json({
    ok: true,
    data: {
      mcp: await coinbaseProvider.status(),
      advancedTrade: {
        status: portfolioProfileCount > 0
          ? "credentials-configured-unvalidated"
          : credentialsDeclared && !portfolioReadsEnabled ? "portfolio-reads-disabled" : credentialsDeclared ? "profile-configuration-incomplete" : "not-configured",
        authentication: "CDP API key + private-key JWT; independent of MCP",
        credentialsConfigured: advancedTradeCredentialsConfigured,
        publicCapabilities: ["product-information", "market-data", "candles"],
        accountReadConfigured: portfolioProfileCount > 0,
        portfolioReadConfigured: portfolioProfileCount > 0,
        portfolioReadsEnabled,
        portfolioProfileCount,
        accountReadValidated: false,
        message: portfolioProfileCount > 0
          ? `${portfolioProfileCount} Advanced Trade portfolio credential profile(s) are present server-side. The first REST response is required to validate access and portfolio-key scope.`
          : credentialsDeclared && !portfolioReadsEnabled
            ? "Advanced Trade credentials or profile references are present, but live portfolio reads are disabled by the explicit opt-in setting."
            : credentialsDeclared
              ? "Portfolio profile configuration is present but no complete server-side credential profile is active."
              : "Public market/product reads do not require credentials. Portfolio reads require server-side Advanced Trade CDP key-name and private-key credentials.",
      },
    },
  });
}
