import { NextResponse } from "next/server";
import { calculateAdvancedPortfolioMetrics } from "@/services/portfolio/advanced-metrics";
import { getConfiguredPortfolioWorkspaceManager } from "@/services/portfolio/portfolio-workspace-manager";

const json = (body: unknown, status = 200) =>
  NextResponse.json(body, { status, headers: { "Cache-Control": "private, no-store" } });

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const providerId = params.get("providerId")?.trim();
  const portfolioId = params.get("portfolioId")?.trim();
  if (Boolean(providerId) !== Boolean(portfolioId) || (providerId && (providerId.length > 80 || portfolioId!.length > 200))) {
    return json({ ok: false, error: { code: "INVALID_PORTFOLIO_CONTEXT", message: "Supply both a valid providerId and portfolioId." } }, 400);
  }

  const manager = getConfiguredPortfolioWorkspaceManager();
  if (!providerId || !portfolioId) {
    const data = await manager.listAuthorizedPortfolios();
    return json({
      ok: true,
      data: {
        ...data,
        mappings: manager.explicitMappings(),
        readOnly: true,
        capabilities: ["list-authorized-portfolios", "read-portfolio-breakdown", "store-snapshot", "compare-snapshots", "fetch-public-product-prices", "calculate-portfolio-xray"],
        unsupportedActions: ["create-portfolio", "delete-portfolio", "transfer-funds"],
      },
    });
  }

  try {
    const data = await manager.loadSnapshot(providerId, portfolioId);
    const metrics = calculateAdvancedPortfolioMetrics(data.snapshot, data.history, {
      riskFreeRateAnnual: process.env.PORTFOLIO_RISK_FREE_RATE_ANNUAL === undefined ? undefined : Number(process.env.PORTFOLIO_RISK_FREE_RATE_ANNUAL),
      periodsPerYear: process.env.PORTFOLIO_SNAPSHOT_PERIODS_PER_YEAR === undefined ? undefined : Number(process.env.PORTFOLIO_SNAPSHOT_PERIODS_PER_YEAR),
    });
    return json({ ok: true, data: { ...data, metrics }, readOnly: true });
  } catch {
    return json({ ok: false, error: { code: "PORTFOLIO_UNAVAILABLE", message: "That portfolio is not authorized for this configured read-only source or its snapshot could not be retrieved." } }, 503);
  }
}
