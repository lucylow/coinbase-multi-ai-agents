import { NextResponse } from "next/server";
import { HttpAdvancedTradeProvider } from "@/integrations/coinbase/advancedTradeProvider";
import { getConfiguredPortfolioWorkspaceManager } from "@/services/portfolio/portfolio-workspace-manager";
import { runPortfolioXray } from "@/services/portfolio/portfolio-xray";

const json = (body: unknown, status = 200) => NextResponse.json(body, {
  status,
  headers: { "Cache-Control": "private, no-store" },
});

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return json({ ok: false, error: { code: "INVALID_REQUEST", message: "Expected a JSON request with providerId and portfolioId." } }, 400);
  }
  const input = body && typeof body === "object" ? body as Record<string, unknown> : {};
  const providerId = typeof input.providerId === "string" ? input.providerId.trim() : "";
  const portfolioId = typeof input.portfolioId === "string" ? input.portfolioId.trim() : "";
  if (!providerId || !portfolioId || providerId.length > 80 || portfolioId.length > 200 || /[\u0000-\u001f]/.test(providerId + portfolioId)) {
    return json({ ok: false, error: { code: "INVALID_PORTFOLIO_CONTEXT", message: "Supply a valid authorized providerId and portfolioId." } }, 400);
  }
  try {
    const manager = getConfiguredPortfolioWorkspaceManager();
    const { snapshot } = await manager.loadSnapshot(providerId, portfolioId);
    const data = await runPortfolioXray(snapshot, new HttpAdvancedTradeProvider());
    return json({ ok: true, data, readOnly: true });
  } catch {
    return json({ ok: false, error: { code: "PORTFOLIO_XRAY_UNAVAILABLE", message: "The selected portfolio could not be authorized or the X-ray could not be completed. No demo account balances were substituted for an unavailable live context." } }, 503);
  }
}
