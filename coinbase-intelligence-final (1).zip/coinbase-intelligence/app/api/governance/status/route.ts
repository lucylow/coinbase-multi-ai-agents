import { NextResponse } from "next/server";
import { getGovernanceStatus } from "@/services/governance/status";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ ok: true, data: getGovernanceStatus() });
}
