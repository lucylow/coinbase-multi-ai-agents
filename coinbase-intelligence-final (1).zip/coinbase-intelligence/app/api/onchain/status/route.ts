import { NextResponse } from "next/server";
import { BASE_NETWORKS, type BaseNetwork } from "@/integrations/base/base-network-config";
import { readChainId } from "@/integrations/base/base-rpc-service";
import { blockchainWritesEnabled } from "@/security/blockchain-policy-engine";
import { createPolicyEngineClient } from "@/integrations/coinbase/policy-engine/policy-client";
import { getProviderStatus } from "@/integrations/coinbase/x402-provider/server";
import { getPaymentAcceptanceStatus } from "@/integrations/coinbase/payment-acceptance/status";
import { getAgentTrustNetworkStatus } from "@/services/agent-identity/phase5-status";
import { RISC0_STATUS } from "@/services/verifiable-compute/risc0-adapter";
import { walletSdkStatus } from "@/integrations/coinbase-wallet/wallet-sdk";

export const dynamic = "force-dynamic";
export async function GET() {
  const networks = await Promise.all((Object.keys(BASE_NETWORKS) as BaseNetwork[]).map(async (network) => {
    try { return { network, ...BASE_NETWORKS[network], rpc: "healthy", chainId: await readChainId(network) }; }
    catch (error) { return { network, ...BASE_NETWORKS[network], rpc: "unavailable", chainId: null, error: error instanceof Error ? error.message : "RPC unavailable" }; }
  }));
  return NextResponse.json({ ok: true, mode: "READ_ONLY_DEMO", writesEnabled: blockchainWritesEnabled(), networks, contracts: { agentRegistry: process.env.AGENT_REGISTRY_ADDRESS || null, researchAttestationRegistry: process.env.RESEARCH_ATTESTATION_REGISTRY_ADDRESS || null, researchBatchAnchor: process.env.RESEARCH_BATCH_ANCHOR_ADDRESS || null, agentExecutionVerifier: process.env.AGENT_EXECUTION_VERIFIER_ADDRESS || null }, phase4: { policyEngine: { configured: createPolicyEngineClient().configured, enforcement: "UNVERIFIED_UNTIL_REMOTE_OPERATION_IS_PROCESSED" }, spendPermissions: { configured: false, reason: "No compatible CDP SDK operation is configured; local validation remains advisory." }, budgets: { mode: "SIMULATION", reservations: "IN_MEMORY_ONLY" }, x402Provider: getProviderStatus(), paymentAcceptance: getPaymentAcceptanceStatus() }, phase5: getAgentTrustNetworkStatus(), phase7: { risc0: RISC0_STATUS, tee: { mode: "PROVIDER_NEUTRAL_DEMO", hardwareAttestation: false }, privacy: { mode: "COMMITMENT_ONLY", rawInputsPublished: false } }, phase8: { walletSdk: walletSdkStatus, network: "BASE_SEPOLIA_ONLY", custody: "NON_CUSTODIAL_USER_SIGNING", eip7702: { enabled: false, automaticDelegation: false } } });
}
