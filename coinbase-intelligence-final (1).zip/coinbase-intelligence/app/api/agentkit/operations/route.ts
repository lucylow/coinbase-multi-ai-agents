import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { createStrategyResearch, getOperationsCenterStatus, StrategyRequestSchema } from "@/services/defi/operations-center";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ ok: true, data: getOperationsCenterStatus() });
}

export async function POST(request: Request) {
  try {
    const input = StrategyRequestSchema.parse(await request.json());
    return NextResponse.json({ ok: true, data: createStrategyResearch(input) }, { status: 201 });
  } catch (error) {
    if (error instanceof ZodError || error instanceof SyntaxError) {
      return NextResponse.json({ ok: false, error: { code: "INVALID_REQUEST", message: "Provide a valid research objective and simulation-only request." } }, { status: 400 });
    }
    return NextResponse.json({ ok: false, error: { code: "REQUEST_FAILED", message: "Research request could not be completed." } }, { status: 500 });
  }
}
