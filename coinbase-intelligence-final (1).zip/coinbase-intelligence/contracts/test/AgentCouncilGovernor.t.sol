// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {AgentCouncilGovernor} from "../src/AgentCouncilGovernor.sol";

interface Vm {
    function prank(address sender) external;
    function warp(uint256 timestamp) external;
}

contract MockGovernanceTimelock {
    uint256 public immutable delay;
    address public governor;
    mapping(bytes32 => uint256) public readyAt;

    constructor(uint256 delay_) { delay = delay_; }
    function setGovernor(address governor_) external { governor = governor_; }
    function getMinDelay() external view returns (uint256) { return delay; }

    function scheduleBatch(address[] calldata targets, uint256[] calldata values, bytes[] calldata payloads, bytes32 predecessor, bytes32 salt, uint256 operationDelay) external {
        require(msg.sender == governor && operationDelay >= delay, "not governor / short delay");
        readyAt[hashOperationBatch(targets, values, payloads, predecessor, salt)] = block.timestamp + operationDelay;
    }

    function executeBatch(address[] calldata targets, uint256[] calldata values, bytes[] calldata payloads, bytes32 predecessor, bytes32 salt) external payable {
        bytes32 operationId = hashOperationBatch(targets, values, payloads, predecessor, salt);
        require(readyAt[operationId] != 0 && block.timestamp >= readyAt[operationId], "not ready");
        delete readyAt[operationId];
        for (uint256 i; i < targets.length; ++i) {
            (bool ok,) = targets[i].call{value: values[i]}(payloads[i]);
            require(ok, "target call failed");
        }
    }

    function hashOperationBatch(address[] calldata targets, uint256[] calldata values, bytes[] calldata payloads, bytes32 predecessor, bytes32 salt) public pure returns (bytes32) {
        return keccak256(abi.encode(targets, values, payloads, predecessor, salt));
    }
}

contract GovernanceTarget {
    uint256 public value;
    function setValue(uint256 value_) external { value = value_; }
}

contract Mock1271Signer {
    bytes32 public expectedDigest;
    function setExpectedDigest(bytes32 digest) external { expectedDigest = digest; }
    function isValidSignature(bytes32 digest, bytes calldata) external view returns (bytes4) {
        return digest == expectedDigest ? bytes4(0x1626ba7e) : bytes4(0xffffffff);
    }
}

contract AgentCouncilGovernorTest {
    Vm private constant vm = Vm(address(uint160(uint256(keccak256("hevm cheat code")))));
    address private constant ALICE = address(0xA11CE);
    address private constant BOB = address(0xB0B);
    address private constant CAROL = address(0xCA701);

    function testThresholdDelayAndExecution() external {
        (AgentCouncilGovernor governor, GovernanceTarget target, MockGovernanceTimelock timelock) = _deploy();
        AgentCouncilGovernor.Action[] memory actions = _action(target, 42);
        uint64 deadline = uint64(block.timestamp + 2 days);
        vm.prank(ALICE);
        uint256 id = governor.createProposal(keccak256("set target to 42"), actions, AgentCouncilGovernor.RiskClass.Operational, deadline);
        vm.prank(ALICE);
        governor.approveProposal(id);
        (AgentCouncilGovernor.Proposal memory waiting,) = governor.getProposal(id);
        require(waiting.status == AgentCouncilGovernor.ProposalStatus.Created, "one approval reached threshold");
        vm.prank(BOB);
        governor.approveProposal(id);
        (AgentCouncilGovernor.Proposal memory approved,) = governor.getProposal(id);
        require(approved.status == AgentCouncilGovernor.ProposalStatus.Approved, "threshold not reached");
        governor.queueProposal(id);
        (AgentCouncilGovernor.Proposal memory queued,) = governor.getProposal(id);
        require(queued.executableAt == block.timestamp + 1 days, "risk delay not applied");
        (bool early,) = address(governor).call(abi.encodeCall(governor.executeProposal, (id)));
        require(!early, "executed before delay");
        vm.warp(queued.executableAt);
        governor.executeProposal(id);
        (AgentCouncilGovernor.Proposal memory executed,) = governor.getProposal(id);
        require(executed.status == AgentCouncilGovernor.ProposalStatus.Executed, "not marked executed");
        require(target.value() == 42, "target state not updated");
        require(address(timelock) != address(0), "timelock missing");
    }

    function testUnknownSelectorRejected() external {
        (AgentCouncilGovernor governor, GovernanceTarget target,) = _deploy();
        AgentCouncilGovernor.Action[] memory actions = new AgentCouncilGovernor.Action[](1);
        actions[0] = AgentCouncilGovernor.Action(address(target), 0, abi.encodeWithSelector(bytes4(0xdeadbeef), uint256(1)));
        vm.prank(ALICE);
        (bool success,) = address(governor).call(abi.encodeCall(governor.createProposal, (keccak256("unknown"), actions, AgentCouncilGovernor.RiskClass.Operational, uint64(block.timestamp + 2 days))));
        require(!success, "unknown selector accepted");
    }

    function testTyped1271ApprovalAndReplayRejection() external {
        GovernanceTarget target = new GovernanceTarget();
        MockGovernanceTimelock timelock = new MockGovernanceTimelock(1 hours);
        Mock1271Signer wallet = new Mock1271Signer();
        address[] memory signers_ = new address[](3);
        uint64[] memory weights = new uint64[](3);
        signers_[0] = address(wallet); signers_[1] = BOB; signers_[2] = CAROL;
        weights[0] = 1; weights[1] = 1; weights[2] = 1;
        address[] memory targets = new address[](1);
        bytes4[] memory selectors = new bytes4[](1);
        targets[0] = address(target); selectors[0] = target.setValue.selector;
        AgentCouncilGovernor governor = new AgentCouncilGovernor(address(timelock), signers_, weights, 2, 3, 1 days, 3 days, 7 days, targets, selectors);
        timelock.setGovernor(address(governor));
        uint64 deadline = uint64(block.timestamp + 2 days);
        vm.prank(BOB);
        uint256 id = governor.createProposal(keccak256("typed wallet approval"), _action(target, 7), AgentCouncilGovernor.RiskClass.Operational, deadline);
        wallet.setExpectedDigest(governor.approvalDigest(id, address(wallet), 0, deadline));
        governor.approveProposalBySig(id, address(wallet), 0, deadline, hex"1234");
        vm.prank(BOB);
        governor.approveProposal(id);
        (AgentCouncilGovernor.Proposal memory proposal,) = governor.getProposal(id);
        require(proposal.status == AgentCouncilGovernor.ProposalStatus.Approved, "ERC1271 approval not counted");
        (bool replay,) = address(governor).call(abi.encodeCall(governor.approveProposalBySig, (id, address(wallet), 0, deadline, bytes(hex"1234"))));
        require(!replay, "signature replay accepted");
    }

    function _deploy() private returns (AgentCouncilGovernor governor, GovernanceTarget target, MockGovernanceTimelock timelock) {
        target = new GovernanceTarget();
        timelock = new MockGovernanceTimelock(1 hours);
        address[] memory signers_ = new address[](3);
        uint64[] memory weights = new uint64[](3);
        signers_[0] = ALICE; signers_[1] = BOB; signers_[2] = CAROL;
        weights[0] = 1; weights[1] = 1; weights[2] = 1;
        address[] memory targets = new address[](1);
        bytes4[] memory selectors = new bytes4[](1);
        targets[0] = address(target); selectors[0] = target.setValue.selector;
        governor = new AgentCouncilGovernor(address(timelock), signers_, weights, 2, 3, 1 days, 3 days, 7 days, targets, selectors);
        timelock.setGovernor(address(governor));
    }

    function _action(GovernanceTarget target, uint256 value) private pure returns (AgentCouncilGovernor.Action[] memory actions) {
        actions = new AgentCouncilGovernor.Action[](1);
        actions[0] = AgentCouncilGovernor.Action(address(target), 0, abi.encodeCall(target.setValue, (value)));
    }
}
