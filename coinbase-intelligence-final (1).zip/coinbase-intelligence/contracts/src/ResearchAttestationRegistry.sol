// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract ResearchAttestationRegistry {
    struct Attestation { bytes32 taskIdHash; bytes32 agentId; bytes32 outputHash; bytes32 evidenceRoot; bytes32 datasetSnapshotHash; uint8 sourceMode; uint64 timestamp; address attestor; }
    mapping(bytes32 => Attestation) private attestations;
    mapping(address => bool) public authorizedAttestors;
    mapping(bytes32 => bool) public taskArtifactUsed;
    address public immutable admin; bool public paused;
    error Unauthorized(); error InvalidHash(); error Duplicate(); error ContractPaused();
    event ResearchAttested(bytes32 indexed receiptId, bytes32 indexed taskIdHash, bytes32 indexed agentId, bytes32 outputHash, address attestor);
    event AttestorAuthorized(address indexed attestor); event AttestorRevoked(address indexed attestor); event Paused(address indexed by); event Unpaused(address indexed by);
    modifier onlyAdmin() { if (msg.sender != admin) revert Unauthorized(); _; } modifier onlyAttestor() { if (!authorizedAttestors[msg.sender]) revert Unauthorized(); _; } modifier whenNotPaused() { if (paused) revert ContractPaused(); _; }
    constructor(address initialAdmin) { if (initialAdmin == address(0)) revert Unauthorized(); admin = initialAdmin; authorizedAttestors[initialAdmin] = true; }
    function setAttestor(address attestor, bool allowed) external onlyAdmin { if (attestor == address(0)) revert Unauthorized(); authorizedAttestors[attestor] = allowed; if (allowed) emit AttestorAuthorized(attestor); else emit AttestorRevoked(attestor); }
    function registerAttestation(bytes32 taskIdHash, bytes32 agentId, bytes32 outputHash, bytes32 evidenceRoot, bytes32 datasetSnapshotHash, uint8 sourceMode) external onlyAttestor whenNotPaused returns (bytes32 receiptId) {
        if (taskIdHash == bytes32(0) || agentId == bytes32(0) || outputHash == bytes32(0)) revert InvalidHash(); receiptId = keccak256(abi.encode(taskIdHash, agentId, outputHash)); if (taskArtifactUsed[receiptId]) revert Duplicate();
        taskArtifactUsed[receiptId] = true; attestations[receiptId] = Attestation(taskIdHash, agentId, outputHash, evidenceRoot, datasetSnapshotHash, sourceMode, uint64(block.timestamp), msg.sender); emit ResearchAttested(receiptId, taskIdHash, agentId, outputHash, msg.sender);
    }
    function getAttestation(bytes32 receiptId) external view returns (bytes32, bytes32, bytes32, bytes32, bytes32, uint8, uint256, address) { Attestation memory a = attestations[receiptId]; return (a.taskIdHash, a.agentId, a.outputHash, a.evidenceRoot, a.datasetSnapshotHash, a.sourceMode, a.timestamp, a.attestor); }
    function pause() external onlyAdmin { paused = true; emit Paused(msg.sender); } function unpause() external onlyAdmin { paused = false; emit Unpaused(msg.sender); }
}
