// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract AgentRegistry {
    struct Agent { address agentWallet; bytes32 capabilityHash; bytes32 metadataHash; bool active; uint64 registeredAt; }
    mapping(bytes32 => Agent) private agents;
    address public immutable admin;
    bool public paused;
    error Unauthorized(); error InvalidAgent(); error InvalidWallet(); error AlreadyRegistered(); error NotRegistered(); error ContractPaused();
    event AgentRegistered(bytes32 indexed agentId, address indexed agentWallet, bytes32 capabilityHash, bytes32 metadataHash);
    event AgentUpdated(bytes32 indexed agentId, address indexed agentWallet, bytes32 capabilityHash, bytes32 metadataHash);
    event AgentDeactivated(bytes32 indexed agentId);
    event Paused(address indexed by); event Unpaused(address indexed by);
    modifier onlyAdmin() { if (msg.sender != admin) revert Unauthorized(); _; }
    modifier whenNotPaused() { if (paused) revert ContractPaused(); _; }
    constructor(address initialAdmin) { if (initialAdmin == address(0)) revert InvalidWallet(); admin = initialAdmin; }
    function registerAgent(bytes32 agentId, address agentWallet, bytes32 capabilityHash, bytes32 metadataHash) external onlyAdmin whenNotPaused {
        if (agentId == bytes32(0)) revert InvalidAgent(); if (agentWallet == address(0)) revert InvalidWallet(); if (agents[agentId].registeredAt != 0) revert AlreadyRegistered();
        agents[agentId] = Agent(agentWallet, capabilityHash, metadataHash, true, uint64(block.timestamp)); emit AgentRegistered(agentId, agentWallet, capabilityHash, metadataHash);
    }
    function updateAgent(bytes32 agentId, address agentWallet, bytes32 capabilityHash, bytes32 metadataHash) external onlyAdmin whenNotPaused {
        if (agentWallet == address(0)) revert InvalidWallet(); if (agents[agentId].registeredAt == 0) revert NotRegistered();
        Agent storage agent = agents[agentId]; agent.agentWallet = agentWallet; agent.capabilityHash = capabilityHash; agent.metadataHash = metadataHash; agent.active = true; emit AgentUpdated(agentId, agentWallet, capabilityHash, metadataHash);
    }
    function deactivateAgent(bytes32 agentId) external onlyAdmin whenNotPaused { if (agents[agentId].registeredAt == 0) revert NotRegistered(); agents[agentId].active = false; emit AgentDeactivated(agentId); }
    function getAgent(bytes32 agentId) external view returns (address, bytes32, bytes32, bool, uint256) { Agent memory agent = agents[agentId]; return (agent.agentWallet, agent.capabilityHash, agent.metadataHash, agent.active, agent.registeredAt); }
    function pause() external onlyAdmin { paused = true; emit Paused(msg.sender); }
    function unpause() external onlyAdmin { paused = false; emit Unpaused(msg.sender); }
}
