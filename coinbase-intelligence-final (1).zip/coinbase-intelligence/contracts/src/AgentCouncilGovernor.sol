// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {EIP712} from "@openzeppelin/contracts/utils/cryptography/EIP712.sol";
import {SignatureChecker} from "@openzeppelin/contracts/utils/cryptography/SignatureChecker.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";

interface IGovernanceTimelock {
    function getMinDelay() external view returns (uint256);
    function scheduleBatch(
        address[] calldata targets,
        uint256[] calldata values,
        bytes[] calldata payloads,
        bytes32 predecessor,
        bytes32 salt,
        uint256 delay
    ) external;
    function executeBatch(
        address[] calldata targets,
        uint256[] calldata values,
        bytes[] calldata payloads,
        bytes32 predecessor,
        bytes32 salt
    ) external payable;
    function hashOperationBatch(
        address[] calldata targets,
        uint256[] calldata values,
        bytes[] calldata payloads,
        bytes32 predecessor,
        bytes32 salt
    ) external pure returns (bytes32);
}

/// @notice Threshold council for tightly allowlisted, delayed configuration changes.
/// @dev This contract never holds tokens. The timelock must grant this contract
///      PROPOSER_ROLE; execution may be permissionless after the timelock delay.
contract AgentCouncilGovernor is EIP712, ReentrancyGuard {
    uint256 public constant MAX_ACTIONS = 10;
    uint256 public constant MIN_APPROVAL_WINDOW = 1 hours;
    uint256 public constant MAX_APPROVAL_WINDOW = 30 days;

    bytes32 private constant APPROVAL_TYPEHASH = keccak256(
        "GovernanceApproval(uint256 proposalId,bytes32 actionsHash,bytes32 descriptionHash,uint8 riskClass,address signer,uint256 signerSetVersion,uint256 nonce,uint256 deadline)"
    );

    enum RiskClass { Operational, Financial, Critical }
    enum ProposalStatus { Created, Approved, Queued, Executed, Rejected, Cancelled, Expired }

    struct CouncilSigner {
        bool active;
        uint64 weight;
        uint64 addedAt;
        uint64 signerVersion;
    }

    struct Action {
        address target;
        uint256 value;
        bytes data;
    }

    struct Proposal {
        bytes32 descriptionHash;
        bytes32 actionsHash;
        address proposer;
        RiskClass riskClass;
        uint64 approvalThreshold;
        uint64 approvalsReceived;
        uint64 rejectionsReceived;
        uint64 createdAt;
        uint64 approvalDeadline;
        uint64 signerSetVersion;
        uint64 scheduledAt;
        uint64 executableAt;
        ProposalStatus status;
        bytes32 operationId;
        bytes32 salt;
    }

    IGovernanceTimelock public immutable timelock;
    uint64 public signerSetVersion = 1;
    uint64 public standardThreshold;
    uint64 public criticalThreshold;
    uint64 public operationalDelay;
    uint64 public financialDelay;
    uint64 public criticalDelay;
    uint256 public totalActiveWeight;
    uint256 public proposalCount;

    mapping(address => CouncilSigner) public signers;
    mapping(address => uint256) public signerNonces;
    mapping(address => mapping(bytes4 => bool)) public allowedSelectors;
    mapping(uint256 => Proposal) private proposals;
    mapping(uint256 => Action[]) private proposalActions;
    mapping(uint256 => mapping(address => bool)) public hasApproved;
    mapping(uint256 => mapping(address => bool)) public hasRejected;

    event ProposalCreated(uint256 indexed proposalId, address indexed proposer, RiskClass riskClass, bytes32 descriptionHash, bytes32 actionsHash, uint64 threshold, uint64 signerSetVersion, uint64 approvalDeadline);
    event ProposalApproved(uint256 indexed proposalId, address indexed signer, uint64 approvalsReceived, uint64 threshold, uint64 signerSetVersion, bool bySignature);
    event ProposalRejected(uint256 indexed proposalId, address indexed signer);
    event ProposalQueued(uint256 indexed proposalId, bytes32 indexed operationId, bytes32 salt, uint64 scheduledAt, uint64 executableAt, uint256 delay);
    event ProposalExecuted(uint256 indexed proposalId, bytes32 indexed operationId);
    event ProposalCancelled(uint256 indexed proposalId, address indexed caller);
    event CouncilSignerUpdated(address indexed signer, bool active, uint64 weight, uint64 signerSetVersion);
    event ThresholdsUpdated(uint64 standardThreshold, uint64 criticalThreshold);
    event RiskDelayUpdated(RiskClass indexed riskClass, uint64 delaySeconds);
    event ActionSelectorUpdated(address indexed target, bytes4 indexed selector, bool allowed);

    error Unauthorized();
    error InvalidConfiguration();
    error InvalidProposal();
    error InvalidAction();
    error ActionNotAllowed(address target, bytes4 selector);
    error AlreadyApproved();
    error ApprovalWindowClosed();
    error ThresholdNotMet();
    error SignerSetChanged();
    error InvalidSignature();
    error TimelockNotReady();
    error InvalidState();

    constructor(
        address timelockAddress,
        address[] memory initialSigners,
        uint64[] memory initialWeights,
        uint64 standardThreshold_,
        uint64 criticalThreshold_,
        uint64 operationalDelay_,
        uint64 financialDelay_,
        uint64 criticalDelay_,
        address[] memory allowedTargets,
        bytes4[] memory allowedFunctionSelectors
    ) EIP712("Coinbase Intelligence Agent Council", "1") {
        if (timelockAddress == address(0) || initialSigners.length == 0 || initialSigners.length != initialWeights.length || allowedTargets.length != allowedFunctionSelectors.length) revert InvalidConfiguration();
        timelock = IGovernanceTimelock(timelockAddress);
        operationalDelay = operationalDelay_;
        financialDelay = financialDelay_;
        criticalDelay = criticalDelay_;
        _validateDelays();
        _setThresholds(standardThreshold_, criticalThreshold_);
        for (uint256 i; i < initialSigners.length; ++i) {
            address signer = initialSigners[i];
            uint64 weight = initialWeights[i];
            if (signer == address(0) || weight == 0 || signers[signer].active || totalActiveWeight + weight > type(uint64).max) revert InvalidConfiguration();
            signers[signer] = CouncilSigner(true, weight, uint64(block.timestamp), signerSetVersion);
            totalActiveWeight += weight;
            emit CouncilSignerUpdated(signer, true, weight, signerSetVersion);
        }
        _validateThresholds();
        for (uint256 i; i < allowedTargets.length; ++i) {
            if (allowedTargets[i] == address(0) || allowedFunctionSelectors[i] == bytes4(0)) revert InvalidConfiguration();
            allowedSelectors[allowedTargets[i]][allowedFunctionSelectors[i]] = true;
            emit ActionSelectorUpdated(allowedTargets[i], allowedFunctionSelectors[i], true);
        }
    }

    modifier onlyTimelock() {
        if (msg.sender != address(timelock)) revert Unauthorized();
        _;
    }

    function createProposal(
        bytes32 descriptionHash,
        Action[] calldata actions,
        RiskClass riskClass,
        uint64 approvalDeadline
    ) external returns (uint256 proposalId) {
        if (descriptionHash == bytes32(0) || actions.length == 0 || actions.length > MAX_ACTIONS) revert InvalidProposal();
        if (!signers[msg.sender].active) revert Unauthorized();
        if (approvalDeadline < block.timestamp + MIN_APPROVAL_WINDOW || approvalDeadline > block.timestamp + MAX_APPROVAL_WINDOW) revert InvalidProposal();
        _validateActions(actions);
        bytes32 actionsHash = keccak256(abi.encode(actions));
        uint64 threshold = riskClass == RiskClass.Critical ? criticalThreshold : standardThreshold;
        if (threshold == 0) revert InvalidConfiguration();
        proposalId = ++proposalCount;
        Proposal storage proposal = proposals[proposalId];
        proposal.descriptionHash = descriptionHash;
        proposal.actionsHash = actionsHash;
        proposal.proposer = msg.sender;
        proposal.riskClass = riskClass;
        proposal.approvalThreshold = threshold;
        proposal.createdAt = uint64(block.timestamp);
        proposal.approvalDeadline = approvalDeadline;
        proposal.signerSetVersion = signerSetVersion;
        proposal.status = ProposalStatus.Created;
        for (uint256 i; i < actions.length; ++i) proposalActions[proposalId].push(actions[i]);
        emit ProposalCreated(proposalId, msg.sender, riskClass, descriptionHash, actionsHash, threshold, signerSetVersion, approvalDeadline);
    }

    function approveProposal(uint256 proposalId) external {
        _approve(proposalId, msg.sender, false);
        signerNonces[msg.sender] += 1;
    }

    function approveProposalBySig(
        uint256 proposalId,
        address signer,
        uint256 nonce,
        uint256 deadline,
        bytes calldata signature
    ) external {
        Proposal storage proposal = _proposalForApproval(proposalId);
        if (deadline < block.timestamp || deadline > proposal.approvalDeadline) revert ApprovalWindowClosed();
        if (signerNonces[signer] != nonce) revert InvalidSignature();
        bytes32 structHash = keccak256(abi.encode(
            APPROVAL_TYPEHASH,
            proposalId,
            proposal.actionsHash,
            proposal.descriptionHash,
            uint8(proposal.riskClass),
            signer,
            proposal.signerSetVersion,
            nonce,
            deadline
        ));
        bytes32 digest = _hashTypedDataV4(structHash);
        if (!SignatureChecker.isValidSignatureNow(signer, digest, signature)) revert InvalidSignature();
        _approve(proposalId, signer, true);
        signerNonces[signer] = nonce + 1;
    }

    function rejectProposal(uint256 proposalId) external {
        Proposal storage proposal = _proposalForApproval(proposalId);
        if (!signers[msg.sender].active) revert Unauthorized();
        if (hasApproved[proposalId][msg.sender] || hasRejected[proposalId][msg.sender]) revert AlreadyApproved();
        hasRejected[proposalId][msg.sender] = true;
        proposal.rejectionsReceived += signers[msg.sender].weight;
        if (proposal.rejectionsReceived >= proposal.approvalThreshold) proposal.status = ProposalStatus.Rejected;
        emit ProposalRejected(proposalId, msg.sender);
    }

    function expireProposal(uint256 proposalId) external {
        Proposal storage proposal = proposals[proposalId];
        if (proposal.proposer == address(0) || proposal.status != ProposalStatus.Created || block.timestamp <= proposal.approvalDeadline) revert InvalidState();
        proposal.status = ProposalStatus.Expired;
    }

    function queueProposal(uint256 proposalId) external nonReentrant returns (bytes32 operationId) {
        Proposal storage proposal = proposals[proposalId];
        if (proposal.status != ProposalStatus.Approved) revert InvalidState();
        if (proposal.signerSetVersion != signerSetVersion) revert SignerSetChanged();
        if (proposal.approvalsReceived < proposal.approvalThreshold) revert ThresholdNotMet();
        Action[] storage actions = proposalActions[proposalId];
        uint256 length = actions.length;
        address[] memory targets = new address[](length);
        uint256[] memory values = new uint256[](length);
        bytes[] memory payloads = new bytes[](length);
        for (uint256 i; i < length; ++i) {
            Action storage action = actions[i];
            _validateAction(action.target, action.value, action.data);
            targets[i] = action.target;
            values[i] = action.value;
            payloads[i] = action.data;
        }
        if (keccak256(abi.encode(actions)) != proposal.actionsHash) revert InvalidProposal();
        uint256 delay = _delayFor(proposal.riskClass);
        uint256 globalDelay = timelock.getMinDelay();
        if (delay < globalDelay) delay = globalDelay;
        bytes32 salt = keccak256(abi.encode(address(this), block.chainid, proposalId, proposal.actionsHash, proposal.signerSetVersion));
        timelock.scheduleBatch(targets, values, payloads, bytes32(0), salt, delay);
        operationId = timelock.hashOperationBatch(targets, values, payloads, bytes32(0), salt);
        proposal.operationId = operationId;
        proposal.salt = salt;
        proposal.scheduledAt = uint64(block.timestamp);
        proposal.executableAt = uint64(block.timestamp + delay);
        proposal.status = ProposalStatus.Queued;
        emit ProposalQueued(proposalId, operationId, salt, proposal.scheduledAt, proposal.executableAt, delay);
    }

    function executeProposal(uint256 proposalId) external nonReentrant {
        Proposal storage proposal = proposals[proposalId];
        if (proposal.status != ProposalStatus.Queued || block.timestamp < proposal.executableAt) revert TimelockNotReady();
        Action[] storage actions = proposalActions[proposalId];
        uint256 length = actions.length;
        address[] memory targets = new address[](length);
        uint256[] memory values = new uint256[](length);
        bytes[] memory payloads = new bytes[](length);
        for (uint256 i; i < length; ++i) {
            _validateAction(actions[i].target, actions[i].value, actions[i].data);
            targets[i] = actions[i].target;
            values[i] = actions[i].value;
            payloads[i] = actions[i].data;
        }
        if (keccak256(abi.encode(actions)) != proposal.actionsHash) revert InvalidProposal();
        if (timelock.hashOperationBatch(targets, values, payloads, bytes32(0), proposal.salt) != proposal.operationId) revert InvalidProposal();
        timelock.executeBatch(targets, values, payloads, bytes32(0), proposal.salt);
        proposal.status = ProposalStatus.Executed;
        emit ProposalExecuted(proposalId, proposal.operationId);
    }

    /// @notice A proposer may withdraw an unqueued proposal; scheduled operations are controlled by the timelock.
    function cancelProposal(uint256 proposalId) external {
        Proposal storage proposal = proposals[proposalId];
        if ((proposal.status != ProposalStatus.Created && proposal.status != ProposalStatus.Approved) || msg.sender != proposal.proposer) revert Unauthorized();
        proposal.status = ProposalStatus.Cancelled;
        emit ProposalCancelled(proposalId, msg.sender);
    }

    function setCouncilSigner(address signer, bool active, uint64 weight) external onlyTimelock {
        if (signer == address(0) || (active && weight == 0) || (!active && weight != 0)) revert InvalidConfiguration();
        ++signerSetVersion;
        CouncilSigner storage current = signers[signer];
        if (current.active) totalActiveWeight -= current.weight;
        if (!active && !current.active) revert InvalidConfiguration();
        if (active && totalActiveWeight + weight > type(uint64).max) revert InvalidConfiguration();
        current.active = active;
        current.weight = weight;
        if (active) totalActiveWeight += weight;
        current.addedAt = active ? uint64(block.timestamp) : current.addedAt;
        current.signerVersion = signerSetVersion;
        _validateThresholds();
        emit CouncilSignerUpdated(signer, active, weight, signerSetVersion);
    }

    function setThresholds(uint64 standardThreshold_, uint64 criticalThreshold_) external onlyTimelock {
        _setThresholds(standardThreshold_, criticalThreshold_);
        _validateThresholds();
        ++signerSetVersion;
    }

    function setRiskDelay(RiskClass riskClass, uint64 delaySeconds) external onlyTimelock {
        if (delaySeconds == 0) revert InvalidConfiguration();
        if (riskClass == RiskClass.Operational) operationalDelay = delaySeconds;
        else if (riskClass == RiskClass.Financial) financialDelay = delaySeconds;
        else criticalDelay = delaySeconds;
        _validateDelays();
        emit RiskDelayUpdated(riskClass, delaySeconds);
    }

    function setAllowedSelector(address target, bytes4 selector, bool allowed) external onlyTimelock {
        if (target == address(0) || selector == bytes4(0)) revert InvalidConfiguration();
        allowedSelectors[target][selector] = allowed;
        emit ActionSelectorUpdated(target, selector, allowed);
    }

    function getProposal(uint256 proposalId) external view returns (Proposal memory proposal, Action[] memory actions) {
        proposal = proposals[proposalId];
        if (proposal.proposer == address(0)) revert InvalidProposal();
        actions = proposalActions[proposalId];
    }

    function approvalDigest(uint256 proposalId, address signer, uint256 nonce, uint256 deadline) external view returns (bytes32) {
        Proposal storage proposal = proposals[proposalId];
        if (proposal.proposer == address(0)) revert InvalidProposal();
        bytes32 structHash = keccak256(abi.encode(APPROVAL_TYPEHASH, proposalId, proposal.actionsHash, proposal.descriptionHash, uint8(proposal.riskClass), signer, proposal.signerSetVersion, nonce, deadline));
        return _hashTypedDataV4(structHash);
    }

    function _approve(uint256 proposalId, address signer, bool bySignature) private {
        Proposal storage proposal = _proposalForApproval(proposalId);
        if (!signers[signer].active) revert Unauthorized();
        if (hasApproved[proposalId][signer] || hasRejected[proposalId][signer]) revert AlreadyApproved();
        hasApproved[proposalId][signer] = true;
        proposal.approvalsReceived += signers[signer].weight;
        if (proposal.approvalsReceived >= proposal.approvalThreshold) proposal.status = ProposalStatus.Approved;
        emit ProposalApproved(proposalId, signer, proposal.approvalsReceived, proposal.approvalThreshold, proposal.signerSetVersion, bySignature);
    }

    function _proposalForApproval(uint256 proposalId) private view returns (Proposal storage proposal) {
        proposal = proposals[proposalId];
        if (proposal.proposer == address(0) || proposal.status != ProposalStatus.Created || block.timestamp > proposal.approvalDeadline) revert ApprovalWindowClosed();
        if (proposal.signerSetVersion != signerSetVersion) revert SignerSetChanged();
    }

    function _validateActions(Action[] calldata actions) private view {
        for (uint256 i; i < actions.length; ++i) _validateAction(actions[i].target, actions[i].value, actions[i].data);
    }

    function _validateAction(address target, uint256 value, bytes memory data) private view {
        if (target == address(0) || target == address(timelock) || value != 0 || data.length < 4) revert InvalidAction();
        bytes4 selector;
        assembly { selector := mload(add(data, 32)) }
        if (!allowedSelectors[target][selector]) revert ActionNotAllowed(target, selector);
    }

    function _setThresholds(uint64 standardThreshold_, uint64 criticalThreshold_) private {
        if (standardThreshold_ == 0 || criticalThreshold_ < standardThreshold_) revert InvalidConfiguration();
        standardThreshold = standardThreshold_;
        criticalThreshold = criticalThreshold_;
        emit ThresholdsUpdated(standardThreshold_, criticalThreshold_);
    }

    function _validateThresholds() private view {
        if (standardThreshold == 0 || criticalThreshold < standardThreshold || criticalThreshold > totalActiveWeight) revert InvalidConfiguration();
    }

    function _validateDelays() private view {
        if (operationalDelay == 0 || financialDelay < operationalDelay || criticalDelay < financialDelay) revert InvalidConfiguration();
    }

    function _delayFor(RiskClass riskClass) private view returns (uint256) {
        if (riskClass == RiskClass.Operational) return operationalDelay;
        if (riskClass == RiskClass.Financial) return financialDelay;
        return criticalDelay;
    }
}
