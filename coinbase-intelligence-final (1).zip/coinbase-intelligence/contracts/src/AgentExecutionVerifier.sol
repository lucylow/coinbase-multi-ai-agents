// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @notice Records outcomes produced by an approved external verifier.
/// Cryptographic RISC Zero verification must use the official verifier integration;
/// this contract intentionally does not reimplement proof cryptography.
contract AgentExecutionVerifier {
    struct Execution { bytes32 taskId; bytes32 agentId; bytes32 inputCommitment; bytes32 outputCommitment; bytes32 imageId; address verifier; uint256 timestamp; address submitter; bool verified; }
    mapping(bytes32 => Execution) public executions; mapping(address => bool) public authorizedVerifiers; mapping(bytes32 => bool) public approvedImages; address public immutable admin; bool public paused;
    error Unauthorized(); error Invalid(); error Duplicate(); error Paused();
    event ImageApproved(bytes32 indexed imageId, bool active); event ExecutionRecorded(bytes32 indexed verificationId, bytes32 indexed taskId, bytes32 indexed agentId, bytes32 imageId, address verifier, bool verified);
    modifier onlyAdmin() { if (msg.sender != admin) revert Unauthorized(); _; } modifier onlyVerifier() { if (!authorizedVerifiers[msg.sender]) revert Unauthorized(); _; } modifier whenNotPaused() { if (paused) revert Paused(); _; }
    constructor(address initialAdmin) { if (initialAdmin == address(0)) revert Invalid(); admin = initialAdmin; authorizedVerifiers[initialAdmin] = true; }
    function setVerifier(address verifier, bool active) external onlyAdmin { if (verifier == address(0)) revert Invalid(); authorizedVerifiers[verifier] = active; }
    function setApprovedImage(bytes32 imageId, bool active) external onlyAdmin { if (imageId == bytes32(0)) revert Invalid(); approvedImages[imageId] = active; emit ImageApproved(imageId, active); }
    function verifyExecution(bytes32 taskId, bytes32 agentId, bytes32 inputCommitment, bytes32 outputCommitment, bytes32 imageId, bool cryptographicVerification) external onlyVerifier whenNotPaused returns (bytes32 verificationId) { if (taskId == bytes32(0) || agentId == bytes32(0) || inputCommitment == bytes32(0) || outputCommitment == bytes32(0) || !approvedImages[imageId] || !cryptographicVerification) revert Invalid(); verificationId = keccak256(abi.encode(taskId, agentId, inputCommitment, outputCommitment, imageId)); if (executions[verificationId].timestamp != 0) revert Duplicate(); executions[verificationId] = Execution(taskId, agentId, inputCommitment, outputCommitment, imageId, msg.sender, block.timestamp, msg.sender, true); emit ExecutionRecorded(verificationId, taskId, agentId, imageId, msg.sender, true); }
    function getExecution(bytes32 verificationId) external view returns (bytes32, bytes32, bytes32, bytes32, bytes32, address, uint256, address, bool) { Execution memory execution = executions[verificationId]; return (execution.taskId, execution.agentId, execution.inputCommitment, execution.outputCommitment, execution.imageId, execution.verifier, execution.timestamp, execution.submitter, execution.verified); }
    function pause() external onlyAdmin { paused = true; } function unpause() external onlyAdmin { paused = false; }
}
