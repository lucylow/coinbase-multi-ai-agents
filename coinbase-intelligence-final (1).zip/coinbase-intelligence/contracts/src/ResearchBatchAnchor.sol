// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

contract ResearchBatchAnchor {
    struct Batch { bytes32 merkleRoot; uint256 leafCount; bytes32 schemaHash; uint256 timestamp; address submitter; }
    mapping(bytes32 => Batch) private batches; mapping(address => bool) public authorizedSubmitters; address public immutable admin; bool public paused;
    error Unauthorized(); error InvalidBatch(); error DuplicateBatch(); error Paused();
    event BatchAnchored(bytes32 indexed batchId, bytes32 indexed merkleRoot, uint256 leafCount, bytes32 schemaHash, address submitter); event BatchSubmitterAuthorized(address indexed submitter); event BatchSubmitterRevoked(address indexed submitter); event BatchVerified(bytes32 indexed batchId, bytes32 indexed leafHash, bool valid);
    modifier onlyAdmin() { if (msg.sender != admin) revert Unauthorized(); _; } modifier onlySubmitter() { if (!authorizedSubmitters[msg.sender]) revert Unauthorized(); _; } modifier whenNotPaused() { if (paused) revert Paused(); _; }
    constructor(address initialAdmin) { if (initialAdmin == address(0)) revert Unauthorized(); admin = initialAdmin; authorizedSubmitters[initialAdmin] = true; }
    function setSubmitter(address submitter, bool allowed) external onlyAdmin { if (submitter == address(0)) revert Unauthorized(); authorizedSubmitters[submitter] = allowed; if (allowed) emit BatchSubmitterAuthorized(submitter); else emit BatchSubmitterRevoked(submitter); }
    function anchorBatch(bytes32 batchId, bytes32 merkleRoot, uint256 leafCount, bytes32 schemaHash) external onlySubmitter whenNotPaused { if (batchId == bytes32(0) || merkleRoot == bytes32(0) || leafCount == 0 || schemaHash == bytes32(0)) revert InvalidBatch(); if (batches[batchId].timestamp != 0) revert DuplicateBatch(); batches[batchId] = Batch(merkleRoot, leafCount, schemaHash, block.timestamp, msg.sender); emit BatchAnchored(batchId, merkleRoot, leafCount, schemaHash, msg.sender); }
    function getBatch(bytes32 batchId) external view returns (bytes32, uint256, bytes32, uint256, address) { Batch memory batch = batches[batchId]; return (batch.merkleRoot, batch.leafCount, batch.schemaHash, batch.timestamp, batch.submitter); }
    function verifyInclusion(bytes32 batchId, bytes32 leafHash, bytes32[] calldata proof) external view returns (bool) { Batch memory batch = batches[batchId]; if (batch.timestamp == 0 || leafHash == bytes32(0)) return false; bytes32 current = leafHash; for (uint256 i = 0; i < proof.length; i++) { bytes32 sibling = proof[i]; current = current < sibling ? keccak256(abi.encodePacked(current, sibling)) : keccak256(abi.encodePacked(sibling, current)); } return current == batch.merkleRoot; }
    function pause() external onlyAdmin { paused = true; } function unpause() external onlyAdmin { paused = false; }
}
