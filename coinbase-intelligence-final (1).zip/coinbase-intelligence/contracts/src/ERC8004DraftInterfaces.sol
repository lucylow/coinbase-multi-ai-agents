// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @notice Interface boundary pinned to ERC-8004 draft as read on 2026-11-06.
/// This file declares interoperability surfaces only; it is not a deployed or
/// complete ERC-8004 implementation. Re-check the EIP before deployment.
interface IERC8004IdentityRegistryDraft {
    struct MetadataEntry { string metadataKey; bytes metadataValue; }
    function register() external returns (uint256 agentId);
    function register(string calldata agentURI) external returns (uint256 agentId);
    function register(string calldata agentURI, MetadataEntry[] calldata metadata) external returns (uint256 agentId);
    function setAgentURI(uint256 agentId, string calldata newURI) external;
    function getAgentWallet(uint256 agentId) external view returns (address);
    function setAgentWallet(uint256 agentId, address newWallet, uint256 deadline, bytes calldata signature) external;
    function unsetAgentWallet(uint256 agentId) external;
    function getMetadata(uint256 agentId, string calldata metadataKey) external view returns (bytes memory);
    function setMetadata(uint256 agentId, string calldata metadataKey, bytes calldata metadataValue) external;
}
interface IERC8004ReputationRegistryDraft {
    function initialize(address identityRegistry_) external;
    function getIdentityRegistry() external view returns (address);
    function giveFeedback(uint256 agentId, int128 value, uint8 valueDecimals, string calldata tag1, string calldata tag2, string calldata endpoint, string calldata feedbackURI, bytes32 feedbackHash) external;
    function revokeFeedback(uint256 agentId, uint64 feedbackIndex) external;
    function appendResponse(uint256 agentId, uint64 feedbackIndex, string calldata responseURI, bytes32 responseHash) external;
}
interface IERC8004ValidationRegistryDraft {
    function validationRequest(address validatorAddress, uint256 agentId, string calldata requestURI, bytes32 requestHash) external;
    function validationResponse(bytes32 requestHash, uint8 response, string calldata responseURI, bytes32 responseHash, string calldata tag) external;
    function getValidationStatus(bytes32 requestHash) external view returns (address validatorAddress, uint256 agentId, uint8 response, bytes32 responseHash, string memory tag, uint256 lastUpdate);
}
