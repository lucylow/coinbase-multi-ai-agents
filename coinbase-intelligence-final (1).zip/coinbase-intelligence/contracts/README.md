# Base Sepolia contracts

This directory contains the Phase 3 testnet-only contract foundation. Deployment is intentionally manual and is not run by the Next.js app.

- `AgentRegistry.sol` stores minimal agent identity hashes and wallet associations.
- `ResearchAttestationRegistry.sol` stores tamper-evident research receipt hashes and allows only approved attestors.
- `AgentCouncilGovernor.sol` is a non-custodial weighted signer council. It binds approvals to proposal/action hashes with EIP-712, validates EOAs/ERC-1271 wallets through OpenZeppelin `SignatureChecker`, restricts actions to explicitly allowed target/selector pairs with zero ETH value, and schedules/executions batches through an externally deployed OpenZeppelin `TimelockController`.

Deploy only to Base Sepolia (`chainId 84532`) after reviewing bytecode and setting an administrator. Never put secrets, prompts, portfolio holdings, or personal information onchain. The application keeps its server-side write kill switch active by default; set `BLOCKCHAIN_WRITE_KILL_SWITCH=false` only in a protected testnet environment with explicit approval flow and contract allowlists.

The existing contracts target Solidity `^0.8.24`; the Foundry profile uses pinned solc 0.8.30, OpenZeppelin Contracts 5.6.1, optimizer + IR pipeline, and Cancun EVM for the new governance dependency. Run `pnpm contracts:check` to compile source and Foundry tests. `contracts/test/AgentCouncilGovernor.t.sol` covers threshold approval, delayed execution, unapproved selectors, ERC-1271 signature acceptance, and signature replay rejection, but Foundry itself is not bundled with this project.

The Governor is not deployed or wired to a TimelockController by this application. Deployment must grant the Governor `PROPOSER_ROLE` on the Timelock; configure only deliberate executors, selectors, and bootstrap self-governance actions. Do not grant unrelated proposers/cancellers, migrate existing contract administrators, transfer assets, or enable mainnet writes. `executeProposal` marks success only after the timelock call returns; independent post-execution state verification and the production deployment/role-recovery scripts remain outstanding.
