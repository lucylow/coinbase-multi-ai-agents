import { describe, expect, it } from "vitest";
import { simulatePolicy } from "@/integrations/coinbase/policy-engine/policy-validator";
import { validateSpendPermission } from "@/integrations/coinbase/spend-permissions/permission-validator";
import { BudgetController, type AgentBudget } from "@/services/treasury/budget-controller";
import { buildMerkleTree, proofFor, verifyProof } from "@/services/blockchain/merkle/merkle-builder";
import { authorizeIntent } from "@/services/blockchain/advanced-authorization-engine";

describe("Phase 4 controlled execution foundations", () => {
  it("fails closed for read-only policy profiles and requires approval for operations", () => {
    expect(simulatePolicy({ profile: "RESEARCH", operation: "sendEvmTransaction", chainId: 84532, userApproved: true }).allowed).toBe(false);
    expect(simulatePolicy({ profile: "BLOCKCHAIN_OPERATIONS", operation: "prepareUserOperation", chainId: 84532, userApproved: false }).allowed).toBe(false);
    expect(simulatePolicy({ profile: "BLOCKCHAIN_OPERATIONS", operation: "prepareUserOperation", chainId: 84532, userApproved: true }).allowed).toBe(true);
  });
  it("rejects expired, revoked, wrong-asset, and over-limit permissions", () => {
    const permission = { id: "p", agentId: "a", smartAccount: "0x0000000000000000000000000000000000000001", network: "base-sepolia" as const, assetAddress: "0x0000000000000000000000000000000000000002", spenderAddress: "0x0000000000000000000000000000000000000003", maximumPerTransaction: "10", maximumTotal: "20", spentTotal: "0", validAfter: "2026-01-01T00:00:00.000Z", validUntil: "2027-01-01T00:00:00.000Z", approved: true, revoked: false, createdAt: "2026-01-01T00:00:00.000Z" };
    expect(validateSpendPermission(permission, { network: "base-sepolia", assetAddress: permission.assetAddress, spenderAddress: permission.spenderAddress, amount: "10", now: "2026-06-01T00:00:00.000Z" }).ok).toBe(true);
    expect(validateSpendPermission({ ...permission, revoked: true }, { network: "base-sepolia", assetAddress: permission.assetAddress, spenderAddress: permission.spenderAddress, amount: "1", now: "2026-06-01T00:00:00.000Z" }).ok).toBe(false);
  });
  it("reserves, idempotently retries, settles, and prevents overspending", () => {
    const budget: AgentBudget = { id: "b", agentId: "a", network: "base-sepolia", assetSymbol: "USDC", maximumPerTransaction: "10", maximumPerDay: "10", maximumPerMonth: "20", spentToday: "0", spentThisMonth: "0", pendingAmount: "0", approvedBy: "owner", validUntil: "2027-01-01T00:00:00.000Z", mode: "simulation", status: "active" };
    const controller = new BudgetController(); const first = controller.reserve(budget, "7", "key"); expect(controller.reserve(budget, "7", "key")).toEqual(first); expect(() => controller.reserve(budget, "4", "other")).toThrow(); controller.settle(budget, "key"); expect(budget.spentToday).toBe("7");
  });
  it("builds and verifies one-leaf, odd, and invalid Merkle proofs", () => {
    const leaves = ["0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "0xbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb", "0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc"] as const;
    const tree = buildMerkleTree([...leaves]); const proof = proofFor(tree, leaves[2]); expect(verifyProof(tree.root, leaves[2], proof)).toBe(true); expect(verifyProof(tree.root, leaves[2], [...proof, leaves[0]])).toBe(false); const single = buildMerkleTree([leaves[0]]); expect(verifyProof(single.root, leaves[0], proofFor(single, leaves[0]))).toBe(true);
  });
  it("blocks expired or incomplete authorization councils", () => {
    const base = { id: "i", taskId: "t", agentId: "a", operation: "REGISTER_RESEARCH", chainId: 84532, walletAddress: "0x0000000000000000000000000000000000000001", contractAddress: "0x0000000000000000000000000000000000000002", functionSelector: "0x12345678", calldataHash: "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" as `0x${string}`, maximumValue: "0", maximumGas: "100000", riskReviewId: "r", approvalRequired: true, expiresAt: "2027-01-01T00:00:00.000Z", status: "draft" as const };
    const council = { requestingAgent: "approved" as const, quantitative: "approved" as const, risk: "approved" as const, security: "approved" as const, verification: "approved" as const };
    expect(authorizeIntent(base, council, { profile: "BLOCKCHAIN_OPERATIONS", operation: "prepareUserOperation", chainId: 84532, userApproved: true }, new Date("2026-06-01T00:00:00.000Z")).ok).toBe(true);
    expect(authorizeIntent({ ...base, expiresAt: "2025-01-01T00:00:00.000Z" }, council, { profile: "BLOCKCHAIN_OPERATIONS", operation: "prepareUserOperation", chainId: 84532, userApproved: true }, new Date("2026-06-01T00:00:00.000Z")).ok).toBe(false);
  });
});
