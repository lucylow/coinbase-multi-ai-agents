import { describe, expect, it } from "vitest";
import type { PortfolioSnapshot } from "@/services/portfolio/portfolio-workspace-manager";
import { runPortfolioXray } from "@/services/portfolio/portfolio-xray";

function snapshot(): PortfolioSnapshot {
  return {
    snapshotId: "s1", providerId: "demo", provider: "demo", portfolioId: "demo-portfolio-01", portfolioName: "Demo", portfolioType: "DEMO", currency: "USD",
    asOf: "2026-11-06T16:00:00.000Z", retrievedAt: "2026-11-06T16:00:00.000Z", totalValueFiat: 250, cashEquivalentFiat: 50,
    positions: [
      { asset: "BTC", quantity: 1, valueFiat: 100, availableToTradeFiat: 100, costBasisFiat: null, averageEntryPrice: null, isCash: false, allocation: 0.4 },
      { asset: "ETH", quantity: 2, valueFiat: 100, availableToTradeFiat: 100, costBasisFiat: null, averageEntryPrice: null, isCash: false, allocation: 0.4 },
      { asset: "USD", quantity: 50, valueFiat: 50, availableToTradeFiat: 50, costBasisFiat: null, averageEntryPrice: null, isCash: true, allocation: 0.2 },
    ],
    coverage: "complete", missingData: [],
  };
}

const product = (productId: string, baseCurrencyId: string, price: string) => ({ productId, baseCurrencyId, quoteCurrencyId: "USD", status: "online", price, tradingDisabled: false });

describe("read-only Coinbase Portfolio X-ray", () => {
  it("fetches spot prices and calculates market-valued allocations while preserving demo labeling", async () => {
    const requested: string[] = [];
    const result = await runPortfolioXray(snapshot(), { getProduct: async (id) => {
      requested.push(id);
      return id === "BTC-USD" ? product(id, "BTC", "120") : product(id, "ETH", "40");
    } }, { retrievedAt: "2026-11-06T16:01:00.000Z" });
    expect(requested.sort()).toEqual(["BTC-USD", "ETH-USD"]);
    expect(result.mode).toBe("demo");
    expect(result.readOnly).toBe(true);
    expect(result.coveredSpotTotalFiat).toBe(250);
    expect(result.positions.find((position) => position.asset === "BTC")?.valueFiat).toBe(120);
    expect(result.positions.find((position) => position.asset === "BTC")?.allocationPct).toBeCloseTo(48);
    expect(result.positions.find((position) => position.asset === "USD")?.price).toBe(1);
    expect(result.coverage).toBe("complete");
  });

  it("uses provider-reported value only as a disclosed fallback when market price is unavailable", async () => {
    const result = await runPortfolioXray(snapshot(), { getProduct: async (id) => {
      if (id === "BTC-USD") return product(id, "BTC", "120");
      throw new Error("product unavailable");
    } });
    const eth = result.positions.find((position) => position.asset === "ETH")!;
    expect(eth.valuationMethod).toBe("provider-reported-value");
    expect(eth.price).toBeNull();
    expect(eth.valueFiat).toBe(100);
    expect(result.coverage).toBe("partial");
    expect(result.warnings.join(" ")).toContain("mixes valuation timestamps/methods");
  });

  it("does not use a mismatched quote currency or invalid/non-online product price", async () => {
    const result = await runPortfolioXray(snapshot(), { getProduct: async (id) => ({ ...product(id, id.split("-")[0], "999"), quoteCurrencyId: "EUR", status: "offline" }) });
    expect(result.positions.find((position) => position.asset === "BTC")?.valuationMethod).toBe("provider-reported-value");
    expect(result.positions.find((position) => position.asset === "BTC")?.valueFiat).toBe(100);
  });
});
