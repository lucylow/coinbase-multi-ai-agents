import { describe, expect, it } from "vitest";
import type { PortfolioSnapshot } from "@/services/portfolio/portfolio-workspace-manager";
import { calculateAdvancedPortfolioMetrics } from "@/services/portfolio/advanced-metrics";

function makeSnapshot(day: number, btc: number, eth: number, cash: number, btcQuantity = 1, ethQuantity = 3): PortfolioSnapshot {
  const total = btc + eth + cash;
  const asOf = new Date(Date.UTC(2026, 0, 1 + day)).toISOString();
  return {
    snapshotId: `snapshot-${day}`,
    providerId: "demo",
    provider: "demo",
    portfolioId: "demo-portfolio-01",
    portfolioName: "Test portfolio",
    portfolioType: "DEMO",
    currency: "USD",
    asOf,
    retrievedAt: asOf,
    totalValueFiat: total,
    cashEquivalentFiat: cash,
    positions: [
      { asset: "BTC", quantity: btcQuantity, valueFiat: btc, availableToTradeFiat: btc, costBasisFiat: null, averageEntryPrice: null, isCash: false, allocation: btc / total },
      { asset: "ETH", quantity: ethQuantity, valueFiat: eth, availableToTradeFiat: eth, costBasisFiat: null, averageEntryPrice: null, isCash: false, allocation: eth / total },
      { asset: "USDC", quantity: cash, valueFiat: cash, availableToTradeFiat: cash, costBasisFiat: null, averageEntryPrice: null, isCash: true, allocation: cash / total },
    ],
    coverage: "complete",
    missingData: [],
  };
}

const regularHistory = [
  makeSnapshot(0, 60, 30, 10),
  makeSnapshot(1, 66, 30, 10),
  makeSnapshot(2, 63, 33, 10),
];
const regularCurrent = makeSnapshot(3, 69, 27, 10);

describe("advanced portfolio metrics", () => {
  it("calculates current exposure, cash, concentration, diversification, and snapshot drift", () => {
    const result = calculateAdvancedPortfolioMetrics(regularCurrent, regularHistory);
    expect(result.totalPortfolioValue).toBe(106);
    expect(result.cashAllocationPct).toBeCloseTo((10 / 106) * 100);
    expect(result.allocations.find((item) => item.asset === "BTC")?.allocationPct).toBeCloseTo((69 / 106) * 100);
    expect(result.assetConcentrationHHI).toBeGreaterThan(0);
    expect(result.concentrationScore).toBeCloseTo(result.assetConcentrationHHI! * 10_000);
    expect(result.effectiveHoldings).toBeCloseTo(1 / result.assetConcentrationHHI!);
    expect(result.largestHoldings[0].asset).toBe("BTC");
    expect(result.allocationDrift.find((item) => item.asset === "BTC")?.changePercentagePoints).toBeCloseTo(((69 - 63) / 106) * 100);
  });

  it("calculates daily/simple/cumulative returns and snapshot-frequency volatility without overclaiming annualization", () => {
    const result = calculateAdvancedPortfolioMetrics(regularCurrent, regularHistory);
    expect(result.dailyChange.referenceAsOf).toBe(makeSnapshot(2, 63, 33, 10).asOf);
    expect(result.dailyChange.amount).toBe(0);
    expect(result.simpleReturnPct).toBe(0);
    expect(result.cumulativeReturnPct).toBeCloseTo(6);
    expect(result.volatilityPct).toBeGreaterThan(0);
    expect(result.annualizedVolatilityPct).toBeNull();
  });

  it("calculates covariance, correlation, and volatility contributions from aligned observations", () => {
    const result = calculateAdvancedPortfolioMetrics(regularCurrent, regularHistory);
    expect(result.historicalCovariance.observationCount).toBe(3);
    expect(result.historicalCovariance.assets).toEqual(["BTC", "ETH", "USDC"]);
    expect(result.historicalCovariance.matrix[0][0]).not.toBeNull();
    expect(result.assetCorrelation.matrix[0][1]).not.toBeNull();
    expect(result.volatilityContributionPct.length).toBe(3);
    expect(result.volatilityContributionPct.reduce((sum, item) => sum + item.contributionPct, 0)).toBeCloseTo(100, 6);
  });

  it("derives asset risk from implied unit-price returns rather than quantity additions", () => {
    const history = [makeSnapshot(0, 60, 30, 10, 1, 3), makeSnapshot(1, 120, 60, 10, 2, 6), makeSnapshot(2, 180, 90, 10, 3, 9)];
    const current = makeSnapshot(3, 240, 120, 10, 4, 12);
    const result = calculateAdvancedPortfolioMetrics(current, history);
    expect(result.historicalCovariance.matrix[0][0]).toBeCloseTo(0, 10);
    expect(result.historicalCovariance.matrix[1][1]).toBeCloseTo(0, 10);
  });

  it("calculates maximum drawdown and recovery duration from dated portfolio values", () => {
    const history = [
      makeSnapshot(0, 60, 30, 10),
      makeSnapshot(1, 72, 36, 12),
      makeSnapshot(2, 54, 27, 9),
      makeSnapshot(3, 66, 33, 11),
    ];
    const current = makeSnapshot(4, 72, 36, 12);
    const result = calculateAdvancedPortfolioMetrics(current, history);
    expect(result.maximumDrawdownPct).toBeCloseTo(25);
    expect(result.recoveredFromMaximumDrawdown).toBe(true);
    expect(result.recoveryTimeDays).toBeCloseTo(3);
  });

  it("calculates annualized volatility and Sharpe only with explicit assumptions and regular sufficient observations", () => {
    const result = calculateAdvancedPortfolioMetrics(regularCurrent, regularHistory, { riskFreeRateAnnual: 0.04, periodsPerYear: 365 });
    expect(result.annualizedVolatilityPct).toBeCloseTo(result.volatilityPct! * Math.sqrt(365));
    expect(Number.isFinite(result.sharpeRatio)).toBe(true);
    expect(result.riskFreeRateAnnual).toBe(0.04);
    expect(result.periodsPerYear).toBe(365);
    const noRate = calculateAdvancedPortfolioMetrics(regularCurrent, regularHistory, { periodsPerYear: 365 });
    expect(noRate.sharpeRatio).toBeNull();
    expect(noRate.sharpeUnavailableReason).toContain("explicit annual risk-free-rate assumption");
  });

  it("withholds historical statistics when there is not enough history and does not infer daily change", () => {
    const result = calculateAdvancedPortfolioMetrics(regularCurrent);
    expect(result.dailyChange.returnPct).toBeNull();
    expect(result.simpleReturnPct).toBeNull();
    expect(result.cumulativeReturnPct).toBeNull();
    expect(result.volatilityPct).toBeNull();
    expect(result.maximumDrawdownPct).toBeNull();
    expect(result.sharpeRatio).toBeNull();
    expect(result.dataWarnings.some((warning) => warning.includes("three distinct"))).toBe(true);
  });

  it("withholds Sharpe when observation cadence is irregular even if assumptions are supplied", () => {
    const irregular = [makeSnapshot(0, 60, 30, 10), makeSnapshot(1, 66, 30, 10), makeSnapshot(4, 63, 33, 10)];
    const result = calculateAdvancedPortfolioMetrics(makeSnapshot(5, 69, 27, 10), irregular, { riskFreeRateAnnual: 0.04, periodsPerYear: 365 });
    expect(result.annualizedVolatilityPct).toBeNull();
    expect(result.sharpeRatio).toBeNull();
    expect(result.sharpeUnavailableReason).toContain("not regular enough");
  });

  it("excludes historical snapshots in a different currency and discloses the gap", () => {
    const otherCurrency = { ...makeSnapshot(2, 63, 33, 10), currency: "EUR" };
    const result = calculateAdvancedPortfolioMetrics(regularCurrent, [otherCurrency]);
    expect(result.historyPointCount).toBe(1);
    expect(result.cumulativeReturnPct).toBeNull();
    expect(result.dataWarnings.join(" ")).toContain("no foreign-exchange normalization");
  });
});
