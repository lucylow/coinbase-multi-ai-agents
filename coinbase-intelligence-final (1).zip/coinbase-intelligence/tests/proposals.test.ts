import { describe, expect, it } from "vitest";
import { balances } from "@/fixtures/demo";
import { simulateAllocation } from "@/services/proposals";

describe("simulation allocation preview", () => {
  it("reduces BTC and credits demo USDC on a sell, net of illustrative fee", () => {
    const btc = balances.find((item) => item.asset === "BTC")!;
    const usdc = balances.find((item) => item.asset === "USDC")!;
    const preview = simulateAllocation(
      {
        productId: "BTC-USD",
        side: "SELL",
        notionalCents: 100_000,
        estimatedFees: "6.00",
      },
      balances,
      Number(btc.price),
    );
    const before = Number(btc.quantity) * Number(btc.price);
    const beforePortfolio = 7_955_950;
    expect(preview.resultingAllocation).toBeLessThan(
      before / (beforePortfolio / 100),
    );
    expect(preview.resultingPortfolioCents).toBe(7_955_350);
    expect(preview.resultingStablecoinCents).toBeGreaterThan(
      Number(usdc.quantity) * 100 - 1,
    );
  });
  it("funds a buy from demo USDC and accounts for its fee", () => {
    const preview = simulateAllocation(
      {
        productId: "ETH-USD",
        side: "BUY",
        notionalCents: 20_000,
        estimatedFees: "1.20",
      },
      balances,
      3450,
    );
    expect(preview.resultingPortfolioCents).toBe(7_955_830);
    expect(preview.resultingStablecoinCents).toBe(229_880);
    expect(preview.resultingAllocation).toBeGreaterThan(1_450_000 / 7_955_950);
  });
});
