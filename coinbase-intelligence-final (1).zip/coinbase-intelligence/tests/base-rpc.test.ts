import { afterEach, describe, expect, it, vi } from "vitest";
import { readChainId, resolveBaseRpcUrl } from "@/integrations/base/base-rpc-service";

afterEach(() => vi.unstubAllGlobals());

describe("Base RPC network boundaries", () => {
  it("uses separate configured endpoints and keeps the legacy endpoint Sepolia-only", () => {
    expect(resolveBaseRpcUrl("base-sepolia", { BASE_RPC_URL: "https://legacy.example" })).toBe("https://legacy.example");
    expect(resolveBaseRpcUrl("base", { BASE_RPC_URL: "https://legacy.example" })).toBe("https://mainnet.base.org");
    expect(resolveBaseRpcUrl("base-sepolia", { BASE_SEPOLIA_RPC_URL: "https://sep.example", BASE_MAINNET_RPC_URL: "https://main.example" })).toBe("https://sep.example");
    expect(resolveBaseRpcUrl("base", { BASE_SEPOLIA_RPC_URL: "https://sep.example", BASE_MAINNET_RPC_URL: "https://main.example" })).toBe("https://main.example");
  });

  it("checks returned chain ID and rejects an endpoint on a different network", async () => {
    const fetchMock = vi.fn(async (_input: RequestInfo | URL, _init?: RequestInit) => new Response(JSON.stringify({ jsonrpc: "2.0", id: 1, result: "0x2105" }), { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);
    await expect(readChainId("base-sepolia", "https://rpc.example")).rejects.toThrow(/RPC chain mismatch/);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const request = fetchMock.mock.calls[0][1];
    expect(request?.method).toBe("POST");
  });

  it("accepts the expected Base Sepolia chain ID", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({ jsonrpc: "2.0", id: 1, result: "0x14a34" }), { status: 200 })));
    await expect(readChainId("base-sepolia", "https://rpc.example")).resolves.toBe(84532);
  });
});
