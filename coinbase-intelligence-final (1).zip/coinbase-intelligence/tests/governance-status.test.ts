import { describe, expect, it } from "vitest";
import { getGovernanceStatus } from "@/services/governance/status";

describe("governance status boundary", () => {
  it("defaults to demo/read-only without configured contracts", () => {
    const status = getGovernanceStatus({});
    expect(status.mode).toBe("demo");
    expect(status.readiness).toBe("read-only-unavailable");
    expect(status.controller.status).toBe("not-configured");
    expect(status.council.signerCount).toBeNull();
    expect(status.execution.submissionsEnabled).toBe(false);
  });

  it("does not treat syntactically valid addresses as verified deployment evidence", () => {
    const status = getGovernanceStatus({ GOVERNANCE_ENABLED: "true", GOVERNANCE_MODE: "testnet", GOVERNANCE_CHAIN_ID: "84532", AGENT_COUNCIL_GOVERNOR_ADDRESS: "0x0000000000000000000000000000000000000001", GOVERNANCE_TIMELOCK_ADDRESS: "0x0000000000000000000000000000000000000002" });
    expect(status.controller.status).toBe("configured-unverified");
    expect(status.chain.verified).toBe(false);
    expect(status.readiness).toBe("configured-awaiting-chain-verification");
    expect(status.execution.testnetWritesEnabled).toBe(false);
  });

  it("rejects unsupported chain configuration and zero addresses", () => {
    const status = getGovernanceStatus({ GOVERNANCE_CHAIN_ID: "1", AGENT_COUNCIL_GOVERNOR_ADDRESS: "0x0000000000000000000000000000000000000000" });
    expect(status.chain.configuredChainId).toBeNull();
    expect(status.controller.status).toBe("invalid-configuration");
    expect(status.execution.mainnetWritesEnabled).toBe(false);
  });
});
