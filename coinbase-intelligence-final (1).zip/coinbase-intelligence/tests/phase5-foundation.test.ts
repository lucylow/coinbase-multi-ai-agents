import { describe, expect, it } from "vitest";
import { validateAgentReference, toAgentRegistryReference } from "@/services/agent-identity/erc8004-adapter";
import { validateRegistrationFile } from "@/services/agent-identity/registration-validator";
import { createValidationRequest, classifyValidation } from "@/services/agent-validation/validation-service";
import { summarizeReputation } from "@/services/agent-reputation/reputation-engine";

describe("Phase 5 ERC-8004 trust network foundations", () => {
  it("never treats an internal UUID as an ERC-8004 token ID", () => {
    expect(toAgentRegistryReference({ chainId: 84532, identityRegistry: "0x0000000000000000000000000000000000000001" })).toBe("eip155:84532:0x0000000000000000000000000000000000000001");
    expect(validateAgentReference({ namespace: "eip155", chainId: 84532, identityRegistry: "0x0000000000000000000000000000000000000001", agentId: "agent-uuid", internalAgentId: "agent-uuid", registrationURI: "ipfs://demo", status: "registered" }).ok).toBe(false);
  });
  it("validates standard registration metadata", () => {
    const valid = { type: "https://eips.ethereum.org/EIPS/eip-8004", name: "Quant Agent", description: "Public research", image: "", services: [{ name: "MCP", endpoint: "https://example.com/mcp", version: "2025-06-18" }], active: true, registrations: [{ agentId: 1, agentRegistry: "eip155:84532:0x0000000000000000000000000000000000000001" }] };
    expect(validateRegistrationFile(valid).ok).toBe(true); expect(validateRegistrationFile({ ...valid, services: [{ name: "unknown", endpoint: "http://bad" }] }).ok).toBe(false);
  });
  it("creates deterministic validation requests and bounds responses", () => {
    const request = createValidationRequest({ agentId: "1", taskId: "task", validatorAddress: "0x0000000000000000000000000000000000000002", requestURI: "ipfs://request", evidenceRefs: ["report:1"], scope: "numerical-reproduction", createdAt: "2026-11-06T00:00:00.000Z" });
    expect(request.requestHash).toMatch(/^0x[0-9a-f]{64}$/); expect(classifyValidation(90, 3)).toBe(3); expect(() => classifyValidation(101, 3)).toThrow();
  });
  it("keeps revoked feedback out of aggregates while retaining evidence limits", () => {
    const base = { agentRegistry: "eip155:84532:0x0000000000000000000000000000000000000001", agentId: "1", value: "90", valueDecimals: 0, tag1: "quality", revoked: false, createdAt: "2026-11-06T00:00:00.000Z" };
    const summary = summarizeReputation([{ ...base, clientAddress: "0x1" }, { ...base, clientAddress: "0x2", value: "80" }, { ...base, clientAddress: "0x3", value: "0", revoked: true }]);
    expect(summary.status).toBe("INSUFFICIENT_EVIDENCE"); expect(summary.average).toBe(85); expect(summary.revokedCount).toBe(1);
  });
});
