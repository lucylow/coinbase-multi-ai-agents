import { describe, expect, it } from "vitest";
import type { MarketProduct } from "@/models/domain";
import { classifyMarketRegime, compareSmaToBuyHold, detectVolumeAnomaly, marketCorrelationMatrix, rollingVolatilityPct } from "@/agents/research-analytics";

function market(productId: string, closes: number[], volumes: number[] = closes.map(() => 10), offset = 0): MarketProduct {
  return { productId, price: closes.at(-1) || 1, change24h: 0, volume24h: 100, volatility: "Moderate", source: "demo", dataAsOf: new Date(Date.UTC(2026, 0, closes.length + offset)).toISOString(), dataQuality: { missingCandles: 0, duplicateCandles: 0, invalidTimestamps: 0 }, candles: closes.map((close, i) => ({ time: new Date(Date.UTC(2026, 0, i + offset + 1)).toISOString(), open: close, high: close * 1.01, low: close * 0.99, close, volume: volumes[i] ?? 10 })) };
}

describe("agent research analytics", () => {
  it("classifies sample regime and surfaces volume relative to a historical median", () => {
    const rising = market("BTC-USD", Array.from({ length: 30 }, (_, i) => 100 + i));
    expect(classifyMarketRegime(rising, 60 * 60 * 1000).trend).toBe("uptrend");
    const anomaly = market("BTC-USD", Array(26).fill(10), [...Array(25).fill(10), 30]);
    expect(detectVolumeAnomaly(anomaly).anomaly).toBe(true);
    const invalidLatest = market("BTC-USD", Array(26).fill(10), [...Array(25).fill(10), Number.NaN]);
    expect(detectVolumeAnomaly(invalidLatest).latestVolume).toBeNull();
    expect(detectVolumeAnomaly(invalidLatest).ratio).toBeNull();
    const rolling = rollingVolatilityPct(rising.candles.map((c) => c.close), 10);
    expect(rolling).toHaveLength(29);
    expect(rolling?.slice(0, 9).every((value) => value === null)).toBe(true);
    expect(rolling?.slice(9).every((value) => value !== null && Number.isFinite(value))).toBe(true);
  });

  it("computes correlations only on common candle timestamps", () => {
    const a = market("BTC-USD", [10, 11, 12, 13, 14]);
    const b = market("ETH-USD", [20, 22, 24, 26, 28]);
    const shifted = market("SOL-USD", [20, 40, 20, 10, 8], undefined, 1);
    const result = marketCorrelationMatrix([a, b, shifted]);
    expect(result.matrix[0][1]).toBeCloseTo(1);
    expect(result.alignedCandleCount).toBe(4);
    expect(result.matrix[0][2]).not.toBe(1);
  });

  it("compares SMA strategy to buy-and-hold using next-bar returns and explicit costs/rate assumptions", () => {
    const prices = Array.from({ length: 80 }, (_, i) => 100 + i + Math.sin(i / 3) * 8);
    const result = compareSmaToBuyHold(prices, { fast: 3, slow: 8, costBpsPerTurn: 10, periodsPerYear: 24 * 365 });
    expect(result.status).toBe("calculated");
    if (result.status === "calculated") {
      expect(result.observations).toBe(80 - 8);
      expect(result.costBpsPerTurn).toBe(10);
      expect(Number.isFinite(result.strategyReturnPct)).toBe(true);
      expect(result.sharpeRatioZeroRiskFree).not.toBeNull();
      expect(result.approximateTwoSidedPValue).not.toBeNull();
    }
    expect(compareSmaToBuyHold([1, 2, 3], { slow: 8 }).status).toBe("insufficient-data");
    expect(() => compareSmaToBuyHold(prices, { costBpsPerTurn: -1 })).toThrow(/non-negative/);
    expect(() => compareSmaToBuyHold(prices, { periodsPerYear: 0 })).toThrow(/periods per year/);
  });
});
