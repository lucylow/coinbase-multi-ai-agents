import { describe, expect, it } from "vitest";
import { GET } from "../app/api/markets/orderbook/route";

describe("public order-book route validation", () => {
  it("rejects malformed product identifiers before making a provider request", async () => {
    const response = await GET(new Request("http://localhost/api/markets/orderbook?productId=not-a-product"));
    expect(response.status).toBe(400);
    expect(await response.json()).toMatchObject({ ok: false });
  });

  it("rejects order-book limits outside the supported range", async () => {
    const response = await GET(new Request("http://localhost/api/markets/orderbook?productId=BTC-USD&limit=100"));
    expect(response.status).toBe(400);
    expect(await response.json()).toMatchObject({ ok: false });
  });
});
