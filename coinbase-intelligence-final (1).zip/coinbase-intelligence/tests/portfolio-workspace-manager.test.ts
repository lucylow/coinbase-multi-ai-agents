import { describe, expect, it } from "vitest";
import type { AdvancedTradePortfolioBreakdown } from "@/integrations/coinbase/advancedTradeProvider";
import {
  comparePortfolioSnapshots,
  createDemoPortfolioSnapshot,
  createConfiguredPortfolioWorkspaceManager,
  normalizeAdvancedTradePortfolioSnapshot,
  PortfolioWorkspaceManager,
  type AuthorizedPortfolio,
  type PortfolioSourceAdapter,
  type PortfolioSnapshot,
} from "@/services/portfolio/portfolio-workspace-manager";

function breakdown(options: { quantity?: number; value?: number; total?: number; missingCost?: boolean; nonSpot?: boolean; portfolioId?: string } = {}): AdvancedTradePortfolioBreakdown {
  const quantity = options.quantity ?? 1;
  const value = options.value ?? 1_000;
  const portfolioId = options.portfolioId || "portfolio-1";
  return {
    portfolio: { uuid: portfolioId, name: "Strategy A", type: "DEFAULT", deleted: false },
    portfolioBalances: {
      totalBalance: { value: String(options.total ?? value), currency: "USD" },
      totalCashEquivalentBalance: { value: "100", currency: "USD" },
    },
    spotPositions: [{
      asset: "BTC",
      accountUuid: "account-1",
      totalBalanceFiat: value,
      totalBalanceCrypto: quantity,
      availableToTradeFiat: value,
      costBasis: options.missingCost ? undefined : { value: "800", currency: "USD" },
      averageEntryPrice: { value: "800", currency: "USD" },
      allocation: 1,
      isCash: false,
    }],
    nonSpotPositionCounts: options.nonSpot ? { perpetuals: 1, futures: 0, predictionMarkets: 0, equities: 0 } : { perpetuals: 0, futures: 0, predictionMarkets: 0, equities: 0 },
  };
}

function source(options: { portfolios?: Array<{ portfolioId: string; name: string; type: string; deleted: boolean }>; response?: AdvancedTradePortfolioBreakdown; onBreakdown?: () => void } = {}): PortfolioSourceAdapter {
  return {
    providerId: "scoped-key-a",
    provider: "coinbase-advanced-trade",
    async listPortfolios() {
      return options.portfolios || [{ portfolioId: "portfolio-1", name: "Strategy A", type: "DEFAULT", deleted: false }];
    },
    async getPortfolioBreakdown() {
      options.onBreakdown?.();
      return options.response || breakdown();
    },
  };
}

const mapping = {
  workspaceId: "research:portfolio-analyst",
  strategyId: "portfolio-analysis",
  providerId: "scoped-key-a",
  portfolioId: "portfolio-1",
  explicitlyConfigured: true as const,
};

describe("portfolio workspace manager", () => {
  it("lists demo and only non-deleted portfolios actually returned by a source", async () => {
    const manager = new PortfolioWorkspaceManager({
      sources: [source({ portfolios: [
        { portfolioId: "portfolio-1", name: "Authorized", type: "DEFAULT", deleted: false },
        { portfolioId: "portfolio-deleted", name: "Deleted", type: "DEFAULT", deleted: true },
      ] })],
    });
    const result = await manager.listAuthorizedPortfolios();
    expect(result.portfolios.map((item) => item.portfolioId)).toEqual(["demo-portfolio-01", "portfolio-1"]);
    expect(result.portfolios.every((item: AuthorizedPortfolio) => item.mode === "demo" || item.mode === "live-read-only")).toBe(true);
  });

  it("requires the explicit live-read opt-in even when server credentials are present", () => {
    const names = ["COINBASE_PORTFOLIO_READS_ENABLED", "COINBASE_ADVANCED_API_KEY_NAME", "COINBASE_ADVANCED_API_PRIVATE_KEY"] as const;
    const previous = Object.fromEntries(names.map((name) => [name, process.env[name]]));
    try {
      process.env.COINBASE_ADVANCED_API_KEY_NAME = "organizations/test/apiKeys/test";
      process.env.COINBASE_ADVANCED_API_PRIVATE_KEY = "placeholder-test-secret";
      delete process.env.COINBASE_PORTFOLIO_READS_ENABLED;
      expect(createConfiguredPortfolioWorkspaceManager().configuredProfileCount()).toBe(0);
      process.env.COINBASE_PORTFOLIO_READS_ENABLED = "true";
      expect(createConfiguredPortfolioWorkspaceManager().configuredProfileCount()).toBe(1);
    } finally {
      for (const name of names) {
        const value = previous[name];
        if (value === undefined) delete process.env[name];
        else process.env[name] = value;
      }
    }
  });

  it("normalizes Coinbase portfolio values, calculates allocation, and marks unsupported positions", () => {
    const snapshot = normalizeAdvancedTradePortfolioSnapshot("scoped-key-a", breakdown({ value: 1_500, total: 2_000, nonSpot: true }));
    expect(snapshot.provider).toBe("coinbase-advanced-trade");
    expect(snapshot.totalValueFiat).toBe(2_000);
    expect(snapshot.positions[0].allocation).toBe(0.75);
    expect(snapshot.positions[0].costBasisFiat).toBe(800);
    expect(snapshot.coverage).toBe("partial");
    expect(snapshot.missingData.join(" ")).toContain("perpetual position");
    expect(snapshot.missingData.join(" ")).toContain("differs from returned spot-position values");
  });

  it("uses demo context when no mapping is configured and live context only for an exact explicit mapping", async () => {
    const sourceAdapter = source();
    const unmapped = await new PortfolioWorkspaceManager({ sources: [sourceAdapter] }).getMappedStrategySnapshot(mapping.workspaceId, mapping.strategyId);
    expect(unmapped.status).toBe("unmapped");
    if (unmapped.status === "unmapped") expect(unmapped.snapshot.provider).toBe("demo");

    const mapped = await new PortfolioWorkspaceManager({ sources: [sourceAdapter], mappings: [mapping] }).getMappedStrategySnapshot(mapping.workspaceId, mapping.strategyId);
    expect(mapped.status).toBe("mapped");
    if (mapped.status === "mapped") {
      expect(mapped.snapshot.portfolioId).toBe("portfolio-1");
      expect(mapped.snapshot.provider).toBe("coinbase-advanced-trade");
      expect(mapped.mapping.explicitlyConfigured).toBe(true);
    }
    const differentWorkspace = await new PortfolioWorkspaceManager({ sources: [sourceAdapter], mappings: [mapping] }).getMappedStrategySnapshot("research:quant", "quant-analysis");
    expect(differentWorkspace.status).toBe("unmapped");
  });

  it("fails closed when a configured mapping is not authorized and does not fetch its breakdown", async () => {
    let breakdownCalls = 0;
    const manager = new PortfolioWorkspaceManager({
      sources: [source({ portfolios: [], onBreakdown: () => { breakdownCalls += 1; } })],
      mappings: [mapping],
    });
    const result = await manager.getMappedStrategySnapshot(mapping.workspaceId, mapping.strategyId);
    expect(result.status).toBe("unavailable");
    expect(breakdownCalls).toBe(0);
  });

  it("detects material quantity changes but does not call pure valuation changes a balance movement", () => {
    const previous = normalizeAdvancedTradePortfolioSnapshot("scoped-key-a", breakdown({ quantity: 1, value: 1_000 }));
    const sameUnits = normalizeAdvancedTradePortfolioSnapshot("scoped-key-a", breakdown({ quantity: 1, value: 1_200, total: 1_200 }));
    const valuationOnly = comparePortfolioSnapshots(previous, sameUnits);
    expect(valuationOnly.portfolioValueChangeFiat).toBe(200);
    expect(valuationOnly.unusualMovements).toEqual([]);

    const increasedUnits = normalizeAdvancedTradePortfolioSnapshot("scoped-key-a", breakdown({ quantity: 1.5, value: 1_500, total: 1_500 }));
    const movement = comparePortfolioSnapshots(previous, increasedUnits);
    expect(movement.unusualMovements.some((item) => item.includes("quantity changed +50.0%"))).toBe(true);
    expect(movement.unusualMovements.join(" ")).toContain("no transfer is inferred");
  });

  it("stores successive snapshots and compares against the prior stored portfolio context", async () => {
    let calls = 0;
    const adapter: PortfolioSourceAdapter = {
      providerId: "scoped-key-a",
      provider: "coinbase-advanced-trade",
      async listPortfolios() { return [{ portfolioId: "portfolio-1", name: "Strategy A", type: "DEFAULT", deleted: false }]; },
      async getPortfolioBreakdown() {
        calls += 1;
        return calls === 1 ? breakdown({ quantity: 1, value: 1_000 }) : breakdown({ quantity: 1.5, value: 1_500, total: 1_500 });
      },
    };
    const manager = new PortfolioWorkspaceManager({ sources: [adapter] });
    const first = await manager.loadSnapshot("scoped-key-a", "portfolio-1");
    const second = await manager.loadSnapshot("scoped-key-a", "portfolio-1");
    expect(second.comparison.previousSnapshotId).toBe(first.snapshot.snapshotId);
    expect(second.comparison.unusualMovements).toHaveLength(1);
  });

  it("treats a position absent from the latest snapshot as missing, not a zero balance", () => {
    const previous = normalizeAdvancedTradePortfolioSnapshot("scoped-key-a", breakdown());
    const current: PortfolioSnapshot = { ...previous, snapshotId: "current", positions: [], totalValueFiat: 0 };
    const result = comparePortfolioSnapshots(previous, current);
    expect(result.positionChanges[0].state).toBe("missing-from-latest");
    expect(result.missingData.join(" ")).toContain("not treated as a confirmed zero balance");
  });

  it("provides a clearly labeled synthetic demo portfolio", () => {
    const snapshot = createDemoPortfolioSnapshot();
    expect(snapshot.provider).toBe("demo");
    expect(snapshot.portfolioId).toBe("demo-portfolio-01");
    expect(snapshot.missingData.join(" ")).toContain("synthetic fixtures");
  });
});
