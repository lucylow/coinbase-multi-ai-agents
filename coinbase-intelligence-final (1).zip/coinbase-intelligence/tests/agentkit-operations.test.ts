import { describe, expect, it } from "vitest";
import { createStrategyResearch, getOperationsCenterStatus, StrategyRequestSchema } from "@/services/defi/operations-center";

describe("AgentKit operations center safety boundary", () => {
  it("reports no provider or protocol facts unless configured", () => {
    const status = getOperationsCenterStatus();
    expect(status.agentKit.status).toBe("not-configured");
    expect(status.actionProviders).toEqual([]);
    expect(status.protocols.every((protocol) => protocol.status === "unverified" && protocol.marketCount === null)).toBe(true);
    expect(status.financialWritesEnabled).toBe(false);
  });

  it("keeps write actions denied across specialist roles", () => {
    const { capabilities } = getOperationsCenterStatus();
    expect(capabilities.find((agent) => agent.agent === "Quantitative Allocator")?.deniedActions).toContain("submit_transaction");
    expect(capabilities.find((agent) => agent.agent === "Independent Auditor")?.deniedActions).toContain("sign_transaction");
  });

  it("rejects malformed objectives and non-simulation requests", () => {
    expect(StrategyRequestSchema.safeParse({ objective: "short", chainId: 84532, simulationOnly: true }).success).toBe(false);
    expect(StrategyRequestSchema.safeParse({ objective: "Compare sourced Base lending markets", chainId: 8453, simulationOnly: false }).success).toBe(false);
    expect(StrategyRequestSchema.safeParse({ objective: "Compare sourced Base lending markets", chainId: 1, simulationOnly: true }).success).toBe(false);
  });

  it("creates a research draft without fabricating rates, allocations, or fees", () => {
    const result = createStrategyResearch({ objective: "Compare verified Base USDC lending opportunities", chainId: 84532, simulationOnly: true });
    expect(result.executionMode).toBe("simulation");
    expect(result.allocations).toEqual([]);
    expect(result.modeledYield).toBeNull();
    expect(result.estimatedFees).toBeNull();
    expect(result.policyDecision.liveExecutionAllowed).toBe(false);
  });
});
