import { describe, expect, it } from "vitest";
import type { Candle } from "@/models/domain";
import {
  calculateMicrostructure,
  createDemoOrderBook,
} from "@/services/market-microstructure";

const candles: Candle[] = [100, 101, 102, 103, 104, 105].map((close, index) => ({
  time: new Date(Date.UTC(2026, 0, 1, index)).toISOString(),
  open: close,
  high: close,
  low: close,
  close,
  volume: 1,
}));

describe("market microstructure analytics", () => {
  it("calculates top-of-book spread, mid, visible depth, imbalance, and estimated spread cost", () => {
    const metrics = calculateMicrostructure(
      {
        productId: "BTC-USD",
        time: "2026-01-01T00:00:00.000Z",
        bids: [
          { price: 99, size: 2 },
          { price: 98, size: 1 },
        ],
        asks: [
          { price: 101, size: 1 },
          { price: 102, size: 3 },
        ],
      },
      candles,
    );
    expect(metrics.bestBid).toBe(99);
    expect(metrics.bestAsk).toBe(101);
    expect(metrics.spread).toBe(2);
    expect(metrics.midPrice).toBe(100);
    expect(metrics.spreadBps).toBe(200);
    expect(metrics.bidDepthBase).toBe(3);
    expect(metrics.askDepthBase).toBe(4);
    expect(metrics.imbalance).toBeCloseTo(-1 / 7);
    expect(metrics.oneWaySpreadCostOn1000).toBe(10);
  });

  it("calculates five-candle momentum and short-window realized volatility descriptively", () => {
    const metrics = calculateMicrostructure(
      { productId: "BTC-USD", bids: [], asks: [], time: "" },
      candles,
    );
    expect(metrics.momentumPct).toBeCloseTo(5);
    expect(metrics.realizedVolPct).toBeGreaterThan(0);
  });

  it("does not invent a spread for missing or crossed quotes", () => {
    const metrics = calculateMicrostructure(
      {
        productId: "BTC-USD",
        time: "",
        bids: [{ price: 101, size: 1 }],
        asks: [{ price: 100, size: 1 }],
      },
      [],
    );
    expect(metrics.spread).toBeNull();
    expect(metrics.midPrice).toBeNull();
    expect(metrics.oneWaySpreadCostOn1000).toBeNull();
  });

  it("labels generated demo depth as synthetic and uses stable levels", () => {
    const first = createDemoOrderBook("BTC-USD", 100, "2026-01-01T00:00:00Z");
    const second = createDemoOrderBook("BTC-USD", 100, "2026-01-01T00:00:00Z");
    expect(first.source).toBe("demo");
    expect(first.bids).toEqual(second.bids);
    expect(first.bids).toHaveLength(10);
    expect(first.asks[0].price).toBeGreaterThan(first.bids[0].price);
  });
});
