import { describe, expect, it } from "vitest";
import type { PortfolioSnapshot } from "@/services/portfolio/portfolio-workspace-manager";
import { alignPortfolioSnapshots, compareCurrentToTargetAllocation, comparePortfolioAllocations } from "@/services/portfolio/portfolio-comparison";

function snapshot(id: string, name: string, asOf: string, positions: PortfolioSnapshot["positions"], currency = "USD"): PortfolioSnapshot {
  return { snapshotId: id, providerId: id.startsWith("demo") ? "demo" : "profile", provider: id.startsWith("demo") ? "demo" : "coinbase-advanced-trade", portfolioId: id, portfolioName: name, portfolioType: "SPOT", currency, asOf, retrievedAt: asOf, totalValueFiat: 100, cashEquivalentFiat: 0, positions, coverage: "complete", missingData: [] };
}
const pos = (asset: string, allocation: number | null) => ({ asset, quantity: 1, valueFiat: allocation === null ? null : allocation * 100, availableToTradeFiat: null, costBasisFiat: null, averageEntryPrice: null, isCash: false, allocation });

describe("portfolio comparison", () => {
  it("aligns to the nearest common-currency observation and breaks ties toward the latest pair", () => {
    const left = [snapshot("l-old", "L", "2026-11-05T12:00:00Z", []), snapshot("l-now", "L", "2026-11-06T12:00:00Z", [])];
    const right = [snapshot("r-old", "R", "2026-11-05T12:02:00Z", []), snapshot("r-now", "R", "2026-11-06T12:03:00Z", [])];
    const result = alignPortfolioSnapshots(left, right)!;
    expect(result.left.snapshotId).toBe("l-old");
    expect(result.right.snapshotId).toBe("r-old");
    expect(result.offsetMilliseconds).toBe(120_000);
  });

  it("explains allocation differences in percentage points without treating missing as zero", () => {
    const left = snapshot("live", "Live", "2026-11-06T12:00:00Z", [pos("BTC", 0.7), pos("ETH", 0.3)]);
    const right = snapshot("demo-1", "Demo", "2026-11-06T12:00:00Z", [pos("BTC", 0.5), pos("SOL", 0.5)]);
    const result = comparePortfolioAllocations(left, right);
    expect(result.differences.find((item) => item.asset === "BTC")?.differencePercentagePoints).toBeCloseTo(20);
    expect(result.differences.find((item) => item.asset === "BTC")?.interpretation).toContain("20.00 percentage points");
    expect(result.differences.find((item) => item.asset === "ETH")?.differencePercentagePoints).toBeNull();
    expect(result.differences.find((item) => item.asset === "ETH")?.interpretation).toContain("not assumed to mean a zero");
  });

  it("withholds allocation comparisons across currencies", () => {
    const result = comparePortfolioAllocations(snapshot("a", "A", "2026-11-06T12:00:00Z", [pos("BTC", 1)]), snapshot("b", "B", "2026-11-06T12:00:00Z", [pos("BTC", 1)], "EUR"));
    expect(result.differences).toEqual([]);
    expect(result.warnings.join(" ")).toContain("no FX conversion");
    expect(alignPortfolioSnapshots([snapshot("a", "A", "2026-11-06T12:00:00Z", [])], [snapshot("b", "B", "2026-11-06T12:00:00Z", [], "EUR")])).toBeNull();
  });

  it("compares target weights and treats absent assets as zero only with complete reported coverage", () => {
    const complete = snapshot("current", "Current", "2026-11-06T12:00:00Z", [pos("BTC", 0.6)]);
    const completeRows = compareCurrentToTargetAllocation(complete, { BTC: 50, ETH: 50 });
    expect(completeRows.find((item) => item.asset === "BTC")?.differencePercentagePoints).toBeCloseTo(10);
    expect(completeRows.find((item) => item.asset === "ETH")?.currentAllocationPct).toBe(0);
    const partial = { ...complete, coverage: "partial" as const };
    const partialEth = compareCurrentToTargetAllocation(partial, { BTC: 50, ETH: 50 }).find((item) => item.asset === "ETH");
    expect(partialEth?.currentAllocationPct).toBeNull();
    expect(partialEth?.differencePercentagePoints).toBeNull();
  });
});
