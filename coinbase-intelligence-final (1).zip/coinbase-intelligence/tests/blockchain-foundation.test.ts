import { describe, expect, it } from "vitest";
import { createResearchHashes, verifyResearchOutput } from "@/services/blockchain/research-hasher";
import { validateBlockchainIntent } from "@/security/blockchain-policy-engine";

describe("blockchain foundation", () => {
  it("creates stable hashes independent of object key order", () => {
    const a = createResearchHashes({ taskId: "task-1", agentId: "quant", output: { z: 2, a: 1 }, evidence: [], datasetSnapshot: { asOf: "2026-01-01" }, sourceMode: "DEMO" });
    const b = createResearchHashes({ taskId: "task-1", agentId: "quant", output: { a: 1, z: 2 }, evidence: [], datasetSnapshot: { asOf: "2026-01-01" }, sourceMode: "DEMO" });
    expect(a.outputHash).toBe(b.outputHash);
    expect(verifyResearchOutput({ a: 1, z: 2 }, a.outputHash)).toBe(true);
  });
  it("rejects malformed or mainnet write intents", () => {
    const result = validateBlockchainIntent({ id: "1", taskId: "t", network: "base-sepolia", chainId: 8453 as 84532, operation: "REGISTER_AGENT", targetContract: "0x0000000000000000000000000000000000000001", functionName: "registerAgent", encodedCallData: "0x", proposedBy: "test", supportingAgents: [], requiresApproval: true, status: "proposed" });
    expect(result.ok).toBe(false);
  });
});
