import { describe, expect, it } from "vitest";
import { SmartAccountManager, type SmartAccountProfile } from "@/integrations/smart-accounts/account-manager";
import { UserOperationManager } from "@/integrations/account-abstraction/user-operation-manager";
import { SpendingLedger } from "@/security/authorization/spending-ledger";
import { AgentTransactionLedger } from "@/services/agent-economy/transaction-ledger";
import { ChainRegistry, canonicalizeToken } from "@/integrations/chains/chain-registry";
import { ReorgAwareIndexer } from "@/services/indexing/reorg-manager";
import { comparePrices, valueBalance } from "@/services/financial-data/valuation";
import { AutomationEngine } from "@/services/automation/automation-engine";

const A = "0x1111111111111111111111111111111111111111" as const;
const B = "0x2222222222222222222222222222222222222222" as const;
const C = "0x3333333333333333333333333333333333333333" as const;
const HASH1 = `0x${"a".repeat(64)}` as `0x${string}`;
const HASH2 = `0x${"b".repeat(64)}` as `0x${string}`;
const profile = (overrides: Partial<SmartAccountProfile> = {}): SmartAccountProfile => ({ accountId: "acc-1", address: A, chainId: 84532, architecture: "erc4337", capabilities: ["user_operation"], isDeployed: false, isVerified: false, authorizationStatus: "unauthorized", status: "discovered", signingMechanism: "account_abstraction", ...overrides });

describe("Phase 11 foundation safety", () => {
  it("keeps account architectures distinct and requires provider identity before readiness", () => {
    expect(() => new SmartAccountManager().discover(profile({ signingMechanism: "eoa_signature" }))).toThrow(/does not match/);
    expect(() => new SmartAccountManager().discover(profile({ isVerified: true, lastVerifiedAt: new Date().toISOString() }))).toThrow(/cannot assert prior verification/);
    const manager = new SmartAccountManager(); manager.discover(profile());
    manager.transition("acc-1", "validated", "Address format passed local validation.");
    expect(() => manager.transition("acc-1", "network_verified", "provider check")).toThrow(/chain ID/);
    manager.transition("acc-1", "network_verified", "provider matched", { verifiedChainId: 84532, verifiedAddress: A });
    expect(manager.get("acc-1")?.isVerified).toBe(true);
    expect(() => manager.transition("acc-1", "permissions_configured", "no approval")).toThrow(/Explicit user authorization/);
    manager.transition("acc-1", "permissions_configured", "user granted scoped permission", { authorizedByUser: true });
    expect(manager.transition("acc-1", "ready", "ready after approval", { authorizedByUser: true }).authorizationStatus).toBe("authorized");
    expect(manager.history()).toHaveLength(5);
  });
  it("does not mark a UserOperation executed without a verified receipt", () => {
    const manager = new UserOperationManager();
    manager.create({ id: "op-1", idempotencyKey: "idem-1", chainId: 84532, sender: A, entryPoint: B, entryPointVersion: "0.7", nonce: "0", callData: "0x1234", expiresAt: new Date(Date.now() + 60_000).toISOString() });
    manager.transition("op-1", "validated", { note: "local checks" }); manager.transition("op-1", "simulated", { note: "simulation passed" }); manager.transition("op-1", "awaiting_approval", { note: "approval needed" });
    expect(() => manager.transition("op-1", "signed", { note: "sign", signature: "0x1234" })).toThrow(/approval/);
    manager.transition("op-1", "signed", { note: "user approved", userApproved: true, signature: "0x1234" }); manager.transition("op-1", "submitted", { note: "bundler accepted", userOpHash: HASH1 });
    manager.transition("op-1", "included", { note: "included" });
    expect(() => manager.transition("op-1", "executed", { note: "assumed success" })).toThrow(/verified on-chain receipt/);
    manager.transition("op-1", "executed", { note: "verified receipt", receipt: { transactionHash: HASH2, success: true, verified: true } });
    expect(manager.get("op-1")?.receiptVerified).toBe(true);
  });
  it("reserves shared authorization budget and requires verified settlement", () => {
    const ledger = new SpendingLedger();
    ledger.register({ authorizationId: "auth-1", agentId: "agent-a", accountId: "acc-1", permissions: ["pay"], allowedNetworks: [84532], allowedContracts: [B], allowedAssets: [A], allowedRecipients: [C], maximumOperationValue: "60", dailyBudget: "100", expiresAt: new Date(Date.now() + 60_000).toISOString(), requiresUserApproval: true, status: "active" });
    const request = { idempotencyKey: "r1", authorizationId: "auth-1", operation: "pay", chainId: 84532, asset: A, contract: B, recipient: C, amount: "60", userApproved: true };
    ledger.reserve(request); expect(ledger.reserve(request).status).toBe("reserved");
    expect(() => ledger.reserve({ ...request, recipient: B })).toThrow(/Idempotency key/);
    expect(() => ledger.reserve({ ...request, idempotencyKey: "wrong-recipient", recipient: B })).toThrow(/Recipient is outside/);
    expect(() => ledger.reserve({ ...request, idempotencyKey: "wrong-operation", operation: "transfer" })).toThrow(/Operation is outside/);
    expect(() => ledger.reserve({ ...request, idempotencyKey: "r2", amount: "41" })).toThrow(/daily budget/);
    expect(() => ledger.settle("r1", "50", { verified: false, transactionHash: HASH2 })).toThrow(/verified transaction receipt/);
    expect(ledger.settle("r1", "50", { verified: true, transactionHash: HASH2 }).status).toBe("settled");
    ledger.revoke("auth-1", "operator requested revocation");
    expect(() => ledger.reserve({ ...request, idempotencyKey: "r3", amount: "1" })).toThrow(/inactive/);
  });
  it("requires verified payment and evidence before an agent settlement", () => {
    const ledger = new AgentTransactionLedger();
    const intent = { intentId: "i1", idempotencyKey: "k1", buyerAgentId: "buyer", sellerAgentId: "seller", serviceId: "svc", requestedOutput: "report", maximumBudget: "100", paymentAsset: A, chainId: 84532, expiresAt: new Date(Date.now() + 60_000).toISOString(), requiresVerification: true, approvalStatus: "approved" as const };
    ledger.create(intent); ledger.transition("i1", "policy_approved", { note: "checks", policyPassed: true, userApproved: true }); ledger.transition("i1", "budget_reserved", { note: "reserve", reservationId: "r1" });
    ledger.transition("i1", "service_completed", { note: "service done" });
    expect(() => ledger.transition("i1", "settled", { note: "pay", payment: { txHash: HASH1, verified: true, amount: "10" } })).toThrow(/Illegal settlement transition/);
    ledger.transition("i1", "evidence_verified", { note: "checked", evidenceHash: HASH2 }); ledger.transition("i1", "payment_simulated", { note: "dry-run only" });
    expect(() => ledger.transition("i1", "settled", { note: "no receipt", payment: { txHash: HASH1, verified: false, amount: "10" } })).toThrow(/verified payment receipt/);
    expect(ledger.transition("i1", "settled", { note: "receipt checked", payment: { txHash: HASH1, verified: true, amount: "10" } }).state).toBe("settled");
  });
  it("uses chain and token address identity, verifies provider chain IDs", () => {
    const registry = new ChainRegistry(); expect(registry.verifyProviderChain(84532, 84532).name).toContain("Sepolia");
    expect(() => registry.verifyProviderChain(84532, 1)).toThrow(/mismatch/);
    expect(canonicalizeToken({ symbol: "USDC", name: "USD Coin", chainId: 84532, contractAddress: A, decimals: 6, verificationStatus: "verified" }).canonicalId).toBe(`eip155:84532/erc20:${A.toLowerCase()}`);
    expect(() => canonicalizeToken({ symbol: "USDC", name: "USD Coin", chainId: 84532, contractAddress: "not-address", decimals: 6, verificationStatus: "verified" })).toThrow(/valid EVM address/);
  });
  it("tracks forks as reorgs and only finalizes by explicit confirmation depth", () => {
    const idx = new ReorgAwareIndexer({ 84532: 2 });
    const block = (number: bigint, hash: string, parentHash: string) => ({ chainId: 84532, number, hash: `0x${hash.repeat(64)}` as `0x${string}`, parentHash: `0x${parentHash.repeat(64)}` as `0x${string}`, observedAt: new Date().toISOString() });
    idx.ingest(block(0n, "0", "f")); idx.ingest(block(1n, "1", "0")); idx.ingest(block(2n, "2", "1"));
    expect(idx.blocks(84532)[0].finalized).toBe(true);
    const fork = idx.ingest(block(2n, "3", "1")); expect(fork.type).toBe("reorg");
    if (fork.type === "reorg") expect(fork.orphaned[0].hash).toBe(`0x${"2".repeat(64)}`);
  });
  it("uses fixed-point valuation and refuses mismatched assets", () => {
    const now = new Date("2026-01-01T00:00:00.000Z");
    const result = valueBalance({ accountId: "a", assetId: "eip155:1/native", quantityBaseUnits: "1500000000000000000", tokenDecimals: 18, sourceId: "rpc", observedAt: now.toISOString() }, { sourceId: "market", assetId: "eip155:1/native", quoteCurrency: "USD", priceMicros: "200000000", timestamp: now.toISOString(), methodology: "trade" }, now);
    expect(result.valueMicros).toBe("300000000"); expect(result.calculationVersion).toBe("fixed-point-v1");
    expect(() => valueBalance({ accountId: "a", assetId: "token-a", quantityBaseUnits: "1", tokenDecimals: 0, sourceId: "rpc", observedAt: now.toISOString() }, { sourceId: "m", assetId: "token-b", quoteCurrency: "USD", priceMicros: "1", timestamp: now.toISOString(), methodology: "oracle" }, now)).toThrow(/same canonical asset/);
    expect(comparePrices([{ sourceId: "a", assetId: "x", quoteCurrency: "USD", priceMicros: "1000000", timestamp: now.toISOString(), methodology: "trade" }, { sourceId: "b", assetId: "x", quoteCurrency: "USD", priceMicros: "1100000", timestamp: now.toISOString(), methodology: "oracle" }]).status).toBe("critical");
  });
  it("deduplicates and bounds automation, rejecting unverified events and financial actions", () => {
    const engine = new AutomationEngine();
    engine.register({ id: "rule", name: "new attestation", eventType: "attestation", conditions: [{ path: "chainId", operator: "eq", value: "84532" }], match: "all", actions: [{ type: "start_research" }], enabled: true, cooldownSeconds: 0, maxExecutions: 1, requiresHumanApproval: false });
    const event = { eventId: "e1", eventType: "attestation", occurredAt: new Date().toISOString(), verified: false, payload: { chainId: 84532 } };
    expect(engine.evaluate(event)[0].status).toBe("rejected"); expect(engine.evaluate(event)[0].status).toBe("duplicate");
    expect(() => engine.register({ id: "bad", name: "bad", eventType: "x", conditions: [{ path: "x", operator: "eq", value: "1" }], match: "all", actions: [{ type: "transfer_funds" as never }], enabled: true, cooldownSeconds: 0, maxExecutions: 1, requiresHumanApproval: false })).toThrow(/Financial actions/);
  });
  it("consumes a human approval exactly once", () => {
    const engine = new AutomationEngine(); engine.register({ id: "approve", name: "approval test", eventType: "verified", conditions: [{ path: "ok", operator: "eq", value: "true" }], match: "all", actions: [{ type: "notify_user" }], enabled: true, cooldownSeconds: 0, maxExecutions: 2, requiresHumanApproval: true });
    const event = { eventId: "event-once", eventType: "verified", occurredAt: new Date().toISOString(), verified: true, payload: { ok: true } };
    expect(engine.evaluate(event)[0].status).toBe("awaiting_approval"); expect(engine.approve("approve", "event-once").status).toBe("executed");
    expect(() => engine.approve("approve", "event-once")).toThrow(/No pending approval/);
  });
});
