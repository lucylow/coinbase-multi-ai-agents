import { describe, expect, it } from "vitest";
import { buildIntegrationHealth, resolveCoinbaseEnvironment } from "@/integrations/coinbase/integration-health";

const successful = {
  marketData: async () => ({ productId: "BTC-USD" }),
  baseRpc: async () => 84532,
  mcp: async () => ({ status: "read-only", authorization: "authorized", capabilities: ["get_market"] }),
};

describe("Coinbase integration health", () => {
  it("defaults to DEMO and never enables trading", () => {
    const environment = resolveCoinbaseEnvironment({});
    expect(environment.mode).toBe("DEMO");
    expect(environment.defaulted).toBe(true);
    expect(environment.tradingEnabled).toBe(false);
  });

  it("falls back to DEMO for unknown or unconfigured SANDBOX modes", () => {
    expect(resolveCoinbaseEnvironment({ COINBASE_ENVIRONMENT: "mystery" })).toMatchObject({ mode: "DEMO", defaulted: true });
    expect(resolveCoinbaseEnvironment({ COINBASE_ENVIRONMENT: "SANDBOX" })).toMatchObject({ mode: "DEMO", defaulted: true });
    expect(resolveCoinbaseEnvironment({ COINBASE_ENVIRONMENT: "SANDBOX", COINBASE_SANDBOX_API_URL: "https://sandbox.example", COINBASE_ADVANCED_TRADE_URL: "https://sandbox.example" }).mode).toBe("SANDBOX");
    expect(resolveCoinbaseEnvironment({ COINBASE_ENVIRONMENT: "SANDBOX", COINBASE_SANDBOX_API_URL: "https://sandbox.example", COINBASE_ADVANCED_TRADE_URL: "https://other.example" }).mode).toBe("DEMO");
  });

  it("does not treat account credential presence as successful authentication", async () => {
    const result = await buildIntegrationHealth({ COINBASE_ENVIRONMENT: "PRODUCTION_READ_ONLY", COINBASE_PORTFOLIO_READS_ENABLED: "true", COINBASE_ADVANCED_API_KEY_NAME: "key-name", COINBASE_ADVANCED_API_PRIVATE_KEY: "secret" }, successful, new Date("2026-11-06T00:00:00Z"));
    expect(result.environment.productionReadOnlyOptIn).toBe(true);
    expect(result.environment.tradingEnabled).toBe(false);
    expect(result.capabilities.advancedTradeRead).toMatchObject({ configured: true, available: null, authenticated: null, lastCheckedAt: null });
    expect(JSON.stringify(result)).not.toContain("secret");
  });

  it("records real public/Base checks and keeps unimplemented services unavailable", async () => {
    const result = await buildIntegrationHealth({ COINBASE_MCP_URL: "https://agents.coinbase.com/mcp" }, successful, new Date("2026-11-06T00:00:00Z"));
    expect(result.capabilities.marketData).toMatchObject({ available: true, authenticated: false, lastSuccessfulCheckAt: "2026-11-06T00:00:00.000Z" });
    expect(result.capabilities.marketData.responseLatencyMs).toEqual(expect.any(Number));
    expect(result.capabilities.baseRpc.available).toBe(true);
    expect(result.capabilities.baseRpc.responseLatencyMs).toEqual(expect.any(Number));
    expect(result.capabilities.mcp).toMatchObject({ available: true, authenticated: true, supportedOperations: ["get_market"] });
    expect(result.capabilities.mcp.responseLatencyMs).toEqual(expect.any(Number));
    expect(result.capabilities.cdpWallet.available).toBeNull();
    expect(result.capabilities.cdpWallet.responseLatencyMs).toBeNull();
    expect(result.capabilities.policyEngine.available).toBe(false);
    expect(result.capabilities.x402Payments.available).toBe(false);
  });

  it("returns actionable generic errors without leaking upstream URLs or credentials", async () => {
    const result = await buildIntegrationHealth({}, {
      marketData: async () => { throw new Error("fetch failed https://secret-user:secret-pass@host/private?token=secret"); },
      baseRpc: async () => { throw new Error("RPC failed https://secret-host"); },
      mcp: async () => ({ status: "not-configured", authorization: "missing" }),
    }, new Date("2026-11-06T00:00:00Z"));
    expect(result.capabilities.marketData.available).toBe(false);
    expect(result.capabilities.marketData.lastError).toContain("Public Coinbase market data health check failed");
    expect(result.capabilities.baseRpc.available).toBe(false);
    expect(JSON.stringify(result)).not.toContain("secret");
  });
});
