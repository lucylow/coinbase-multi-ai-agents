import { describe, expect, it } from "vitest";
import { POST } from "../app/api/proposals/route";

describe("proposal rejection explanations", () => {
  it("returns actionable explanations based on exact rejected policy flags", async () => {
    const response = await POST(new Request("http://local/api/proposals", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: "BTC-USD", side: "BUY", orderType: "MARKET", proposedSize: "100", rationale: "Oversized simulation request" }),
    }));
    const payload = await response.json();
    expect(response.status).toBe(201);
    expect(payload.data.proposal.riskStatus).toBe("rejected");
    expect(payload.data.proposal.rejectionExplanations.length).toBeGreaterThan(0);
    expect(payload.data.proposal.rejectionExplanations.join(" ")).toContain("policy reason supplied");
  });
});
