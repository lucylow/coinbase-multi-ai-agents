import { describe, expect, it } from "vitest";
import { generateKeyPairSync } from "node:crypto";
import { AdvancedTradeRequestError, HttpAdvancedTradeProvider, validateCandles } from "@/integrations/coinbase/advancedTradeProvider";
import { syncPublicMarkets } from "@/integrations/coinbase/marketData";

describe("Advanced Trade normalized market data", () => {
  it("discovers supported pairs, selects available primary products, and preserves source timestamps", async () => {
    const seen: string[] = [];
    const provider = new HttpAdvancedTradeProvider({
      baseUrl: "https://unit.test",
      fetcher: async (input) => {
        const url = new URL(String(input)); seen.push(url.pathname + url.search);
        if (url.pathname.endsWith("/market/products")) return new Response(JSON.stringify({ products: [
          { product_id: "BTC-USD", base_currency_id: "BTC", quote_currency_id: "USD", status: "online" },
          { product_id: "ETH-USD", base_currency_id: "ETH", quote_currency_id: "USD", status: "online" },
          { product_id: "USDC-USD", base_currency_id: "USDC", quote_currency_id: "USD", status: "offline" },
          { product_id: "ABC-USD", base_currency_id: "ABC", quote_currency_id: "USD", status: "online" },
        ] }), { status: 200 });
        if (url.pathname.endsWith("/candles")) return new Response(JSON.stringify({ candles: [
          { start: "1793901600", open: "10", high: "12", low: "9", close: "11", volume: "2" },
          { start: "1793908800", open: "11", high: "13", low: "10", close: "12", volume: "3" },
        ] }), { status: 200 });
        return new Response(JSON.stringify({ product: { product_id: url.pathname.split("/").at(-1), base_currency_id: "BTC", quote_currency_id: "USD", status: "online", price: "12" } }), { status: 200 });
      },
    });
    const result = await syncPublicMarkets({ provider, now: new Date("2026-11-05T13:00:00Z"), granularity: "TWO_HOUR", start: "2026-11-05T00:00:00Z" });
    expect(result.mode).toBe("live-read-only");
    expect(result.markets.map((market) => market.productId)).toContain("ABC-USD");
    expect(result.markets.map((market) => market.productId)).not.toContain("USDC-USD");
    expect(result.markets[0].candles[0].sourceTimestamp).toBe("1793901600");
    expect(result.markets[0].candles[0].time.endsWith("Z")).toBe(true);
    expect(result.granularity).toBe("TWO_HOUR");
    expect(seen.some((path) => path.includes("granularity=TWO_HOUR"))).toBe(true);
    expect(result.unavailableProducts).toContain("USDC-USD");
  });

  it("rejects duplicate timestamps instead of silently merging them", () => {
    const candle = { timestamp: "2026-11-05T00:00:00.000Z", sourceTimestamp: "1793836800", open: 1, high: 2, low: 1, close: 1.5, volume: 1 };
    expect(() => validateCandles([candle, candle])).toThrow(/Duplicate Coinbase candle timestamp/);
  });

  it("implements public book, best-bid-ask and trades with numeric normalization", async () => {
    const { privateKey } = generateKeyPairSync("ed25519");
    const provider = new HttpAdvancedTradeProvider({ baseUrl: "https://unit.test", credentials: { keyName: "organizations/test/apiKeys/test", privateKey: privateKey.export({ type: "pkcs8", format: "pem" }).toString() }, fetcher: async (input) => {
      const url = String(input);
      if (url.includes("product_book?")) return new Response(JSON.stringify({ pricebook: { product_id: "BTC-USD", time: "2026-11-05T12:00:00Z", bids: [{ price: "100", size: "2" }], asks: [{ price: "101", size: "3" }] } }), { status: 200 });
      if (url.includes("best_bid_ask")) return new Response(JSON.stringify({ pricebooks: [{ product_id: "BTC-USD", bids: [{ price: "100" }], asks: [{ price: "101" }] }] }), { status: 200 });
      return new Response(JSON.stringify({ trades: [{ trade_id: "1", price: "100.5", size: "0.1", side: "BUY", time: "2026-11-05T12:00:00Z" }] }), { status: 200 });
    } });
    const book = await provider.getProductBook("BTC-USD");
    const top = await provider.getBestBidAsk(["BTC-USD"]);
    const trades = await provider.getMarketTrades("BTC-USD");
    expect(book.bids[0].price).toBe(100);
    expect(top[0].ask).toBe(101);
    expect(trades[0].price).toBe(100.5);
    expect(trades[0].sourceTimestamp).toBe("2026-11-05T12:00:00Z");
  });

  it("retries a transient rate limit once and returns a sanitized typed error for terminal authorization failures", async () => {
    let attempts = 0;
    const retrying = new HttpAdvancedTradeProvider({ baseUrl: "https://unit.test", fetcher: async () => {
      attempts += 1;
      if (attempts === 1) return new Response("", { status: 429, headers: { "retry-after": "0" } });
      return new Response(JSON.stringify({ product: { product_id: "BTC-USD", status: "online" } }), { status: 200 });
    } });
    expect((await retrying.getProduct("BTC-USD")).productId).toBe("BTC-USD");
    expect(attempts).toBe(2);

    attempts = 0;
    const longWait = new HttpAdvancedTradeProvider({ baseUrl: "https://unit.test", fetcher: async () => {
      attempts += 1;
      return new Response("", { status: 429, headers: { "retry-after": "5" } });
    } });
    await expect(longWait.getProduct("BTC-USD")).rejects.toMatchObject({ status: 429, code: "RATE_LIMITED" });
    expect(attempts).toBe(1);

    attempts = 0;
    const forbidden = new HttpAdvancedTradeProvider({ baseUrl: "https://unit.test", fetcher: async () => {
      attempts += 1;
      return new Response(JSON.stringify({ message: "secret account context" }), { status: 403 });
    } });
    let error: unknown;
    try { await forbidden.getProduct("BTC-USD"); } catch (caught) { error = caught; }
    expect(error).toBeInstanceOf(AdvancedTradeRequestError);
    expect(error).toMatchObject({ name: "AdvancedTradeRequestError", status: 403, code: "UPSTREAM_4XX" });
    expect((error as Error).message).not.toContain("secret");
    expect(attempts).toBe(1);
  });
});
