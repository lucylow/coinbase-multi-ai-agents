import { describe, expect, it } from "vitest";
import { commitmentHash, createPrivateInputCommitment, selectiveDisclosure } from "@/services/verifiable-compute/commitments";
import { concentrationCompliance, drawdownCompliance, milestoneCompliance } from "@/services/verifiable-compute/workloads";
import { canClaimCryptographicVerification, createDemoReceipt } from "@/services/verifiable-compute/receipts";
import { DemoTeeProvider } from "@/integrations/tee/provider-interface";

describe("Phase 7 verifiable compute foundation", () => {
  it("creates salted, domain-separated commitments and selective disclosure", () => {
    expect(() => commitmentHash({ balance: "1" }, "short", "portfolio-v1")).toThrow();
    const commitment = createPrivateInputCommitment({ balance: "100" }, "portfolio-v1", "authorized-account-read", "a".repeat(32), "c1");
    expect(commitment.inputHash).toMatch(/^0x[0-9a-f]{64}$/); expect(selectiveDisclosure({ pass: true, secret: "hidden" }, ["pass"])).toEqual({ pass: true });
  });
  it("uses integer fixed-point compliance workloads", () => {
    expect(concentrationCompliance(["60", "40"], 6000, "input").passed).toBe(true); expect(concentrationCompliance(["61", "39"], 6000, "input").passed).toBe(false); expect(drawdownCompliance("100", "80", 2000, "input").passed).toBe(true); expect(milestoneCompliance(true, true, false, "input").passed).toBe(false);
  });
  it("never labels a demo receipt as cryptographically verified", () => {
    const receipt = createDemoReceipt({ id: "r", taskId: "t", agentId: "a", programId: "p", programVersion: "1", imageId: "image", inputCommitment: "0x01", outputCommitment: "0x02", journalHash: "0x03", receiptHash: "0x04" }); expect(receipt.verificationStatus).toBe("unavailable"); expect(canClaimCryptographicVerification(receipt)).toBe(false);
  });
  it("rejects demo TEE evidence and checks binding/freshness", async () => { const provider = new DemoTeeProvider(); const result = await provider.verify({ provider: "demo", documentHash: "0x01", workloadMeasurement: "demo", taskId: "task", inputCommitment: "in", outputCommitment: "out", nonce: "n", issuedAt: "2026-11-06T00:00:00.000Z" }, { taskId: "task", inputCommitment: "in", outputCommitment: "out", nonce: "n", now: new Date("2026-11-06T00:01:00.000Z") }); expect(result.verified).toBe(false); expect(result.reasons[0]).toContain("Demo TEE"); });
});
