import { describe, expect, it } from "vitest";
import { portfolioAnalyst } from "@/agents/specialists";
import { createDemoPortfolioSnapshot, getConfiguredPortfolioWorkspaceManager } from "@/services/portfolio/portfolio-workspace-manager";

describe("Portfolio Analyst v2", () => {
  it("decomposes concentration, reports position/scenario exposure, and compares an explicit peer snapshot", async () => {
    const context = await getConfiguredPortfolioWorkspaceManager().getMappedStrategySnapshot("test-workspace", "test-strategy");
    expect(context.status).toBe("unmapped");
    if (context.status === "unavailable") return;
    const peerBase = createDemoPortfolioSnapshot();
    const peer = {
      ...peerBase,
      snapshotId: "peer-snapshot",
      providerId: "authorized-peer",
      provider: "coinbase-advanced-trade" as const,
      portfolioId: "peer-portfolio",
      portfolioName: "Authorized peer",
      positions: peerBase.positions.map((position) => position.asset === "BTC" ? { ...position, allocation: (position.allocation || 0) * 0.8 } : position),
    };
    const finding = await portfolioAnalyst("task-v2", "Compare these portfolios", context, [peer]);
    expect(finding.agentId).toBe("portfolio-analyst");
    expect(finding.findings.join(" ")).toContain("HHI decomposition by asset");
    expect(finding.findings.join(" ")).toContain("Position exposure:");
    expect(finding.findings.join(" ")).toContain("Illustrative single-factor scenario");
    expect(finding.findings.join(" ")).toContain("Authorized portfolio comparison: Authorized peer");
    expect(finding.metrics?.multiPortfolioComparisonCount).toBe(1);
    expect(finding.toolTrace?.some((trace) => trace.toolId === "authorized-portfolio-comparison")).toBe(true);
  });
});
