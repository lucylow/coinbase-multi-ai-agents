import { describe, expect, it } from "vitest";
import { generateKeyPairSync } from "node:crypto";
import { HttpAdvancedTradeProvider } from "@/integrations/coinbase/advancedTradeProvider";

describe("Coinbase Advanced Trade portfolio reads", () => {
  it("uses the official read-only list and breakdown routes and normalizes positions", async () => {
    const { privateKey } = generateKeyPairSync("ed25519");
    const requests: Array<{ url: string; authorization: string | null }> = [];
    const provider = new HttpAdvancedTradeProvider({
      baseUrl: "https://unit.test",
      credentials: {
        keyName: "organizations/test/apiKeys/test",
        privateKey: privateKey.export({ type: "pkcs8", format: "pem" }).toString(),
      },
      fetcher: async (input, init) => {
        const url = new URL(String(input));
        requests.push({ url: url.pathname + url.search, authorization: new Headers(init?.headers).get("authorization") });
        if (url.pathname === "/api/v3/brokerage/portfolios") {
          return new Response(JSON.stringify({ portfolios: [
            { uuid: "portfolio-1", name: "Strategy A", type: "DEFAULT", deleted: false },
            { uuid: "portfolio-deleted", name: "Deleted", type: "DEFAULT", deleted: true },
          ] }), { status: 200 });
        }
        return new Response(JSON.stringify({ breakdown: {
          portfolio: { uuid: "portfolio-1", name: "Strategy A", type: "DEFAULT", deleted: false },
          portfolio_balances: {
            total_balance: { value: "1500.00", currency: "USD" },
            total_cash_equivalent_balance: { value: "100.00", currency: "USD" },
          },
          spot_positions: [{
            asset: "BTC",
            account_uuid: "account-1",
            total_balance_fiat: 1400,
            total_balance_crypto: 0.035,
            available_to_trade_fiat: 1300,
            allocation: 0.9333,
            cost_basis: { value: "1200.00", currency: "USD" },
            average_entry_price: { value: "34285.71", currency: "USD" },
            is_cash: false,
          }],
          perp_positions: [{}],
          futures_positions: [],
          prediction_markets_positions: [],
          equity_positions: [],
        } }), { status: 200 });
      },
    });

    const portfolios = await provider.listPortfolios();
    const snapshot = await provider.getPortfolioBreakdown("portfolio-1", "USD");
    expect(portfolios.map((portfolio) => portfolio.uuid)).toEqual(["portfolio-1", "portfolio-deleted"]);
    expect(snapshot.portfolio.uuid).toBe("portfolio-1");
    expect(snapshot.portfolioBalances.totalBalance?.value).toBe("1500.00");
    expect(snapshot.spotPositions[0]).toMatchObject({ asset: "BTC", totalBalanceFiat: 1400, totalBalanceCrypto: 0.035, costBasis: { value: "1200.00", currency: "USD" } });
    expect(snapshot.nonSpotPositionCounts.perpetuals).toBe(1);
    expect(requests.map((request) => request.url)).toContain("/api/v3/brokerage/portfolios");
    expect(requests.some((request) => request.url === "/api/v3/brokerage/portfolios/portfolio-1?currency=USD")).toBe(true);
    expect(requests.every((request) => request.authorization?.startsWith("Bearer "))).toBe(true);
  });

  it("does not send authenticated portfolio requests without credentials", async () => {
    const provider = new HttpAdvancedTradeProvider({ baseUrl: "https://unit.test", fetcher: async () => new Response("{}", { status: 200 }) });
    await expect(provider.listPortfolios()).rejects.toThrow(/credentials/);
    await expect(provider.getPortfolioBreakdown("portfolio-1")).rejects.toThrow(/credentials/);
  });
});
