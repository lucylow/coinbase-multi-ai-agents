export interface AdvancedTradeProduct {
  productId: string;
  baseCurrencyId: string;
  quoteCurrencyId: string;
  status: string;
}

/** Normalized internal data shapes; this unconfigured adapter does not parse undocumented responses. */
export interface AdvancedTradeCandle {
  timestamp: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface AdvancedTradeAccount {
  accountId: string;
  currency: string;
  availableBalance: string;
  holdBalance: string;
}

export interface AdvancedTradeProvider {
  getProduct(productId: string): Promise<AdvancedTradeProduct>;
  getPublicCandles(
    productId: string,
    start: string,
    end: string,
    granularity: string,
  ): Promise<AdvancedTradeCandle[]>;
  getAccounts(): Promise<AdvancedTradeAccount[]>;
}

/** Authentication and verified endpoint implementations are intentionally separate from MCP. */
export class UnconfiguredAdvancedTradeProvider
  implements AdvancedTradeProvider
{
  private unavailable(): never {
    throw new Error(
      "Advanced Trade API is not configured; no request was sent.",
    );
  }
  async getProduct(_productId: string): Promise<AdvancedTradeProduct> {
    return this.unavailable();
  }
  async getPublicCandles(
    _productId: string,
    _start: string,
    _end: string,
    _granularity: string,
  ): Promise<AdvancedTradeCandle[]> {
    return this.unavailable();
  }
  async getAccounts(): Promise<AdvancedTradeAccount[]> {
    return this.unavailable();
  }
}
