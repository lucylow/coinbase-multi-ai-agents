import type { PortfolioBalance, TradeProposal } from "@/models/domain";
import { DEMO_AS_OF } from "@/fixtures/demo";
import { multiplyToCents, portfolioMetrics } from "./analytics";

const SUPPORTED_PRODUCTS = new Set([
  "BTC-USD",
  "ETH-USD",
  "SOL-USD",
  "USDC-USD",
]);
const MAX_NOTIONAL_CENTS = 500_000;
const MAX_MARKET_AGE_MS = 48 * 60 * 60 * 1000;

export interface PolicyResult {
  allowedForSimulation: boolean;
  checks: string[];
  riskFlags: string[];
  notionalCents: number;
}

export function evaluateProposal(
  input: Pick<
    TradeProposal,
    "productId" | "side" | "orderType" | "proposedSize" | "proposedPrice"
  >,
  portfolio: PortfolioBalance[],
  dataAsOf = DEMO_AS_OF,
): PolicyResult {
  const checks: string[] = [];
  const riskFlags: string[] = [];
  let notionalCents = 0;
  const size = Number(input.proposedSize);
  if (!SUPPORTED_PRODUCTS.has(input.productId))
    riskFlags.push("Unsupported product");
  if (input.side !== "BUY" && input.side !== "SELL")
    riskFlags.push("Unsupported side");
  if (input.orderType !== "MARKET" && input.orderType !== "LIMIT")
    riskFlags.push("Unsupported order type");
  if (!Number.isFinite(size) || size <= 0)
    riskFlags.push("Size must be a positive finite amount");
  if (!/^\d+(?:\.\d{1,8})?$/.test(input.proposedSize))
    riskFlags.push("Amount precision exceeds 8 decimal places");
  if (
    input.orderType === "LIMIT" &&
    (!input.proposedPrice ||
      !Number.isFinite(Number(input.proposedPrice)) ||
      Number(input.proposedPrice) <= 0)
  )
    riskFlags.push("Limit order requires a positive finite price");
  if (input.proposedPrice && !/^\d+(?:\.\d{1,8})?$/.test(input.proposedPrice))
    riskFlags.push("Price precision exceeds 8 decimal places");

  const asset = input.productId.split("-")[0];
  const balance = portfolio.find((item) => item.asset === asset);
  const price = input.proposedPrice || balance?.price;
  if (balance && price && Number.isFinite(size) && size > 0) {
    try {
      notionalCents = multiplyToCents(input.proposedSize, price);
    } catch {
      riskFlags.push("Amount precision or value is invalid");
    }
  } else if (!balance) {
    riskFlags.push("No supported demo market price is available");
  }

  if (notionalCents > MAX_NOTIONAL_CENTS)
    riskFlags.push("Proposal exceeds the $5,000 simulation limit");
  if (input.side === "BUY" && asset !== "USDC" && notionalCents > 0) {
    const availableCents =
      portfolioMetrics(portfolio).rows.find((row) => row.asset === "USDC")
        ?.valueCents ?? 0;
    const illustrativeFeeCents = Math.round(notionalCents * 0.006);
    if (notionalCents + illustrativeFeeCents > availableCents)
      riskFlags.push(
        "Insufficient demo USDC for notional and illustrative fee",
      );
  }
  const age = Date.now() - Date.parse(dataAsOf);
  if (!Number.isFinite(age) || age < 0 || age > MAX_MARKET_AGE_MS)
    riskFlags.push("Market data is stale");
  const metrics = portfolioMetrics(portfolio);
  const topAllocation = Math.max(...metrics.rows.map((row) => row.allocation));
  if (topAllocation > 0.85) riskFlags.push("Hard concentration limit exceeded");
  else if (topAllocation > 0.65)
    riskFlags.push("Elevated portfolio concentration requires review");
  if (input.side === "SELL" && balance && size > Number(balance.quantity))
    riskFlags.push("Sell size exceeds available demo balance");

  checks.push(
    "Demo mode: no external financial writes",
    "Product allowlist verified",
    "Positive finite amount checked",
    "Proposal limit evaluated",
    "Market snapshot provenance: synthetic fixture",
    "Concentration policy evaluated",
  );
  const hardStop = riskFlags.some(
    (flag) =>
      flag === "Unsupported product" ||
      flag.startsWith("Size must") ||
      flag.startsWith("Amount precision") ||
      flag.startsWith("Price precision") ||
      flag.startsWith("Limit order") ||
      flag.startsWith("Proposal exceeds") ||
      flag.startsWith("Hard concentration") ||
      flag.startsWith("Sell size") ||
      flag.startsWith("Insufficient demo USDC"),
  );
  return { allowedForSimulation: !hardStop, checks, riskFlags, notionalCents };
}

export function liveExecutionAllowed(): false {
  return false;
}
