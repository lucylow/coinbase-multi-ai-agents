import type { AgentTask, AuditEvent, TradeProposal } from "@/models/domain";

const KEYS = {
  tasks: "coinintel.tasks.v1",
  proposals: "coinintel.proposals.v1",
  audit: "coinintel.audit.v1",
} as const;

function read<T>(key: string): T[] {
  try {
    const value: unknown = JSON.parse(window.localStorage.getItem(key) || "[]");
    return Array.isArray(value) ? (value as T[]) : [];
  } catch {
    return [];
  }
}
function write<T>(key: string, value: T[]): void {
  window.localStorage.setItem(key, JSON.stringify(value));
}

export const loadTasks = () => read<AgentTask>(KEYS.tasks);
export const loadProposals = () => read<TradeProposal>(KEYS.proposals);
export const loadAudit = () => read<AuditEvent>(KEYS.audit);
export const saveTasks = (items: AgentTask[]) => write(KEYS.tasks, items);
export const saveProposals = (items: TradeProposal[]) =>
  write(KEYS.proposals, items);
export const saveAudit = (items: AuditEvent[]) => write(KEYS.audit, items);
export function resetDemoState(): void {
  Object.values(KEYS).forEach((key) => window.localStorage.removeItem(key));
}
